@echo off
echo Leave blank to auto-generate a test Android project, or enter the path to your ORIGINAL Karlivery project (keeps app ID + signing).
set /p ORIG=Original project path (optional): 
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD_RELEASE.ps1" -Target apk -OriginalAndroidProject "%ORIG%"
pause
