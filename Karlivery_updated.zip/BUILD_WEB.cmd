@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD_RELEASE.ps1" -Target web
pause
