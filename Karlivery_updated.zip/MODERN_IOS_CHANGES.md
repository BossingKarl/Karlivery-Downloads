# Karlivery — Modern iOS UI refinement

This release extends the previous Flutter source. It is not a complete visual recreation of the 10-screen concept.

## Implemented
- Added photo-first KIOSRestaurantCard with dynamic image, title, metadata and optional badge.
- Added KIOSBottomAction for checkout/cart/product calls to action.
- Added KIOSSegmentedTabs for filter/queue selection.
- Removed restaurant pictogram from failed-image placeholder; shows neutral text instead.
- Reduced shared navigation icon sizes and adjusted bottom bar height.
- Preserved existing role modules, Supabase logic and project configuration.

## Integration required
Wire the new components to existing customer/seller/rider/admin screens; migrate old layouts deliberately and test flows. Components are currently reusable primitives, not proof of screen-wide migration.

## Verification
Python package integrity checked. Flutter and Dart compilation, simulator testing, and Cloudflare deployment not performed in this environment.
