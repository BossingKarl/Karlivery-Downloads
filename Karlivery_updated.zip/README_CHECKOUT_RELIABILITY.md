# Karlivery Checkout Reliability Update — October 23, 2026

Changes in `lib/features/customer/checkout_flow.dart`:
- Reject checkout with an empty basket or while another checkout submission is active.
- Capture the initial basket and reject stale checkout if the store, contents or subtotal changes before submission.
- Validate GCash proof extension (JPG/JPEG/PNG/WebP), non-empty bytes and 8 MB maximum before accepting upload.
- Prevent simultaneous `createOrder` calls in the same app process.
- Preserve existing recovery behavior if an order is created but GCash proof submission fails.

No database schema or production records were modified.

Verification: source-level assertions and ZIP integrity check only. Flutter compilation, integration tests, and actual payment/order execution have NOT been performed. Backend idempotency keys are still recommended to prevent duplicates across devices or retries after ambiguous network failures.
