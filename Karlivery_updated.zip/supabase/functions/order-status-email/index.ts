import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

type Row = Record<string, unknown>;
const headers = { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info" };
const json = (value: unknown, status = 200) => new Response(JSON.stringify(value), { status, headers });
const val = (x: unknown) => x == null ? "" : String(x);
const htmlEscape = (x: unknown) => val(x).replace(/&/g, "&amp;").replace(/</g, "&lt;")
  .replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
const money = (x: unknown) => `PHP ${(Number(x ?? 0) || 0).toFixed(2)}`;

/**
 * Send ordinary order-status updates and a single itemized completion receipt.
 * Recipient and amounts ALWAYS come from service-role DB reads; the caller
 * controls neither the recipient email nor the charged amount.
 * The first successful completion email is protected by a unique DB ledger key.
 */
serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  const url = Deno.env.get("SUPABASE_URL");
  const anon = Deno.env.get("SUPABASE_ANON_KEY");
  const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const resend = Deno.env.get("RESEND_API_KEY");
  const from = Deno.env.get("FROM_EMAIL");
  if (!url || !anon || !service) return json({ error: "Supabase secrets missing" }, 503);
  if (!resend || !from) return json({ error: "RESEND_API_KEY or FROM_EMAIL missing" }, 503);

  try {
    const body = await req.json();
    const type = body?.order_type === "pabili" ? "pabili" : "regular";
    const id = val(body?.order_id).trim();
    if (!id || id.length > 128) return json({ error: "Invalid order ID" }, 400);

    const caller = createClient(url, anon, { global: { headers: {
      Authorization: req.headers.get("Authorization") ?? "",
    } } });
    const { data: session, error: sessionError } = await caller.auth.getUser();
    if (sessionError || !session?.user) return json({ error: "Unauthorized" }, 401);

    const admin = createClient(url, service, { auth: { persistSession: false, autoRefreshToken: false } });
    const table = type === "pabili" ? "pasabuy_orders" : "orders";
    const { data: order, error: orderError } = await admin.from(table).select("*").eq("id", id).maybeSingle();
    if (orderError) throw orderError;
    if (!order) return json({ error: "Order not found" }, 404);
    const o = order as Row;
    const customerId = val(o.customer_id);
    const riderId = val(o.rider_id);

    // Only an order participant, its seller or a verified Karlivery admin
    // may request a status/receipt email. Never allow arbitrary recipients.
    let allowed = session.user.id === customerId || session.user.id === riderId;
    if (!allowed) {
      const { data: profile } = await admin.from("profiles").select("role").eq("id", session.user.id).maybeSingle();
      allowed = val(profile?.role) === "admin";
    }
    let store: Row | null = null;
    if (type === "regular") {
      const { data: s } = await admin.from("stores").select("name,owner_id").eq("id", o.store_id).maybeSingle();
      store = s as Row | null;
      if (val(store?.owner_id) === session.user.id) allowed = true;
    } else {
      const { data: s } = await admin.from("pasabuy_shops").select("name").eq("id", o.shop_id).maybeSingle();
      store = s as Row | null;
    }
    if (!allowed) return json({ error: "Forbidden" }, 403);

    const completed = type === "pabili"
      ? val(o.status).toLowerCase() === "delivered"
      : ["delivered", "completed"].includes(val(o.status).toLowerCase());
    // KARLIVERY_NO_EMAIL_RECEIPTS_2026: reject legacy receipt requests.
    // Keep ordinary non-completed regular order-status emails functioning.
    if (completed || type === "pabili") {
      return json({ ok: true, skipped: "Completed-order email receipts have been discontinued. Save the PDF in Karlivery instead." });
    }
    if (type === "pabili" && !completed) {
      return json({ ok: true, skipped: "Pabili completion email waits for delivered status" });
    }

    // Authentication's verified account email is authoritative.
    const { data: account, error: accountError } = await admin.auth.admin.getUserById(customerId);
    if (accountError) throw accountError;
    const recipient = account.user?.email;
    if (!recipient) return json({ ok: true, skipped: "Customer has no email address" });

    const { data: profile } = await admin.from("profiles").select("full_name").eq("id", customerId).maybeSingle();
    const name = val(profile?.full_name) || "there";
    const { data: address } = o.address_id
      ? await admin.from("addresses").select("address_line,barangay,city,province").eq("id", o.address_id).maybeSingle()
      : { data: null };
    const addressText = [address?.address_line, address?.barangay, address?.city, address?.province]
      .filter((x) => val(x).trim()).map(val).join(", ");
    const itemTable = type === "pabili" ? "pasabuy_order_items" : "order_items";
    const { data: items, error: itemError } = await admin.from(itemTable).select("*").eq("order_id", id);
    if (itemError) throw itemError;
    const lineItems: Row[] = (items ?? []) as Row[];
    const total = Number(type === "pabili" ? o.total_amount : o.total) || 0;
    const delivery = Number(o.delivery_fee) || 0;
    const handling = type === "pabili" ? Number(o.handling_fee) || 0 : 0;
    const subtotal = Number(o.subtotal ?? (total - delivery - handling)) || 0;
    const distance = o.delivery_distance_km == null ? null : Number(o.delivery_distance_km);
    const orderNo = type === "pabili" ? id : val(o.order_no || id);
    const payment = val(o.payment_method || "Not specified").toUpperCase();
    const deliveryProvider = type === "pabili" ? "Karlivery rider" : o.delivery_provider === "seller" ? "store rider" : "Karlivery rider";
    const status = val(o.status).replace(/_/g, " ");

    let claimed = false;
    if (completed) {
      const { error: claimError } = await admin.from("order_receipt_email_deliveries").insert({
        order_type: type, order_id: id, customer_id: customerId, status: "sending",
      });
      if (claimError) {
        if (claimError.code === "23505") {
          const { data: previous } = await admin.from("order_receipt_email_deliveries")
            .select("status,sent_at").eq("order_type", type).eq("order_id", id).maybeSingle();
          const label = previous?.status === "sent"
            ? "Receipt was already submitted to the email provider. Check inbox, spam and Resend logs."
            : "A receipt request is already processing. If it remains stuck, check the email delivery ledger and function logs.";
          return json({ ok: true, skipped: label });
        }
        throw claimError;
      }
      claimed = true;
    }

    const lines = lineItems.map((item) => {
      const quantity = Number(item.quantity) || 1;
      const unit = Number(item.item_price ?? item.unit_price ?? item.price ?? 0) || 0;
      const amount = Number(item.line_total ?? item.total_price ?? unit * quantity) || 0;
      return `<tr><td style="padding:10px;border-bottom:1px solid #eee">${quantity} × ${htmlEscape(item.item_name ?? item.product_name ?? item.name ?? "Item")}</td><td style="padding:10px;text-align:right;border-bottom:1px solid #eee">${money(amount)}</td></tr>`;
    }).join("");
    const specialRequest = type === "pabili" && val(o.custom_request).trim()
      ? `<p style="overflow-wrap:anywhere"><strong>Requested items / notes:</strong> ${htmlEscape(o.custom_request)}</p>` : "";
    const rateSnapshot = o.delivery_rate_snapshot as Row | null;
    const storedRate = Number(rateSnapshot?.delivery_fee);
    const rateRow = rateSnapshot && Number.isFinite(storedRate) && Math.abs(storedRate - delivery) < 0.01
      ? `<tr><td colspan="2" style="padding:7px;font-size:12px;color:#666">Rate when ordered: ${money(rateSnapshot.base_fee)} first ${htmlEscape(rateSnapshot.included_radius_km)} km + ${money(rateSnapshot.step_fee)} per started ${htmlEscape(rateSnapshot.step_distance_km)} km (${htmlEscape(rateSnapshot.extra_steps)} extra steps)</td></tr>`
      : "";
    const formattedDistance = distance != null && Number.isFinite(distance)
      ? `<tr><td style="padding:7px">Pickup to customer GPS distance</td><td style="padding:7px;text-align:right">${distance.toFixed(2)} km</td></tr>` : "";
    const itemized = completed ? `
      <h3>Items ${type === "pabili" ? "(estimated)" : ""}</h3>
      <table style="width:100%;border-collapse:collapse">${lines || "<tr><td>No saved item rows</td></tr>"}</table>
      ${specialRequest}
      <table style="width:100%;margin-top:12px">
        <tr><td style="padding:7px">Items subtotal</td><td style="padding:7px;text-align:right">${money(subtotal)}</td></tr>
        ${handling > 0 ? `<tr><td style="padding:7px">Pabili handling fee</td><td style="padding:7px;text-align:right">${money(handling)}</td></tr>` : ""}
        ${formattedDistance}
        ${rateRow}
        <tr><td style="padding:7px">Delivery fee</td><td style="padding:7px;text-align:right">${money(delivery)}</td></tr>
        <tr><td style="padding:12px;background:#fff1bc;font-weight:bold">${type === "pabili" ? "Estimated total" : "Order total"}</td>
          <td style="padding:12px;background:#fff1bc;text-align:right;font-weight:bold">${money(total)}</td></tr>
      </table>
      <p style="font-size:12px;color:#666">${type === "pabili"
        ? "Pabili item prices are estimates unless confirmed with the rider. This email is not proof of payment."
        : "This summary shows saved order charges; delivery completed does not independently confirm payment."}</p>
      <p style="font-size:12px;color:#666">GPS distance is straight-line between the saved pins, not a road route.</p>` : `
      <h2>${htmlEscape(status)}</h2><p>Your order was updated. View the Karlivery app for the latest details.</p>`;
    const emailHtml = `<!doctype html><html><body style="font-family:Arial,sans-serif;background:#fff8ef;color:#242021;padding:24px">
      <div style="max-width:600px;margin:auto;background:white;border-radius:18px;overflow:hidden">
        <header style="background:#e51c23;color:#fff;padding:24px">
          <div style="font-size:26px;font-weight:bold">KARLIVERY</div>
          <div style="color:#ffe083">${completed ? "Order completed — receipt" : "Order update"}</div>
        </header>
        <main style="padding:24px"><p>Hi ${htmlEscape(name)},</p>
          <h2>${htmlEscape(store?.name || "Karlivery store")}</h2>
          <p><strong>Order:</strong> ${htmlEscape(orderNo)}<br>
          <strong>Status:</strong> ${htmlEscape(status)}<br>
          <strong>Payment:</strong> ${htmlEscape(payment)}<br>
          <strong>Delivered by:</strong> ${htmlEscape(deliveryProvider)}
          ${addressText ? `<br><strong>Deliver to:</strong> ${htmlEscape(addressText)}` : ""}</p>
          ${itemized}
          <p style="margin-top:22px">Thank you for ordering with Karlivery!</p>
        </main></div></body></html>`;

    try {
      const response = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${resend}`, "Content-Type": "application/json" },
        body: JSON.stringify({ from, to: [recipient],
          subject: `${completed ? "Your Karlivery receipt" : "Karlivery order update"} — ${orderNo}`,
          html: emailHtml, // Customer email, not any client-supplied recipient
        }),
      });
      if (!response.ok) throw new Error(`Email provider returned ${response.status}`);
      if (claimed) {
        const { error: markError } = await admin.from("order_receipt_email_deliveries")
          .update({ status: "sent", sent_at: new Date().toISOString() })
          .eq("order_type", type).eq("order_id", id);
        if (markError) throw markError;
      }
      return json({ ok: true, receipt: completed, order_type: type });
    } catch (error) {
      // Failed provider sends may be retried. A successful email followed by
      // a ledger update failure is ambiguous and must not cause duplicates.
      if (claimed) {
        const { data: current } = await admin.from("order_receipt_email_deliveries")
          .select("status").eq("order_type", type).eq("order_id", id).maybeSingle();
        if (current?.status === "sending") {
          // Only release a claim for clear provider delivery failures.
          if (String(error).includes("Email provider returned")) {
            await admin.from("order_receipt_email_deliveries").delete()
              .eq("order_type", type).eq("order_id", id).eq("status", "sending");
          }
        }
      }
      return json({ error: String(error) }, 502);
    }
  } catch (error) {
    return json({ error: String(error) }, 500);
  }
});
