import { createClient } from "npm:@supabase/supabase-js@2";
import { parseAnnouncementRoles, matchActiveRecipients, audienceCounts } from "./announcement_audience.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: {
      ...corsHeaders,
      "Content-Type": "application/json",
    },
  });

const statusCopy: Record<string, { title: string; body: string }> = {
  pending_payment: {
    title: "GCash payment needed",
    body: "Complete your GCash payment to continue your Karlivery order.",
  },
  payment_review: {
    title: "Payment proof received",
    body: "Your GCash proof is being reviewed by the store.",
  },
  payment_rejected: {
    title: "GCash proof needs attention",
    body: "Please check your payment details and submit a valid proof.",
  },
  paid: {
    title: "Payment confirmed",
    body: "Your Karlivery payment has been confirmed.",
  },
  accepted: {
    title: "Order accepted",
    body: "The store accepted your Karlivery order.",
  },
  preparing: {
    title: "Your food is being prepared",
    body: "The store is now preparing your order.",
  },
  ready: {
    title: "Order ready for a rider",
    body: "Your order is packed and waiting for delivery pickup.",
  },
  ready_for_pickup: {
    title: "Ready for pick-up",
    body: "Your order is ready for you to collect.",
  },
  assigned: {
    title: "Rider assigned",
    body: "A Karlivery rider has accepted your delivery.",
  },
  picked_up: {
    title: "Order picked up",
    body: "Your order has been handed to the delivery rider.",
  },
  delivering: {
    title: "Rider is on the way",
    body: "Your Karlivery rider is heading to your delivery location.",
  },
  delivered: {
    title: "Order delivered",
    body: "Your Karlivery order has arrived. Enjoy your meal!",
  },
  completed: {
    title: "Order completed",
    body: "Thank you for using Karlivery. You can now rate the restaurant and rider.",
  },
  cancelled: {
    title: "Order cancelled",
    body: "This Karlivery order has been cancelled.",
  },
  rejected: {
    title: "Order could not be accepted",
    body: "The store was unable to accept this order.",
  },
};

async function persistNotifications(
  admin: ReturnType<typeof createClient>,
  recipients: string[],
  title: string,
  message: string,
  kind: string,
  orderId: string | null,
  data: Record<string, unknown>,
) {
  if (recipients.length === 0) return;

  const rows = recipients.map((userId) => ({
    user_id: userId,
    order_id: orderId,
    title,
    message,
    kind,
    data,
    is_read: false,
  }));

  // Supabase/PostgREST and PostgreSQL payloads have practical limits;
  // splitting prevents large broadcasts from silently dropping recipients.
  for (let start = 0; start < rows.length; start += 150) {
    const { error } = await admin.from("notifications")
      .insert(rows.slice(start, start + 150));
    if (error) {
      console.error("Notification history insert failed:", error.message);
      throw new Error(`Notification inbox insert failed after ${start} recipients: ${error.message}`);
    }
  }
}

async function sendOneSignal(
  appId: string | undefined,
  apiKey: string | undefined,
  recipients: string[],
  title: string,
  message: string,
  data: Record<string, unknown>,
  event: string,
) {
  if (recipients.length === 0) {
    return { skipped: "no push recipients" };
  }

  if (!appId || !apiKey) {
    return {
      skipped: "OneSignal not configured; Karlivery inbox delivery completed",
    };
  }

  const response = await fetch(
    "https://api.onesignal.com/notifications",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Authorization": `Key ${apiKey}`,
      },
      body: JSON.stringify({
        app_id: appId,
        target_channel: "push",
        name: `Karlivery ${event}`,
        include_aliases: {
          external_id: recipients,
        },
        headings: {
          en: title,
        },
        contents: {
          en: message,
        },
        data,
        small_icon: "ic_stat_karlivery",
        android_accent_color: "FFE81123",
        priority: 10,
      }),
    },
  );

  const responseText = await response.text();

  if (!response.ok) {
    return {
      error: `OneSignal ${response.status}: ${responseText}`,
    };
  }

  try {
    return JSON.parse(responseText);
  } catch (_) {
    return responseText;
  }
}

// A signed, short-lived preview ensures that older/incompatible clients
// cannot accidentally broadcast to everyone, and that the confirmed audience
// still matches the recipient set at send time.
const encoder = new TextEncoder();
const hex = (bytes: Uint8Array) =>
  Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");

async function signAudiencePreview(
  key: string,
  selectedRoles: string[],
  recipients: string[],
  expiry: number,
) {
  const material = `${expiry}|${selectedRoles.join(",")}|${[...recipients].sort().join(",")}`;
  const hmacKey = await crypto.subtle.importKey(
    "raw", encoder.encode(key), { name: "HMAC", hash: "SHA-256" }, false, ["sign"],
  );
  return `${expiry}.${hex(new Uint8Array(await crypto.subtle.sign("HMAC", hmacKey, encoder.encode(material))))}`;
}

function safeTokenMatch(received: string, expected: string): boolean {
  if (received.length !== expected.length) return false;
  let difference = 0;
  for (let i = 0; i < received.length; i++) {
    difference |= received.charCodeAt(i) ^ expected.charCodeAt(i);
  }
  return difference === 0;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const appId = Deno.env.get("ONESIGNAL_APP_ID");
    const apiKey = Deno.env.get("ONESIGNAL_REST_API_KEY");
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const authHeader = req.headers.get("Authorization");

    if (!supabaseUrl || !anonKey || !serviceKey || !authHeader) {
      return json(
        { error: "Push function environment is incomplete." },
        500,
      );
    }

    const callerClient = createClient(supabaseUrl, anonKey, {
      global: {
        headers: { Authorization: authHeader },
      },
      auth: { persistSession: false },
    });

    const admin = createClient(supabaseUrl, serviceKey, {
      auth: {
        persistSession: false,
        autoRefreshToken: false,
      },
    });

    const {
      data: { user: caller },
      error: callerError,
    } = await callerClient.auth.getUser();

    if (callerError || !caller) {
      return json({ error: "Unauthorized." }, 401);
    }

    const body = await req.json();
    const event = String(body.event ?? "order_update").trim();
    const orderId = String(body.order_id ?? "").trim();
    const chatText = String(body.message ?? "").trim();

    const { data: callerProfile, error: profileError } = await admin
      .from("profiles")
      .select("id,role,status,full_name")
      .eq("id", caller.id)
      .maybeSingle();

    if (profileError || !callerProfile) {
      return json({ error: "Caller profile not found." }, 403);
    }

    // -------------------------------------------------------
    // Admin announcements must explicitly select one or more roles.
    // An omitted audience, or the old target_role="all" shortcut, fails closed.
    // The preview endpoint is safe to call before the administrator confirms.
    // -------------------------------------------------------
    if (event === "announcement" || event === "announcement_preview") {
      if (callerProfile.role !== "admin" || callerProfile.status !== "active") {
        return json({ error: "Active admin account required." }, 403);
      }

      let selectedRoles: ReturnType<typeof parseAnnouncementRoles>;
      try {
        selectedRoles = parseAnnouncementRoles(body.target_roles);
      } catch (error) {
        return json({ error: String((error as Error).message) }, 400);
      }

      const rows: Array<{ id: string; role: string; status: string }> = [];
      const pageSize = 400;
      for (let start = 0; ; start += pageSize) {
        const { data: page, error: recipientError } = await admin
          .from("profiles")
          .select("id,role,status")
          .eq("status", "active")
          .in("role", selectedRoles)
          .order("id", { ascending: true })
          .range(start, start + pageSize - 1);
        if (recipientError) throw recipientError;
        rows.push(...(page ?? []));
        if ((page ?? []).length < pageSize) break;
      }
      // Defense in depth: check each returned profile's role again before sending.
      const profiles = matchActiveRecipients(rows, selectedRoles);
      const recipients = profiles.map((profile) => profile.id);
      const byRole = audienceCounts(profiles);

      if (event === "announcement_preview") {
        const expiresAt = Date.now() + 5 * 60 * 1000;
        return json({
          ok: true,
          target_roles: selectedRoles,
          recipients: recipients.length,
          recipients_by_role: byRole,
          preview_token: await signAudiencePreview(serviceKey, selectedRoles, recipients, expiresAt),
        });
      }

      const title = String(body.title ?? "").trim();
      const message = String(body.message ?? "").trim();
      if (!title || !message || title.length > 80 || message.length > 500) {
        return json({ error: "Enter a title (max 80) and message (max 500)." }, 400);
      }
      const receivedToken = String(body.preview_token ?? "");
      const expiryString = receivedToken.split(".")[0];
      const expiry = Number(expiryString);
      const now = Date.now();
      if (!/^\d{13}\.[0-9a-f]{64}$/.test(receivedToken) ||
          !Number.isSafeInteger(expiry) || expiry <= now || expiry > now + 5 * 60 * 1000) {
        return json({ error: "Audience preview expired or missing. Preview recipients again." }, 409);
      }
      const expectedToken = await signAudiencePreview(serviceKey, selectedRoles, recipients, expiry);
      if (!safeTokenMatch(receivedToken, expectedToken)) {
        return json({ error: "Audience changed since preview. Review recipients and retry." }, 409);
      }

      const data = {
        screen: "notifications",
        event: "announcement",
        target_roles: selectedRoles,
      };
      await persistNotifications(admin, recipients, title, message, "announcement", null, data);

      const pushBatches = [];
      for (let start = 0; start < recipients.length; start += 1000) {
        pushBatches.push(await sendOneSignal(
          appId, apiKey, recipients.slice(start, start + 1000), title, message,
          data, event,
        ));
      }
      const pushErrors = pushBatches.filter((item) =>
        typeof item === "object" && item !== null && "error" in item
      );
      const provider = {
        batches: pushBatches.length,
        ...(pushErrors.length ? { error: `${pushErrors.length} push batch(es) failed` } : {}),
        ...(!appId || !apiKey ? { skipped: "Push not configured; inbox messages saved" } : {}),
      };

      return json({
        ok: true,
        target_roles: selectedRoles,
        recipients_by_role: byRole,
        recipients: recipients.length,
        provider,
      });
    }

    // -------------------------------------------------------
    // Pabili events use pasabuy_orders (TEXT IDs), not regular orders UUIDs.
    // Inbox records are produced transactionally by our participant-scoped
    // database triggers / existing rider RPCs; this branch sends PHONE PUSH.
    // The app never chooses who receives a push or its message content.
    // -------------------------------------------------------
    if (body.order_type === "pabili") {
      if (callerProfile.status !== "active") {
        return json({ error: "Active Karlivery account required." }, 403);
      }
      const allowedEvents = new Set([
        "pabili_created", "pabili_claimed", "pabili_status",
        "pabili_chat", "pabili_payment_sent", "pabili_payment_received",
      ]);
      if (!allowedEvents.has(event) || !orderId || orderId.length > 130) {
        return json({ error: "Invalid Pabili event or order ID." }, 400);
      }
      const { data: pb, error: pbError } = await admin
        .from("pasabuy_orders")
        .select("id,shop_id,customer_id,rider_id,status,payment_status,created_at,updated_at")
        .eq("id", orderId).maybeSingle();
      if (pbError) throw pbError;
      if (!pb) return json({ error: "Pabili order not found." }, 404);
      const customerId = pb.customer_id ? String(pb.customer_id) : null;
      const riderId = pb.rider_id ? String(pb.rider_id) : null;
      const isCustomer = customerId === caller.id;
      const isRider = riderId === caller.id && callerProfile.role === "rider";
      const isNew = (value: unknown, minutes = 10) => {
        const delta = Date.now() - Date.parse(String(value ?? ""));
        return Number.isFinite(delta) && delta >= -60000 && delta <= minutes * 60000;
      };
      const status = String(pb.status ?? "");
      let recipients: string[] = [];
      let title = "Pabili with Karlivery";
      let message = "There's an update to your Pabili request.";
      let screen = "pabili_order";

      if (event === "pabili_created") {
        if (!isCustomer || status !== "Waiting for Rider" || riderId || !isNew(pb.created_at)) {
          return json({ error: "New Pabili notification is not authorized." }, 403);
        }
        // Riders who are ONLINE and active are the eligible recipients.
        // Keep recipients server-derived; never take a list from the app.
        for (let start = 0; start < 2000; start += 400) {
          const { data: page, error: ridersError } = await admin.from("profiles")
            .select("id").eq("role", "rider").eq("status", "active")
            .eq("is_online", true).order("id")
            .range(start, start + 399);
          if (ridersError) throw ridersError;
          recipients.push(...(page ?? []).map((r: { id: string }) => String(r.id)));
          if ((page ?? []).length < 400) break;
        }
        title = "New Pabili request";
        message = "A customer needs a Karlivery rider. Open Deliveries to review available requests.";
      } else if (event === "pabili_claimed") {
        if (!isRider || status !== "Rider Accepted" || !isNew(pb.updated_at)) {
          return json({ error: "Pabili rider acceptance could not be verified." }, 403);
        }
        recipients = customerId ? [customerId] : [];
        title = "Your Pabili rider is ready";
        message = "A rider accepted your request. You can chat and track your delivery.";
        screen = "pabili_tracking";
      } else if (event === "pabili_status") {
        const known = ["Rider Accepted", "Buying in Progress", "Purchased", "On the Way", "Delivered"];
        if (!isRider || !known.includes(status) || !isNew(pb.updated_at)) {
          return json({ error: "Pabili status change could not be verified." }, 403);
        }
        recipients = customerId ? [customerId] : [];
        const statusMessages: Record<string, string> = {
          "Rider Accepted": "Your rider accepted the request.",
          "Buying in Progress": "Your rider is now buying the requested items.",
          "Purchased": "Your requested items have been purchased.",
          "On the Way": "Your rider is heading to the delivery address.",
          "Delivered": "Your Pabili order was delivered. View your receipt in Karlivery.",
        };
        title = `Pabili update: ${status}`;
        message = statusMessages[status];
        screen = status === "On the Way" ? "pabili_tracking" : "pabili_order";
      } else if (event === "pabili_chat") {
        if (!isCustomer && !isRider) return json({ error: "Not a conversation participant." }, 403);
        const messageId = String(body.message_id ?? "");
        if (!messageId || messageId.length > 140) return json({ error: "Missing saved message ID." }, 400);
        const { data: savedMessage, error: messageError } = await admin
          .from("pasabuy_messages")
          .select("id,order_id,sender_id,message,created_at")
          .eq("id", messageId).eq("order_id", orderId).maybeSingle();
        if (messageError) throw messageError;
        if (!savedMessage || savedMessage.sender_id !== caller.id || !isNew(savedMessage.created_at)) {
          return json({ error: "Saved Pabili message could not be verified." }, 403);
        }
        recipients = isCustomer ? (riderId ? [riderId] : []) : (customerId ? [customerId] : []);
        title = "New Pabili message";
        const safeText = String(savedMessage.message ?? "").trim();
        message = safeText.length > 120 ? `${safeText.slice(0, 117)}...` : safeText;
        screen = "pabili_chat";
      } else if (event === "pabili_payment_sent") {
        if (!isCustomer || !riderId || pb.payment_status !== "customer_sent" || !isNew(pb.updated_at)) {
          return json({ error: "Pabili payment submission could not be verified." }, 403);
        }
        recipients = [riderId];
        title = "Pabili GCash marked as sent";
        message = "Customer marked GCash payment as sent. Please verify it before confirming.";
      } else if (event === "pabili_payment_received") {
        if (!isRider || pb.payment_status !== "paid" || !isNew(pb.updated_at)) {
          return json({ error: "Pabili payment confirmation could not be verified." }, 403);
        }
        recipients = customerId ? [customerId] : [];
        title = "Pabili GCash confirmed";
        message = "Your rider confirmed the GCash payment was received.";
      }

      recipients = [...new Set(recipients.filter((id) => id !== caller.id))];
      // Deduplicate retries; do not let the mobile/browser client generate
      // arbitrary idempotency keys. The key uses verified database state.
      const claimSuffix = event === "pabili_chat"
        ? String(body.message_id)
        : event === "pabili_created" || event === "pabili_claimed"
          ? "once"
          : `${status}:${String(pb.updated_at ?? "")}:${String(pb.payment_status ?? "")}`;
      const eventKey = `${event}:${orderId}:${claimSuffix}`.slice(0, 255);
      let claimed = false;
      if (recipients.length && appId && apiKey) {
        const { error: claimError } = await admin.from("pabili_push_event_claims")
          .insert({ event_key: eventKey });
        if (claimError?.code === "23505") {
          return json({ ok: true, duplicate: true, order_type: "pabili",
            recipients: recipients.length,
            provider: { skipped: "Push event already submitted" } });
        }
        if (claimError) {
          return json({ error: `Pabili push claim unavailable: ${claimError.message}. Run migration 40.` }, 503);
        }
        claimed = true;
      }
      const pushData = {
        order_type: "pabili", pasabuy_order_id: String(pb.id),
        screen, event, status,
      };
      const batches: unknown[] = [];
      for (let start = 0; start < recipients.length; start += 1000) {
        batches.push(await sendOneSignal(
          appId, apiKey, recipients.slice(start, start + 1000), title, message,
          pushData, event,
        ));
      }
      const providerErrors = batches.filter((x) =>
        typeof x === "object" && x !== null && "error" in x
      );
      if (providerErrors.length && claimed) {
        // A provider rejection must not prevent the next legitimate retry.
        await admin.from("pabili_push_event_claims").delete().eq("event_key", eventKey);
      }
      return json({
        ok: providerErrors.length === 0,
        order_type: "pabili",
        recipients: recipients.length,
        provider: batches.length === 0 ? { skipped: "No eligible recipient" }
          : providerErrors.length > 0 ? { error: "Push provider failure", batches }
          : { batches },
        // Phone delivery requires OneSignal credentials and a subscribed device.
        push_configured: Boolean(appId && apiKey),
      }, providerErrors.length ? 502 : 200);
    }

    // -------------------------------------------------------
    // All order/chat events require an order.
    // -------------------------------------------------------
    if (!orderId) {
      return json({ error: "order_id is required." }, 400);
    }

    const { data: order, error: orderError } = await admin
      .from("orders")
      .select(
        "id,order_no,status,customer_id,rider_id,store_id,payment_method,fulfillment",
      )
      .eq("id", orderId)
      .maybeSingle();

    if (orderError || !order) {
      return json({ error: "Order not found." }, 404);
    }

    const { data: store, error: storeError } = await admin
      .from("stores")
      .select("id,name,owner_id")
      .eq("id", order.store_id)
      .maybeSingle();

    if (storeError) throw storeError;

    const ownerId = store?.owner_id ? String(store.owner_id) : null;
    const customerId = order.customer_id
      ? String(order.customer_id)
      : null;
    const riderId = order.rider_id
      ? String(order.rider_id)
      : null;

    const isParticipant =
      callerProfile.role === "admin" ||
      caller.id === customerId ||
      caller.id === riderId ||
      caller.id === ownerId;

    if (!isParticipant) {
      return json({ error: "Not allowed for this order." }, 403);
    }

    let recipients: string[] = [];
    let title = "Karlivery";
    let message = "You have a new Karlivery update.";
    let kind = "order";
    let screen = "order";

    if (event === "new_order") {
      if (ownerId && ownerId !== caller.id) recipients = [ownerId];
      title = "New Karlivery order";
      message =
        `${order.order_no ?? "New order"} • ${store?.name ?? "Store"}`;
    } else if (event === "payment_proof") {
      if (ownerId && ownerId !== caller.id) recipients = [ownerId];
      title = "GCash proof submitted";
      message =
        `Payment proof for ${order.order_no ?? "an order"} is ready for review.`;
    } else if (event === "payment_sent") {
      if (ownerId && ownerId !== caller.id) recipients = [ownerId];
      title = "Customer marked GCash as sent";
      message =
        `${order.order_no ?? "An order"} is waiting for your payment receipt confirmation.`;
    } else if (event === "payment_received") {
      if (customerId && customerId !== caller.id) recipients = [customerId];
      title = "GCash payment received";
      message =
        `${store?.name ?? "The seller"} confirmed receipt of your payment for ${order.order_no ?? "your order"}.`;
    } else if (event === "payment_attention") {
      if (customerId && customerId !== caller.id) recipients = [customerId];
      title = "GCash payment needs attention";
      message =
        `${store?.name ?? "The seller"} needs you to check the payment details for ${order.order_no ?? "your order"}. Open the order chat if you need help.`;
    } else if (event === "rider_fee_due") {
      if (ownerId && ownerId !== caller.id) recipients = [ownerId];
      title = "Rider delivery fee is due";
      message = `${order.order_no ?? "This order"} was paid through store GCash. Keep the delivery fee for the assigned rider and settle it through Karlivery.`;
      kind = "rider_fee";
    } else if (event === "rider_fee_sent") {
      if (riderId && riderId !== caller.id) recipients = [riderId];
      title = "Seller marked rider fee sent";
      message = `${store?.name ?? "The store"} marked your delivery fee as sent. Confirm only after you actually receive it.`;
      kind = "rider_fee";
    } else if (event === "rider_fee_received") {
      if (ownerId && ownerId !== caller.id) recipients = [ownerId];
      title = "Rider confirmed delivery fee";
      message = `The rider confirmed receiving the delivery fee for ${order.order_no ?? "this order"}.`;
      kind = "rider_fee";
    } else if (event === "chat") {
      recipients = [customerId, riderId, ownerId]
        .filter(
          (id): id is string =>
            Boolean(id) && id !== caller.id,
        );

      kind = "chat";
      screen = "chat";

      title = `New order chat message`;

      const safeChat =
        chatText.length > 120
          ? `${chatText.slice(0, 117)}...`
          : chatText;

      message =
        safeChat ||
        `Open ${order.order_no ?? "your order"} chat.`;
    } else {
      recipients = [customerId, riderId, ownerId]
        .filter(
          (id): id is string =>
            Boolean(id) && id !== caller.id,
        );

      const status = String(order.status);
      if (["assigned", "picked_up", "delivering"].includes(status)) {
        screen = "tracking";
      } else {
        screen = "order";
      }

      const copy = statusCopy[status];
      title = copy?.title ?? "Karlivery order update";
      message =
        copy?.body ??
        `${order.order_no ?? "Your order"} has a new update.`;
    }

    recipients = [...new Set(recipients)];

    const data = {
      screen,
      order_id: order.id,
      order_no: order.order_no,
      event,
      status: order.status,
      store_name: store?.name ?? null,
    };

    if (!event.startsWith("rider_fee_")) {
      await persistNotifications(
        admin,
        recipients,
        title,
        message,
        kind,
        order.id,
        data,
      );
    }

    const provider = await sendOneSignal(
      appId,
      apiKey,
      recipients,
      title,
      message,
      data,
      event,
    );

    return json({
      ok: true,
      recipients,
      provider,
    });
  } catch (error) {
    return json({ error: String(error) }, 500);
  }
});
