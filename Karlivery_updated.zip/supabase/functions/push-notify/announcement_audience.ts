// Explicit role selection is mandatory for every announcement. Never default
// an omitted/unknown audience to "all" (including for older client builds).
export const ANNOUNCEMENT_ROLES = ["customer", "store_owner", "rider", "admin"] as const;
export type AnnouncementRole = typeof ANNOUNCEMENT_ROLES[number];

export function parseAnnouncementRoles(input: unknown): AnnouncementRole[] {
  if (!Array.isArray(input) || input.length === 0 || input.length > 4) {
    throw new Error("Select at least one recipient role before sending.");
  }
  const supplied = new Set<string>();
  for (const value of input) {
    if (typeof value !== "string" || !(ANNOUNCEMENT_ROLES as readonly string[]).includes(value)) {
      throw new Error("Invalid announcement audience. Update Karlivery before sending.");
    }
    supplied.add(value);
  }
  return ANNOUNCEMENT_ROLES.filter((role) => supplied.has(role));
}

export function matchActiveRecipients(
  rows: Array<{ id: string; role: string; status?: string }>,
  selectedRoles: readonly string[],
): Array<{ id: string; role: AnnouncementRole }> {
  const selected = new Set(selectedRoles);
  const ids = new Set<string>();
  const result: Array<{ id: string; role: AnnouncementRole }> = [];
  for (const row of rows) {
    if (!row.id || !selected.has(row.role) ||
        (row.status !== undefined && row.status !== "active") || ids.has(row.id)) {
      continue;
    }
    ids.add(row.id);
    result.push({ id: row.id, role: row.role as AnnouncementRole });
  }
  return result;
}

export function audienceCounts(
  recipients: Array<{ role: string }>,
): Record<AnnouncementRole, number> {
  const counts: Record<AnnouncementRole, number> = {
    customer: 0, store_owner: 0, rider: 0, admin: 0,
  };
  for (const recipient of recipients) {
    if (recipient.role in counts) counts[recipient.role as AnnouncementRole]++;
  }
  return counts;
}
