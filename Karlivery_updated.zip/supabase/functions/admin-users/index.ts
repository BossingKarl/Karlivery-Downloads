import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const activeStatuses = [
  "pending_payment",
  "payment_review",
  "paid",
  "accepted",
  "preparing",
  "ready",
  "ready_for_pickup",
  "assigned",
  "picked_up",
  "delivering",
];

const cleanRole = (value: unknown) => {
  const role = String(value ?? "customer").trim().toLowerCase();
  return ["customer", "store_owner", "rider", "admin"].includes(role)
    ? role
    : "customer";
};

const cleanStatus = (value: unknown) => {
  const status = String(value ?? "active").trim().toLowerCase();
  return ["active", "suspended", "rejected", "pending"].includes(status)
    ? status
    : "active";
};


const errorText = (error: unknown) => {
  if (error instanceof Error) return error.message;
  if (error && typeof error === "object") {
    const e = error as Record<string, unknown>;
    return [e.message, e.details, e.hint, e.code]
      .filter((v) => v != null && String(v).trim() !== "")
      .map(String)
      .join(" | ") || JSON.stringify(error);
  }
  return String(error);
};

const upsertProfile = async (
  adminClient: ReturnType<typeof createClient>,
  values: {
    id: string;
    email: string;
    fullName: string;
    phone: string;
    role: string;
    status?: string;
  },
) => {
  const { error } = await adminClient.rpc(
    "karlivery_service_upsert_profile",
    {
      p_user_id: values.id,
      p_email: values.email,
      p_full_name: values.fullName,
      p_phone: values.phone,
      p_role: values.role,
      p_status: values.status ?? "active",
    },
  );

  if (error) {
    throw new Error(`Profile sync failed: ${errorText(error)}`);
  }
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const authHeader = req.headers.get("Authorization");

    if (!supabaseUrl || !anonKey || !serviceKey) {
      return json({ error: "Supabase function environment is incomplete." }, 500);
    }

    if (!authHeader) {
      return json({ error: "Missing authorization token." }, 401);
    }

    const callerClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
      auth: { persistSession: false },
    });

    const adminClient = createClient(supabaseUrl, serviceKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    const {
      data: { user: caller },
      error: callerError,
    } = await callerClient.auth.getUser();

    if (callerError || !caller) {
      return json({ error: "Invalid session." }, 401);
    }

    let { data: callerProfile, error: callerProfileError } = await adminClient
      .from("profiles")
      .select("id,role,status")
      .eq("id", caller.id)
      .maybeSingle();

    if (callerProfileError) {
      throw callerProfileError;
    }

    if (!callerProfile) {
      const metadataRole = cleanRole(
        caller.user_metadata?.role ?? caller.app_metadata?.role,
      );
      const metadataStatus = cleanStatus(
        caller.user_metadata?.status ?? caller.app_metadata?.status,
      );

      await upsertProfile(adminClient, {
        id: caller.id,
        email: caller.email ?? "",
        fullName: String(caller.user_metadata?.full_name ?? "").trim(),
        phone: String(caller.user_metadata?.phone ?? "").trim(),
        role: metadataRole,
        status: metadataStatus,
      });

      const bootstrapResult = await adminClient
        .from("profiles")
        .select("id,role,status")
        .eq("id", caller.id)
        .maybeSingle();

      callerProfile = bootstrapResult.data;

      if (!callerProfile) {
        return json(
          {
            error:
              "Caller profile was missing and could not be prepared. Run database/10_ADMIN_PROFILE_BOOTSTRAP.sql, then try again.",
          },
          403,
        );
      }
    }

    const body = await req.json();
    const action = String(body.action ?? "").toLowerCase();

    // Customer self-delete is permitted. Seller/rider/admin accounts remain admin-managed.
    if (action === "self_delete") {
      if (callerProfile.role !== "customer") {
        return json({ error: "Only customer accounts can self-delete." }, 403);
      }

      const { count, error: activeError } = await adminClient
        .from("orders")
        .select("id", { count: "exact", head: true })
        .eq("customer_id", caller.id)
        .in("status", activeStatuses);

      if (activeError) throw activeError;
      if ((count ?? 0) > 0) {
        return json(
          { error: "Complete or cancel active orders before deleting your account." },
          409,
        );
      }

      const { error: deleteError } = await adminClient.auth.admin.deleteUser(caller.id);
      if (deleteError) throw deleteError;

      return json({ ok: true, deleted: caller.id });
    }

    if (callerProfile.role !== "admin" || callerProfile.status !== "active") {
      return json({ error: "Admin access required." }, 403);
    }

    if (action === "create") {
      const email = String(body.email ?? "").trim().toLowerCase();
      const password = String(body.password ?? "");
      const fullName = String(body.full_name ?? "").trim();
      const phone = String(body.phone ?? "").trim();
      const role = cleanRole(body.role ?? "customer");

      if (!email || !email.includes("@")) {
        return json({ error: "A valid email is required." }, 400);
      }
      if (password.length < 8) {
        return json({ error: "Password must be at least 8 characters." }, 400);
      }
      if (!["customer", "store_owner", "rider"].includes(role)) {
        return json({ error: "Invalid role." }, 400);
      }

      const { data: created, error: createError } =
        await adminClient.auth.admin.createUser({
          email,
          password,
          email_confirm: true,
          user_metadata: {
            full_name: fullName,
            phone,
            role,
            status: "active",
          },
        });

      if (createError || !created.user) {
        return json({ error: createError?.message ?? "Could not create user." }, 400);
      }

      try {
        await upsertProfile(adminClient, {
          id: created.user.id,
          email,
          fullName,
          phone,
          role,
          status: "active",
        });
      } catch (profileError) {
        await adminClient.auth.admin.deleteUser(created.user.id);
        return json(
          {
            error: errorText(profileError),
            stage: "profile_sync",
            hint: "Run database/11_ADMIN_MANAGED_ACCOUNT_FIX.sql, then redeploy admin-users.",
          },
          500,
        );
      }

      return json({ ok: true, user_id: created.user.id });
    }

    if (action === "update") {
      const userId = String(body.user_id ?? "");
      if (!userId) return json({ error: "user_id is required." }, 400);

      const { data: targetProfile } = await adminClient
        .from("profiles")
        .select("id,role")
        .eq("id", userId)
        .maybeSingle();

      if (!targetProfile) return json({ error: "User not found." }, 404);

      // Do not allow this endpoint to demote or overwrite the primary admin.
      if (targetProfile.role === "admin" && userId !== caller.id) {
        return json({ error: "Another admin account cannot be edited here." }, 403);
      }

      let role = cleanRole(body.role ?? targetProfile.role);
      let status = cleanStatus(body.status ?? "active");

      if (targetProfile.role === "admin") {
        role = "admin";
        status = "active";
      }

      if (!["customer", "store_owner", "rider", "admin"].includes(role)) {
        return json({ error: "Invalid role." }, 400);
      }
      if (!["active", "suspended", "rejected", "pending"].includes(status)) {
        return json({ error: "Invalid status." }, 400);
      }

      const authPatch: Record<string, unknown> = {};
      const nextFullName =
        body.full_name != null ? String(body.full_name).trim() : undefined;
      const nextPhone =
        body.phone != null ? String(body.phone).trim() : undefined;
      if (body.email != null && String(body.email).trim() !== "") {
        authPatch.email = String(body.email).trim().toLowerCase();
        authPatch.email_confirm = true;
      }
      if (body.password != null && String(body.password).length > 0) {
        if (String(body.password).length < 8) {
          return json({ error: "New password must be at least 8 characters." }, 400);
        }
        authPatch.password = String(body.password);
      }
      authPatch.user_metadata = {
        full_name: nextFullName ?? String(body.full_name ?? "").trim(),
        phone: nextPhone ?? String(body.phone ?? "").trim(),
        role,
        status,
      };

      if (Object.keys(authPatch).length > 0) {
        const { error: authUpdateError } =
          await adminClient.auth.admin.updateUserById(userId, authPatch);
        if (authUpdateError) return json({ error: authUpdateError.message }, 400);
      }

      const profilePatch: Record<string, unknown> = {
        role,
        status,
        updated_at: new Date().toISOString(),
      };

      if (body.email != null && String(body.email).trim() !== "") {
        profilePatch.email = String(body.email).trim().toLowerCase();
      }
      if (body.full_name != null) {
        profilePatch.full_name = String(body.full_name).trim();
      }
      if (body.phone != null) {
        profilePatch.phone = String(body.phone).trim();
      }

      const { data: existingProfile, error: existingProfileError } =
        await adminClient
          .from("profiles")
          .select("email,full_name,phone")
          .eq("id", userId)
          .maybeSingle();

      if (existingProfileError) {
        throw new Error(errorText(existingProfileError));
      }

      await upsertProfile(adminClient, {
        id: userId,
        email: String(profilePatch.email ?? existingProfile?.email ?? ""),
        fullName: String(
          profilePatch.full_name ?? existingProfile?.full_name ?? "",
        ),
        phone: String(profilePatch.phone ?? existingProfile?.phone ?? ""),
        role,
        status,
      });

      return json({ ok: true, user_id: userId });
    }

    if (action === "delete") {
      const userId = String(body.user_id ?? "");
      if (!userId) return json({ error: "user_id is required." }, 400);
      if (userId === caller.id) {
        return json({ error: "The signed-in admin account cannot delete itself." }, 403);
      }

      const { data: targetProfile, error: targetError } = await adminClient
        .from("profiles")
        .select("id,role")
        .eq("id", userId)
        .maybeSingle();

      if (targetError) throw targetError;
      if (!targetProfile) return json({ error: "User not found." }, 404);
      if (targetProfile.role === "admin") {
        return json({ error: "Admin accounts cannot be deleted here." }, 403);
      }

      let activeCount = 0;

      if (targetProfile.role === "customer") {
        const { count, error } = await adminClient
          .from("orders")
          .select("id", { count: "exact", head: true })
          .eq("customer_id", userId)
          .in("status", activeStatuses);
        if (error) throw error;
        activeCount = count ?? 0;
      }

      if (targetProfile.role === "rider") {
        const { count, error } = await adminClient
          .from("orders")
          .select("id", { count: "exact", head: true })
          .eq("rider_id", userId)
          .in("status", ["assigned", "picked_up", "delivering"]);
        if (error) throw error;
        activeCount = count ?? 0;
      }

      if (targetProfile.role === "store_owner") {
        const { data: ownedStores, error: storesError } = await adminClient
          .from("stores")
          .select("id")
          .eq("owner_id", userId);
        if (storesError) throw storesError;

        const storeIds = (ownedStores ?? []).map((s) => s.id);
        if (storeIds.length > 0) {
          const { count, error } = await adminClient
            .from("orders")
            .select("id", { count: "exact", head: true })
            .in("store_id", storeIds)
            .in("status", activeStatuses);
          if (error) throw error;
          activeCount = count ?? 0;

          if (activeCount === 0) {
            await adminClient
              .from("stores")
              .update({ is_open: false, owner_id: null })
              .in("id", storeIds);
          }
        }
      }

      if (activeCount > 0) {
        return json(
          { error: "This account still has active orders. Complete or cancel them before hard delete." },
          409,
        );
      }

      const { error: deleteError } = await adminClient.auth.admin.deleteUser(userId);
      if (deleteError) return json({ error: deleteError.message }, 400);

      return json({ ok: true, deleted: userId });
    }

    return json({ error: "Unknown action." }, 400);
  } catch (error) {
    return json(
      {
        error: errorText(error),
        stage: "admin_users",
      },
      500,
    );
  }
});
