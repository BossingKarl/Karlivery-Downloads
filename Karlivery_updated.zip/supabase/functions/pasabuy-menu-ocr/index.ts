import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

function readOutputText(payload: any): string {
  if (typeof payload?.output_text === "string") return payload.output_text;
  const chunks: string[] = [];
  for (const item of payload?.output ?? []) {
    for (const content of item?.content ?? []) {
      if (content?.type === "output_text" && typeof content?.text === "string") {
        chunks.push(content.text);
      }
    }
  }
  return chunks.join("\n").trim();
}

function parseJsonText(raw: string): any {
  const clean = raw
    .replace(/^```json\s*/i, "")
    .replace(/^```\s*/i, "")
    .replace(/```$/i, "")
    .trim();
  return JSON.parse(clean);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "POST required." }, 405);

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const openAiKey = Deno.env.get("OPENAI_API_KEY");
    const model = Deno.env.get("OPENAI_OCR_MODEL") || "gpt-4.1-mini";
    const authHeader = req.headers.get("Authorization");

    if (!supabaseUrl || !anonKey || !serviceKey || !authHeader) {
      return json({ error: "Supabase function environment is incomplete." }, 500);
    }
    if (!openAiKey) {
      return json({
        error: "OPENAI_API_KEY is not configured for menu OCR.",
        setup: "Run: npx.cmd supabase secrets set OPENAI_API_KEY=YOUR_KEY OPENAI_OCR_MODEL=gpt-4.1-mini",
      }, 503);
    }

    const callerClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
      auth: { persistSession: false },
    });
    const admin = createClient(supabaseUrl, serviceKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    const { data: { user }, error: userError } = await callerClient.auth.getUser();
    if (userError || !user) return json({ error: "Unauthorized." }, 401);

    const { data: profile } = await admin
      .from("profiles")
      .select("role,status")
      .eq("id", user.id)
      .maybeSingle();
    if (!profile || profile.role !== "admin" || profile.status !== "active") {
      return json({ error: "Admin account required for OCR menu import." }, 403);
    }

    const body = await req.json();
    const shopId = String(body.shop_id ?? "").trim();
    const shopName = String(body.shop_name ?? "Pasabuy shop").trim();
    const filename = String(body.filename ?? "menu-image").trim();
    const mimeType = String(body.mime_type ?? "image/jpeg").trim();
    const imageBase64 = String(body.image_base64 ?? "").trim();

    if (!shopId || !imageBase64) return json({ error: "shop_id and image_base64 are required." }, 400);
    if (imageBase64.length > 16_000_000) return json({ error: "Image is too large. Use a photo under about 10 MB." }, 413);

    const prompt = `You are Karlivery's restaurant-menu OCR parser. Read this menu image carefully and return ONLY valid JSON.\n\nShop: ${shopName}\nFilename: ${filename}\n\nExtract every menu item that is visibly readable. Preserve item codes when shown (example: C1, Y2, B3). Do not invent prices. If a price is unreadable, use null. Group each item under a concise category. Also detect obvious add-ons/upgrade choices shown in the same menu, such as add rice, spicy upgrade, drink upgrade, extra cheese.\n\nReturn exactly this shape:\n{\n  "items": [\n    {\n      "category": "Chickenjoy",\n      "name": "C1 1-pc Chickenjoy",\n      "price": 105,\n      "addons": [{"name":"Spicy upgrade","price":7}],\n      "confidence": 0.95\n    }\n  ],\n  "notes": ["Any ambiguous text or price that an admin should review"]\n}\n\nRules:\n- Price is a number in Philippine pesos without the currency symbol, or null.\n- confidence is 0 to 1.\n- Never fabricate a missing item, price, brand, or promotion.\n- Do not output markdown or commentary outside JSON.`;

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${openAiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model,
        input: [{
          role: "user",
          content: [
            { type: "input_text", text: prompt },
            { type: "input_image", image_url: `data:${mimeType};base64,${imageBase64}`, detail: "high" },
          ],
        }],
        max_output_tokens: 6000,
      }),
    });

    const responseText = await response.text();
    if (!response.ok) {
      console.error("OpenAI OCR request failed:", response.status, responseText);
      return json({ error: `OCR provider returned ${response.status}.`, details: responseText }, 502);
    }

    const payload = JSON.parse(responseText);
    const outputText = readOutputText(payload);
    if (!outputText) return json({ error: "OCR provider returned no readable text." }, 502);

    let parsed: any;
    try {
      parsed = parseJsonText(outputText);
    } catch (error) {
      console.error("OCR JSON parse failed", error, outputText);
      return json({ error: "OCR result could not be parsed as structured menu data.", raw: outputText }, 502);
    }

    const items = Array.isArray(parsed?.items) ? parsed.items : [];
    const normalized = items
      .map((item: any) => ({
        category: String(item?.category ?? "Menu").trim() || "Menu",
        name: String(item?.name ?? "").trim(),
        price: item?.price == null ? null : Number(item.price),
        addons: Array.isArray(item?.addons)
          ? item.addons.map((a: any) => ({
              name: String(a?.name ?? "").trim(),
              price: a?.price == null ? 0 : Number(a.price),
            })).filter((a: any) => a.name)
          : [],
        confidence: Number.isFinite(Number(item?.confidence)) ? Number(item.confidence) : null,
      }))
      .filter((item: any) => item.name);

    await admin.from("pasabuy_menu_images").insert({
      shop_id: shopId,
      source_label: filename,
      upload_notes: "AI/OCR import through Karlivery Pasabuy Studio",
      imported_json: { items: normalized, notes: parsed?.notes ?? [] },
    });

    return json({
      items: normalized,
      notes: Array.isArray(parsed?.notes) ? parsed.notes : [],
      model,
      count: normalized.length,
    });
  } catch (error) {
    console.error(error);
    return json({ error: String(error) }, 500);
  }
});
