# Karlivery - build on Windows

Prerequisites: Flutter SDK, Chrome, and (for APK) Android Studio + SDK. Run `flutter doctor` first.

| What you want | Double-click | Output |
|---|---|---|
| Website for Cloudflare Pages | BUILD_WEB.cmd | build\web\ and build\Karlivery_Cloudflare_Pages.zip |
| Android APK | BUILD_APK.cmd | build\Karlivery-release.apk |
| Both | BUILD_BOTH.cmd | all of the above |

When a build finishes it prints the full paths, saves them to BUILD_OUTPUT_PATHS.txt, and opens the build folder.

APK: leave the prompt blank to auto-generate a test Android project, or enter the path to your original
Karlivery project to keep its app ID and signing key.

Cloudflare Pages: upload the CONTENTS of build\web (drag the folder in the dashboard). Add your Pages URL
to Supabase Site URL + redirect allowlist.

Quick local test: `flutter run -d chrome`
