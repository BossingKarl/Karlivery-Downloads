# Karlivery UI upgrade (this release)

NOT compiled or run: no Flutter SDK was available. Run `flutter pub get`, `flutter analyze`, `flutter test` first.

## Done
1. Shared image primitive `lib/design_system/k_network_image.dart` (KNetImage, KShimmer, KStoreCardSkeleton): shimmer placeholder, fade-in, decode at display size (cacheWidth). All 33 `Image.network` call sites now use it.
2. Typography: every fontSize below 12 raised to 12 (73 places); FontWeight w800/w900 flattened to w700 (200 places). Token scale in k_tokens.dart updated (hero/section/money stay w800).
3. Home (customer_shell.dart): search + filter chips pinned; "Order again" row from real past orders (new customers see a compact hero instead); restaurants moved above dish spotlight and Pabili; skeleton grid while loading; duplicate "Deliver to" label removed.
4. Store card: ETA (eta_min_minutes/eta_max_minutes from home feed) added; star/open/closed colors moved to KPalette.
5. Consolidation (partial): deleted dead `ios_food_components.dart`, `food_first_design.dart` and its test; removed AppTheme green/lime aliases; hex literals matching palette tokens replaced with KPalette. About 200 one-off colors and the modern_ui / future_food_ui / karlivery_2026 layers still exist: migrate gradually.
6. Cart: sticky subtotal + Secure checkout bar; item thumbnails.

## Review first
- Raising small fonts to 12 may overflow tight badges/chips; check on a 360px device and at 1.3x text scale.
- "Order again" opens the store page; it does not auto-fill the basket.
- Menu (store_screen) and checkout got the image/type/token changes only, no layout redesign.
