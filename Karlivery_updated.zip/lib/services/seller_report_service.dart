import 'dart:convert';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:intl/intl.dart';

class SellerReportService {
  SellerReportService._();

  static final DateFormat _date = DateFormat('yyyy-MM-dd HH:mm');

  static List<List<String>> _rows(List<Map<String, dynamic>> orders) {
    final rows = <List<String>>[
      [
        'Order No',
        'Date',
        'Status',
        'Payment',
        'Fulfillment',
        'Recipient',
        'Address',
        'Subtotal',
        'Delivery Fee',
        'Total',
      ],
    ];

    for (final o in orders) {
      rows.add([
        (o['order_no'] ?? '').toString(),
        _formatDate(o['created_at']),
        (o['status'] ?? '').toString(),
        (o['payment_method'] ?? '').toString().toUpperCase(),
        (o['fulfillment'] ?? '').toString(),
        (o['recipient_name'] ?? '').toString(),
        (o['delivery_address'] ?? '').toString(),
        _num(o['subtotal']),
        _num(o['delivery_fee']),
        _num(o['total']),
      ]);
    }

    return rows;
  }

  static String _formatDate(dynamic value) {
    final dt = DateTime.tryParse(value?.toString() ?? '');
    if (dt == null) return '';
    return _date.format(dt.toLocal());
  }

  static String _num(dynamic value) {
    final n = num.tryParse(value?.toString() ?? '') ?? 0;
    return n.toStringAsFixed(2);
  }

  static String _csvCell(String value) =>
      '"${value.replaceAll('"', '""')}"';

  static String _xml(String value) => value
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&apos;');

  static String _ascii(String value) {
    final normalized = value
        .replaceAll('₱', 'PHP ')
        .replaceAll('•', '-')
        .replaceAll('—', '-')
        .replaceAll('–', '-')
        .replaceAll('’', "'")
        .replaceAll('“', '"')
        .replaceAll('”', '"');
    return normalized.codeUnits
        .map((c) => c >= 32 && c <= 126 ? String.fromCharCode(c) : '?')
        .join();
  }

  static Future<bool> saveCsv({
    required String storeName,
    required List<Map<String, dynamic>> orders,
  }) async {
    final data = _rows(orders)
        .map((r) => r.map(_csvCell).join(','))
        .join('\r\n');

    final bytes = Uint8List.fromList(utf8.encode('\uFEFF$data'));
    final path = await FilePicker.platform.saveFile(
      dialogTitle: 'Save Karlivery CSV report',
      fileName: '${_safeFileName(storeName)}_orders.csv',
      bytes: bytes,
    );
    return path != null;
  }

  static Future<bool> saveExcel({
    required String storeName,
    required List<Map<String, dynamic>> orders,
  }) async {
    final rows = _rows(orders);

    final out = StringBuffer()
      ..writeln('<?xml version="1.0"?>')
      ..writeln('<?mso-application progid="Excel.Sheet"?>')
      ..writeln(
        '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" '
        'xmlns:o="urn:schemas-microsoft-com:office:office" '
        'xmlns:x="urn:schemas-microsoft-com:office:excel" '
        'xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">',
      )
      ..writeln('<Worksheet ss:Name="Orders"><Table>');

    for (var i = 0; i < rows.length; i++) {
      out.writeln('<Row>');
      for (final cell in rows[i]) {
        out.writeln(
          '<Cell><Data ss:Type="String">${_xml(cell)}</Data></Cell>',
        );
      }
      out.writeln('</Row>');
    }

    out
      ..writeln('</Table></Worksheet>')
      ..writeln('</Workbook>');

    final bytes = Uint8List.fromList(utf8.encode(out.toString()));
    final path = await FilePicker.platform.saveFile(
      dialogTitle: 'Save Karlivery Excel report',
      fileName: '${_safeFileName(storeName)}_orders.xls',
      bytes: bytes,
    );
    return path != null;
  }

  static Future<bool> savePdf({
    required String storeName,
    required List<Map<String, dynamic>> orders,
  }) async {
    final lines = <String>[
      'KARLIVERY SELLER ORDER REPORT',
      'Store: ${_ascii(storeName)}',
      'Generated: ${_date.format(DateTime.now())}',
      'Records: ${orders.length}',
      '',
      'ORDER | DATE | STATUS | PAYMENT | TYPE | TOTAL',
      List.filled(82, '-').join(),
      ...orders.map((o) {
        final orderNo = _clip(_ascii((o['order_no'] ?? '').toString()), 14);
        final date = _clip(_formatDate(o['created_at']), 16);
        final status = _clip(_ascii((o['status'] ?? '').toString()), 15);
        final payment = _clip(
          _ascii((o['payment_method'] ?? '').toString().toUpperCase()),
          7,
        );
        final fulfillment = _clip(
          _ascii((o['fulfillment'] ?? '').toString()),
          8,
        );
        final total = _num(o['total']);
        return '$orderNo | $date | $status | $payment | $fulfillment | PHP $total';
      }),
      '',
      'Gross filtered order value: PHP ${orders.fold<double>(0, (sum, o) => sum + (double.tryParse(o['total']?.toString() ?? '') ?? 0)).toStringAsFixed(2)}',
    ];

    final bytes = _simplePdf(lines);
    final path = await FilePicker.platform.saveFile(
      dialogTitle: 'Save Karlivery PDF report',
      fileName: '${_safeFileName(storeName)}_orders.pdf',
      bytes: bytes,
    );
    return path != null;
  }

  static String _clip(String value, int max) =>
      value.length <= max ? value : value.substring(0, max);

  static String _safeFileName(String value) {
    final clean = value
        .replaceAll(RegExp(r'[^A-Za-z0-9_-]+'), '_')
        .replaceAll(RegExp(r'_+'), '_');
    return clean.isEmpty ? 'karlivery_store' : clean;
  }

  static String _pdfEscape(String value) => _ascii(value)
      .replaceAll('\\', '\\\\')
      .replaceAll('(', r'\(')
      .replaceAll(')', r'\)');

  static Uint8List _simplePdf(List<String> lines) {
    const pageSize = 48;
    final pages = <List<String>>[];
    for (var i = 0; i < lines.length; i += pageSize) {
      pages.add(
        lines.sublist(
          i,
          i + pageSize > lines.length ? lines.length : i + pageSize,
        ),
      );
    }
    if (pages.isEmpty) pages.add(['Karlivery Report']);

    final pageCount = pages.length;
    final firstPageObj = 4;
    final firstContentObj = firstPageObj + pageCount;
    final objectCount = 3 + pageCount * 2;

    final objects = <int, String>{};
    objects[1] = '<< /Type /Catalog /Pages 2 0 R >>';

    final kids = List.generate(
      pageCount,
      (i) => '${firstPageObj + i} 0 R',
    ).join(' ');

    objects[2] = '<< /Type /Pages /Kids [$kids] /Count $pageCount >>';
    objects[3] =
        '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>';

    for (var i = 0; i < pageCount; i++) {
      final pageObj = firstPageObj + i;
      final contentObj = firstContentObj + i;

      objects[pageObj] =
          '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] '
          '/Resources << /Font << /F1 3 0 R >> >> '
          '/Contents $contentObj 0 R >>';

      final stream = StringBuffer()
        ..writeln('BT')
        ..writeln('/F1 9 Tf')
        ..writeln('42 800 Td');

      for (final line in pages[i]) {
        stream.writeln('(${_pdfEscape(line)}) Tj');
        stream.writeln('0 -15 Td');
      }

      stream.writeln('ET');
      final content = stream.toString();
      objects[contentObj] =
          '<< /Length ${latin1.encode(content).length} >>\n'
          'stream\n$content'
          'endstream';
    }

    final out = StringBuffer('%PDF-1.4\n');
    final offsets = <int>[0];

    for (var i = 1; i <= objectCount; i++) {
      offsets.add(latin1.encode(out.toString()).length);
      out
        ..writeln('$i 0 obj')
        ..writeln(objects[i] ?? '<< >>')
        ..writeln('endobj');
    }

    final xref = latin1.encode(out.toString()).length;
    out
      ..writeln('xref')
      ..writeln('0 ${objectCount + 1}')
      ..writeln('0000000000 65535 f ');

    for (var i = 1; i <= objectCount; i++) {
      out.writeln('${offsets[i].toString().padLeft(10, '0')} 00000 n ');
    }

    out
      ..writeln('trailer')
      ..writeln('<< /Size ${objectCount + 1} /Root 1 0 R >>')
      ..writeln('startxref')
      ..writeln('$xref')
      ..writeln('%%EOF');

    return Uint8List.fromList(latin1.encode(out.toString()));
  }
}
