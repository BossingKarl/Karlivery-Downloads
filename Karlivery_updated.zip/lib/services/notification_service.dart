import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/push_config.dart';
import 'web_push/web_push_bridge.dart';

class NotificationService {
  NotificationService._();

  static final FlutterLocalNotificationsPlugin _local =
      FlutterLocalNotificationsPlugin();

  static StreamSubscription<List<Map<String, dynamic>>>? _fallbackSub;
  static String? _fallbackLastId;
  static bool _oneSignalInitialized = false;
  static bool _webPushInitialized = false;
  static bool _webPushPermission = false;
  static bool _localInitialized = false;
  static bool _initializing = false;

  static void Function(String route)? onOpenRoute;

  static String? routeForNotificationData(Map<String, dynamic>? data) {
    if (data == null) return null;
    final screen = data['screen']?.toString();
    final pabiliId = data['pasabuy_order_id']?.toString() ??
        (data['order_type'] == 'pabili' ? data['order_id']?.toString() : null);
    if (pabiliId != null && pabiliId.isNotEmpty) {
      final safe = Uri.encodeComponent(pabiliId);
      if (screen == 'pabili_chat' || screen == 'chat') {
        return '/pasabuy/chat/$safe';
      }
      if (screen == 'pabili_tracking' || screen == 'tracking') {
        return '/pasabuy/track/$safe';
      }
      return '/pasabuy/order/$safe';
    }
    final orderId = data['order_id']?.toString();
    if (screen == 'chat' && orderId != null && orderId.isNotEmpty) {
      return '/chat/$orderId';
    }
    if (screen == 'tracking' && orderId != null && orderId.isNotEmpty) {
      return '/track/$orderId';
    }
    if (screen == 'order' && orderId != null && orderId.isNotEmpty) {
      return '/order/$orderId';
    }
    if (screen == 'notifications' || screen == 'announcement') {
      return '/notifications';
    }
    return null;
  }

  static bool get truePushEnabled => kIsWeb
      ? _webPushInitialized && _webPushPermission
      : PushConfig.enabled && _oneSignalInitialized;

  static bool get webPushReady => kIsWeb && _webPushInitialized;
  static bool get webAppInstalled => kIsWeb && webAppStandalone();

  static Future<void> init() async {
    if (_initializing) return;
    _initializing = true;

    if (kIsWeb) {
      try {
        _webPushInitialized = await webPushInitialize();
        if (_webPushInitialized) {
          _webPushPermission = await webPushPermissionGranted();
        }
      } catch (e) {
        debugPrint('Karlivery web push init failed: $e');
        _webPushInitialized = false;
        _webPushPermission = false;
      } finally {
        _initializing = false;
      }
      return;
    }

    try {
      // Local notifications should never be able to crash app startup.
      try {
        const android =
            AndroidInitializationSettings('ic_stat_karlivery');
        const darwin = DarwinInitializationSettings(
          requestAlertPermission: false,
          requestBadgePermission: false,
          requestSoundPermission: false,
        );
        const settings = InitializationSettings(
          android: android,
          iOS: darwin,
        );
        await _local.initialize(settings);
        _localInitialized = true;
      } catch (e) {
        debugPrint('Karlivery custom notification icon init failed: $e');

        // Retry using Android's launcher icon, which always exists after
        // Flutter creates the Android project.
        try {
          const android =
              AndroidInitializationSettings('@mipmap/ic_launcher');
          const darwin = DarwinInitializationSettings(
            requestAlertPermission: false,
            requestBadgePermission: false,
            requestSoundPermission: false,
          );
          const settings = InitializationSettings(
            android: android,
            iOS: darwin,
          );
          await _local.initialize(settings);
          _localInitialized = true;
        } catch (fallbackError) {
          debugPrint(
            'Karlivery local notification fallback init failed: '
            '$fallbackError',
          );
          _localInitialized = false;
        }
      }

      if (PushConfig.enabled) {
        try {
          OneSignal.initialize(PushConfig.oneSignalAppId);
          _oneSignalInitialized = true;

          OneSignal.Notifications.addClickListener((event) {
            final raw = event.notification.additionalData;
            final data = raw == null
                ? null
                : Map<String, dynamic>.from(raw);
            final route = routeForNotificationData(data);
            if (route != null) onOpenRoute?.call(route);
          });
        } catch (e) {
          debugPrint('OneSignal init failed: $e');
          _oneSignalInitialized = false;
        }
      }
    } finally {
      _initializing = false;
    }
  }

  static Future<void> requestPermission() async {
    if (kIsWeb) {
      try {
        if (!_webPushInitialized) {
          await init();
        }

        if (_webPushInitialized && await webPushSupported()) {
          _webPushPermission = await webPushRequestPermission();
        }
      } catch (e) {
        debugPrint('Karlivery web push permission failed: $e');
        _webPushPermission = false;
      }
      return;
    }

    // This is called after the UI is already visible (login/notification
    // center), never before runApp.
    if (_oneSignalInitialized) {
      try {
        final canRequest =
            await OneSignal.Notifications.canRequest();
        if (canRequest) {
          await OneSignal.Notifications.requestPermission(true);
        }
        return;
      } catch (e) {
        debugPrint('OneSignal permission request failed: $e');
      }
    }

    if (_localInitialized) {
      try {
        final androidImpl =
            _local.resolvePlatformSpecificImplementation<
                AndroidFlutterLocalNotificationsPlugin>();
        await androidImpl?.requestNotificationsPermission();
      } catch (e) {
        debugPrint('Local notification permission request failed: $e');
      }
    }
  }

  static Future<void> startForCurrentUser() async {
    if (kIsWeb) {
      try {
        if (!_webPushInitialized) {
          await init();
        }

        final currentUser = Supabase.instance.client.auth.currentUser;

        if (currentUser == null) {
          if (_webPushInitialized) {
            await webPushLogout();
          }
          return;
        }

        if (_webPushInitialized) {
          await webPushLogin(currentUser.id);
          _webPushPermission = await webPushPermissionGranted();
        }
      } catch (e) {
        debugPrint('Karlivery web push user login failed: $e');
      }
      return;
    }

    await _fallbackSub?.cancel();
    _fallbackSub = null;

    User? currentUser;
    try {
      currentUser = Supabase.instance.client.auth.currentUser;
    } catch (e) {
      debugPrint('Notification auth lookup failed: $e');
      return;
    }

    if (currentUser == null) {
      if (_oneSignalInitialized) {
        try {
          OneSignal.logout();
        } catch (_) {}
      }
      return;
    }

    if (_oneSignalInitialized) {
      try {
        OneSignal.login(currentUser.id);
        return;
      } catch (e) {
        debugPrint('OneSignal login failed; using realtime fallback: $e');
      }
    }

    // Realtime/local fallback if OneSignal is unavailable.
    try {
      _fallbackSub = Supabase.instance.client
          .from('notifications')
          .stream(primaryKey: ['id'])
          .eq('user_id', currentUser.id)
          .order('created_at')
          .listen(
        (rows) async {
          if (rows.isEmpty) return;

          final latest = Map<String, dynamic>.from(rows.last);
          final id = latest['id']?.toString();

          if (id == null || id == _fallbackLastId) return;

          if (_fallbackLastId != null) {
            await showLocal(
              title: latest['title']?.toString() ?? 'Karlivery',
              body: latest['message']?.toString() ?? '',
            );
          }

          _fallbackLastId = id;
        },
        onError: (Object e) {
          debugPrint('Notification fallback stream error: $e');
        },
      );
    } catch (e) {
      debugPrint('Notification fallback setup failed: $e');
    }
  }

  static Future<void> stop() async {
    if (kIsWeb) {
      try {
        await webPushLogout();
      } catch (_) {}
      _webPushPermission = false;
      return;
    }

    try {
      await _fallbackSub?.cancel();
    } catch (_) {}
    _fallbackSub = null;
    _fallbackLastId = null;

    if (_oneSignalInitialized) {
      try {
        OneSignal.logout();
      } catch (_) {}
    }
  }

  static Future<void> showLoginNotification({
    required String role,
    String displayName = '',
  }) async {
    final label = switch (role) {
      'store_owner' => 'Seller',
      'rider' => 'Rider',
      'admin' => 'Administrator',
      _ => 'Customer',
    };

    final name = displayName.trim();

    try {
      await showLocal(
        title: name.isEmpty ? 'Welcome to Karlivery' : 'Welcome, $name',
        body: 'Signed in successfully as $label.',
      );
    } catch (e) {
      debugPrint('Login notification failed: $e');
    }
  }

  static Future<void> showLocal({
    required String title,
    required String body,
  }) async {
    if (kIsWeb || !_localInitialized) return;

    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        'karlivery_orders',
        'Karlivery Orders & Delivery',
        channelDescription:
            'Order, delivery, rider, payment, chat, and announcement updates',
        importance: Importance.high,
        priority: Priority.high,
        playSound: true,
        enableVibration: true,
        icon: 'ic_stat_karlivery',
      ),
      iOS: DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
      ),
    );

    try {
      await _local.show(
        DateTime.now()
            .millisecondsSinceEpoch
            .remainder(2147483647),
        title,
        body,
        details,
      );
    } catch (e) {
      debugPrint('Local notification display failed: $e');
    }
  }
}
