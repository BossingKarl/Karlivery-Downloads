import 'dart:js_interop';

@JS('karliveryPushInit')
external JSPromise<JSBoolean> _pushInit();

@JS('karliveryPushRequestPermission')
external JSPromise<JSBoolean> _pushRequestPermission();

@JS('karliveryPushPermissionGranted')
external JSPromise<JSBoolean> _pushPermissionGranted();

@JS('karliveryPushSupported')
external JSPromise<JSBoolean> _pushSupported();

@JS('karliveryPushLogin')
external JSPromise<JSBoolean> _pushLogin(JSString userId);

@JS('karliveryPushLogout')
external JSPromise<JSBoolean> _pushLogout();

@JS('karliveryIsStandalone')
external JSBoolean _isStandalone();

Future<bool> webPushInitialize() async =>
    (await _pushInit().toDart).toDart;

Future<bool> webPushRequestPermission() async =>
    (await _pushRequestPermission().toDart).toDart;

Future<bool> webPushPermissionGranted() async =>
    (await _pushPermissionGranted().toDart).toDart;

Future<bool> webPushSupported() async =>
    (await _pushSupported().toDart).toDart;

Future<void> webPushLogin(String userId) async {
  await _pushLogin(userId.toJS).toDart;
}

Future<void> webPushLogout() async {
  await _pushLogout().toDart;
}

bool webAppStandalone() => _isStandalone().toDart;
