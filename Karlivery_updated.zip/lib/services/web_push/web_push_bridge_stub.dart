Future<bool> webPushInitialize() async => false;
Future<bool> webPushRequestPermission() async => false;
Future<bool> webPushPermissionGranted() async => false;
Future<bool> webPushSupported() async => false;
Future<void> webPushLogin(String userId) async {}
Future<void> webPushLogout() async {}
bool webAppStandalone() => false;
