import 'package:url_launcher/url_launcher.dart';

class IntegrationService {
  IntegrationService._();

  static Future<bool> openNavigation(String destination) async {
    final clean = destination.trim();
    if (clean.isEmpty) return false;
    final uri = Uri.parse(
      'https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent(clean)}',
    );
    return launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  static Future<bool> call(String phone) async {
    final clean = phone.replaceAll(RegExp(r'[^0-9+]'), '');
    if (clean.isEmpty) return false;
    return launchUrl(Uri.parse('tel:$clean'));
  }

  static Future<bool> sms(String phone, {String body = ''}) async {
    final clean = phone.replaceAll(RegExp(r'[^0-9+]'), '');
    if (clean.isEmpty) return false;
    final uri = Uri(
      scheme: 'sms',
      path: clean,
      queryParameters: body.isEmpty ? null : {'body': body},
    );
    return launchUrl(uri);
  }

  static const capabilities = <Map<String, String>>[
    {
      'name': 'Supabase Auth + RLS',
      'status': 'Active',
      'detail': 'Authentication, secure roles and database policies',
    },
    {
      'name': 'Supabase Realtime',
      'status': 'Active',
      'detail': 'Order updates, chat and rider location streams',
    },
    {
      'name': 'Supabase Storage',
      'status': 'Active',
      'detail': 'Store logos, menu photos, gallery and payment proofs',
    },
    {
      'name': 'OpenStreetMap',
      'status': 'Active',
      'detail': 'In-app map rendering with flutter_map',
    },
    {
      'name': 'Device GPS + Geocoding',
      'status': 'Active',
      'detail': 'Address pinning and rider live location',
    },
    {
      'name': 'External navigation',
      'status': 'Active',
      'detail': 'Open delivery addresses in the phone map application',
    },
    {
      'name': 'Order chat calling',
      'status': 'On hold',
      'detail': 'Calling from order chat is disabled; text messaging remains available',
    },
    {
      'name': 'Android local notifications',
      'status': 'Active',
      'detail': 'Realtime in-app order notification alerts',
    },
    {
      'name': 'Firebase Cloud Messaging',
      'status': 'Optional',
      'detail': 'Needed for push alerts when the app is fully closed',
    },
    {
      'name': 'Official GCash gateway',
      'status': 'Optional',
      'detail': 'Requires merchant/payment-provider credentials; current flow uses proof verification',
    },
  ];
}
