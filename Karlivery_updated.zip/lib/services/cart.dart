import 'package:flutter/foundation.dart';

class CartLine {
  final String key;
  final Map<String, dynamic> product;
  final List<Map<String, dynamic>> addons;
  int quantity;

  CartLine({
    required this.key,
    required this.product,
    required this.addons,
    required this.quantity,
  });

  double get basePrice => double.tryParse(product['price'].toString()) ?? 0;

  double get addonPrice => addons.fold<double>(
        0,
        (sum, a) => sum + (double.tryParse(a['price'].toString()) ?? 0),
      );

  double get unitPrice => basePrice + addonPrice;
  double get subtotal => unitPrice * quantity;
}

class CartService extends ChangeNotifier {
  CartService._();
  static final CartService instance = CartService._();

  String? storeId;
  String? storeName;
  final Map<String, CartLine> _lines = {};

  List<CartLine> get lines => _lines.values.toList();
  int get count => _lines.values.fold(0, (a, b) => a + b.quantity);
  double get subtotal => _lines.values.fold(0, (a, b) => a + b.subtotal);

  void add(
    Map<String, dynamic> product,
    String sId,
    String sName, {
    List<Map<String, dynamic>> addons = const [],
    int quantity = 1,
  }) {
    if (storeId != null && storeId != sId && _lines.isNotEmpty) {
      throw StateError('The basket contains items from another restaurant. Confirm replacement first.');
    }

    storeId = sId;
    storeName = sName;

    final addonIds = addons.map((a) => a['id'].toString()).toList()..sort();
    final key = '${product['id']}|${addonIds.join(",")}';

    final safeQuantity = quantity < 1 ? 1 : quantity;

    _lines.update(
      key,
      (v) => v..quantity += safeQuantity,
      ifAbsent: () => CartLine(
        key: key,
        product: Map<String, dynamic>.from(product),
        addons: addons.map((a) => Map<String, dynamic>.from(a)).toList(),
        quantity: safeQuantity,
      ),
    );
    notifyListeners();
  }

  void change(String key, int delta) {
    final line = _lines[key];
    if (line == null) return;

    line.quantity += delta;
    if (line.quantity <= 0) _lines.remove(key);

    if (_lines.isEmpty) {
      storeId = null;
      storeName = null;
    }
    notifyListeners();
  }

  void clear() {
    _lines.clear();
    storeId = null;
    storeName = null;
    notifyListeners();
  }

  List<Map<String, dynamic>> toOrderItems() => lines
      .map(
        (e) => {
          'product_id': e.product['id'],
          'quantity': e.quantity,
          'addon_ids': e.addons.map((a) => a['id']).toList(),
        },
      )
      .toList();
}
