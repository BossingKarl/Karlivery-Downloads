class StoreSchedule {
  StoreSchedule._();

  static bool isOpenNow(Map<String, dynamic> store, {DateTime? now}) {
    final manualOpen = store['is_open'] == true;
    if (!manualOpen) return false;

    if (store['schedule_enabled'] != true) return manualOpen;

    final current = now ?? DateTime.now();
    final days = _intList(store['opening_days']);

    final open = _minutes(store['opening_time']?.toString());
    final close = _minutes(store['closing_time']?.toString());
    if (open == null || close == null) return manualOpen;

    final minute = current.hour * 60 + current.minute;
    if (open == close) {
      return days.isEmpty || days.contains(current.weekday);
    }

    if (close > open) {
      if (days.isNotEmpty && !days.contains(current.weekday)) return false;
      return minute >= open && minute < close;
    }

    // Overnight schedule, e.g. Friday 6 PM to Saturday 2 AM.
    if (minute >= open) {
      return days.isEmpty || days.contains(current.weekday);
    }

    if (minute < close) {
      final previousDay = current.weekday == DateTime.monday
          ? DateTime.sunday
          : current.weekday - 1;
      return days.isEmpty || days.contains(previousDay);
    }

    return false;
  }

  static String scheduleLabel(Map<String, dynamic> store) {
    if (store['schedule_enabled'] != true) {
      return store['is_open'] == true ? 'Open manually' : 'Closed';
    }

    final open = _prettyTime(store['opening_time']?.toString());
    final close = _prettyTime(store['closing_time']?.toString());
    final days = _intList(store['opening_days']);
    final dayText = _daySummary(days);
    return '$dayText • $open–$close';
  }

  static List<int> _intList(dynamic raw) {
    if (raw is List) {
      return raw.map((e) => int.tryParse(e.toString())).whereType<int>().toList();
    }
    return const [];
  }

  static int? _minutes(String? raw) {
    if (raw == null || raw.isEmpty) return null;
    final value = raw.split('.').first;
    final parts = value.split(':');
    if (parts.length < 2) return null;
    final h = int.tryParse(parts[0]);
    final m = int.tryParse(parts[1]);
    if (h == null || m == null) return null;
    return h * 60 + m;
  }

  static String _prettyTime(String? raw) {
    final mins = _minutes(raw);
    if (mins == null) return '--:--';
    final h24 = mins ~/ 60;
    final m = mins % 60;
    final h12 = h24 % 12 == 0 ? 12 : h24 % 12;
    final suffix = h24 >= 12 ? 'PM' : 'AM';
    return '$h12:${m.toString().padLeft(2, '0')} $suffix';
  }

  static String _daySummary(List<int> days) {
    if (days.length == 7) return 'Daily';
    if (days.length == 5 &&
        const [1, 2, 3, 4, 5].every(days.contains)) {
      return 'Mon–Fri';
    }
    const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return days
        .where((d) => d >= 1 && d <= 7)
        .map((d) => labels[d - 1])
        .join(', ');
  }
}
