import 'package:flutter/foundation.dart';

class PasabuyCartLine {
  final String key;
  final Map<String, dynamic> item;
  final List<Map<String, dynamic>> addons;
  int quantity;
  String note;

  PasabuyCartLine({
    required this.key,
    required this.item,
    required this.addons,
    required this.quantity,
    this.note = '',
  });

  double get basePrice => double.tryParse(item['price']?.toString() ?? '') ?? 0;
  double get addonPrice => addons.fold<double>(
        0,
        (sum, addon) =>
            sum + (double.tryParse(addon['price']?.toString() ?? '') ?? 0),
      );
  double get unitPrice => basePrice + addonPrice;
  double get subtotal => unitPrice * quantity;
}

class PasabuyCartService extends ChangeNotifier {
  PasabuyCartService._();

  static final PasabuyCartService instance = PasabuyCartService._();

  String? shopId;
  String? shopName;
  Map<String, dynamic>? shop;
  String customRequest = '';
  double customRequestAmount = 0;
  final Map<String, PasabuyCartLine> _lines = {};

  List<PasabuyCartLine> get lines => _lines.values.toList();
  int get count => _lines.values.fold(0, (sum, line) => sum + line.quantity) + (customRequest.trim().isEmpty ? 0 : 1);
  double get subtotal =>
      _lines.values.fold<double>(
        0.0,
        (sum, line) => sum + line.subtotal,
      ) + customRequestAmount;
  bool get isEmpty => _lines.isEmpty && customRequest.trim().isEmpty;

  void setShop(Map<String, dynamic> value) {
    final id = value['id']?.toString();
    if (id == null || id.isEmpty) return;
    if (shopId != null && shopId != id && !isEmpty) {
      throw StateError('Another Pabili request is saved. Confirm replacement first.');
    }
    shopId = id;
    shopName = value['name']?.toString() ?? 'Pabili store';
    shop = Map<String, dynamic>.from(value);
    notifyListeners();
  }

  void add(
    Map<String, dynamic> item, {
    List<Map<String, dynamic>> addons = const [],
    int quantity = 1,
    String note = '',
  }) {
    final sId = item['shop_id']?.toString();
    if (sId == null || sId.isEmpty) return;

    if (shopId != null && shopId != sId) {
      _lines.clear();
      customRequest = '';
      customRequestAmount = 0;
    }

    shopId = sId;
    final addonIds = addons.map((a) => a['id'].toString()).toList()..sort();
    final normalizedNote = note.trim();
    final key = '${item['id']}|${addonIds.join(',')}|$normalizedNote';
    final safeQuantity = quantity < 1 ? 1 : quantity;

    _lines.update(
      key,
      (line) => line..quantity += safeQuantity,
      ifAbsent: () => PasabuyCartLine(
        key: key,
        item: Map<String, dynamic>.from(item),
        addons: addons.map((a) => Map<String, dynamic>.from(a)).toList(),
        quantity: safeQuantity,
        note: normalizedNote,
      ),
    );
    notifyListeners();
  }

  void changeQuantity(String key, int delta) {
    final line = _lines[key];
    if (line == null) return;
    line.quantity += delta;
    if (line.quantity <= 0) _lines.remove(key);
    _resetIfEmpty();
    notifyListeners();
  }

  void remove(String key) {
    _lines.remove(key);
    _resetIfEmpty();
    notifyListeners();
  }

  void setCustomRequest(String value) {
    customRequest = value.trim();
    notifyListeners();
  }

  void setCustomRequestAmount(double value) {
    customRequestAmount = value < 0 ? 0 : value;
    notifyListeners();
  }

  void clear() {
    _lines.clear();
    customRequest = '';
    customRequestAmount = 0;
    shopId = null;
    shopName = null;
    shop = null;
    notifyListeners();
  }

  void _resetIfEmpty() {
    if (_lines.isEmpty && customRequest.trim().isEmpty) {
      customRequestAmount = 0;
      shopId = null;
      shopName = null;
      shop = null;
    }
  }

  List<Map<String, dynamic>> toOrderItems() => lines
      .map(
        (line) => {
          'item_id': line.item['id'],
          'quantity': line.quantity,
          'addon_ids': line.addons.map((a) => a['id']).toList(),
          'note': line.note,
        },
      )
      .toList();
}
