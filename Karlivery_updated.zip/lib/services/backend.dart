import 'dart:typed_data';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../config/app_config.dart';
import 'store_schedule.dart';

class Backend {
  Backend._();
  static final SupabaseClient db = Supabase.instance.client;

  static User? get user => db.auth.currentUser;

  static Future<AuthResponse> login(String usernameOrEmail, String password) {
    final raw = usernameOrEmail.trim();
    final email =
        raw.toLowerCase() == AppConfig.adminAlias.toLowerCase()
            ? AppConfig.adminEmail
            : raw;
    return db.auth.signInWithPassword(email: email, password: password);
  }

  static Future<AuthResponse> register({
    required String fullName,
    required String phone,
    required String email,
    required String password,
  }) {
    return db.auth.signUp(
      email: email.trim(),
      password: password,
      data: {
        'full_name': fullName.trim(),
        'phone': phone.trim(),
        'role': 'customer',
      },
    );
  }


  static Future<AuthResponse> verifySignupCode({
    required String email,
    required String code,
  }) {
    return db.auth.verifyOTP(
      email: email.trim(),
      token: code.trim(),
      type: OtpType.signup,
    );
  }

  static Future<void> resendSignupCode(String email) async {
    await db.auth.resend(
      type: OtpType.signup,
      email: email.trim(),
    );
  }

  static Future<void> requestPasswordResetCode(String email) async {
    await db.auth.resetPasswordForEmail(email.trim());
  }

  static Future<AuthResponse> verifyPasswordResetCode({
    required String email,
    required String code,
  }) {
    return db.auth.verifyOTP(
      email: email.trim(),
      token: code.trim(),
      type: OtpType.recovery,
    );
  }

  static Future<void> finishPasswordReset(String newPassword) async {
    if (newPassword.length < 8) {
      throw Exception('Password must be at least 8 characters.');
    }
    await db.auth.updateUser(UserAttributes(password: newPassword));
  }

  static Future<Map<String, dynamic>?> access() async {
    final result = await db.rpc('get_my_access');
    if (result is List && result.isNotEmpty) {
      return Map<String, dynamic>.from(result.first as Map);
    }
    return null;
  }

  static Future<void> logout() => db.auth.signOut();

  // CUSTOMER
  static Future<List<Map<String, dynamic>>> approvedStores({
    String? addressId,
  }) async {
    try {
      final raw = await db.rpc(
        'karlivery_home_feed',
        params: {'p_address_id': addressId},
      );
      final stores = List<Map<String, dynamic>>.from(raw as List);
      return stores.map(_withEffectiveOpen).toList();
    } catch (_) {
      final rows = await db
          .from('stores')
          .select()
          .eq('is_approved', true)
          .order('is_open', ascending: false)
          .order('name');
      return List<Map<String, dynamic>>.from(rows)
          .map(_withEffectiveOpen)
          .toList();
    }
  }

  static Map<String, dynamic> _withEffectiveOpen(Map<String, dynamic> store) {
    final copy = Map<String, dynamic>.from(store);
    copy['manual_is_open'] = store['is_open'] == true;
    copy['is_open'] = StoreSchedule.isOpenNow(store);
    copy['schedule_label'] = StoreSchedule.scheduleLabel(store);
    return copy;
  }

  static Future<List<Map<String, dynamic>>> featuredProducts({
    int limit = 16,
  }) async {
    try {
      final raw = await db.rpc(
        'karlivery_featured_products',
        params: {'p_limit': limit},
      );
      return List<Map<String, dynamic>>.from(raw as List);
    } catch (_) {
      return <Map<String, dynamic>>[];
    }
  }

  /// Optional database migration 41 enables public, approved-store-wide menu search.
  /// If not installed, the home feed's featured-dish search still works.
  static Future<List<Map<String, dynamic>>> searchMenuProducts(
    String query, {int limit = 40}
  ) async {
    final term = query.trim();
    if (term.length < 2) return <Map<String, dynamic>>[];
    try {
      final raw = await db.rpc('karlivery_search_menu', params: {
        'p_query': term,
        'p_limit': limit,
      });
      return List<Map<String, dynamic>>.from(raw as List);
    } catch (_) {
      return <Map<String, dynamic>>[];
    }
  }

  static Future<Map<String, dynamic>?> storeById(String id) async {
    try {
      final raw = await db.rpc(
        'karlivery_public_store',
        params: {'p_store_id': id},
      );
      if (raw is List && raw.isNotEmpty) {
        return _withEffectiveOpen(
          Map<String, dynamic>.from(raw.first as Map),
        );
      }
    } catch (_) {
      if (user != null) {
        final row = await db.from('stores').select().eq('id', id).maybeSingle();
        if (row != null) return _withEffectiveOpen(Map<String, dynamic>.from(row));
      }
    }
    return null;
  }

  static Future<List<Map<String, dynamic>>> productsForStore(
    String storeId,
  ) async {
    try {
      final raw = await db.rpc(
        'karlivery_public_products',
        params: {'p_store_id': storeId},
      );
      return List<Map<String, dynamic>>.from(raw as List);
    } catch (_) {
      if (user == null) return <Map<String, dynamic>>[];
      final rows = await db
          .from('products')
          .select('*, product_addons(*)')
          .eq('store_id', storeId)
          .order('is_featured', ascending: false)
          .order('is_available', ascending: false)
          .order('category')
          .order('name');
      return List<Map<String, dynamic>>.from(rows);
    }
  }

  static Future<List<Map<String, dynamic>>> myAddresses() async {
    final rows = await db
        .from('addresses')
        .select()
        .order('is_default', ascending: false)
        .order('created_at');
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<void> addAddress({
    required String label,
    required String recipientName,
    required String phone,
    required String addressLine,
    required String barangay,
    String city = 'Camiling',
    String province = 'Tarlac',
    String landmark = '',
    double? latitude,
    double? longitude,
  }) async {
    await db.from('addresses').insert({
      'user_id': user!.id,
      'label': label,
      'recipient_name': recipientName,
      'phone': phone,
      'address_line': addressLine,
      'barangay': barangay.trim(),
      'city': city.trim().isEmpty ? 'Camiling' : city.trim(),
      'province': province.trim().isEmpty ? 'Tarlac' : province.trim(),
      'landmark': landmark,
      'latitude': latitude,
      'longitude': longitude,
    });
  }

  static Future<String> storeDeliveryProvider(String storeId) async {
    final value = await db.rpc('get_store_delivery_provider', params: {
      'p_store_id': storeId,
    });
    return value?.toString() == 'seller' ? 'seller' : 'karlivery';
  }

  /// Owner-selectable delivery for future regular-store orders.
  static Future<void> sellerSetDeliveryProvider({
    required String storeId,
    required String provider,
  }) async {
    if (provider != 'karlivery' && provider != 'seller') {
      throw ArgumentError.value(provider, 'provider');
    }
    await db.rpc('seller_set_delivery_provider', params: {
      'p_store_id': storeId,
      'p_provider': provider,
    });
  }

  static Future<void> sellerSelfDeliveryStatus(String orderId, String status) async {
    await db.rpc('seller_self_delivery_status', params: {
      'p_order_id': orderId,
      'p_new_status': status,
    });
    await Future.wait([
      if (!{'delivered', 'completed'}.contains(status.toLowerCase()))
        emailOrderUpdate(orderId),
      pushOrderEvent(orderId, 'order_update'),
    ]);
  }

  static Future<double> deliveryFee({
    required String storeId,
    required String addressId,
  }) async {
    final result = await db.rpc('get_delivery_fee', params: {
      'p_store_id': storeId,
      'p_address_id': addressId,
    });
    final fee = double.tryParse(result.toString());
    if (fee == null || !fee.isFinite || fee < 0) {
      throw StateError('Delivery fee unavailable. Please retry with a valid GPS address.');
    }
    return fee;
  }

  static Future<Map<String, dynamic>> createOrder({
    required String storeId,
    String? addressId,
    required String fulfillment,
    required String paymentMethod,
    required List<Map<String, dynamic>> items,
    required String notes,
    bool utensils = false,
  }) async {
    final result = await db.rpc('place_order_v8', params: {
      'p_store_id': storeId,
      'p_address_id': addressId,
      'p_fulfillment': fulfillment,
      'p_payment_method': paymentMethod,
      'p_items': items,
      'p_notes': notes,
      'p_utensils': utensils,
    });
    if (result is List && result.isNotEmpty) {
      final order = Map<String, dynamic>.from(result.first as Map);
      final orderId = order['id']?.toString();
      if (orderId != null && orderId.isNotEmpty) {
        await pushOrderEvent(orderId, 'new_order');
      }
      return order;
    }
    throw Exception('Order creation returned no result.');
  }

  static Future<Map<String, dynamic>> createGcashOrder({
    required String storeId,
    String? addressId,
    required String fulfillment,
    required List<Map<String, dynamic>> items,
    required String notes,
  }) async {
    final result = await db.rpc('place_gcash_order', params: {
      'p_store_id': storeId,
      'p_address_id': addressId,
      'p_fulfillment': fulfillment,
      'p_items': items,
      'p_notes': notes,
    });

    if (result is List && result.isNotEmpty) {
      final order = Map<String, dynamic>.from(result.first as Map);
      final orderId = order['id']?.toString();
      if (orderId != null && orderId.isNotEmpty) {
        await pushOrderEvent(orderId, 'new_order');
      }
      return order;
    }
    throw Exception('Order creation returned no result.');
  }

  static Future<String> uploadPaymentProof({
    required String orderId,
    required Uint8List bytes,
    required String extension,
  }) async {
    final path = '${user!.id}/$orderId/proof.$extension';
    await db.storage.from('payment-proofs').uploadBinary(
          path,
          bytes,
          fileOptions: const FileOptions(upsert: true),
        );
    return path;
  }

  static Future<void> submitPaymentProof({
    required String orderId,
    required String proofPath,
    required String referenceNo,
  }) async {
    await db.rpc('submit_payment_proof', params: {
      'p_order_id': orderId,
      'p_proof_path': proofPath,
      'p_reference_no': referenceNo.trim(),
    });
    // The customer confirmation below is the authoritative notification trigger.
  }

  static Future<void> customerConfirmGcashSent(String orderId) async {
    await db.rpc(
      'customer_confirm_gcash_sent',
      params: {'p_order_id': orderId},
    );
    await pushOrderEvent(orderId, 'payment_sent');
  }

  static Future<void> sellerConfirmGcashReceived(String orderId) async {
    await db.rpc(
      'seller_confirm_gcash_received',
      params: {'p_order_id': orderId},
    );
    try {
      await db.rpc('ensure_delivery_fee_settlement', params: {'p_order_id': orderId});
      await pushOrderEvent(orderId, 'rider_fee_due');
    } catch (_) {}
    await pushOrderEvent(orderId, 'payment_received');
  }

  static Future<void> sellerRejectGcashPayment(
    String orderId, {
    String reason = 'Please check the payment reference or proof and try again.',
  }) async {
    await db.rpc(
      'seller_reject_gcash_payment',
      params: {
        'p_order_id': orderId,
        'p_reason': reason.trim(),
      },
    );
    await pushOrderEvent(orderId, 'payment_attention');
  }

  static Future<List<Map<String, dynamic>>> myOrders() async {
    final rows = await db
        .from('orders')
        .select('*, stores(name)')
        .order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<List<Map<String, dynamic>>> myMessageOrders() async {
    final rows = await db
        .from('orders')
        .select('*, stores(name)')
        .order('updated_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<List<Map<String, dynamic>>> riderMessageOrders() async {
    final rows = await db
        .from('orders')
        .select('*, stores(name)')
        .eq('rider_id', user!.id)
        .inFilter('status', ['assigned', 'picked_up', 'delivering'])
        .order('updated_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<List<Map<String, dynamic>>> riderArchivedOrders() async {
    final rows = await db
        .from('orders')
        .select('*, stores(name)')
        .eq('rider_id', user!.id)
        .inFilter('status', ['delivered', 'completed', 'cancelled', 'rejected'])
        .order('updated_at', ascending: false)
        .limit(100);
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<Map<String, dynamic>?> orderChatContext(
    String orderId,
  ) async {
    final result = await db.rpc(
      'get_order_chat_context',
      params: {'p_order_id': orderId},
    );

    if (result is List && result.isNotEmpty) {
      return Map<String, dynamic>.from(result.first as Map);
    }
    return null;
  }

  static Future<List<Map<String, dynamic>>> myMessageThreads() async {
    final orders = await myMessageOrders();

    final enriched = await Future.wait(
      orders.map((order) async {
        try {
          final context = await orderChatContext(order['id'].toString());
          return {
            ...order,
            ...?context,
          };
        } catch (_) {
          return order;
        }
      }),
    );

    enriched.sort((a, b) {
      final aRaw = a['last_message_at'] ?? a['updated_at'] ?? a['created_at'];
      final bRaw = b['last_message_at'] ?? b['updated_at'] ?? b['created_at'];
      final ad = DateTime.tryParse(aRaw?.toString() ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0);
      final bd = DateTime.tryParse(bRaw?.toString() ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0);
      return bd.compareTo(ad);
    });

    return enriched;
  }

  static Future<Map<String, dynamic>?> myProfile() async {
    final row = await db
        .from('profiles')
        .select()
        .eq('id', user!.id)
        .maybeSingle();
    return row == null ? null : Map<String, dynamic>.from(row);
  }

  static Future<void> updateMyProfile({
    required String fullName,
    required String phone,
  }) async {
    await db.rpc('update_my_profile', params: {
      'p_full_name': fullName.trim(),
      'p_phone': phone.trim(),
    });
  }

  static Future<void> updateMyPassword(String password) async {
    if (password.length < 8) {
      throw Exception('Password must be at least 8 characters.');
    }
    await db.auth.updateUser(UserAttributes(password: password));
  }

  static Future<void> changeMyPassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    final signedInUser = user;
    final email = signedInUser?.email;
    if (signedInUser == null || email == null || email.trim().isEmpty) {
      throw Exception('Your signed-in account could not be verified.');
    }
    if (currentPassword.isEmpty) {
      throw Exception('Enter your current password.');
    }
    if (newPassword.length < 8) {
      throw Exception('New password must be at least 8 characters.');
    }
    if (currentPassword == newPassword) {
      throw Exception('Choose a new password that is different from your current password.');
    }

    final verified = await db.auth.signInWithPassword(
      email: email,
      password: currentPassword,
    );
    if (verified.user?.id != signedInUser.id) {
      throw Exception('Current password verification failed.');
    }

    await db.auth.updateUser(UserAttributes(password: newPassword));
  }

  static Future<void> deleteAddress(String addressId) async {
    await db
        .from('addresses')
        .delete()
        .eq('id', addressId)
        .eq('user_id', user!.id);
  }

  static Future<void> deleteMyCustomerAccount() async {
    final response = await db.functions.invoke(
      'admin-users',
      body: {'action': 'self_delete'},
    );
    if (response.status >= 400) {
      final data = response.data;
      if (data is Map && data['error'] != null) {
        throw Exception(data['error'].toString());
      }
      throw Exception('Could not delete account.');
    }
  }

  static Future<void> recordLoginNotification(String role) async {
    try {
      await db.rpc(
        'create_login_notification',
        params: {'p_role': role},
      );
    } catch (_) {
      // Login must never fail because notification history failed.
    }
  }

  static Future<void> markNotificationRead(String notificationId) async {
    await db.rpc(
      'mark_notification_read',
      params: {'p_notification_id': notificationId},
    );
  }

  static Future<void> markAllNotificationsRead() async {
    await db.rpc('mark_all_notifications_read');
  }

  static Future<Map<String, dynamic>?> myOrderRating(String orderId) async {
    final result = await db.rpc(
      'get_my_order_rating',
      params: {'p_order_id': orderId},
    );
    if (result is List && result.isNotEmpty) {
      return Map<String, dynamic>.from(result.first as Map);
    }
    return null;
  }

  static Future<void> submitOrderRating({
    required String orderId,
    required int storeRating,
    int? riderRating,
    String comment = '',
  }) async {
    await db.rpc(
      'submit_order_rating',
      params: {
        'p_order_id': orderId,
        'p_store_rating': storeRating,
        'p_rider_rating': riderRating,
        'p_comment': comment.trim(),
      },
    );
  }

  static Future<Map<String, dynamic>> riderRatingSummary() async {
    try {
      final result = await db.rpc(
        'get_rider_rating_stats',
        params: {'p_rider_id': user!.id},
      );
      if (result is List && result.isNotEmpty) {
        return Map<String, dynamic>.from(result.first as Map);
      }
    } catch (_) {}
    return {'rating_avg': null, 'rating_count': 0};
  }

  static Future<List<Map<String, dynamic>>> storeReviews(
    String storeId, {
    int limit = 60,
  }) async {
    final raw = await db.rpc(
      'karlivery_store_reviews',
      params: {'p_store_id': storeId, 'p_limit': limit},
    );
    return List<Map<String, dynamic>>.from(raw as List);
  }

  static Future<Map<String, dynamic>?> reorderPayload(String orderId) async {
    final raw = await db.rpc(
      'karlivery_reorder_payload',
      params: {'p_order_id': orderId},
    );
    if (raw is Map) return Map<String, dynamic>.from(raw);
    return null;
  }

  // STORE OWNER
  static Future<Map<String, dynamic>?> myStore() async {
    final row = await db
        .from('stores')
        .select()
        .eq('owner_id', user!.id)
        .maybeSingle();
    return row == null ? null : Map<String, dynamic>.from(row);
  }

  static Future<void> saveStoreOpeningHours({
    required String storeId,
    required bool enabled,
    required String openingTime,
    required String closingTime,
    required List<int> days,
  }) async {
    await db.rpc('seller_save_opening_hours', params: {
      'p_store_id': storeId,
      'p_enabled': enabled,
      'p_opening_time': openingTime,
      'p_closing_time': closingTime,
      'p_days': days,
    });
  }

  static Future<void> createStore({
    required String name,
    required String description,
    required String barangay,
    required String address,
    required String phone,
  }) async {
    await db.from('stores').insert({
      'owner_id': user!.id,
      'name': name,
      'description': description,
      'barangay': barangay,
      'address_text': address,
      'phone': phone,
    });
  }

  static Future<void> renameStore({
    required String storeId,
    required String name,
  }) async {
    final clean = name.trim();
    if (clean.length < 2) {
      throw Exception('Store name must be at least 2 characters.');
    }
    await db.rpc('seller_update_store_name', params: {
      'p_store_id': storeId,
      'p_name': clean,
    });
  }

  static Future<void> toggleStore(String id, bool open) async {
    await db.from('stores').update({'is_open': open}).eq('id', id);
  }

  static Future<String> uploadStoreQr({
    required String storeId,
    required Uint8List bytes,
    required String extension,
  }) async {
    final path =
        '${user!.id}/$storeId/gcash_${DateTime.now().millisecondsSinceEpoch}.$extension';
    await db.storage.from('store-gcash-qr').uploadBinary(
      path,
      bytes,
      fileOptions: const FileOptions(upsert: false),
    );
    return db.storage.from('store-gcash-qr').getPublicUrl(path);
  }

  static Future<void> saveGcash({
    required String storeId,
    required String number,
    required String qrUrl,
  }) async {
    await db.rpc('seller_save_gcash', params: {
      'p_store_id': storeId,
      'p_number': number.trim(),
      'p_qr_url': qrUrl.trim(),
    });
  }

  static Future<List<Map<String, dynamic>>> ownerProducts(String storeId) async {
    final rows = await db
        .from('products')
        .select('*, product_addons(*)')
        .eq('store_id', storeId)
        .order('is_featured', ascending: false)
        .order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<Map<String, dynamic>> addProduct({
    required String storeId,
    required String name,
    required String description,
    required String category,
    required double price,
    String? imageUrl,
    bool isFeatured = false,
    bool isAvailable = true,
    int prepTimeMin = 10,
    int prepTimeMax = 20,
  }) async {
    final row = await db.from('products').insert({
      'store_id': storeId,
      'name': name.trim(),
      'description': description.trim(),
      'category': category.trim().isEmpty ? 'Food' : category.trim(),
      'price': price,
      'image_url': imageUrl,
      'is_featured': isFeatured,
      'is_available': isAvailable,
      'prep_time_min': prepTimeMin,
      'prep_time_max': prepTimeMax,
    }).select().single();
    return Map<String, dynamic>.from(row);
  }

  static Future<void> updateProduct({
    required String productId,
    required String name,
    required String description,
    required String category,
    required double price,
    String? imageUrl,
    required bool isFeatured,
    required bool isAvailable,
    required int prepTimeMin,
    required int prepTimeMax,
  }) async {
    await db.rpc('seller_update_product', params: {
      'p_product_id': productId,
      'p_name': name.trim(),
      'p_description': description.trim(),
      'p_category': category.trim().isEmpty ? 'Food' : category.trim(),
      'p_price': price,
      'p_image_url': imageUrl,
      'p_is_featured': isFeatured,
      'p_is_available': isAvailable,
      'p_prep_time_min': prepTimeMin,
      'p_prep_time_max': prepTimeMax,
    });
  }

  static Future<void> setProductAvailability(
    String productId,
    bool isAvailable,
  ) async {
    await db.rpc('seller_set_product_available', params: {
      'p_product_id': productId,
      'p_is_available': isAvailable,
    });
  }

  static Future<List<Map<String, dynamic>>> paymentReviews(String storeId) async {
    final rows = await db
        .from('orders')
        .select()
        .eq('store_id', storeId)
        .eq('status', 'payment_review')
        .order('created_at');
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<String?> signedPaymentProof(String path) async {
    final r = await db.storage.from('payment-proofs').createSignedUrl(path, 900);
    return r;
  }

  static Future<void> verifyPayment(String orderId, bool approve) async {
    await db.rpc('seller_verify_payment', params: {
      'p_order_id': orderId,
      'p_approve': approve,
    });
    await pushOrderEvent(orderId, 'order_update');
  }

  static Future<List<Map<String, dynamic>>> storeOrders(String storeId) async {
    final rows = await db
        .from('orders')
        .select()
        .eq('store_id', storeId)
        .inFilter('status', [
          'paid',
          'accepted',
          'preparing',
          'ready',
          'ready_for_pickup',
          'assigned',
          'picked_up',
          'delivering',
          'delivered',
          'completed'
        ])
        .order('created_at', ascending: false);
    final result = List<Map<String, dynamic>>.from(rows);
    return result.where((o) {
      final status = (o['status'] ?? '').toString();
      if (status != 'delivered' && status != 'completed') return true;
      final isGcashDelivery = o['delivery_provider'] != 'seller' &&
          (o['payment_method'] ?? '').toString().toLowerCase() == 'gcash' &&
          (o['fulfillment'] ?? '').toString().toLowerCase() == 'delivery';
      final fee = double.tryParse(o['delivery_fee']?.toString() ?? '') ?? 0;
      final settlement = (o['rider_fee_settlement_status'] ?? 'not_applicable').toString();
      return isGcashDelivery && fee > 0 && settlement != 'received';
    }).toList();
  }

  static Future<void> storeStatus(String orderId, String status) async {
    if (status == 'delivering' || status == 'delivered') {
      await sellerSelfDeliveryStatus(orderId, status);
      return;
    }
    await db.rpc('store_set_order_status', params: {
      'p_order_id': orderId,
      'p_new_status': status,
    });
    await Future.wait([
      if (!{'delivered', 'completed'}.contains(status.toLowerCase()))
        emailOrderUpdate(orderId),
      pushOrderEvent(orderId, 'order_update'),
    ]);
  }

  static Future<void> setDeliveryZone({
    required String storeId,
    required String barangay,
    required double fee,
  }) async {
    await db.from('store_delivery_zones').upsert({
      'store_id': storeId,
      'barangay': barangay.trim(),
      'fee': fee,
    }, onConflict: 'store_id,barangay');
  }

  static Future<List<Map<String, dynamic>>> deliveryZones(String storeId) async {
    final rows = await db
        .from('store_delivery_zones')
        .select()
        .eq('store_id', storeId)
        .order('fee');
    return List<Map<String, dynamic>>.from(rows);
  }


  static Future<List<Map<String, dynamic>>> storeGallery(String storeId) async {
    try {
      final raw = await db.rpc(
        'karlivery_public_gallery',
        params: {'p_store_id': storeId},
      );
      return List<Map<String, dynamic>>.from(raw as List);
    } catch (_) {
      if (user == null) return <Map<String, dynamic>>[];
      final rows = await db
          .from('store_gallery')
          .select()
          .eq('store_id', storeId)
          .order('sort_order')
          .order('created_at');
      return List<Map<String, dynamic>>.from(rows);
    }
  }

  static Future<String> uploadStoreGalleryImage({
    required String storeId,
    required Uint8List bytes,
    required String extension,
  }) async {
    final path =
        '${user!.id}/$storeId/${DateTime.now().millisecondsSinceEpoch}.$extension';
    await db.storage.from('store-gallery').uploadBinary(
      path,
      bytes,
      fileOptions: const FileOptions(upsert: false),
    );
    return db.storage.from('store-gallery').getPublicUrl(path);
  }

  static Future<void> addStoreGalleryImage({
    required String storeId,
    required String imageUrl,
  }) async {
    await db.from('store_gallery').insert({
      'store_id': storeId,
      'image_url': imageUrl,
    });
  }

  static Future<String> uploadProductImage({
    required String storeId,
    required Uint8List bytes,
    required String extension,
  }) async {
    final path =
        '${user!.id}/$storeId/${DateTime.now().millisecondsSinceEpoch}.$extension';
    await db.storage.from('product-images').uploadBinary(
      path,
      bytes,
      fileOptions: const FileOptions(upsert: false),
    );
    return db.storage.from('product-images').getPublicUrl(path);
  }

  static Future<List<Map<String, dynamic>>> productAddons(String productId) async {
    final rows = await db
        .from('product_addons')
        .select()
        .eq('product_id', productId)
        .order('created_at');
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<void> addProductAddon({
    required String productId,
    required String name,
    required double price,
  }) async {
    await db.from('product_addons').insert({
      'product_id': productId,
      'name': name.trim(),
      'price': price,
    });
  }

  static Future<void> updateStoreAddress({
    required String storeId,
    required String address,
    required String barangay,
    required double latitude,
    required double longitude,
  }) async {
    await db.rpc('seller_update_store_address', params: {
      'p_store_id': storeId,
      'p_address_text': address,
      'p_barangay': barangay,
      'p_latitude': latitude,
      'p_longitude': longitude,
    });
  }

  static Future<void> saveStoreLocation({
    required String storeId,
    required double latitude,
    required double longitude,
  }) async {
    await db.rpc('seller_save_store_location', params: {
      'p_store_id': storeId,
      'p_latitude': latitude,
      'p_longitude': longitude,
    });
  }

  static Stream<List<Map<String, dynamic>>> watchMyOrders() {
    final uid = user!.id;
    return db
        .from('orders')
        .stream(primaryKey: ['id'])
        .eq('customer_id', uid)
        .order('created_at', ascending: false)
        .map((rows) => List<Map<String, dynamic>>.from(rows));
  }

  static Stream<List<Map<String, dynamic>>> watchMyNotifications() {
    final uid = user!.id;
    return db
        .from('notifications')
        .stream(primaryKey: ['id'])
        .eq('user_id', uid)
        .order('created_at', ascending: false)
        .map((rows) => List<Map<String, dynamic>>.from(rows));
  }

  static Future<Map<String, dynamic>?> orderDetails(String orderId) async {
    final row = await db
        .from('orders')
        .select('*, addresses(latitude,longitude,barangay,address_line), stores(name,latitude,longitude)')
        .eq('id', orderId)
        .maybeSingle();
    return row == null ? null : Map<String, dynamic>.from(row);
  }

  static Future<String> uploadStoreLogo({
    required String storeId,
    required Uint8List bytes,
    required String extension,
  }) async {
    final path =
        '${user!.id}/$storeId/logo_${DateTime.now().millisecondsSinceEpoch}.$extension';
    await db.storage.from('store-logos').uploadBinary(
      path,
      bytes,
      fileOptions: const FileOptions(upsert: false),
    );
    return db.storage.from('store-logos').getPublicUrl(path);
  }

  static Future<void> saveStoreLogo({
    required String storeId,
    required String logoUrl,
  }) async {
    await db.rpc('seller_save_store_logo', params: {
      'p_store_id': storeId,
      'p_logo_url': logoUrl,
    });
  }

  static Future<void> setProductFeatured(
    String productId,
    bool featured,
  ) async {
    await db.rpc('seller_set_product_featured', params: {
      'p_product_id': productId,
      'p_featured': featured,
    });
  }

  static Future<void> deleteProduct(String productId) async {
    await db.from('products').delete().eq('id', productId);
  }

  static Future<List<Map<String, dynamic>>> storeOrderHistory(
    String storeId,
  ) async {
    final rows = await db
        .from('orders')
        .select()
        .eq('store_id', storeId)
        .order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<Map<String, dynamic>> deliveryRateSettings() async {
    final raw = await db.rpc('karlivery_delivery_rates');
    if (raw is Map) return Map<String, dynamic>.from(raw);
    if (raw is List && raw.isNotEmpty && raw.first is Map) {
      return Map<String, dynamic>.from(raw.first as Map);
    }
    return {
      'base_location_name': 'Store pickup location',
      'base_latitude': 15.6861,
      'base_longitude': 120.4123,
      'base_fee': 50,
      'included_radius_km': 3,
      'step_distance_km': 2,
      'step_fee': 15,
    };
  }

  static Future<void> adminSaveDeliveryRates({
    required double baseFee,
    required double includedRadiusKm,
    required double stepDistanceKm,
    required double stepFee,
  }) async {
    await db.rpc('admin_save_market_delivery_rates', params: {
      'p_base_fee': baseFee,
      'p_included_radius_km': includedRadiusKm,
      'p_step_distance_km': stepDistanceKm,
      'p_step_fee': stepFee,
    });
  }

  // RIDER
  static Future<void> setRiderOnline(bool online) async {
    await db.rpc('set_my_rider_online', params: {
      'p_online': online,
    });
  }

  static Future<List<Map<String, dynamic>>> riderAvailableOrders() async {
    final rows = await db
        .from('orders')
        .select('*, stores(name)')
        .eq('fulfillment', 'delivery')
        .eq('status', 'ready')
        .eq('delivery_provider', 'karlivery')
        .isFilter('rider_id', null)
        .order('created_at');
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<List<Map<String, dynamic>>> riderAssignedOrders() async {
    final rows = await db
        .from('orders')
        .select('*, stores(name)')
        .eq('rider_id', user!.id)
        .inFilter('status', ['assigned', 'picked_up', 'delivering'])
        .order('created_at');
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<void> claimOrder(String orderId) async {
    await db.rpc('rider_claim_order', params: {'p_order_id': orderId});
    try {
      await db.rpc('ensure_delivery_fee_settlement', params: {'p_order_id': orderId});
      await pushOrderEvent(orderId, 'rider_fee_due');
    } catch (_) {}
    await Future.wait([
      emailOrderUpdate(orderId),
      pushOrderEvent(orderId, 'order_update'),
    ]);
  }

  static Future<void> riderStatus(String orderId, String status) async {
    await db.rpc('rider_set_order_status', params: {
      'p_order_id': orderId,
      'p_new_status': status,
    });
    await Future.wait([
      if (!{'delivered', 'completed'}.contains(status.toLowerCase()))
        emailOrderUpdate(orderId),
      pushOrderEvent(orderId, 'order_update'),
    ]);
  }

  static Future<void> sellerMarkRiderFeeSent(
    String orderId, {
    String reference = '',
  }) async {
    await db.rpc('seller_mark_rider_fee_sent', params: {
      'p_order_id': orderId,
      'p_reference': reference.trim(),
    });
    try { await pushOrderEvent(orderId, 'rider_fee_sent'); } catch (_) {}
  }

  static Future<void> riderConfirmDeliveryFeeReceived(String orderId) async {
    await db.rpc('rider_confirm_rider_fee_received', params: {
      'p_order_id': orderId,
    });
    try { await pushOrderEvent(orderId, 'rider_fee_received'); } catch (_) {}
  }

  // ADMIN
  static Future<List<Map<String, dynamic>>> pendingProfiles() async {
    final rows = await db
        .from('profiles')
        .select()
        .inFilter('role', ['rider', 'store_owner'])
        .eq('status', 'pending')
        .order('created_at');
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<List<Map<String, dynamic>>> pendingStores() async {
    final rows = await db
        .from('stores')
        .select()
        .eq('is_approved', false)
        .order('created_at');
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<void> approveProfile(String id, bool approve) async {
    await db
        .from('profiles')
        .update({'status': approve ? 'active' : 'rejected'})
        .eq('id', id);
  }

  static Future<void> approveStore(String id, bool approve) async {
    await db.from('stores').update({'is_approved': approve}).eq('id', id);
  }

  static Future<List<Map<String, dynamic>>> adminOrders() async {
    final rows = await db
        .from('orders')
        .select('*, stores(name)')
        .order('created_at', ascending: false)
        .limit(100);
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<Map<String, int>> adminMetrics() async {
    final profiles = await db.from('profiles').select('id');
    final stores = await db.from('stores').select('id');
    final orders = await db.from('orders').select('id');
    final products = await db.from('products').select('id');
    return {
      'users': profiles.length,
      'stores': stores.length,
      'orders': orders.length,
      'products': products.length,
    };
  }

  // KARLIVERY_NO_EMAIL_RECEIPTS_2026
  // Completed order receipts are available in-app and as PDF only.
  // Non-completed regular order-status notifications remain supported.

  static Future<void> emailOrderUpdate(String orderId) async {
    try {
      await db.functions.invoke(
        'order-status-email',
        body: {'order_id': orderId},
      );
    } catch (_) {
      // Email failure must never block the transaction flow.
    }
  }

  static Future<void> pushOrderEvent(
    String orderId,
    String event, {
    String message = '',
  }) async {
    try {
      await db.functions.invoke(
        'push-notify',
        body: {
          'order_id': orderId,
          'event': event,
          if (message.trim().isNotEmpty)
            'message': message.trim(),
        },
      );
    } catch (_) {
      // Push failure must never block ordering, chat, or delivery flow.
    }
  }

  // Preview comes from the server and contains the EXACT count per selected role.
  // If the function has not been updated yet, preview fails closed (no send).
  static Future<Map<String, dynamic>> previewAnnouncementAudience({
    required List<String> targetRoles,
  }) async {
    final response = await db.functions.invoke(
      'push-notify',
      body: {
        'event': 'announcement_preview',
        'target_roles': targetRoles,
      },
    );
    _throwFunctionError(response, 'Could not preview announcement recipients.');
    final data = response.data;
    if (data is! Map || data['preview_token'] is! String) {
      throw StateError('Notification server requires an update before announcements can be sent.');
    }
    return Map<String, dynamic>.from(data);
  }

  static Future<Map<String, dynamic>> sendAnnouncement({
    required String title,
    required String message,
    required List<String> targetRoles,
    required String previewToken,
  }) async {
    final response = await db.functions.invoke(
      'push-notify',
      body: {
        'event': 'announcement',
        'title': title.trim(),
        'message': message.trim(),
        'target_roles': targetRoles,
        'preview_token': previewToken,
      },
    );
    _throwFunctionError(response, 'Could not send announcement.');
    final data = response.data;
    if (data is! Map || data['target_roles'] is! List) {
      throw StateError('Announcement response did not confirm its recipient roles.');
    }
    return Map<String, dynamic>.from(data);
  }

  static String _functionErrorMessage(
    FunctionsHttpException error,
    String fallback,
  ) {
    final details = error.details;
    if (details is Map) {
      final raw = details['error'];
      if (raw != null && raw.toString().trim().isNotEmpty) {
        final stage = details['stage'];
        final hint = details['hint'];
        final parts = <String>[raw.toString()];
        if (stage != null && stage.toString().trim().isNotEmpty) {
          parts.add('Stage: $stage');
        }
        if (hint != null && hint.toString().trim().isNotEmpty) {
          parts.add(hint.toString());
        }
        return parts.join(' • ');
      }
    }
    final text = details?.toString() ?? '';
    return text.isNotEmpty ? text : fallback;
  }

  static Future<dynamic> _invokeAdminUsers(
    Map<String, dynamic> body,
    String fallback,
  ) async {
    try {
      final response = await db.functions.invoke(
        'admin-users',
        body: body,
      );
      _throwFunctionError(response, fallback);
      return response.data;
    } on FunctionsHttpException catch (e) {
      throw Exception(_functionErrorMessage(e, fallback));
    }
  }

  static Future<void> adminCreateUser({
    required String email,
    required String password,
    required String fullName,
    required String phone,
    required String role,
  }) async {
    await _invokeAdminUsers(
      {
        'action': 'create',
        'email': email.trim(),
        'password': password,
        'full_name': fullName.trim(),
        'phone': phone.trim(),
        'role': role,
      },
      'Could not create account.',
    );
  }

  static Future<void> adminUpdateUser({
    required String userId,
    required String email,
    required String fullName,
    required String phone,
    required String role,
    required String status,
    String password = '',
  }) async {
    await _invokeAdminUsers(
      {
        'action': 'update',
        'user_id': userId,
        'email': email.trim(),
        'full_name': fullName.trim(),
        'phone': phone.trim(),
        'role': role,
        'status': status,
        if (password.isNotEmpty) 'password': password,
      },
      'Could not update account.',
    );
  }

  static Future<void> adminDeleteUser(String userId) async {
    await _invokeAdminUsers(
      {
        'action': 'delete',
        'user_id': userId,
      },
      'Could not delete account.',
    );
  }

  static void _throwFunctionError(
    dynamic response,
    String fallback,
  ) {
    if (response.status < 400) return;
    final data = response.data;
    if (data is Map && data['error'] != null) {
      throw Exception(data['error'].toString());
    }
    throw Exception(fallback);
  }

  // REALTIME CHAT + TRACKING
  static Stream<List<Map<String, dynamic>>> watchChat(String orderId) {
    return db
        .from('chat_messages')
        .stream(primaryKey: ['id'])
        .eq('order_id', orderId)
        .order('created_at')
        .map((rows) => List<Map<String, dynamic>>.from(rows));
  }

  static Future<void> sendChatMessage(String orderId, String message) async {
    final text = message.trim();
    if (text.isEmpty) return;
    await db.from('chat_messages').insert({
      'order_id': orderId,
      'sender_id': user!.id,
      'message': text,
    });
    await pushOrderEvent(
      orderId,
      'chat',
      message: text,
    );
  }

  static Future<void> updateRiderLocation({
    required String orderId,
    required double latitude,
    required double longitude,
    double? heading,
    double? speed,
  }) async {
    await db.from('rider_locations').upsert({
      'order_id': orderId,
      'rider_id': user!.id,
      'latitude': latitude,
      'longitude': longitude,
      'heading': heading,
      'speed': speed,
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    }, onConflict: 'order_id');
  }

  static Stream<Map<String, dynamic>?> watchOrderTracking(String orderId) {
    return db
        .from('rider_locations')
        .stream(primaryKey: ['order_id'])
        .eq('order_id', orderId)
        .map((rows) => rows.isEmpty ? null : Map<String, dynamic>.from(rows.first));
  }

  static Stream<Map<String, dynamic>?> watchOrderStatus(String orderId) {
    return db
        .from('orders')
        .stream(primaryKey: ['id'])
        .eq('id', orderId)
        .map((rows) => rows.isEmpty ? null : Map<String, dynamic>.from(rows.first));
  }

  // EXPANDED ADMIN
  static Future<List<Map<String, dynamic>>> adminUsers() async {
    final rows = await db.from('profiles').select().order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<List<Map<String, dynamic>>> adminStores() async {
    final rows = await db.from('stores').select().order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<List<Map<String, dynamic>>> adminLiveDeliveries() async {
    final rows = await db
        .from('orders')
        .select('*, stores(name)')
        .eq('fulfillment', 'delivery')
        .inFilter('status', ['assigned', 'picked_up', 'delivering'])
        .order('updated_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<void> adminSetUserStatus(String id, String status) async {
    await db.from('profiles').update({'status': status}).eq('id', id);
  }

  static Future<void> adminSetStoreApproval(String id, bool approved) async {
    await db.from('stores').update({'is_approved': approved}).eq('id', id);
  }

}
