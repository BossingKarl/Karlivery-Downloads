import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeController {
  ThemeController._();

  static const _key = 'karlivery_dark_mode';
  static const _v11MigrationKey = 'karlivery_v11_light_default_applied';
  static final ValueNotifier<ThemeMode> mode = ValueNotifier(ThemeMode.light);

  static Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();

    // V11 deliberately starts in light mode once, including users updating
    // from older builds that may have inherited system/dark appearance.
    if (prefs.getBool(_v11MigrationKey) != true) {
      mode.value = ThemeMode.light;
      await prefs.setBool(_key, false);
      await prefs.setBool(_v11MigrationKey, true);
      return;
    }

    mode.value = prefs.getBool(_key) == true
        ? ThemeMode.dark
        : ThemeMode.light;
  }

  static bool isDark(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark;

  static Future<void> setDark(bool enabled) async {
    mode.value = enabled ? ThemeMode.dark : ThemeMode.light;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_key, enabled);
  }

  static Future<void> toggle(BuildContext context) async {
    await setDark(!isDark(context));
  }
}
