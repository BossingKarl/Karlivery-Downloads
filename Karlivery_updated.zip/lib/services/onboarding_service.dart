import 'package:shared_preferences/shared_preferences.dart';

class OnboardingService {
  OnboardingService._();

  static const _welcomeKey = 'karlivery_v12_welcome_seen';
  static const _customerTipsKey = 'karlivery_v12_customer_tips_seen';
  static const _sellerTipsKey = 'karlivery_v12_seller_tips_seen';
  static const _riderTipsKey = 'karlivery_v12_rider_tips_seen';
  static const _adminTipsKey = 'karlivery_v12_admin_tips_seen';

  static Future<bool> hasSeenWelcome() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_welcomeKey) ?? false;
  }

  static Future<void> markWelcomeSeen() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_welcomeKey, true);
  }

  static String _keyForRole(String role) => switch (role) {
        'store_owner' => _sellerTipsKey,
        'rider' => _riderTipsKey,
        'admin' => _adminTipsKey,
        _ => _customerTipsKey,
      };

  static Future<bool> hasSeenRoleTips(String role) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_keyForRole(role)) ?? false;
  }

  static Future<void> markRoleTipsSeen(String role) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyForRole(role), true);
  }

  static Future<void> replayWelcome() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_welcomeKey);
  }
}
