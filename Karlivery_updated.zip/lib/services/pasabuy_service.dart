import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'backend.dart';

class PasabuyService {
  /// Pabili notifications are delivered by the authenticated server after
  /// verifying the saved order/event. Never block a financial action on push.
  static Future<void> _pushPabiliEvent(String orderId, String event, {String? messageId}) async {
    try {
      final response = await Backend.db.functions.invoke('push-notify', body: {
        'order_type': 'pabili',
        'order_id': orderId,
        'event': event,
        'message_id': ?messageId,
      });
      if (response.status >= 400 || (response.data is Map && response.data['error'] != null)) {
        throw StateError('Pabili push rejected: ${response.status} ${response.data}');
      }
      final provider = response.data is Map ? response.data['provider'] : null;
      if (provider is Map && (provider['error'] != null || provider['skipped'] != null)) {
        debugPrint('Pabili push provider: $provider');
      }
    } catch (error) {
      debugPrint('Pabili push-notify could not be submitted: $error');
    }
  }

  PasabuyService._();

  static const double handlingFee = 20;
  /// Parse the actual fee supplied by the server. Do not compute Pabili fees
  /// from hardcoded client-side rates: admins can change the rate settings.
  static double quoteDeliveryFee(Map<String, dynamic> quote) {
    final amount = double.tryParse(quote['delivery_fee']?.toString() ?? '');
    if (amount == null || !amount.isFinite || amount < 0) {
      throw StateError('Invalid Pabili delivery quote.');
    }
    return amount;
  }

  /// Returns the verified straight-line GPS distance reported by the server.
  /// This must not be labelled as a driving-route distance.
  static double? quoteDistanceKm(Map<String, dynamic> quote) {
    final amount = double.tryParse(quote['delivery_distance_km']?.toString() ?? '');
    return amount != null && amount.isFinite && amount >= 0 ? amount : null;
  }

  /// Server-authoritative quote. Prices reflect current admin delivery settings;
  /// the checkout trigger independently recomputes and records the final fee.
  static Future<Map<String, dynamic>> deliveryQuote({
    required String shopId,
    required String addressId,
  }) async {
    final raw = await Backend.db.rpc('karlivery_pabili_delivery_quote', params: {
      'p_shop_id': shopId,
      'p_address_id': addressId,
    });
    if (raw is! Map) {
      throw StateError('Pabili delivery quote is unavailable. Please try again.');
    }
    final quote = Map<String, dynamic>.from(raw);
    quoteDeliveryFee(quote);
    if (quoteDistanceKm(quote) == null) {
      throw StateError('Pabili delivery distance is unavailable.');
    }
    return quote;
  }


  static final Map<String, String> _brandLogoAssets = {
    'jollibee': 'assets/pasabuy/logos/jollibee-camiling_logo.png',
    'chowking': 'assets/pasabuy/logos/chowking-camiling_logo.png',
    'mang_inasal': 'assets/pasabuy/logos/mang-inasal-mangatarem_logo.png',
    'mcdonalds': 'assets/pasabuy/logos/mcdonalds-mangatarem_logo.png',
    'kfc': 'assets/pasabuy/logos/kfc-mangatarem_logo.png',
    'andoks': 'assets/pasabuy/logos/andoks-camiling_logo.png',
    'delishcheese': 'assets/pasabuy/logos/delishcheese-camiling_logo.png',
    'custom': 'assets/pasabuy/logos/other_store_logo.png',
  };

  static final Map<String, Map<String, dynamic>> _fallbackShopDecor = {
    'pasabuy-jollibee-camiling': {
      'latitude': 15.6865,
      'longitude': 120.4147,
      'coordinate_source': 'town_center_estimate',
      'location_label': 'Camiling, Tarlac',
      'logo_asset': 'assets/branding/karlivery_logo.png',
      'cover_photo_asset': 'assets/pasabuy/branch_reference/jollibee/menu_01.jpg',
      'menu_photo_assets': const [
        'assets/pasabuy/branch_reference/jollibee/menu_01.jpg',
        'assets/pasabuy/branch_reference/jollibee/menu_02.jpg',
        'assets/pasabuy/branch_reference/jollibee/menu_03.jpg',
        'assets/pasabuy/branch_reference/jollibee/menu_04.jpg',
        'assets/pasabuy/branch_reference/jollibee/menu_05.jpg',
        'assets/pasabuy/branch_reference/jollibee/menu_06.jpg',
        'assets/pasabuy/branch_reference/jollibee/menu_07.jpg',
        'assets/pasabuy/branch_reference/jollibee/menu_08.jpg',
        'assets/pasabuy/branch_reference/jollibee/menu_09.jpg',
        'assets/pasabuy/branch_reference/jollibee/menu_10.jpg',
        'assets/pasabuy/branch_reference/jollibee/menu_11.jpg',
      ],
    },
    'pasabuy-chowking-camiling': {
      'latitude': 15.6865,
      'longitude': 120.4147,
      'coordinate_source': 'town_center_estimate',
      'location_label': 'Camiling, Tarlac',
      'logo_asset': 'assets/branding/karlivery_logo.png',
      'cover_photo_asset': 'assets/pasabuy/branch_reference/chowking/menu_01.jpg',
      'menu_photo_assets': const [
        'assets/pasabuy/branch_reference/chowking/menu_01.jpg',
        'assets/pasabuy/branch_reference/chowking/menu_02.jpg',
        'assets/pasabuy/branch_reference/chowking/menu_03.jpg',
        'assets/pasabuy/branch_reference/chowking/menu_04.jpg',
        'assets/pasabuy/branch_reference/chowking/menu_05.jpg',
        'assets/pasabuy/branch_reference/chowking/menu_06.jpg',
      ],
    },
    'pasabuy-andoks-camiling': {
      'latitude': 15.6865,
      'longitude': 120.4147,
      'coordinate_source': 'town_center_estimate',
      'location_label': 'Camiling, Tarlac',
      'logo_asset': 'assets/branding/karlivery_logo.png',
      'cover_photo_asset': 'assets/pasabuy/branch_reference/andoks/menu_01.jpg',
      'menu_photo_assets': const [
        'assets/pasabuy/branch_reference/andoks/menu_01.jpg',
        'assets/pasabuy/branch_reference/andoks/menu_02.jpg',
        'assets/pasabuy/branch_reference/andoks/menu_03.jpg',
        'assets/pasabuy/branch_reference/andoks/menu_04.jpg',
        'assets/pasabuy/branch_reference/andoks/menu_05.jpg',
      ],
    },
    'pasabuy-delishcheese-camiling': {
      'latitude': 15.6865,
      'longitude': 120.4147,
      'coordinate_source': 'town_center_estimate',
      'location_label': 'Camiling, Tarlac',
      'logo_asset': 'assets/branding/karlivery_logo.png',
      'cover_photo_asset': 'assets/pasabuy/branch_reference/delishcheese/menu_01.jpg',
      'menu_photo_assets': const [
        'assets/pasabuy/branch_reference/delishcheese/menu_01.jpg',
      ],
    },
    'pasabuy-mcdonalds-mangatarem': {
      'latitude': 15.7885,
      'longitude': 120.2939,
      'coordinate_source': 'town_center_estimate',
      'location_label': 'Mangatarem, Pangasinan',
      'logo_asset': 'assets/branding/karlivery_logo.png',
      'cover_photo_asset': 'assets/pasabuy/branch_reference/mcdonalds/menu_01.jpg',
      'menu_photo_assets': const [
        'assets/pasabuy/branch_reference/mcdonalds/menu_01.jpg',
        'assets/pasabuy/branch_reference/mcdonalds/menu_02.jpg',
        'assets/pasabuy/branch_reference/mcdonalds/menu_03.jpg',
        'assets/pasabuy/branch_reference/mcdonalds/menu_04.jpg',
        'assets/pasabuy/branch_reference/mcdonalds/menu_05.jpg',
        'assets/pasabuy/branch_reference/mcdonalds/menu_06.jpg',
        'assets/pasabuy/branch_reference/mcdonalds/menu_07.jpg',
        'assets/pasabuy/branch_reference/mcdonalds/menu_08.jpg',
        'assets/pasabuy/branch_reference/mcdonalds/menu_09.jpg',
        'assets/pasabuy/branch_reference/mcdonalds/menu_10.jpg',
        'assets/pasabuy/branch_reference/mcdonalds/menu_11.jpg',
        'assets/pasabuy/branch_reference/mcdonalds/menu_12.jpg',
        'assets/pasabuy/branch_reference/mcdonalds/menu_13.jpg',
        'assets/pasabuy/branch_reference/mcdonalds/menu_14.jpg',
        'assets/pasabuy/branch_reference/mcdonalds/menu_15.jpg',
        'assets/pasabuy/branch_reference/mcdonalds/menu_16.jpg',
        'assets/pasabuy/branch_reference/mcdonalds/menu_17.jpg',
        'assets/pasabuy/branch_reference/mcdonalds/menu_18.jpg',
        'assets/pasabuy/branch_reference/mcdonalds/menu_19.jpg',
        'assets/pasabuy/branch_reference/mcdonalds/menu_20.jpg',
        'assets/pasabuy/branch_reference/mcdonalds/menu_21.jpg',
      ],
    },
    'pasabuy-kfc-mangatarem': {
      'latitude': 15.7885,
      'longitude': 120.2939,
      'coordinate_source': 'town_center_estimate',
      'location_label': 'Mangatarem, Pangasinan',
      'logo_asset': 'assets/branding/karlivery_logo.png',
      'cover_photo_asset': 'assets/pasabuy/branch_reference/kfc/menu_01.jpg',
      'menu_photo_assets': const [
        'assets/pasabuy/branch_reference/kfc/menu_01.jpg',
        'assets/pasabuy/branch_reference/kfc/menu_02.jpg',
        'assets/pasabuy/branch_reference/kfc/menu_03.jpg',
        'assets/pasabuy/branch_reference/kfc/menu_04.jpg',
        'assets/pasabuy/branch_reference/kfc/menu_05.jpg',
        'assets/pasabuy/branch_reference/kfc/menu_06.jpg',
        'assets/pasabuy/branch_reference/kfc/menu_07.jpg',
        'assets/pasabuy/branch_reference/kfc/menu_08.jpg',
      ],
    },
    'pasabuy-mang-inasal-sta-ignacia': {
      'latitude': 15.6162,
      'longitude': 120.4359,
      'coordinate_source': 'town_center_estimate',
      'location_label': 'Sta. Ignacia, Tarlac',
      'logo_asset': 'assets/branding/karlivery_logo.png',
      'cover_photo_asset': 'assets/pasabuy/branch_reference/mang_inasal/menu_01.jpg',
      'menu_photo_assets': const [
        'assets/pasabuy/branch_reference/mang_inasal/menu_01.jpg',
        'assets/pasabuy/branch_reference/mang_inasal/menu_02.jpg',
        'assets/pasabuy/branch_reference/mang_inasal/menu_03.jpg',
        'assets/pasabuy/branch_reference/mang_inasal/menu_04.jpg',
        'assets/pasabuy/branch_reference/mang_inasal/menu_05.jpg',
        'assets/pasabuy/branch_reference/mang_inasal/menu_06.jpg',
        'assets/pasabuy/branch_reference/mang_inasal/menu_07.jpg',
      ],
    },
    'pasabuy-mang-inasal-mangatarem': {
      'latitude': 15.6162,
      'longitude': 120.4359,
      'coordinate_source': 'town_center_estimate',
      'location_label': 'Sta. Ignacia, Tarlac',
      'menu_photo_assets': const [
        'assets/pasabuy/branch_reference/mang_inasal/menu_01.jpg',
        'assets/pasabuy/branch_reference/mang_inasal/menu_02.jpg',
        'assets/pasabuy/branch_reference/mang_inasal/menu_03.jpg',
        'assets/pasabuy/branch_reference/mang_inasal/menu_04.jpg',
        'assets/pasabuy/branch_reference/mang_inasal/menu_05.jpg',
        'assets/pasabuy/branch_reference/mang_inasal/menu_06.jpg',
        'assets/pasabuy/branch_reference/mang_inasal/menu_07.jpg',
      ],
    },
    'pasabuy-other-store': {
      'logo_asset': 'assets/branding/karlivery_logo.png',
      'cover_photo_asset': 'assets/pasabuy/curated/other/card_01.webp',
      'menu_photo_assets': const [
        'assets/pasabuy/curated/other/card_01.webp',
        'assets/pasabuy/curated/other/card_02.webp',
        'assets/pasabuy/curated/other/card_03.webp',
      ]
    },
  };


  static List<String> _stringList(dynamic raw) {
    if (raw is List) {
      return raw.map((e) => e?.toString() ?? '').where((e) => e.trim().isNotEmpty).toList();
    }
    return const <String>[];
  }

  static Map<String, dynamic> _decorateShop(Map<String, dynamic> raw) {
    final shop = Map<String, dynamic>.from(raw);
    final decor = _fallbackShopDecor[shop['id']?.toString() ?? ''];
    if (decor != null) {
      for (final entry in decor.entries) {
        final current = shop[entry.key];
        final blank = current == null || (current is String && current.trim().isEmpty) || (current is List && current.isEmpty);
        if (blank) shop[entry.key] = entry.value;
      }
    }
    final brand = shop['brand']?.toString();
    if ((shop['logo_asset'] == null || shop['logo_asset'].toString().trim().isEmpty) && brand != null) {
      shop['logo_asset'] = _brandLogoAssets[brand];
    }
    return shop;
  }

  /// Customer-facing short location. Exact address remains in the admin database.
  static String townLabel(Map<String, dynamic>? shop) {
    if (shop == null) return 'Location to confirm';
    final id = shop['id']?.toString() ?? '';
    if (id == 'pasabuy-other-store') return 'Choose your store';
    final raw = shop['location_label']?.toString().trim() ?? '';
    if (raw.isNotEmpty) {
      final parts = raw.split(',').map((x) => x.trim()).where((x) => x.isNotEmpty).toList();
      return parts.length >= 2 ? parts.sublist(parts.length - 2).join(', ') : raw;
    }
    if (id.contains('mang-inasal')) return 'Sta. Ignacia, Tarlac';
    if (id.contains('mangatarem')) return 'Mangatarem, Pangasinan';
    if (id.contains('camiling')) return 'Camiling, Tarlac';
    return 'Pickup location to confirm';
  }

  static bool hasConfirmedPickup(Map<String, dynamic>? shop) =>
      shop?['coordinate_source']?.toString() == 'admin_confirmed';

  static String? shopLogoAsset(Map<String, dynamic>? shop) => shop == null ? null : _decorateShop(shop)['logo_asset']?.toString();

  static String? shopLogoImage(Map<String, dynamic>? shop) {
    if (shop == null) return null;
    final remote = shop['logo_url']?.toString().trim() ?? '';
    if (remote.startsWith('https://')) return remote;
    return shopLogoAsset(shop);
  }


  static String? shopCoverImage(Map<String, dynamic>? shop) {
    if (shop == null) return null;
    final decorated = _decorateShop(shop);
    final remote = decorated['cover_image_url']?.toString();
    if (remote != null && remote.startsWith('https://')) return remote;
    final asset = decorated['cover_photo_asset']?.toString();
    if (asset != null && asset.isNotEmpty) return asset;
    final gallery = shopMenuImages(decorated);
    return gallery.isNotEmpty ? gallery.first : null;
  }

  static List<String> shopMenuImages(Map<String, dynamic>? shop) {
    if (shop == null) return const <String>[];
    final decorated = _decorateShop(shop);
    final result = <String>[];
    // Admin-managed gallery overrides bundled illustrative cards.
    final curated = _stringList(decorated['menu_image_urls']);
    if (curated.isNotEmpty) return curated.toSet().toList();
    if (decorated['show_bundled_gallery'] == false) return const <String>[];
    result.addAll(_stringList(decorated['menu_photo_assets']));
    final singleAsset = decorated['menu_photo_asset']?.toString();
    if (singleAsset != null && singleAsset.trim().isNotEmpty) result.add(singleAsset.trim());
    final singleRemote = decorated['menu_photo_url']?.toString();
    if (singleRemote != null && singleRemote.startsWith('https://')) result.add(singleRemote);
    return result.toSet().toList();
  }

  static final Map<String, List<Map<String, dynamic>>> _fallbackItemsByShop = {
    'pasabuy-jollibee-camiling': [
      _item('jb-c1', 'pasabuy-jollibee-camiling', 'Chickenjoy', 'C1 1-pc Chickenjoy', 105, addons: [_addon('jb-a1', 'Spicy upgrade', 7), _addon('jb-a2', 'Add-on rice', 40)]),
      _item('jb-c2', 'pasabuy-jollibee-camiling', 'Chickenjoy', 'C2 2-pc Chickenjoy', 195),
      _item('jb-c3', 'pasabuy-jollibee-camiling', 'Chickenjoy', 'C3 1-pc Chickenjoy w/ Jolly Spaghetti', 185),
      _item('jb-c4', 'pasabuy-jollibee-camiling', 'Chickenjoy', 'C4 1-pc Chickenjoy w/ Palabok', 259),
      _item('jb-c5', 'pasabuy-jollibee-camiling', 'Chickenjoy', 'C5 1-pc Chickenjoy w/ Fries', 170),
      _item('jb-bucket4', 'pasabuy-jollibee-camiling', 'Chickenjoy Bucket', 'G7 4-pc Chickenjoy Bucket', 379),
      _item('jb-bucket6', 'pasabuy-jollibee-camiling', 'Chickenjoy Bucket', '6-pc Chickenjoy Bucket', 525),
      _item('jb-bucket8', 'pasabuy-jollibee-camiling', 'Chickenjoy Bucket', '8-pc Chickenjoy Bucket', 675),
      _item('jb-y1', 'pasabuy-jollibee-camiling', 'Burgers', 'Y1 Yumburger', 145),
      _item('jb-y2', 'pasabuy-jollibee-camiling', 'Burgers', 'Y2 Original Cheesy Yumburger', 150),
      _item('jb-y3', 'pasabuy-jollibee-camiling', 'Burgers', 'Y3 Bacon Cheesy Yumburger', 199),
      _item('jb-y4', 'pasabuy-jollibee-camiling', 'Burgers', 'Y4 Champ Jr.', 220),
      _item('jb-y6', 'pasabuy-jollibee-camiling', 'Burgers', 'Y6 Aloha Champ Jr.', 249),
      _item('jb-y7', 'pasabuy-jollibee-camiling', 'Burgers', 'Y7 Champ', 325),
      _item('jb-b1', 'pasabuy-jollibee-camiling', 'Rice Meals', 'B1 1-pc Burger Steak', 85),
      _item('jb-b2', 'pasabuy-jollibee-camiling', 'Rice Meals', 'B2 2-pc Burger Steak', 149),
      _item('jb-b3', 'pasabuy-jollibee-camiling', 'Rice Meals', 'B3 1-pc Burger Steak w/ Fries', 139),
      _item('jb-pc1', 'pasabuy-jollibee-camiling', 'Rice Meals', 'Pepper Cream Chicken Fillet 1-pc', 99),
      _item('jb-pc2', 'pasabuy-jollibee-camiling', 'Rice Meals', 'Pepper Cream Chicken Fillet 1-pc w/ Fries', 135),
      _item('jb-pc3', 'pasabuy-jollibee-camiling', 'Rice Meals', 'Pepper Cream Chicken Fillet 2-pc', 175),
      _item('jb-pc4', 'pasabuy-jollibee-camiling', 'Rice Meals', 'Pepper Cream Chicken Fillet w/ Jolly Spaghetti', 159),
      _item('jb-b5', 'pasabuy-jollibee-camiling', 'Rice Meals', 'B5 6-pc Burger Steak Family Pan', 400),
      _item('jb-b6', 'pasabuy-jollibee-camiling', 'Rice Meals', 'B6 8-pc Burger Steak Family Pan', 530),
      _item('jb-s2', 'pasabuy-jollibee-camiling', 'Jolly Spaghetti', 'S2 Jolly Spaghetti', 139),
      _item('jb-s3', 'pasabuy-jollibee-camiling', 'Jolly Spaghetti', 'S3 Jolly Spaghetti w/ Yumburger', 135),
      _item('jb-s4', 'pasabuy-jollibee-camiling', 'Jolly Spaghetti', 'S4 Jolly Spaghetti w/ Cheesy Yumburger', 164),
      _item('jb-s5', 'pasabuy-jollibee-camiling', 'Jolly Spaghetti', 'S5 Jolly Spaghetti w/ Burger Steak', 150),
      _item('jb-s6', 'pasabuy-jollibee-camiling', 'Jolly Spaghetti', 'S6 Jolly Spaghetti Family Pan', 285),
      _item('jb-mm1', 'pasabuy-jollibee-camiling', 'Mix & Match', 'Mix & Match ₱85', 85),
      _item('jb-mm2', 'pasabuy-jollibee-camiling', 'Mix & Match', 'Mix & Match ₱95', 95),
      _item('jb-dessert1', 'pasabuy-jollibee-camiling', 'Desserts & Drinks', 'Peach Mango Pie', 50),
      _item('jb-dessert2', 'pasabuy-jollibee-camiling', 'Desserts & Drinks', 'Choco Sundae', 59),
      _item('jb-dessert3', 'pasabuy-jollibee-camiling', 'Desserts & Drinks', 'Cookies and Cream Sundae', 79),
      _item('jb-dessert4', 'pasabuy-jollibee-camiling', 'Desserts & Drinks', 'Coke Float', 75),
      _item('jb-drink1', 'pasabuy-jollibee-camiling', 'Desserts & Drinks', 'Hot Fresh Brew', 69),
      _item('jb-drink2', 'pasabuy-jollibee-camiling', 'Desserts & Drinks', 'Iced Mocha', 79),
      _item('jb-drink3', 'pasabuy-jollibee-camiling', 'Desserts & Drinks', 'Iced Latte', 75),
    ],
    'pasabuy-mang-inasal-sta-ignacia': [
      _item('mi-paa1', 'pasabuy-mang-inasal-sta-ignacia', 'Chicken Inasal', 'Paa Large 1 Rice', 139),
      _item('mi-paa2', 'pasabuy-mang-inasal-sta-ignacia', 'Chicken Inasal', 'Paa Large 1 Rice Value Meal', 170),
      _item('mi-paa3', 'pasabuy-mang-inasal-sta-ignacia', 'Chicken Inasal', 'Paa Large Unli Rice', 179),
      _item('mi-pecho1', 'pasabuy-mang-inasal-sta-ignacia', 'Chicken Inasal', 'Pecho Large 1 Rice', 169),
      _item('mi-pecho2', 'pasabuy-mang-inasal-sta-ignacia', 'Chicken Inasal', 'Pecho Large Unli Rice', 209),
      _item('mi-reg1', 'pasabuy-mang-inasal-sta-ignacia', 'Chicken Inasal', 'Regular Chicken 1 Rice', 99),
      _item('mi-bbq1', 'pasabuy-mang-inasal-sta-ignacia', 'Pork BBQ', '1pc Pork BBQ Ala Carte', 50),
      _item('mi-bbq2', 'pasabuy-mang-inasal-sta-ignacia', 'Pork BBQ', '2pc Pork BBQ Value Meal', 134),
      _item('mi-bbq3', 'pasabuy-mang-inasal-sta-ignacia', 'Pork BBQ', 'Buddy Size 4pcs', 193),
      _item('mi-spbbq1', 'pasabuy-mang-inasal-sta-ignacia', 'Spicy Pork BBQ', '1pc Spicy Pork BBQ Ala Carte', 55),
      _item('mi-chbbq1', 'pasabuy-mang-inasal-sta-ignacia', 'Chicken BBQ', '2pc Chicken BBQ Value Meal', 134),
      _item('mi-liempo1', 'pasabuy-mang-inasal-sta-ignacia', 'Liempo', 'Liempo Inasal 1 Rice', 135),
      _item('mi-liempo2', 'pasabuy-mang-inasal-sta-ignacia', 'Liempo', 'Liempo Inasal Unli Rice', 175),
      _item('mi-sisig1', 'pasabuy-mang-inasal-sta-ignacia', 'Sisig', 'Pork Sisig 1 Rice', 105),
      _item('mi-sisig2', 'pasabuy-mang-inasal-sta-ignacia', 'Sisig', 'Chicken Sisig 1 Rice', 105),
      _item('mi-hh1', 'pasabuy-mang-inasal-sta-ignacia', 'Halo-Halo', 'Extra Creamy 8oz', 39),
      _item('mi-hh2', 'pasabuy-mang-inasal-sta-ignacia', 'Halo-Halo', '12oz Small', 75),
      _item('mi-hh3', 'pasabuy-mang-inasal-sta-ignacia', 'Halo-Halo', '16oz Regular', 95),
      _item('mi-pal1', 'pasabuy-mang-inasal-sta-ignacia', 'Palabok', 'Solo', 89),
      _item('mi-pal2', 'pasabuy-mang-inasal-sta-ignacia', 'Palabok', 'Family Size', 345),
      _item('mi-combo1', 'pasabuy-mang-inasal-sta-ignacia', 'Ihaw-sarap Combos', 'Paa Large + Halo Halo', 194),
      _item('mi-combo2', 'pasabuy-mang-inasal-sta-ignacia', 'Ihaw-sarap Combos', 'Pecho Large + Halo Halo', 224),
    ],
    'pasabuy-mcdonalds-mangatarem': [
      _item('mc-1', 'pasabuy-mcdonalds-mangatarem', 'Burgers', 'Big Mac', 0, published: false),
      _item('mc-2', 'pasabuy-mcdonalds-mangatarem', 'Burgers', 'Cheeseburger', 0, published: false),
      _item('mc-3', 'pasabuy-mcdonalds-mangatarem', 'Chicken', '1-pc Chicken McDo with Rice', 0, published: false),
      _item('mc-4', 'pasabuy-mcdonalds-mangatarem', 'Meals', 'McSpaghetti', 0, published: false),
      _item('mc-5', 'pasabuy-mcdonalds-mangatarem', 'Fries & Extras', 'BFF Fries', 0, published: false),
      _item('mc-6', 'pasabuy-mcdonalds-mangatarem', 'Desserts & McCafé', 'Sundae', 0, published: false),
    ],
    'pasabuy-kfc-mangatarem': [
      _item('kfc-1', 'pasabuy-kfc-mangatarem', 'Buckets', '6-PC Bucket Combo', 780, published: false),
      _item('kfc-2', 'pasabuy-kfc-mangatarem', 'Buckets', '8-PC Bucket Combo', 1010, published: false),
      _item('kfc-3', 'pasabuy-kfc-mangatarem', 'Burgers', 'Original Recipe Double Down Ala Carte', 295, published: false),
      _item('kfc-4', 'pasabuy-kfc-mangatarem', 'Burgers', 'Zinger Double Down Ala Carte', 295, published: false),
      _item('kfc-5', 'pasabuy-kfc-mangatarem', 'Burgers', 'Original Recipe Double Down Combo', 370, published: false),
      _item('kfc-6', 'pasabuy-kfc-mangatarem', 'Meals', 'Double Down Fully Loaded Box', 450, published: false),
    ],
    'pasabuy-other-store': [],
    'pasabuy-chowking-camiling': [
      _item('ck-1', 'pasabuy-chowking-camiling', 'Chao Fan', 'Pork Chao Fan', 0, published: false),
      _item('ck-2', 'pasabuy-chowking-camiling', 'Chao Fan', 'Beef Chao Fan', 0, published: false),
      _item('ck-3', 'pasabuy-chowking-camiling', 'Chinese-Style Fried Chicken', 'Chinese-Style Fried Chicken Meal', 0, published: false),
      _item('ck-4', 'pasabuy-chowking-camiling', 'Lauriat', 'Beef Wonton Mami Lauriat', 0, published: false),
      _item('ck-5', 'pasabuy-chowking-camiling', 'Noodles', 'Beef Wonton Noodles', 0, published: false),
      _item('ck-6', 'pasabuy-chowking-camiling', 'Siopao & Siomai', 'Bola-Bola Siopao', 0, published: false),
      _item('ck-7', 'pasabuy-chowking-camiling', 'Desserts', 'SuperSangkap Halo-Halo', 0, published: false),
    ],
    'pasabuy-delishcheese-camiling': [
      _item('dc-classic-1', 'pasabuy-delishcheese-camiling', 'Classic Flavors', 'Classic Cheese', 229),
      _item('dc-classic-2', 'pasabuy-delishcheese-camiling', 'Classic Flavors', 'Pepperoni', 289),
      _item('dc-classic-3', 'pasabuy-delishcheese-camiling', 'Classic Flavors', 'Three Cheese', 279),
      _item('dc-classic-4', 'pasabuy-delishcheese-camiling', 'Classic Flavors', 'Hawaiian', 299),
      _item('dc-premium-1', 'pasabuy-delishcheese-camiling', 'Premium Flavors', 'Manhattan', 469),
      _item('dc-premium-2', 'pasabuy-delishcheese-camiling', 'Premium Flavors', 'Kaniyaki', 499),
      _item('dc-premium-3', 'pasabuy-delishcheese-camiling', 'Premium Flavors', 'AllMeat', 439),
      _item('dc-premium-4', 'pasabuy-delishcheese-camiling', 'Premium Flavors', 'Garlic Seafood', 499),
      _item('dc-sign-1', 'pasabuy-delishcheese-camiling', 'Signature Flavors', 'Bacon Cheese', 349),
      _item('dc-sign-2', 'pasabuy-delishcheese-camiling', 'Signature Flavors', 'Pepper Beef', 359),
      _item('dc-sign-3', 'pasabuy-delishcheese-camiling', 'Signature Flavors', 'Margherita', 369),
      _item('dc-sign-4', 'pasabuy-delishcheese-camiling', 'Signature Flavors', 'Vegizza', 389),
      _item('dc-sign-5', 'pasabuy-delishcheese-camiling', 'Signature Flavors', 'Hamzarella', 389),
      _item('dc-sign-6', 'pasabuy-delishcheese-camiling', 'Signature Flavors', 'Pesto', 379),
    ],
  };

  static Map<String, dynamic> _item(
    String id,
    String shopId,
    String category,
    String name,
    num price, {
    bool published = true,
    List<Map<String, dynamic>> addons = const [],
  }) => {
        'id': id,
        'shop_id': shopId,
        'category_name': category,
        'name': name,
        'price': price.toDouble(),
        'is_published': published,
        'is_available': true,
        'image_url': null,
        'addons': addons,
      };

  static Map<String, dynamic> _addon(String id, String name, num price) => {
        'id': id,
        'name': name,
        'price': price.toDouble(),
      };

  static Future<List<Map<String, dynamic>>> listShops() async {
    try {
      final rows = await Backend.db
          .from('pasabuy_shops')
          .select()
          .eq('is_active', true)
          .order('sort_order')
          .order('name');
      final list = List<Map<String, dynamic>>.from(rows).map(_decorateShop).toList();
      return list; // Respect admin-disabled stores; an empty table must stay empty.
    } catch (e) {
      throw StateError('Unable to load Pabili stores from Supabase: $e');
    }
  }

  static Future<List<Map<String, dynamic>>> listAdminShops() async {
    final rows = await Backend.db.from('pasabuy_shops').select().order('sort_order').order('name');
    return List<Map<String, dynamic>>.from(rows).map(_decorateShop).toList();
  }

  /// Uploaded images are stored on Supabase and managed per shop, not per menu item.
  static Future<String> uploadGalleryImage({
    required String shopId,
    required String filename,
    required Uint8List bytes,
  }) async {
    if (bytes.isEmpty || bytes.length > 5 * 1024 * 1024) {
      throw Exception('Image must be 5 MB or less.');
    }
    final dot = filename.lastIndexOf('.');
    final ext = dot >= 0 ? filename.substring(dot + 1).toLowerCase() : '';
    if (!{'jpg', 'jpeg', 'png', 'webp'}.contains(ext)) {
      throw Exception('Only JPG, PNG or WebP images are supported.');
    }
    final user = Backend.user;
    if (user == null) throw Exception('Admin sign-in required.');
    final path = '${user.id}/$shopId/${DateTime.now().microsecondsSinceEpoch}.$ext';
    await Backend.db.storage.from('pasabuy-gallery').uploadBinary(
      path, bytes, fileOptions: FileOptions(contentType: ext == 'png' ? 'image/png' : ext == 'webp' ? 'image/webp' : 'image/jpeg'),
    );
    return Backend.db.storage.from('pasabuy-gallery').getPublicUrl(path);
  }

  static Future<Map<String, dynamic>?> shopById(String id) async {
    final row = await Backend.db.from('pasabuy_shops')
        .select().eq('id', id).eq('is_active', true).maybeSingle();
    return row == null ? null : _decorateShop(Map<String, dynamic>.from(row));
  }

  static Future<List<Map<String, dynamic>>> listPublishedItems(String shopId) async {
    try {
      final rows = await Backend.db
          .from('pasabuy_items')
          .select('*, pasabuy_categories(name), pasabuy_item_addons(*)')
          .eq('shop_id', shopId)
          .eq('is_published', true)
          .order('sort_order')
          .order('name');
      final items = List<Map<String, dynamic>>.from(rows).map(_normalizeItem).toList();
      if (items.isNotEmpty) return items;
    } catch (_) {}
    return (_fallbackItemsByShop[shopId] ?? const [])
        .where((item) => item['is_published'] == true && (item['price'] ?? 0) > 0)
        .map((e) => Map<String, dynamic>.from(e))
        .toList();
  }

  static Future<List<Map<String, dynamic>>> listAdminItems(String shopId) async {
    try {
      final rows = await Backend.db
          .from('pasabuy_items')
          .select('*, pasabuy_categories(name), pasabuy_item_addons(*)')
          .eq('shop_id', shopId)
          .order('sort_order')
          .order('name');
      final items = List<Map<String, dynamic>>.from(rows).map(_normalizeItem).toList();
      if (items.isNotEmpty) return items;
    } catch (_) {}
    return (_fallbackItemsByShop[shopId] ?? const [])
        .map((e) => Map<String, dynamic>.from(e))
        .toList();
  }

  static Map<String, dynamic> _normalizeItem(Map<String, dynamic> raw) {
    final item = Map<String, dynamic>.from(raw);
    item['category_name'] = raw['pasabuy_categories'] is Map
        ? (raw['pasabuy_categories']['name']?.toString() ?? raw['category_name']?.toString() ?? 'Menu')
        : (raw['category_name']?.toString() ?? 'Menu');
    item['addons'] = raw['pasabuy_item_addons'] is List
        ? List<Map<String, dynamic>>.from(raw['pasabuy_item_addons'])
        : (raw['addons'] is List ? List<Map<String, dynamic>>.from(raw['addons']) : <Map<String, dynamic>>[]);
    return item;
  }

  // Only whitelisted columns are writable. Partial updates must not silently
  // erase the rest of a shop when changing just a gallery, cover or logo.
  static Future<void> updateShop({required String id, required Map<String, dynamic> values}) async {
    const editable = <String>{
      'name', 'brand', 'description', 'location_label', 'source',
      'logo_url', 'cover_image_url', 'menu_image_urls',
      'latitude', 'longitude', 'coordinate_source',
      'is_active', 'sort_order', 'show_bundled_gallery',
    };
    final payload = <String, dynamic>{};
    for (final key in editable) {
      if (values.containsKey(key)) {
        payload[key] = values[key];
      }
    }
    if (payload.isEmpty) return;
    if (payload['menu_image_urls'] != null && payload['menu_image_urls'] is! List) {
      throw const FormatException('Gallery must contain a list of image URLs.');
    }
    final changed = await Backend.db.from('pasabuy_shops')
        .update(payload).eq('id', id).select('id');
    if (changed.isEmpty) {
      throw StateError('Store was not updated. Check admin permissions and store ID.');
    }
  }

  static Future<String> createShop({
    required String name,
    required String locationLabel,
    required int sortOrder,
  }) async {
    if (name.trim().isEmpty) throw const FormatException('Store name is required.');
    final id = 'pabili-${DateTime.now().microsecondsSinceEpoch}';
    await Backend.db.from('pasabuy_shops').insert({
      'id': id,
      'name': name.trim(),
      'brand': 'custom',
      'description': '',
      'location_label': locationLabel.trim(),
      'source': 'Karlivery admin',
      'logo_url': null,
      'is_active': false, // New stores stay hidden until GPS and photos are verified.
      'sort_order': sortOrder,
      'coordinate_source': 'unverified',
      'menu_image_urls': <String>[],
      'show_bundled_gallery': false,
    }).select('id').single();
    return id;
  }

  static Future<void> updateItem({
    required String shopId,
    required Map<String, dynamic> item,
  }) async {
    final payload = {
      'shop_id': shopId,
      'name': item['name']?.toString().trim(),
      'price': double.tryParse(item['price']?.toString() ?? ''),
      'is_published': item['is_published'] == true,
      'is_available': item['is_available'] != false,
      'image_url': item['image_url']?.toString().trim(),
    };

    try {
      final categoryName = item['category_name']?.toString().trim().isNotEmpty == true
          ? item['category_name'].toString().trim()
          : 'Menu';
      String? categoryId;
      final existingCategory = await Backend.db
          .from('pasabuy_categories')
          .select('id')
          .eq('shop_id', shopId)
          .eq('name', categoryName)
          .maybeSingle();
      if (existingCategory != null) {
        categoryId = existingCategory['id']?.toString();
      } else {
        final created = await Backend.db
            .from('pasabuy_categories')
            .insert({'shop_id': shopId, 'name': categoryName})
            .select('id')
            .single();
        categoryId = created['id']?.toString();
      }
      payload['category_id'] = categoryId;

      final id = item['id']?.toString();
      if (id != null && id.isNotEmpty) {
        final existing = await Backend.db
            .from('pasabuy_items')
            .select('id')
            .eq('id', id)
            .maybeSingle();
        if (existing != null) {
          await Backend.db.from('pasabuy_items').update(payload).eq('id', id);
        } else {
          await Backend.db.from('pasabuy_items').insert({...payload, 'id': id});
        }
      } else {
        await Backend.db.from('pasabuy_items').insert(payload);
      }
    } catch (e) {
      throw Exception('Failed to save Pabili item: $e');
    }
  }

  static Future<List<Map<String, dynamic>>> seedDraftItems(String shopId) async {
    final seeds = (_fallbackItemsByShop[shopId] ?? const [])
        .map((e) => Map<String, dynamic>.from(e))
        .toList();
    try {
      for (final item in seeds) {
        await updateItem(shopId: shopId, item: item);
      }
    } catch (_) {}
    return seeds;
  }

  static Future<String> createOrder({
    required String shopId,
    required String paymentMethod,
    required List<Map<String, dynamic>> items,
    required String customRequest,
    double customRequestAmount = 0,
    required String notes,
    String? addressId,
    required double deliveryFee,
  }) async {
    final menuSubtotal = items.fold<double>(0, (sum, row) {
      final qty = int.tryParse(row['quantity']?.toString() ?? '1') ?? 1;
      final price = double.tryParse(row['unit_price']?.toString() ?? '') ?? 0;
      return sum + (qty * price);
    });
    final subtotal = menuSubtotal + (customRequestAmount < 0 ? 0 : customRequestAmount);

    try {
      final order = await Backend.db.from('pasabuy_orders').insert({
        'customer_id': Backend.user?.id,
        'shop_id': shopId,
        'address_id': addressId,
        'payment_method': paymentMethod,
        'payment_status': paymentMethod == 'rider_gcash' ? 'waiting_for_rider' : 'unpaid',
        'status': 'Waiting for Rider',
        'custom_request': customRequest.trim(),
        'custom_request_amount': customRequestAmount < 0 ? 0 : customRequestAmount,
        'notes': notes.trim(),
        'subtotal': subtotal,
        'handling_fee': handlingFee,
        'delivery_fee': deliveryFee,
        'total_amount': subtotal + handlingFee + deliveryFee,
      }).select('id').single();
      final orderId = order['id']?.toString() ?? 'PB-${DateTime.now().millisecondsSinceEpoch}';
      for (final row in items) {
        final insertedItem = await Backend.db.from('pasabuy_order_items').insert({
          'order_id': orderId,
          'item_name': row['name'],
          'item_price': row['unit_price'],
          'quantity': row['quantity'],
          'note': row['note'],
        }).select('id').single();
        final orderItemId = insertedItem['id']?.toString();
        final addons = row['addons'] is List ? List<Map<String, dynamic>>.from(row['addons']) : <Map<String, dynamic>>[];
        if (orderItemId != null) {
          for (final addon in addons) {
            await Backend.db.from('pasabuy_order_item_addons').insert({
              'order_item_id': orderItemId,
              'addon_name': addon['name'],
              'addon_price': addon['price'],
            });
          }
        }
      }
      // Items have been saved: notify online riders of the new Pabili job.
      await _pushPabiliEvent(orderId, 'pabili_created');
      return orderId;
    } catch (e) {
      throw Exception('Pabili order could not be saved: $e');
    }
  }

  static Future<List<Map<String, dynamic>>> extractMenuFromImage({
    required String shopId,
    required String shopName,
    required String filename,
    required Uint8List bytes,
    required String mimeType,
  }) async {
    final response = await Backend.db.functions.invoke(
      'pasabuy-menu-ocr',
      body: {
        'shop_id': shopId,
        'shop_name': shopName,
        'filename': filename,
        'mime_type': mimeType,
        'image_base64': base64Encode(bytes),
      },
    );
    final data = response.data;
    if (data is! Map) {
      throw Exception('OCR returned an invalid response.');
    }
    if (data['error'] != null) {
      throw Exception(data['error'].toString());
    }
    final rawItems = data['items'];
    if (rawItems is! List) return <Map<String, dynamic>>[];
    return rawItems
        .whereType<Map>()
        .map((raw) => {
              'shop_id': shopId,
              'category_name': raw['category']?.toString().trim().isNotEmpty == true
                  ? raw['category'].toString().trim()
                  : 'Menu',
              'name': raw['name']?.toString().trim() ?? '',
              'price': raw['price'],
              'is_published': false,
              'is_available': true,
              'ocr_confidence': raw['confidence'],
              'addons': raw['addons'] is List
                  ? List<Map<String, dynamic>>.from(
                      (raw['addons'] as List).whereType<Map>().map((a) => Map<String, dynamic>.from(a)),
                    )
                  : <Map<String, dynamic>>[],
            })
        .where((item) => item['name'].toString().isNotEmpty)
        .toList();
  }

  static Future<void> saveOcrDraftItems({
    required String shopId,
    required List<Map<String, dynamic>> items,
  }) async {
    for (final item in items) {
      final categoryName = item['category_name']?.toString().trim().isNotEmpty == true
          ? item['category_name'].toString().trim()
          : 'Menu';
      String? categoryId;
      final existingCategory = await Backend.db
          .from('pasabuy_categories')
          .select('id')
          .eq('shop_id', shopId)
          .eq('name', categoryName)
          .maybeSingle();
      if (existingCategory != null) {
        categoryId = existingCategory['id']?.toString();
      } else {
        final created = await Backend.db
            .from('pasabuy_categories')
            .insert({'shop_id': shopId, 'name': categoryName})
            .select('id')
            .single();
        categoryId = created['id']?.toString();
      }

      final createdItem = await Backend.db.from('pasabuy_items').insert({
        'shop_id': shopId,
        'category_id': categoryId,
        'name': item['name'],
        'price': item['price'],
        'source_type': 'ocr',
        'is_published': false,
        'is_available': true,
      }).select('id').single();
      final itemId = createdItem['id']?.toString();
      if (itemId != null && item['addons'] is List) {
        for (final addonRaw in item['addons'] as List) {
          if (addonRaw is! Map) continue;
          final addon = Map<String, dynamic>.from(addonRaw);
          final name = addon['name']?.toString().trim() ?? '';
          if (name.isEmpty) continue;
          await Backend.db.from('pasabuy_item_addons').insert({
            'item_id': itemId,
            'name': name,
            'price': double.tryParse(addon['price']?.toString() ?? '') ?? 0,
          });
        }
      }
    }
  }

  static Future<List<Map<String, dynamic>>> myOrders() async {
    try {
      final rows = await Backend.db
          .from('pasabuy_orders')
          .select('*, pasabuy_shops(name,location_label)')
          .eq('customer_id', Backend.user!.id)
          .order('created_at', ascending: false);
      return List<Map<String, dynamic>>.from(rows);
    } catch (_) {
      return <Map<String, dynamic>>[];
    }
  }

  static Future<Map<String, dynamic>?> orderById(String orderId) async {
    try {
      final raw = await Backend.db.rpc(
        'get_pasabuy_order_detail',
        params: {'p_order_id': orderId},
      );
      if (raw is Map) return Map<String, dynamic>.from(raw);
    } catch (_) {}
    return null;
  }

  static Future<List<Map<String, dynamic>>> orderItems(String orderId) async {
    final rows = await Backend.db
        .from('pasabuy_order_items')
        .select('*, pasabuy_order_item_addons(*)')
        .eq('order_id', orderId)
        .order('created_at');
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<List<Map<String, dynamic>>> riderAvailableOrders() async {
    try {
      final rows = await Backend.db
          .from('pasabuy_orders')
          .select('*, pasabuy_shops(name,location_label)')
          .eq('status', 'Waiting for Rider')
          .isFilter('rider_id', null)
          .order('created_at');
      return List<Map<String, dynamic>>.from(rows);
    } catch (_) {
      return <Map<String, dynamic>>[];
    }
  }

  static Future<List<Map<String, dynamic>>> riderAssignedOrders() async {
    try {
      final rows = await Backend.db
          .from('pasabuy_orders')
          .select('*, pasabuy_shops(name,location_label)')
          .eq('rider_id', Backend.user!.id)
          .neq('status', 'Delivered')
          .order('created_at');
      return List<Map<String, dynamic>>.from(rows);
    } catch (_) {
      return <Map<String, dynamic>>[];
    }
  }

  static Future<void> claimOrder(String orderId) async {
    await Backend.db.rpc('rider_claim_pasabuy_order', params: {'p_order_id': orderId});
    await _pushPabiliEvent(orderId, 'pabili_claimed');
  }

  // KARLIVERY_NO_EMAIL_RECEIPTS_2026: delivery and push only.
  static Future<void> updateStatus(String orderId, String status) async {
    await Backend.db.rpc('rider_set_pasabuy_status', params: {
      'p_order_id': orderId,
      'p_status': status,
    });
    await _pushPabiliEvent(orderId, 'pabili_status');
  }

  static Future<Map<String, dynamic>?> riderGcashProfile() async {
    final row = await Backend.db
        .from('profiles')
        .select('id,full_name,phone,rider_gcash_number,rider_gcash_qr_url')
        .eq('id', Backend.user!.id)
        .maybeSingle();
    return row == null ? null : Map<String, dynamic>.from(row);
  }

  static Future<String> uploadRiderGcashQr({
    required Uint8List bytes,
    required String extension,
  }) async {
    final path = '${Backend.user!.id}/gcash_${DateTime.now().millisecondsSinceEpoch}.$extension';
    await Backend.db.storage.from('rider-gcash-qr').uploadBinary(
          path,
          bytes,
          fileOptions: const FileOptions(upsert: true),
        );
    return Backend.db.storage.from('rider-gcash-qr').getPublicUrl(path);
  }

  static Future<void> saveRiderGcash({
    required String number,
    String? qrUrl,
  }) async {
    await Backend.db.rpc('rider_save_pasabuy_gcash', params: {
      'p_number': number.trim(),
      'p_qr_url': qrUrl,
    });
  }

  static Future<String> uploadPasabuyPaymentProof({
    required String orderId,
    required Uint8List bytes,
    required String extension,
  }) async {
    final path = '${Backend.user!.id}/$orderId/proof_${DateTime.now().millisecondsSinceEpoch}.$extension';
    await Backend.db.storage.from('pasabuy-payment-proofs').uploadBinary(
          path,
          bytes,
          fileOptions: const FileOptions(upsert: true),
        );
    return path;
  }

  static Future<String> signedPasabuyPaymentProof(String path) async {
    return Backend.db.storage
        .from('pasabuy-payment-proofs')
        .createSignedUrl(path, 900);
  }

  static Future<void> customerConfirmGcashSent({
    required String orderId,
    required String reference,
    String? proofPath,
  }) async {
    await Backend.db.rpc('customer_confirm_pasabuy_gcash_sent', params: {
      'p_order_id': orderId,
      'p_reference': reference.trim(),
      'p_proof_path': proofPath,
    });
    await _pushPabiliEvent(orderId, 'pabili_payment_sent');
  }

  static Future<void> riderConfirmGcashReceived(String orderId) async {
    await Backend.db.rpc('rider_confirm_pasabuy_gcash_received', params: {
      'p_order_id': orderId,
    });
    await _pushPabiliEvent(orderId, 'pabili_payment_received');
  }

  /// Customer and rider Pabili conversations are separate from normal-store
  /// chat_messages. Do not hide permission errors: they need to be visible.
  static Future<List<Map<String, dynamic>>> pabiliChatOrders({
    required bool forRider,
  }) async {
    final uid = Backend.user?.id;
    if (uid == null) throw StateError('Sign in to see your Pabili messages.');

    final query = Backend.db
        .from('pasabuy_orders')
        .select('id, status, rider_id, customer_id, created_at, pasabuy_shops(name)');
    final rows = forRider
        ? await query.eq('rider_id', uid).order('created_at', ascending: false)
        : await query.eq('customer_id', uid).order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<List<Map<String, dynamic>>> chatMessages(String orderId) async {
    final rows = await Backend.db
        .from('pasabuy_messages')
        .select()
        .eq('order_id', orderId)
        .order('created_at');
    return List<Map<String, dynamic>>.from(rows);
  }

  static Stream<List<Map<String, dynamic>>> watchChat(String orderId) {
    return Backend.db
        .from('pasabuy_messages')
        .stream(primaryKey: ['id'])
        .eq('order_id', orderId)
        .order('created_at')
        .map((rows) => List<Map<String, dynamic>>.from(rows));
  }

  static Future<void> sendMessage(String orderId, String text) async {
    final uid = Backend.user?.id;
    if (uid == null) throw StateError('Please sign in before sending messages.');
    final message = text.trim();
    if (message.isEmpty) return;
    if (message.length > 2000) {
      throw StateError('Pabili messages cannot exceed 2,000 characters.');
    }

    final order = await Backend.db
        .from('pasabuy_orders')
        .select('customer_id, rider_id')
        .eq('id', orderId)
        .maybeSingle();
    if (order == null) {
      throw StateError('This Pabili conversation is unavailable to your account.');
    }
    if (order['rider_id'] == null) {
      throw StateError('Wait for a rider to accept your Pabili order before chatting.');
    }
    final isCustomer = order['customer_id']?.toString() == uid;
    final isRider = order['rider_id']?.toString() == uid;
    if (!isCustomer && !isRider) {
      throw StateError('Only the customer and assigned rider can send Pabili messages.');
    }

    final saved = await Backend.db.from('pasabuy_messages').insert({
      'order_id': orderId,
      'sender_id': uid,
      'sender_role': isRider ? 'rider' : 'customer',
      'message': message,
    }).select('id').single();
    final messageId = saved['id']?.toString();
    if (messageId != null) {
      await _pushPabiliEvent(orderId, 'pabili_chat', messageId: messageId);
    }
  }

  /// Returns a GPS destination only to the order customer, the assigned rider,
  /// or an admin. The SQL RPC enforces the access check server-side.
  static Future<Map<String, dynamic>> trackingDestination(String orderId) async {
    final raw = await Backend.db.rpc(
      'karlivery_pabili_tracking_destination',
      params: {'p_order_id': orderId},
    );
    if (raw is! Map) {
      throw StateError('Pabili destination GPS is unavailable.');
    }
    return Map<String, dynamic>.from(raw);
  }

  static Future<void> updateRiderLocation({
    required String orderId,
    required double latitude,
    required double longitude,
    double? heading,
    double? speed,
  }) async {
    await Backend.db.from('pasabuy_rider_locations').upsert({
      'order_id': orderId,
      'rider_id': Backend.user!.id,
      'latitude': latitude,
      'longitude': longitude,
      'heading': heading,
      'speed': speed,
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    }, onConflict: 'order_id');
  }

  /// Polls authenticated latest GPS every 12s. Unlike a Realtime-only stream,
  /// it still works when a Supabase publication has not been enabled. A query
  /// failure is propagated to the map rather than shown as a fake location.
  static Stream<Map<String, dynamic>?> watchRiderLocation(String orderId) async* {
    Future<Map<String, dynamic>?> latest() async {
      final row = await Backend.db.from('pasabuy_rider_locations')
          .select('order_id,rider_id,latitude,longitude,heading,speed,updated_at')
          .eq('order_id', orderId).maybeSingle();
      return row == null ? null : Map<String, dynamic>.from(row);
    }
    yield await latest();
    await for (final _ in Stream.periodic(const Duration(seconds: 12))) {
      yield await latest();
    }
  }

  static Stream<Map<String, dynamic>?> watchOrder(String orderId) {
    return Backend.db
        .from('pasabuy_orders')
        .stream(primaryKey: ['id'])
        .eq('id', orderId)
        .map((rows) => rows.isEmpty ? null : Map<String, dynamic>.from(rows.first));
  }

}
