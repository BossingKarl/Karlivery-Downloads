import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';

class LocationResult {
  final double latitude;
  final double longitude;
  final String addressLine;
  final String barangay;
  final String city;
  final String province;
  final String postalCode;

  const LocationResult({
    required this.latitude,
    required this.longitude,
    this.addressLine = '',
    this.barangay = '',
    this.city = '',
    this.province = '',
    this.postalCode = '',
  });
}

class LocationService {
  LocationService._();

  static bool get supportedPlatform {
    if (kIsWeb) return true;
    return defaultTargetPlatform == TargetPlatform.android ||
        defaultTargetPlatform == TargetPlatform.iOS;
  }

  static Future<LocationPermission> ensurePermission() async {
    if (!supportedPlatform) return LocationPermission.denied;
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    return permission;
  }

  static Future<LocationResult?> currentWithAddress() async {
    if (!supportedPlatform) return null;
    if (!await Geolocator.isLocationServiceEnabled()) return null;

    final permission = await ensurePermission();
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      return null;
    }

    final p = await Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        timeLimit: Duration(seconds: 15),
      ),
    );
    return reverse(p.latitude, p.longitude);
  }

  static Future<LocationResult> reverse(double lat, double lng) async {
    String addressLine = '';
    String barangay = '';
    String city = '';
    String province = '';
    String postalCode = '';

    try {
      final marks = await placemarkFromCoordinates(lat, lng);
      if (marks.isNotEmpty) {
        final m = marks.first;
        final parts = <String>[
          if ((m.street ?? '').trim().isNotEmpty) m.street!.trim(),
          if ((m.subLocality ?? '').trim().isNotEmpty) m.subLocality!.trim(),
        ];
        addressLine = parts.join(', ');
        barangay = (m.subLocality ?? m.locality ?? '').trim();
        city = (m.locality ?? m.subAdministrativeArea ?? '').trim();
        province = (m.administrativeArea ?? '').trim();
        postalCode = (m.postalCode ?? '').trim();
      }
    } catch (_) {
      // Reverse geocoding can fail on some emulators/web browsers.
      // Coordinates remain useful and the user can edit the text fields.
    }

    return LocationResult(
      latitude: lat,
      longitude: lng,
      addressLine: addressLine,
      barangay: barangay,
      city: city,
      province: province,
      postalCode: postalCode,
    );
  }

  static Future<void> showStartupPermissionPrompt(BuildContext context) async {
    if (!supportedPlatform || !context.mounted) return;
    final existing = await Geolocator.checkPermission();
    if (existing != LocationPermission.denied) return;

    if (!context.mounted) return;
    final allow = await showModalBottomSheet<bool>(
      context: context,
      useSafeArea: true,
      isDismissible: true,
      showDragHandle: true,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(22, 8, 22, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              width: 64,
              height: 64,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Theme.of(ctx).colorScheme.primaryContainer,
                borderRadius: BorderRadius.circular(22),
              ),
              child: Icon(
                Icons.location_on_rounded,
                size: 34,
                color: Theme.of(ctx).colorScheme.primary,
              ),
            ),
            const SizedBox(height: 18),
            Text(
              'Allow location for faster delivery?',
              style: Theme.of(ctx).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Karlivery uses your location to pin delivery addresses, help fill address fields, and show nearby delivery information. You can still edit everything before saving.',
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: () => Navigator.pop(ctx, true),
              icon: const Icon(Icons.my_location_rounded),
              label: const Text('Allow location'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Not now'),
            ),
          ],
        ),
      ),
    );

    if (allow == true) {
      await Geolocator.requestPermission();
    }
  }
}
