import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';

import 'backend.dart';
import 'pasabuy_service.dart';

/// Foreground GPS session persists when rider opens chat / order details.
/// Does not pretend to provide background or terminated-app tracking.
class PasabuyGpsSession extends ChangeNotifier {
  PasabuyGpsSession._();
  static final PasabuyGpsSession instance = PasabuyGpsSession._();

  StreamSubscription<Position>? _subscription;
  Timer? _heartbeat;
  String? orderId;
  String? userId;
  String? lastError;
  DateTime? lastSentAt;
  bool _publishing = false;

  Future<void> start(String id) async {
    final current = Backend.user?.id;
    if (current == null) throw StateError('Sign in as the assigned rider.');
    if (!await Geolocator.isLocationServiceEnabled()) {
      throw StateError('Enable device Location services.');
    }
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      throw StateError('Allow precise location permission to share your position.');
    }
    await stop();
    // First GPS point must reach the database before claiming tracking works.
    final first = await Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 20),
      ),
    );
    await PasabuyService.updateRiderLocation(
      orderId: id, latitude: first.latitude, longitude: first.longitude,
      heading: first.heading, speed: first.speed,
    );
    orderId = id;
    userId = current;
    lastError = null;
    lastSentAt = DateTime.now();
    notifyListeners();
    const settings = LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 8);
    _subscription = Geolocator.getPositionStream(locationSettings: settings).listen(
      (point) => _publish(id, point),
      onError: (Object error) {
        lastError = 'GPS listener: $error';
        notifyListeners();
      },
    );
    // Heartbeat even while stationary: location streams can wait for movement.
    _heartbeat = Timer.periodic(const Duration(seconds: 25), (_) async {
      if (orderId != id || Backend.user?.id != current || _publishing) return;
      try {
        final point = await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(
            accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 15),
          ),
        );
        await _publish(id, point);
      } catch (error) {
        lastError = 'Location refresh failed: $error';
        notifyListeners();
      }
    });
  }

  Future<void> _publish(String id, Position position) async {
    if (orderId != id || Backend.user?.id != userId || _publishing) return;
    _publishing = true;
    try {
      await PasabuyService.updateRiderLocation(
        orderId: id, latitude: position.latitude, longitude: position.longitude,
        heading: position.heading, speed: position.speed,
      );
      lastSentAt = DateTime.now();
      lastError = null;
      notifyListeners();
    } catch (error) {
      lastError = 'Location upload failed: $error';
      notifyListeners();
    } finally {
      _publishing = false;
    }
  }

  Future<void> stop() async {
    _heartbeat?.cancel();
    _heartbeat = null;
    await _subscription?.cancel();
    _subscription = null;
    orderId = null;
    userId = null;
    lastError = null;
    notifyListeners();
  }
}
