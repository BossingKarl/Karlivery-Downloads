import 'package:flutter/material.dart';
import 'modern_palette.dart';

/// Modern restaurant card matching UberEats, GrabFood, DoorDash design language.
/// Shows restaurant image, rating, delivery time, and discount badge.
class ModernStoreCard extends StatelessWidget {
  final String id;
  final String name;
  final String? imageUrl;
  final String? category;
  final double rating;
  final int ratingCount;
  final double eta;
  final String? discount;
  final String? badge;
  final bool closed;
  final VoidCallback? onTap;

  const ModernStoreCard({
    super.key,
    required this.id,
    required this.name,
    this.imageUrl,
    this.category,
    this.rating = 4.5,
    this.ratingCount = 0,
    this.eta = 25,
    this.discount,
    this.badge,
    this.closed = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: closed ? null : onTap,
    child: Container(
      decoration: BoxDecoration(
        color: ModernPalette.surface,
        borderRadius: BorderRadius.circular(ModernRadius.lg),
        boxShadow: ModernShadow.sm,
        border: Border.all(color: ModernPalette.outline, width: 0.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// Image with badges overlay
          Stack(
            children: [
              /// Restaurant image
              Container(
                height: 180,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: ModernPalette.surfaceVariant,
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(ModernRadius.lg),
                  ),
                ),
                child: imageUrl != null
                    ? Image.network(
                        imageUrl!,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, _) => Center(
                          child: Icon(
                            Icons.restaurant,
                            size: 48,
                            color: ModernPalette.onSurfaceLight,
                          ),
                        ),
                      )
                    : Center(
                        child: Icon(
                          Icons.restaurant,
                          size: 48,
                          color: ModernPalette.onSurfaceLight,
                        ),
                      ),
              ),

              /// Closed overlay
              if (closed)
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.4),
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(ModernRadius.lg),
                      ),
                    ),
                    child: const Center(
                      child: Text(
                        'CLOSED',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                          letterSpacing: 1.2,
                        ),
                      ),
                    ),
                  ),
                ),

              /// Discount badge (top right)
              if (discount != null)
                Positioned(
                  top: ModernSpacing.md,
                  right: ModernSpacing.md,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: ModernSpacing.sm,
                      vertical: ModernSpacing.xs,
                    ),
                    decoration: BoxDecoration(
                      color: ModernPalette.discount,
                      borderRadius: BorderRadius.circular(ModernRadius.sm),
                    ),
                    child: Text(
                      discount!,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ),

              /// Badge (top left) - Promoted, Trending, etc
              if (badge != null)
                Positioned(
                  top: ModernSpacing.md,
                  left: ModernSpacing.md,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: ModernSpacing.sm,
                      vertical: ModernSpacing.xs,
                    ),
                    decoration: BoxDecoration(
                      color: ModernPalette.primary,
                      borderRadius: BorderRadius.circular(ModernRadius.sm),
                    ),
                    child: Text(
                      badge!,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ),
            ],
          ),

          /// Content section
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(ModernSpacing.md),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  /// Restaurant name
                  Text(
                    name,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: ModernPalette.onSurface,
                    ),
                  ),

                  /// Category and rating on same line
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      /// Rating stars
                      Expanded(
                        child: Row(
                          children: [
                            const Icon(
                              Icons.star_rounded,
                              size: 16,
                              color: ModernPalette.starRating,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              rating.toStringAsFixed(1),
                              style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: ModernPalette.onSurface,
                              ),
                            ),
                            if (ratingCount > 0) ...[
                              const SizedBox(width: 4),
                              Text(
                                '($ratingCount)',
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: ModernPalette.onSurfaceLight,
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),

                      /// Category
                      if (category != null)
                        Text(
                          category!,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 12,
                            color: ModernPalette.onSurfaceVariant,
                          ),
                        ),
                    ],
                  ),

                  const Spacer(),

                  /// ETA/Delivery time at bottom
                  Row(
                    children: [
                      const Icon(
                        Icons.access_time_rounded,
                        size: 14,
                        color: ModernPalette.onSurfaceVariant,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        '${eta.toInt()} min',
                        style: const TextStyle(
                          fontSize: 13,
                          color: ModernPalette.onSurfaceVariant,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Icon(
                        Icons.local_shipping_outlined,
                        size: 14,
                        color: ModernPalette.delivery,
                      ),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          'Free delivery',
                          style: const TextStyle(
                            fontSize: 12,
                            color: ModernPalette.delivery,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

/// Modern product/dish card for featured items and search results
class ModernProductCard extends StatelessWidget {
  final String name;
  final String? imageUrl;
  final double? price;
  final String? category;
  final double rating;
  final String? description;
  final bool featured;
  final VoidCallback? onTap;

  const ModernProductCard({
    super.key,
    required this.name,
    this.imageUrl,
    this.price,
    this.category,
    this.rating = 4.5,
    this.description,
    this.featured = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      decoration: BoxDecoration(
        color: ModernPalette.surface,
        borderRadius: BorderRadius.circular(ModernRadius.md),
        border: Border.all(color: ModernPalette.outline, width: 0.5),
        boxShadow: ModernShadow.xs,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// Image with featured badge
          Stack(
            children: [
              Container(
                height: 140,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: ModernPalette.surfaceVariant,
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(ModernRadius.md),
                  ),
                ),
                child: imageUrl != null
                    ? Image.network(
                        imageUrl!,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, _) => const Center(
                          child: Icon(
                            Icons.restaurant_menu,
                            size: 36,
                            color: ModernPalette.onSurfaceLight,
                          ),
                        ),
                      )
                    : const Center(
                        child: Icon(
                          Icons.restaurant_menu,
                          size: 36,
                          color: ModernPalette.onSurfaceLight,
                        ),
                      ),
              ),

              /// Featured badge
              if (featured)
                Positioned(
                  top: 8,
                  right: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: ModernPalette.primary,
                      borderRadius: BorderRadius.circular(ModernRadius.sm),
                    ),
                    child: const Text(
                      'Featured',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
            ],
          ),

          /// Content
          Padding(
            padding: const EdgeInsets.all(ModernSpacing.md),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /// Name
                Text(
                  name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: ModernPalette.onSurface,
                  ),
                ),

                /// Description
                if (description != null) ...[
                  const SizedBox(height: 4),
                  Text(
                    description!,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 12,
                      color: ModernPalette.onSurfaceVariant,
                    ),
                  ),
                ],

                const SizedBox(height: 8),

                /// Price and rating
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    if (price != null)
                      Text(
                        '₱${price!.toStringAsFixed(0)}',
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          color: ModernPalette.primary,
                        ),
                      ),
                    if (rating > 0)
                      Row(
                        children: [
                          const Icon(
                            Icons.star_rounded,
                            size: 14,
                            color: ModernPalette.starRating,
                          ),
                          const SizedBox(width: 2),
                          Text(
                            rating.toStringAsFixed(1),
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: ModernPalette.onSurface,
                            ),
                          ),
                        ],
                      ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

/// Modern search bar with location and filters
class ModernSearchBar extends StatelessWidget {
  final TextEditingController? controller;
  final String hintText;
  final VoidCallback? onFilterTap;
  final ValueChanged<String>? onChanged;

  const ModernSearchBar({
    super.key,
    this.controller,
    this.hintText = 'Search restaurants or food',
    this.onFilterTap,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(
      horizontal: ModernSpacing.lg,
      vertical: ModernSpacing.md,
    ),
    decoration: BoxDecoration(
      color: ModernPalette.surface,
      border: Border(
        bottom: BorderSide(color: ModernPalette.outline),
      ),
    ),
    child: Column(
      children: [
        /// Search bar
        Container(
          decoration: BoxDecoration(
            color: ModernPalette.surfaceVariant,
            borderRadius: BorderRadius.circular(ModernRadius.full),
            border: Border.all(color: ModernPalette.outline),
          ),
          child: TextField(
            controller: controller,
            onChanged: onChanged,
            decoration: InputDecoration(
              hintText: hintText,
              hintStyle: const TextStyle(
                color: ModernPalette.onSurfaceLight,
                fontSize: 14,
              ),
              border: InputBorder.none,
              prefixIcon: const Icon(
                Icons.search_rounded,
                color: ModernPalette.onSurfaceVariant,
              ),
              suffixIcon: onFilterTap != null
                  ? IconButton(
                      icon: const Icon(
                        Icons.tune_rounded,
                        color: ModernPalette.onSurfaceVariant,
                      ),
                      onPressed: onFilterTap,
                    )
                  : null,
              contentPadding: const EdgeInsets.symmetric(vertical: 12),
            ),
            style: const TextStyle(
              fontSize: 14,
              color: ModernPalette.onSurface,
            ),
          ),
        ),
      ],
    ),
  );
}

/// Modern category chip with professional icon
class ModernCategoryChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;
  final Color? backgroundColor;
  final Color? selectedColor;

  const ModernCategoryChip({
    super.key,
    required this.label,
    required this.icon,
    this.selected = false,
    required this.onTap,
    this.backgroundColor,
    this.selectedColor,
  });

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(
        horizontal: ModernSpacing.md,
        vertical: ModernSpacing.sm,
      ),
      decoration: BoxDecoration(
        color: selected 
            ? (selectedColor ?? ModernPalette.primary)
            : (backgroundColor ?? ModernPalette.surfaceVariant),
        borderRadius: BorderRadius.circular(ModernRadius.md),
        border: !selected ? Border.all(color: ModernPalette.outline) : null,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            color: selected ? Colors.white : ModernPalette.onSurfaceVariant,
            size: 24,
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: selected ? Colors.white : ModernPalette.onSurface,
            ),
          ),
        ],
      ),
    ),
  );
}
