import 'package:flutter/material.dart';
import 'claude_design.dart';

/// Claude-inspired elegant restaurant card.
/// Minimal, sophisticated design with thoughtful spacing and typography.
class ClaudeRestaurantCard extends StatelessWidget {
  final String id;
  final String name;
  final String? imageUrl;
  final String? cuisine;
  final double rating;
  final int ratingCount;
  final int deliveryMinutes;
  final String? deliveryFee;
  final bool closed;
  final VoidCallback? onTap;

  const ClaudeRestaurantCard({
    super.key,
    required this.id,
    required this.name,
    this.imageUrl,
    this.cuisine,
    this.rating = 4.5,
    this.ratingCount = 0,
    this.deliveryMinutes = 25,
    this.deliveryFee,
    this.closed = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: closed ? null : onTap,
    child: Container(
      decoration: BoxDecoration(
        color: ClaudeColors.background,
        borderRadius: BorderRadius.circular(ClaudeRadius.lg),
        border: Border.all(color: ClaudeColors.border),
        boxShadow: ClaudeShadow.xs,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// Image section
          Stack(
            children: [
              Container(
                height: 160,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: ClaudeColors.surfaceDark,
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(ClaudeRadius.lg - 1),
                  ),
                ),
                child: imageUrl != null
                    ? Image.network(
                        imageUrl!,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, _) => const Center(
                          child: Icon(
                            Icons.restaurant_outlined,
                            size: 48,
                            color: ClaudeColors.textTertiary,
                          ),
                        ),
                      )
                    : const Center(
                        child: Icon(
                          Icons.restaurant_outlined,
                          size: 48,
                          color: ClaudeColors.textTertiary,
                        ),
                      ),
              ),

              /// Closed overlay
              if (closed)
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.3),
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(ClaudeRadius.lg - 1),
                      ),
                    ),
                    child: const Center(
                      child: Text(
                        'Closed',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          fontSize: 14,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),

          /// Content section
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(ClaudeSpacing.lg),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  /// Restaurant name
                  Text(
                    name,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: ClaudeTypography.headingSmall.copyWith(
                      color: ClaudeColors.text,
                    ),
                  ),

                  /// Cuisine type
                  if (cuisine != null) ...[
                    const SizedBox(height: 4),
                    Text(
                      cuisine!,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: ClaudeTypography.bodySmall.copyWith(
                        color: ClaudeColors.textSecondary,
                      ),
                    ),
                  ],

                  const Spacer(),

                  /// Rating and delivery info
                  Row(
                    children: [
                      /// Rating
                      Icon(
                        Icons.star_rounded,
                        size: 16,
                        color: ClaudeColors.rating,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        rating.toStringAsFixed(1),
                        style: ClaudeTypography.labelMedium.copyWith(
                          color: ClaudeColors.text,
                        ),
                      ),
                      if (ratingCount > 0) ...[
                        const SizedBox(width: 4),
                        Text(
                          '($ratingCount)',
                          style: ClaudeTypography.captionSmall,
                        ),
                      ],
                      const Spacer(),

                      /// Delivery time and fee
                      Flexible(
                        child: Text(
                          '$deliveryMinutes min • ${deliveryFee ?? "Free"}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.right,
                          style: ClaudeTypography.labelSmall.copyWith(
                            color: ClaudeColors.textSecondary,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

/// Claude-inspired elegant product/dish card.
/// Minimal, focused on the essentials with refined typography.
class ClaudeDishCard extends StatelessWidget {
  final String name;
  final String? imageUrl;
  final double? price;
  final String? restaurant;
  final double rating;
  final bool featured;
  final VoidCallback? onTap;

  const ClaudeDishCard({
    super.key,
    required this.name,
    this.imageUrl,
    this.price,
    this.restaurant,
    this.rating = 0,
    this.featured = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      decoration: BoxDecoration(
        color: ClaudeColors.background,
        borderRadius: BorderRadius.circular(ClaudeRadius.lg),
        border: Border.all(color: ClaudeColors.border),
        boxShadow: ClaudeShadow.xs,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// Image
          Stack(
            children: [
              Container(
                height: 140,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: ClaudeColors.surfaceDark,
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(ClaudeRadius.lg - 1),
                  ),
                ),
                child: imageUrl != null
                    ? Image.network(
                        imageUrl!,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, _) => const Center(
                          child: Icon(
                            Icons.restaurant_menu_outlined,
                            size: 32,
                            color: ClaudeColors.textTertiary,
                          ),
                        ),
                      )
                    : const Center(
                        child: Icon(
                          Icons.restaurant_menu_outlined,
                          size: 32,
                          color: ClaudeColors.textTertiary,
                        ),
                      ),
              ),

              /// Featured label
              if (featured)
                Positioned(
                  top: ClaudeSpacing.md,
                  right: ClaudeSpacing.md,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: ClaudeSpacing.sm,
                      vertical: ClaudeSpacing.xs,
                    ),
                    decoration: BoxDecoration(
                      color: ClaudeColors.accent,
                      borderRadius: BorderRadius.circular(ClaudeRadius.xs),
                    ),
                    child: Text(
                      'Featured',
                      style: ClaudeTypography.labelSmall.copyWith(
                        color: ClaudeColors.background,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
            ],
          ),

          /// Content
          Padding(
            padding: const EdgeInsets.all(ClaudeSpacing.lg),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /// Name
                Text(
                  name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: ClaudeTypography.bodyMedium.copyWith(
                    color: ClaudeColors.text,
                    fontWeight: FontWeight.w600,
                  ),
                ),

                /// Restaurant name
                if (restaurant != null) ...[
                  const SizedBox(height: 4),
                  Text(
                    restaurant!,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: ClaudeTypography.captionSmall,
                  ),
                ],

                const SizedBox(height: 8),

                /// Price and rating
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    if (price != null)
                      Text(
                        '₱${price!.toStringAsFixed(0)}',
                        style: ClaudeTypography.labelLarge.copyWith(
                          color: ClaudeColors.primary,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    if (rating > 0)
                      Row(
                        children: [
                          const Icon(
                            Icons.star_rounded,
                            size: 14,
                            color: ClaudeColors.rating,
                          ),
                          const SizedBox(width: 2),
                          Text(
                            rating.toStringAsFixed(1),
                            style: ClaudeTypography.labelSmall.copyWith(
                              color: ClaudeColors.text,
                            ),
                          ),
                        ],
                      ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

/// Claude-style search and filter bar.
/// Elegant, minimal search interface.
class ClaudeSearchBar extends StatelessWidget {
  final TextEditingController? controller;
  final String placeholder;
  final ValueChanged<String>? onChanged;
  final VoidCallback? onFilterTap;

  const ClaudeSearchBar({
    super.key,
    this.controller,
    this.placeholder = 'Search restaurants or dishes',
    this.onChanged,
    this.onFilterTap,
  });

  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(
      color: ClaudeColors.background,
      border: Border(
        bottom: BorderSide(color: ClaudeColors.border),
      ),
    ),
    padding: const EdgeInsets.symmetric(
      horizontal: ClaudeSpacing.lg,
      vertical: ClaudeSpacing.md,
    ),
    child: TextField(
      controller: controller,
      onChanged: onChanged,
      decoration: InputDecoration(
        hintText: placeholder,
        hintStyle: ClaudeTypography.bodyMedium.copyWith(
          color: ClaudeColors.textHint,
        ),
        prefixIcon: const Icon(
          Icons.search_outlined,
          color: ClaudeColors.textSecondary,
        ),
        suffixIcon: onFilterTap != null
            ? IconButton(
                icon: const Icon(
                  Icons.tune_outlined,
                  color: ClaudeColors.textSecondary,
                ),
                onPressed: onFilterTap,
              )
            : null,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(ClaudeRadius.md),
          borderSide: const BorderSide(color: ClaudeColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(ClaudeRadius.md),
          borderSide: const BorderSide(color: ClaudeColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(ClaudeRadius.md),
          borderSide: const BorderSide(
            color: ClaudeColors.primary,
            width: 1.5,
          ),
        ),
        filled: true,
        fillColor: ClaudeColors.surfaceDark,
        contentPadding: const EdgeInsets.symmetric(vertical: 12),
      ),
      style: ClaudeTypography.bodyMedium.copyWith(
        color: ClaudeColors.text,
      ),
    ),
  );
}

/// Claude-style category button.
/// Elegant, minimal category selection.
class ClaudeCategoryButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const ClaudeCategoryButton({
    super.key,
    required this.label,
    required this.icon,
    this.selected = false,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(
        horizontal: ClaudeSpacing.md,
        vertical: ClaudeSpacing.sm,
      ),
      decoration: BoxDecoration(
        color: selected ? ClaudeColors.primary : ClaudeColors.background,
        border: Border.all(
          color: selected ? ClaudeColors.primary : ClaudeColors.border,
          width: 1.5,
        ),
        borderRadius: BorderRadius.circular(ClaudeRadius.md),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            color: selected ? Colors.white : ClaudeColors.textSecondary,
            size: 20,
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: ClaudeTypography.labelSmall.copyWith(
              color: selected ? Colors.white : ClaudeColors.text,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    ),
  );
}
