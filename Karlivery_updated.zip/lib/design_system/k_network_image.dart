import 'package:flutter/material.dart';
import 'k_tokens.dart';

/// Single network-image primitive for the whole app.
///
/// - Shimmer placeholder while loading (no blank pop-in).
/// - Smooth fade-in once the first frame is ready.
/// - Decodes at display size (cacheWidth) so mid-range Android phones do not
///   hold full-resolution photos in memory.
/// - Neutral, non-invented fallback on failure.
class KNetImage extends StatelessWidget {
  const KNetImage(
    this.url, {
    super.key,
    this.fit = BoxFit.cover,
    this.width,
    this.height,
    this.color,
    this.errorBuilder,
    this.maxDecodeWidth = 1200,
  });

  final String url;
  final BoxFit fit;
  final double? width;
  final double? height;
  final Color? color;
  final ImageErrorWidgetBuilder? errorBuilder;
  final int maxDecodeWidth;

  @override
  Widget build(BuildContext context) {
    // No LayoutBuilder: it cannot be used inside IntrinsicHeight/Width.
    final dpr = MediaQuery.devicePixelRatioOf(context);
    final cacheWidth = width != null && width!.isFinite && width! > 0
        ? (width! * dpr).round().clamp(64, maxDecodeWidth)
        : (720 < maxDecodeWidth ? 720 : maxDecodeWidth);
    return Image.network(
      url,
      fit: fit,
      width: width,
      height: height,
      color: color,
      cacheWidth: cacheWidth,
      gaplessPlayback: true,
      errorBuilder: errorBuilder ??
          (_, _, _) => const ColoredBox(color: KPalette.hairline),
      frameBuilder: (context, child, frame, sync) {
        if (sync) return child;
        return Stack(fit: StackFit.passthrough, children: [
          if (frame == null) const Positioned.fill(child: KShimmer()),
          AnimatedOpacity(
            opacity: frame == null ? 0 : 1,
            duration: KMotion.standard,
            curve: KMotion.ease,
            child: child,
          ),
        ]);
      },
    );
  }
}

/// Lightweight shimmer block used for image and card loading states.
class KShimmer extends StatefulWidget {
  const KShimmer({super.key, this.radius = 0});
  final double radius;

  @override
  State<KShimmer> createState() => _KShimmerState();
}

class _KShimmerState extends State<KShimmer>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1300),
  )..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final base = dark ? KPalette.darkSurface : KPalette.hairline;
    final hi = dark ? KPalette.darkLine : const Color(0xFFF4F4F7);
    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) => DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(widget.radius),
          gradient: LinearGradient(
            begin: Alignment(-1.0 + 2.4 * _c.value, 0),
            end: Alignment(0.2 + 2.4 * _c.value, 0),
            colors: [base, hi, base],
          ),
        ),
        child: const SizedBox.expand(),
      ),
    );
  }
}

/// Skeleton placeholder shaped like a restaurant card, shown while Home loads.
class KStoreCardSkeleton extends StatelessWidget {
  const KStoreCardSkeleton({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const AspectRatio(aspectRatio: 1.65, child: KShimmer(radius: KRadius.md)),
      const SizedBox(height: KSpace.xs),
      SizedBox(
          height: 14,
          width: 140,
          child: const KShimmer(radius: KRadius.xs)),
      const SizedBox(height: 6),
      SizedBox(
          height: 12,
          width: 90,
          child: const KShimmer(radius: KRadius.xs)),
    ]);
  }
}
