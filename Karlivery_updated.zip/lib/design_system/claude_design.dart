import 'package:flutter/material.dart';

/// Claude-inspired design system for Karlivery.
/// Elegant, minimal, sophisticated - the kind of design that makes people pause
/// and appreciate the beauty and thoughtfulness of the interface.

abstract final class ClaudeColors {
  // Sophisticated neutral palette - the foundation of elegance
  static const surface = Color(0xFFFAFAFA);        // Almost white, very subtle
  static const surfaceDark = Color(0xFFF5F5F5);    // Slightly darker surface
  static const background = Color(0xFFFFFFFF);    // Pure white for content areas
  
  // Elegant neutrals for text and depth
  static const text = Color(0xFF0F0F0F);          // Deep charcoal, not pure black
  static const textSecondary = Color(0xFF626262);  // Medium gray, professional
  static const textTertiary = Color(0xFF9A9A9A);   // Light gray, subtle
  static const textHint = Color(0xFFC4C4C4);       // Very light gray
  
  // Elegant accent - sophisticated teal/blue inspired
  static const primary = Color(0xFF1E8E89);        // Sophisticated teal
  static const primaryLight = Color(0xFFE8F5F3);   // Very soft teal background
  static const primaryDark = Color(0xFF156B63);    // Darker teal for interactions
  
  // Complementary accent for warmth
  static const accent = Color(0xFFD97706);         // Warm amber/gold
  static const accentLight = Color(0xFFFEF3C7);    // Soft amber background
  
  // Status colors - refined and sophisticated
  static const success = Color(0xFF059669);        // Elegant green
  static const successLight = Color(0xFFECFDF5);
  static const warning = Color(0xFFD97706);        // Amber
  static const warningLight = Color(0xFFFEF3C7);
  static const error = Color(0xFFDC2626);          // Red
  static const errorLight = Color(0xFFFEE2E2);
  static const info = Color(0xFF0284C7);           // Blue
  static const infoLight = Color(0xFFE0F2FE);
  
  // Borders and dividers - subtle, refined
  static const border = Color(0xFFE5E7EB);         // Light border
  static const borderLight = Color(0xFFF3F4F6);    // Very subtle
  
  // Special
  static const rating = Color(0xFFFCD34D);         // Soft gold for stars
}

abstract final class ClaudeSpacing {
  static const none = 0.0;
  static const xs = 4.0;
  static const sm = 8.0;
  static const md = 12.0;
  static const lg = 16.0;
  static const xl = 20.0;
  static const xxl = 24.0;
  static const xxxl = 32.0;
  static const huge = 40.0;
  static const massive = 48.0;
}

abstract final class ClaudeRadius {
  static const xs = 4.0;
  static const sm = 8.0;
  static const md = 12.0;
  static const lg = 16.0;
  static const xl = 20.0;
  static const full = 999.0;
}

abstract final class ClaudeShadow {
  // Subtle, elegant shadows that don't overpower
  static const none = [];
  
  static const xs = [
    BoxShadow(
      color: Color(0x06000000),
      blurRadius: 1,
      offset: Offset(0, 1),
    ),
  ];

  static const sm = [
    BoxShadow(
      color: Color(0x0A000000),
      blurRadius: 2,
      offset: Offset(0, 1),
    ),
  ];

  static const md = [
    BoxShadow(
      color: Color(0x0F000000),
      blurRadius: 4,
      offset: Offset(0, 2),
    ),
  ];

  static const lg = [
    BoxShadow(
      color: Color(0x12000000),
      blurRadius: 8,
      offset: Offset(0, 4),
    ),
  ];

  static const xl = [
    BoxShadow(
      color: Color(0x18000000),
      blurRadius: 12,
      offset: Offset(0, 6),
    ),
  ];
}

abstract final class ClaudeTypography {
  // Elegant serif for display (rare, used for special moments)
  // Main font: sophisticated sans-serif for modern appeal
  static const fontFamily = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
  
  // Display sizes - rare, for hero moments
  static const displayXL = TextStyle(
    fontSize: 36,
    fontWeight: FontWeight.w600,
    height: 1.2,
    letterSpacing: -0.6,
  );

  static const displayLarge = TextStyle(
    fontSize: 32,
    fontWeight: FontWeight.w600,
    height: 1.2,
    letterSpacing: -0.5,
  );

  static const displayMedium = TextStyle(
    fontSize: 28,
    fontWeight: FontWeight.w600,
    height: 1.25,
    letterSpacing: -0.3,
  );

  // Heading sizes - clear hierarchy
  static const headingXL = TextStyle(
    fontSize: 24,
    fontWeight: FontWeight.w600,
    height: 1.3,
    letterSpacing: -0.2,
  );

  static const headingLarge = TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.w600,
    height: 1.35,
  );

  static const headingMedium = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.w600,
    height: 1.35,
  );

  static const headingSmall = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w600,
    height: 1.4,
  );

  // Body text - readable, elegant
  static const bodyLarge = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w400,
    height: 1.6,
    letterSpacing: 0.15,
  );

  static const bodyMedium = TextStyle(
    fontSize: 15,
    fontWeight: FontWeight.w400,
    height: 1.6,
    letterSpacing: 0.15,
  );

  static const bodySmall = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.w400,
    height: 1.5,
    letterSpacing: 0.15,
  );

  // Labels and fine print
  static const labelLarge = TextStyle(
    fontSize: 13,
    fontWeight: FontWeight.w600,
    height: 1.4,
    letterSpacing: 0.3,
  );

  static const labelMedium = TextStyle(
    fontSize: 12,
    fontWeight: FontWeight.w600,
    height: 1.35,
    letterSpacing: 0.2,
  );

  static const labelSmall = TextStyle(
    fontSize: 11,
    fontWeight: FontWeight.w500,
    height: 1.3,
    letterSpacing: 0.1,
  );

  // Caption - for secondary info
  static const caption = TextStyle(
    fontSize: 12,
    fontWeight: FontWeight.w400,
    height: 1.4,
    color: ClaudeColors.textTertiary,
  );

  static const captionSmall = TextStyle(
    fontSize: 11,
    fontWeight: FontWeight.w400,
    height: 1.3,
    color: ClaudeColors.textTertiary,
  );
}

/// Claude-inspired theme data
ThemeData claudeTheme() {
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    scaffoldBackgroundColor: ClaudeColors.surface,
    colorScheme: ColorScheme.light(
      surface: ClaudeColors.background,
      surfaceContainer: ClaudeColors.surfaceDark,
      primary: ClaudeColors.primary,
      onPrimary: Colors.white,
      secondary: ClaudeColors.accent,
      error: ClaudeColors.error,
      onError: Colors.white,
    ),
    
    // Typography
    fontFamily: 'Outfit, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto',
    textTheme: TextTheme(
      displayLarge: ClaudeTypography.displayLarge.copyWith(
        color: ClaudeColors.text,
      ),
      displayMedium: ClaudeTypography.displayMedium.copyWith(
        color: ClaudeColors.text,
      ),
      headlineLarge: ClaudeTypography.headingXL.copyWith(
        color: ClaudeColors.text,
      ),
      headlineMedium: ClaudeTypography.headingLarge.copyWith(
        color: ClaudeColors.text,
      ),
      headlineSmall: ClaudeTypography.headingMedium.copyWith(
        color: ClaudeColors.text,
      ),
      titleLarge: ClaudeTypography.headingSmall.copyWith(
        color: ClaudeColors.text,
      ),
      titleMedium: ClaudeTypography.labelLarge.copyWith(
        color: ClaudeColors.text,
      ),
      bodyLarge: ClaudeTypography.bodyLarge.copyWith(
        color: ClaudeColors.text,
      ),
      bodyMedium: ClaudeTypography.bodyMedium.copyWith(
        color: ClaudeColors.text,
      ),
      bodySmall: ClaudeTypography.bodySmall.copyWith(
        color: ClaudeColors.textSecondary,
      ),
      labelLarge: ClaudeTypography.labelLarge.copyWith(
        color: ClaudeColors.text,
      ),
    ),
    
    // App bar
    appBarTheme: AppBarTheme(
      backgroundColor: ClaudeColors.background,
      foregroundColor: ClaudeColors.text,
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      centerTitle: false,
      titleTextStyle: ClaudeTypography.headingSmall.copyWith(
        color: ClaudeColors.text,
      ),
    ),
    
    // Cards
    cardTheme: CardThemeData(
      color: ClaudeColors.background,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(ClaudeRadius.lg),
        side: const BorderSide(color: ClaudeColors.border, width: 1),
      ),
      surfaceTintColor: Colors.transparent,
    ),
    
    // Input decoration
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: ClaudeColors.surfaceDark,
      contentPadding: const EdgeInsets.symmetric(
        horizontal: ClaudeSpacing.lg,
        vertical: ClaudeSpacing.md,
      ),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(ClaudeRadius.md),
        borderSide: const BorderSide(color: ClaudeColors.border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(ClaudeRadius.md),
        borderSide: const BorderSide(color: ClaudeColors.border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(ClaudeRadius.md),
        borderSide: const BorderSide(
          color: ClaudeColors.primary,
          width: 1.5,
        ),
      ),
      hintStyle: ClaudeTypography.bodyMedium.copyWith(
        color: ClaudeColors.textHint,
      ),
      labelStyle: ClaudeTypography.labelLarge.copyWith(
        color: ClaudeColors.primary,
      ),
    ),
    
    // Buttons
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: ClaudeColors.primary,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(
          horizontal: ClaudeSpacing.xl,
          vertical: ClaudeSpacing.lg,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(ClaudeRadius.md),
        ),
        elevation: 0,
      ),
    ),
    
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: ClaudeColors.primary,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(
          horizontal: ClaudeSpacing.xl,
          vertical: ClaudeSpacing.lg,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(ClaudeRadius.md),
        ),
      ),
    ),
    
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: ClaudeColors.primary,
        side: const BorderSide(color: ClaudeColors.border),
        padding: const EdgeInsets.symmetric(
          horizontal: ClaudeSpacing.xl,
          vertical: ClaudeSpacing.lg,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(ClaudeRadius.md),
        ),
      ),
    ),
    
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: ClaudeColors.primary,
        padding: const EdgeInsets.symmetric(
          horizontal: ClaudeSpacing.lg,
          vertical: ClaudeSpacing.md,
        ),
      ),
    ),
    
    // Navigation
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: ClaudeColors.background,
      elevation: 0,
      labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
      indicatorColor: ClaudeColors.primaryLight,
      labelTextStyle: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.selected)) {
          return ClaudeTypography.labelMedium.copyWith(
            color: ClaudeColors.primary,
          );
        }
        return ClaudeTypography.labelMedium.copyWith(
          color: ClaudeColors.textTertiary,
        );
      }),
    ),
    
    // Divider
    dividerColor: ClaudeColors.border,
    dividerTheme: const DividerThemeData(
      color: ClaudeColors.border,
      thickness: 1,
      space: 1,
    ),
  );
}
