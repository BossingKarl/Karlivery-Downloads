import 'package:flutter/material.dart';
import 'k_tokens.dart';

/// Semantic primitives, shared by customer discovery and all 3 workspaces.
/// These accept real values and callbacks from existing features.
class KDSSectionHeading extends StatelessWidget {
  const KDSSectionHeading({super.key, required this.title, this.eyebrow,
    this.subtitle, this.trailing});
  final String title;
  final String? eyebrow;
  final String? subtitle;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (eyebrow != null) ...[
            Text(eyebrow!.toUpperCase(), style: KTypography.eyebrow.copyWith(color: scheme.primary)),
            const SizedBox(height: 5),
          ],
          Text(title, maxLines: 3, overflow: TextOverflow.ellipsis,
            style: KTypography.section.copyWith(color: scheme.onSurface)),
          if (subtitle != null) ...[
            const SizedBox(height: 5),
            Text(subtitle!, style: KTypography.meta.copyWith(color: scheme.onSurfaceVariant)),
          ],
        ])),
        if (trailing != null) ...[const SizedBox(width: 8), trailing!],
      ]),
    );
  }
}

class KDSStatusBadge extends StatelessWidget {
  const KDSStatusBadge({super.key, required this.label, required this.color,
    this.icon, this.darkText = false});
  final String label;
  final Color color;
  final IconData? icon;
  final bool darkText;

  @override
  Widget build(BuildContext context) => DecoratedBox(
    decoration: BoxDecoration(
      color: color.withValues(alpha: .12),
      borderRadius: BorderRadius.circular(KRadius.pill),
      border: Border.all(color: color.withValues(alpha: .16)),
    ),
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        if (icon != null) ...[Icon(icon, size: 13, color: darkText ? KPalette.ink : color), const SizedBox(width: 4)],
        Text(label, maxLines: 1, overflow: TextOverflow.ellipsis,
          style: KTypography.meta.copyWith(fontWeight: FontWeight.w700,
            color: darkText ? KPalette.ink : color)),
      ]),
    ),
  );
}

class KDSIconTile extends StatelessWidget {
  const KDSIconTile({super.key, required this.icon, this.color, this.size = 40});
  final IconData icon;
  final Color? color;
  final double size;

  @override
  Widget build(BuildContext context) {
    final accent = color ?? Theme.of(context).colorScheme.primary;
    return Container(
      height: size, width: size,
      decoration: BoxDecoration(
        color: accent.withValues(alpha: .11),
        borderRadius: BorderRadius.circular(size * .32),
      ),
      child: Icon(icon, color: accent, size: size * .45),
    );
  }
}

class KDSStatCard extends StatelessWidget {
  const KDSStatCard({super.key, required this.label, required this.value,
    required this.icon, this.accent});
  final String label;
  final String value;
  final IconData icon;
  final Color? accent;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final dark = theme.brightness == Brightness.dark;
    final highlight = accent ?? KPalette.red;
    return Semantics(
      label: '$label: $value',
      child: Container(
        constraints: const BoxConstraints(minHeight: 108),
        padding: const EdgeInsets.all(KSpace.md),
        decoration: BoxDecoration(
          color: dark ? scheme.surface : Colors.white,
          borderRadius: BorderRadius.circular(KRadius.lg),
          border: Border.all(color: dark ? KPalette.darkLine : highlight.withValues(alpha: .08)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(children: [
              Container(
                width: 30, height: 30,
                decoration: BoxDecoration(
                  color: dark ? highlight.withValues(alpha: .18) : Colors.white,
                  borderRadius: BorderRadius.circular(KRadius.sm)),
                child: Icon(icon, size: 16, color: dark ? scheme.primary : highlight)),
              const Spacer(),
              const SizedBox.shrink(),
            ]),
            const SizedBox(height: KSpace.sm),
            Text(value, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: KTypography.money.copyWith(color: scheme.onSurface)),
            const SizedBox(height: 4),
            Text(label, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: KTypography.meta.copyWith(color: scheme.onSurfaceVariant,
                fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }
}

enum KDSWorkspace { customer, rider, seller, admin }

class KDSWorkspaceHero extends StatelessWidget {
  const KDSWorkspaceHero({super.key, required this.workspace,
    required this.eyebrow, required this.title, required this.subtitle,
    required this.icon, this.trailing});
  final KDSWorkspace workspace;
  final String eyebrow;
  final String title;
  final String subtitle;
  final IconData icon;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final ink = scheme.onSurface;
    final subtle = scheme.onSurfaceVariant;
    return Semantics(container: true, child: Container(
      width: double.infinity,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(KRadius.xl),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Stack(children: [
        Positioned(top: -72, right: -64,
          child: Container(width: 236, height: 236,
            decoration: BoxDecoration(shape: BoxShape.circle,
              color: scheme.surface))),
        Positioned(top: 21, right: 20, child: Container(
          height: 38, width: 38,
          decoration: BoxDecoration(color: KPalette.blush,
            borderRadius: BorderRadius.circular(KRadius.md)),
          child: Icon(icon, size: 19, color: KPalette.red),
        )),
        Padding(
          padding: const EdgeInsets.fromLTRB(21, 25, 75, 23),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(eyebrow.toUpperCase(), maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: KTypography.eyebrow.copyWith(
                color: KPalette.red)),
            const SizedBox(height: 11),
            Text(title, maxLines: 3, overflow: TextOverflow.ellipsis,
              style: KTypography.hero.copyWith(color: ink,
                fontSize: MediaQuery.sizeOf(context).width < 370 ? 22 : 25)),
            const SizedBox(height: 9),
            Text(subtitle, maxLines: 4, overflow: TextOverflow.ellipsis,
              style: KTypography.body.copyWith(color: subtle, fontSize: 12.5)),
            if (trailing != null) ...[
              const SizedBox(height: KSpace.md),
              Container(
                constraints: const BoxConstraints(minHeight: 48),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(KRadius.md)),
                child: IconTheme(data: const IconThemeData(color: KPalette.red),
                  child: DefaultTextStyle(style: const TextStyle(color: KPalette.ink),
                    child: trailing!)),
              ),
            ],
          ]),
        ),
      ]),
    ));
  }
}

/// A reusable full-width action surface; never invents or performs any action.
class KDSActionTile extends StatelessWidget {
  const KDSActionTile({super.key, required this.icon, required this.title,
    required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Material(
      color: theme.colorScheme.surface,
      clipBehavior: Clip.antiAlias,
      borderRadius: BorderRadius.circular(KRadius.lg),
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(KSpace.md),
          constraints: const BoxConstraints(minHeight: 82),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(KRadius.lg),
            border: Border.all(color: theme.colorScheme.outlineVariant)),
          child: Row(children: [
            KDSIconTile(icon: icon),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, maxLines: 2, overflow: TextOverflow.ellipsis,
                style: KTypography.cardTitle.copyWith(color: theme.colorScheme.onSurface)),
              const SizedBox(height: 4),
              Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis,
                style: KTypography.meta.copyWith(color: theme.colorScheme.onSurfaceVariant)),
            ])),
            const SizedBox(width: 7),
            Icon(Icons.chevron_right_rounded, size: 20, color: theme.colorScheme.onSurfaceVariant),
          ]),
        ),
      ),
    );
  }
}
