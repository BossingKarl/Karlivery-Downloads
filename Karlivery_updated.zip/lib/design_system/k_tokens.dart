import 'package:flutter/material.dart';

/// Karlivery / Atelier — a single, implementation-level source of design truth.
/// Presentation-only. Do not place business rules, Supabase or order state here.
abstract final class KPalette {
  static const red = Color(0xFFE51E32);
  static const redDark = Color(0xFFB91429);
  static const redPressed = Color(0xFF9C1025);
  static const yellow = Color(0xFFFFCC35);
  static const yellowSoft = Color(0xFFFFF1CC);
  static const yellowDeep = Color(0xFFF5A900);
  static const canvas = Color(0xFFF8F8FA);
  static const paper = Color(0xFFFFFFFF);
  static const ink = Color(0xFF1C1C1E);
  static const secondaryInk = Color(0xFF73737A);
  static const hairline = Color(0xFFE8E8ED);
  static const blush = Color(0xFFFFEBED);
  static const success = Color(0xFF168657);
  static const successSoft = Color(0xFFE7F8EE);
  static const darkCanvas = Color(0xFF141217);
  static const darkSurface = Color(0xFF211C24);
  static const darkLine = Color(0xFF403541);
  static const star = Color(0xFFFAA500);
  static const openBadge = Color(0xFF1F7541);
  static const closedBadge = Color(0xFF444049);
}

abstract final class KSpace {
  static const xxs = 4.0;
  static const xs = 8.0;
  static const sm = 12.0;
  static const md = 16.0;
  static const lg = 20.0;
  static const xl = 24.0;
  static const xxl = 32.0;
  static const xxxl = 40.0;
}

abstract final class KRadius {
  static const xs = 10.0;
  static const sm = 14.0;
  static const md = 18.0;
  static const lg = 20.0;
  static const xl = 24.0;
  static const pill = 999.0;
}

abstract final class KBreakpoints {
  static const narrow = 340.0;
  static const tablet = 720.0;
  static const desktop = 1050.0;
  static const wideDesktop = 1440.0;

  /// Minimum card dimension prevents cramped tiles at 320px and large text.
  static int storeColumns(double width, {double textScale = 1}) {
    if (width < 330 || textScale > 1.5) return 1;
    if (width < tablet) return 2;
    if (width < desktop) return 3;
    return 4;
  }
}

abstract final class KMotion {
  static const fast = Duration(milliseconds: 140);
  static const standard = Duration(milliseconds: 220);
  static const slow = Duration(milliseconds: 320);
  static const ease = Curves.easeOutCubic;
}

abstract final class KShadows {
  static List<BoxShadow> soft({bool dark = false}) => [
    BoxShadow(
      color: Colors.black.withValues(alpha: dark ? .16 : .045),
      blurRadius: 22,
      offset: const Offset(0, 8),
    ),
  ];
}

abstract final class KTypography {
  static const family = 'Roboto'; // Android-safe native-like type; iOS uses the platform renderer.
  static const eyebrow = TextStyle(fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 1.5);
  static const hero = TextStyle(fontSize: 29, fontWeight: FontWeight.w800, letterSpacing: -1.0, height: 1.09);
  static const section = TextStyle(fontSize: 21, fontWeight: FontWeight.w800, letterSpacing: -.6, height: 1.17);
  static const cardTitle = TextStyle(fontSize: 15, fontWeight: FontWeight.w700, letterSpacing: -.25, height: 1.25);
  static const body = TextStyle(fontSize: 14, fontWeight: FontWeight.w500, height: 1.45);
  static const meta = TextStyle(fontSize: 12, fontWeight: FontWeight.w600, height: 1.32);
  static const money = TextStyle(fontSize: 21, fontWeight: FontWeight.w800, letterSpacing: -.5);
}
