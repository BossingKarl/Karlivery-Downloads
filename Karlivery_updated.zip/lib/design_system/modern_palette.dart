import 'package:flutter/material.dart';

/// Modern food delivery app palette inspired by GrabFood, Uber Eats, DoorDash.
/// Primary colors are vibrant and appetizing; neutral palette is clean and minimal.
abstract final class ModernPalette {
  // Primary brand colors - vibrant and energetic like UberEats (red) + GrabFood (green)
  static const primary = Color(0xFFE63946);      // Vibrant red - main action
  static const primaryDark = Color(0xFFD62828);  // Darker red for pressed states
  static const primaryLight = Color(0xFFFF6B7A); // Light red for backgrounds
  static const primaryBg = Color(0xFFFAEAED);    // Very light pink background

  // Secondary accent - green energy (GrabFood inspired)
  static const secondary = Color(0xFF06A77D);    // Fresh green for positives
  static const secondaryLight = Color(0xFFE1F5EE);
  
  // Neutral palette - clean like DoorDash
  static const surface = Color(0xFFFFFFFF);      // Pure white surface
  static const surfaceVariant = Color(0xFFFAFAFA);  // Very light gray
  static const outline = Color(0xFFE0E0E0);      // Subtle borders
  static const outlineDark = Color(0xFFC5C5C5);

  // Text colors
  static const onSurface = Color(0xFF1A1A1A);    // Dark text
  static const onSurfaceVariant = Color(0xFF666666); // Medium gray text
  static const onSurfaceLight = Color(0xFF999999);   // Light gray text

  // Status colors
  static const success = Color(0xFF06A77D);      // Success/ready
  static const warning = Color(0xFFF59E0B);      // In progress
  static const error = Color(0xFFDC2626);        // Error/closed
  static const info = Color(0xFF0EA5E9);         // Info/open soon

  // Special colors
  static const starRating = Color(0xFFFABD02);   // Gold star
  static const discount = Color(0xFFDC2626);     // Red for discounts
  static const delivery = Color(0xFF0EA5E9);     // Blue for delivery
}

abstract final class ModernSpacing {
  static const xs = 4.0;
  static const sm = 8.0;
  static const md = 12.0;
  static const lg = 16.0;
  static const xl = 20.0;
  static const xxl = 24.0;
  static const xxxl = 32.0;
  static const huge = 40.0;
}

abstract final class ModernRadius {
  static const sm = 8.0;
  static const md = 12.0;
  static const lg = 16.0;
  static const xl = 20.0;
  static const full = 999.0;
}

abstract final class ModernShadow {
  static const xs = [
    BoxShadow(
      color: Color(0x0A000000),
      blurRadius: 2,
      offset: Offset(0, 1),
    ),
  ];

  static const sm = [
    BoxShadow(
      color: Color(0x0F000000),
      blurRadius: 3,
      offset: Offset(0, 1),
    ),
  ];

  static const md = [
    BoxShadow(
      color: Color(0x1A000000),
      blurRadius: 8,
      offset: Offset(0, 4),
    ),
  ];

  static const lg = [
    BoxShadow(
      color: Color(0x25000000),
      blurRadius: 16,
      offset: Offset(0, 10),
    ),
  ];
}
