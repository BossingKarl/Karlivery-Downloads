import 'package:flutter/cupertino.dart' show CupertinoPageTransitionsBuilder;
import 'package:flutter/material.dart';
import '../design_system/k_tokens.dart';

class AppTheme {
  static const red = KPalette.red;
  static const deepRed = KPalette.redDark;
  static const crimson = Color(0xFF940B1D);
  static const yellow = KPalette.yellow;
  static const warmYellow = Color(0xFFFFE9A8);
  static const ink = KPalette.ink;
  static const muted = KPalette.secondaryInk;
  static const cream = KPalette.canvas;
  static const paper = KPalette.paper;
  static const softRed = KPalette.blush;
  static const softYellow = KPalette.yellowSoft;
  static const line = KPalette.hairline;


  static ThemeData light() => _theme(Brightness.light);
  static ThemeData dark() => _theme(Brightness.dark);

  static ThemeData _theme(Brightness brightness) {
    final dark = brightness == Brightness.dark;

    final scheme = ColorScheme.fromSeed(
      seedColor: red,
      brightness: brightness,
      primary: dark ? const Color(0xFFFF687B) : red,
      secondary: dark ? const Color(0xFFFFD95E) : yellow,
      tertiary: const Color(0xFFFFCC35),
      surface: dark ? const Color(0xFF231B23) : Colors.white,
    );

    final surface = dark ? KPalette.darkSurface : Colors.white;
    final scaffold = dark ? KPalette.darkCanvas : KPalette.canvas;
    final outline = dark ? KPalette.darkLine : line;
    final text = dark ? const Color(0xFFFFF8FA) : ink;
    final subtext = dark ? const Color(0xFFD4C2CB) : muted;

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      materialTapTargetSize: MaterialTapTargetSize.padded,
      // Quiet iOS-inspired visual language; functionality stays in feature widgets.
      dividerColor: outline,
      visualDensity: VisualDensity.standard,
      colorScheme: scheme,
      scaffoldBackgroundColor: scaffold,
      fontFamily: KTypography.family,
      // NOVA / 10: cohesive adaptive color, spacing & accessibility across all roles.
      // EVOLVE / 09: one brand palette across customer, seller, rider & admin.
      extensions: <ThemeExtension<dynamic>>[
        KarliveryVisualTokens(
          attention: dark ? const Color(0xFFFFD95E) : yellow,
          premiumInk: dark ? const Color(0xFFFFF8FA) : ink,
          canvasTint: dark ? const Color(0xFF231B23) : const Color(0xFFFFF2E8),
          fineBorder: outline,
        ),
      ],
      splashFactory: InkRipple.splashFactory,
      pageTransitionsTheme: const PageTransitionsTheme(
        builders: {
          TargetPlatform.android: CupertinoPageTransitionsBuilder(),
          TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
          TargetPlatform.macOS: CupertinoPageTransitionsBuilder(),
          TargetPlatform.windows: ZoomPageTransitionsBuilder(),
          TargetPlatform.linux: ZoomPageTransitionsBuilder(),
          TargetPlatform.fuchsia: ZoomPageTransitionsBuilder(),
        },
      ),
      textTheme: TextTheme(
        displaySmall: TextStyle(
          fontWeight: FontWeight.w700,
          letterSpacing: -1.45,
          height: 1.08,
          color: text,
        ),
        headlineLarge: TextStyle(
          fontWeight: FontWeight.w700,
          letterSpacing: -1.05,
          height: 1.10,
          color: text,
        ),
        headlineMedium: TextStyle(
          fontWeight: FontWeight.w700,
          letterSpacing: -.75,
          height: 1.12,
          color: text,
        ),
        headlineSmall: TextStyle(
          fontWeight: FontWeight.w700,
          letterSpacing: -.55,
          color: text,
        ),
        titleLarge: TextStyle(
          fontWeight: FontWeight.w700,
          letterSpacing: -.4,
          color: text,
        ),
        titleMedium: TextStyle(
          fontWeight: FontWeight.w700,
          color: text,
        ),
        titleSmall: TextStyle(
          fontWeight: FontWeight.w700,
          color: text,
        ),
        bodyLarge: TextStyle(color: text, height: 1.5),
        bodyMedium: TextStyle(color: subtext, height: 1.5),
        bodySmall: TextStyle(color: subtext, height: 1.4),
        labelLarge: TextStyle(color: text, fontWeight: FontWeight.w700),
      ),
      iconTheme: IconThemeData(size: 20, color: text),
      iconButtonTheme: IconButtonThemeData(
        style: ButtonStyle(
          minimumSize: const WidgetStatePropertyAll(Size(44, 44)),
          shape: WidgetStatePropertyAll(
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        ),
      ),
      listTileTheme: ListTileThemeData(
        iconColor: scheme.primary,
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 6),
        minTileHeight: 58,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        titleTextStyle: TextStyle(
          color: text,
          fontSize: 15,
          fontWeight: FontWeight.w700,
        ),
        subtitleTextStyle: TextStyle(
          color: subtext,
          fontSize: 13,
          height: 1.4,
        ),
      ),
      appBarTheme: AppBarTheme(
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        toolbarHeight: 56,
        backgroundColor: scaffold.withValues(alpha: .96),
        surfaceTintColor: Colors.transparent,
        foregroundColor: text,
        titleTextStyle: TextStyle(
          color: text,
          fontSize: 18,
          fontWeight: FontWeight.w700,
          letterSpacing: -.4,
        ),
      ),
      cardTheme: CardThemeData(
        color: surface,
        surfaceTintColor: Colors.transparent,
        margin: EdgeInsets.zero,
        elevation: 0,
        shadowColor: Colors.black.withValues(alpha: dark ? .20 : .08),
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(KRadius.lg),
          side: BorderSide(color: outline.withValues(alpha: .66)),
        ),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: surface,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: surface,
        surfaceTintColor: Colors.transparent,
        showDragHandle: true,
        dragHandleColor: subtext.withValues(alpha: .45),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: dark ? const Color(0xFF2C202B) : paper,
        labelStyle: TextStyle(fontWeight: FontWeight.w700, color: subtext),
        floatingLabelStyle: TextStyle(fontWeight: FontWeight.w700, color: scheme.primary),
        hintStyle: TextStyle(color: subtext.withValues(alpha: .74)),
        helperStyle: TextStyle(color: subtext, height: 1.25),
        contentPadding: const EdgeInsets.symmetric(horizontal: 17, vertical: 16),
        prefixIconColor: subtext,
        suffixIconColor: subtext,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(13),
          borderSide: BorderSide(color: outline),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(13),
          borderSide: BorderSide(color: outline),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(KRadius.md),
          borderSide: BorderSide(color: scheme.primary, width: 1.8),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(KRadius.md),
          borderSide: const BorderSide(color: red),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(KRadius.md),
          borderSide: const BorderSide(color: red, width: 1.8),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size(0, 54),
          elevation: 0,
          backgroundColor: scheme.primary,
          foregroundColor: Colors.white,
          disabledBackgroundColor: scheme.primary.withValues(alpha: .45),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size(0, 52),
          side: BorderSide(color: outline),
          foregroundColor: text,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          textStyle: const TextStyle(fontWeight: FontWeight.w700),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: scheme.primary,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
          textStyle: const TextStyle(fontWeight: FontWeight.w700),
        ),
      ),
      chipTheme: ChipThemeData(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        backgroundColor: dark ? const Color(0xFF262A34) : const Color(0xFFF6F6F6),
        selectedColor: dark ? const Color(0xFF432734) : softRed,
        side: BorderSide(color: outline),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
        labelStyle: TextStyle(fontWeight: FontWeight.w700, color: text),
      ),
      navigationBarTheme: NavigationBarThemeData(
        height: 64,
        elevation: 0,
        backgroundColor: Colors.transparent,
        indicatorColor: Colors.transparent,
        indicatorShape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        iconTheme: WidgetStateProperty.resolveWith(
          (states) => IconThemeData(
            size: states.contains(WidgetState.selected) ? 22 : 20,
            color: states.contains(WidgetState.selected) ? scheme.primary : subtext,
          ),
        ),
        labelTextStyle: WidgetStateProperty.resolveWith(
          (states) => TextStyle(
            fontWeight: states.contains(WidgetState.selected)
                ? FontWeight.w700
                : FontWeight.w500,
            fontSize: 12,
            color: states.contains(WidgetState.selected) ? scheme.primary : subtext,
          ),
        ),
      ),
      navigationRailTheme: NavigationRailThemeData(
        backgroundColor: Colors.transparent,
        indicatorColor: Colors.transparent,
        indicatorShape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        selectedIconTheme: IconThemeData(color: scheme.primary, size: 24),
        unselectedIconTheme: IconThemeData(color: subtext, size: 22),
        selectedLabelTextStyle: TextStyle(
          color: scheme.primary,
          fontWeight: FontWeight.w700,
          fontSize: 13,
        ),
        unselectedLabelTextStyle: TextStyle(
          color: subtext,
          fontWeight: FontWeight.w700,
          fontSize: 13,
        ),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: dark ? const Color(0xFF292C38) : ink,
        contentTextStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      tooltipTheme: TooltipThemeData(
        waitDuration: const Duration(milliseconds: 450),
        showDuration: const Duration(seconds: 3),
        decoration: BoxDecoration(
          color: dark ? const Color(0xFF292C38) : ink,
          borderRadius: BorderRadius.circular(12),
        ),
        textStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
      ),
      dividerTheme: DividerThemeData(color: outline, thickness: 1),
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: scheme.primary,
        linearTrackColor: softYellow,
        circularTrackColor: softYellow,
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith(
          (states) => states.contains(WidgetState.selected) ? Colors.white : null,
        ),
        trackColor: WidgetStateProperty.resolveWith(
          (states) => states.contains(WidgetState.selected) ? scheme.primary : null,
        ),
      ),
    );
  }
}


/// EVOLVE / 09 brand tokens shared across features; no state or networking
/// belongs in a theme extension.
@immutable
class KarliveryVisualTokens extends ThemeExtension<KarliveryVisualTokens> {
  const KarliveryVisualTokens({
    required this.attention,
    required this.premiumInk,
    required this.canvasTint,
    required this.fineBorder,
  });

  final Color attention;
  final Color premiumInk;
  final Color canvasTint;
  final Color fineBorder;

  @override
  KarliveryVisualTokens copyWith({
    Color? attention,
    Color? premiumInk,
    Color? canvasTint,
    Color? fineBorder,
  }) => KarliveryVisualTokens(
    attention: attention ?? this.attention,
    premiumInk: premiumInk ?? this.premiumInk,
    canvasTint: canvasTint ?? this.canvasTint,
    fineBorder: fineBorder ?? this.fineBorder,
  );

  @override
  KarliveryVisualTokens lerp(
    covariant ThemeExtension<KarliveryVisualTokens>? other,
    double t,
  ) {
    if (other is! KarliveryVisualTokens) return this;
    return KarliveryVisualTokens(
      attention: Color.lerp(attention, other.attention, t)!,
      premiumInk: Color.lerp(premiumInk, other.premiumInk, t)!,
      canvasTint: Color.lerp(canvasTint, other.canvasTint, t)!,
      fineBorder: Color.lerp(fineBorder, other.fineBorder, t)!,
    );
  }
}
