import 'package:intl/intl.dart';

String money(num? value) =>
    NumberFormat.currency(locale: 'en_PH', symbol: '₱', decimalDigits: 2)
        .format(value ?? 0);

String niceStatus(String value) {
  return value
      .replaceAll('_', ' ')
      .split(' ')
      .map((e) => e.isEmpty ? e : '${e[0].toUpperCase()}${e.substring(1)}')
      .join(' ');
}


String prepTimeLabelFromValues(int? minMinutes, int? maxMinutes) {
  final min = minMinutes ?? 10;
  final max = maxMinutes ?? min;
  if (max <= min) return '$min min';
  return '$min–$max min';
}

String prepTimeLabel(Map<String, dynamic> product) {
  final min = int.tryParse(product['prep_time_min']?.toString() ?? '');
  final max = int.tryParse(product['prep_time_max']?.toString() ?? '');
  return prepTimeLabelFromValues(min, max);
}
