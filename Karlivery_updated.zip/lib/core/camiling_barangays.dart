class CamilingBarangays {
  CamilingBarangays._();

  static const values = <String>[
    'Anoling 1st',
    'Anoling 2nd',
    'Anoling 3rd',
    'Bacabac',
    'Bacsay',
    'Bancay 1st',
    'San Isidro',
    'Bilad',
    'Birbira',
    'Bobon Caarosipan',
    'Bobon 1st',
    'Bobon 2nd',
    'Cabanabaan',
    'Cacamilingan Norte',
    'Cacamilingan Sur',
    'Caniag',
    'Carael',
    'Cayaoan',
    'Cayasan',
    'Florida',
    'Lasong',
    'Libueg',
    'Malacampa',
    'Manaquem',
    'Manupeg',
    'Marawi',
    'Matubog',
    'Nagrambacan',
    'Nagserialan',
    'Palimbo Proper',
    'Palimbo Caarosipan',
    'Pao 1st',
    'Pao 2nd',
    'Pao 3rd',
    'Papaac',
    'Pindangan 1st',
    'Pindangan 2nd',
    'Poblacion A',
    'Poblacion B',
    'Poblacion C',
    'Poblacion D',
    'Poblacion E',
    'Poblacion F',
    'Poblacion G',
    'Poblacion H',
    'Poblacion I',
    'Poblacion J',
    'Sta. Maria',
    'Sawat',
    'Sinilian 1st',
    'Sinilian 2nd',
    'Sinilian 3rd',
    'Sinilian Cacalibosoan',
    'Sinulatan 1st',
    'Sinulatan 2nd',
    'Surgui 1st',
    'Surgui 2nd',
    'Surgui 3rd',
    'Tambugan',
    'Telbang',
    'Tuec',
  ];

  static String? match(String? raw) {
    final input = (raw ?? '').trim().toLowerCase();
    if (input.isEmpty) return null;

    String normalize(String value) => value
        .toLowerCase()
        .replaceAll('.', '')
        .replaceAll('-', ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();

    final normalized = normalize(input);
    for (final barangay in values) {
      if (normalize(barangay) == normalized) return barangay;
    }

    for (final barangay in values) {
      final b = normalize(barangay);
      if (normalized.contains(b) || b.contains(normalized)) return barangay;
    }
    return null;
  }
}
