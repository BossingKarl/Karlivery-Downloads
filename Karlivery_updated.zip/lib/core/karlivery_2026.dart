import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Karlivery 2026 - small, reusable product components.
/// Use the same visual language for Customer, Pabili, Rider, Seller and Admin.
class K26Headline extends StatelessWidget {
  final String eyebrow;
  final String title;
  final String subtitle;
  final IconData icon;
  final Widget? trailing;
  const K26Headline({super.key, required this.eyebrow, required this.title,
    required this.subtitle, required this.icon, this.trailing});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          height: 48, width: 48,
          decoration: BoxDecoration(color: isDark ? AppTheme.red.withValues(alpha: .20) : Colors.white,
            borderRadius: BorderRadius.circular(17)),
          child: Icon(icon, color: isDark ? const Color(0xFFFF8787) : AppTheme.red, size: 25),
        ),
        const SizedBox(width: 13),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(eyebrow.toUpperCase(), style: TextStyle(fontSize: 12, letterSpacing: 1.35,
            fontWeight: FontWeight.w700, color: isDark ? const Color(0xFFFFBC9A) : AppTheme.deepRed)),
          const SizedBox(height: 4),
          Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontSize: 21, height: 1.08, fontWeight: FontWeight.w700, letterSpacing: -.7)),
          const SizedBox(height: 6),
          Text(subtitle, style: Theme.of(context).textTheme.bodySmall?.copyWith(fontSize: 12.5, height: 1.38)),
        ])),
        if (trailing != null) ...[const SizedBox(width: 8), trailing!],
      ]),
    );
  }
}

class K26Action extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final Color tint;
  const K26Action({super.key, required this.icon, required this.title,
    required this.subtitle, required this.onTap, this.tint = const Color(0xFFFFF4DF)});

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Material(
      color: Theme.of(context).colorScheme.surface,
      borderRadius: BorderRadius.circular(21),
      child: InkWell(
        borderRadius: BorderRadius.circular(21),
        onTap: onTap,
        child: Container(
          constraints: const BoxConstraints(minHeight: 108),
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(border: Border.all(color: Theme.of(context).dividerColor),
            borderRadius: BorderRadius.circular(21)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(height: 40, width: 40,
              decoration: BoxDecoration(color: dark ? AppTheme.red.withValues(alpha: .18) : tint,
                borderRadius: BorderRadius.circular(14)),
              child: Icon(icon, color: dark ? const Color(0xFFFF9191) : AppTheme.deepRed, size: 21)),
            const SizedBox(height: 10),
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.titleSmall?.copyWith(fontSize: 13.5, fontWeight: FontWeight.w700)),
            const SizedBox(height: 3),
            Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(fontSize: 12, height: 1.2)),
          ]),
        ),
      ),
    );
  }
}

class K26Section extends StatelessWidget {
  final String title;
  final String? detail;
  final Widget? trailing;
  const K26Section({super.key, required this.title, this.detail, this.trailing});

  @override
  Widget build(BuildContext context) => Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(
        fontWeight: FontWeight.w700, fontSize: 19, letterSpacing: -.55)),
      if (detail != null) ...[const SizedBox(height: 3),
        Text(detail!, style: Theme.of(context).textTheme.bodySmall?.copyWith(fontSize: 12))],
    ])),
    ?trailing,
  ]);
}

/// Always uses real app navigation callbacks. No decorative dead buttons.
class K26ActionGrid extends StatelessWidget {
  final List<K26Action> actions;
  const K26ActionGrid({super.key, required this.actions});

  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (context, constraints) {
    final columns = constraints.maxWidth >= 620 ? 4 : 2;
    final gap = 10.0;
    final width = (constraints.maxWidth - gap * (columns - 1)) / columns;
    return Wrap(spacing: gap, runSpacing: gap,
      children: [for (final action in actions) SizedBox(width: width, child: action)]);
  });
}
