import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../design_system/k_network_image.dart';

/// Karlivery's food-first customer hero. Uses actual featured-product imagery
/// and real shop counts. It deliberately does not invent discounts or ETAs.
class KarliveryDiscoveryHero extends StatelessWidget {
  const KarliveryDiscoveryHero({super.key, required this.storeCount,
    required this.onExplore, this.loading = false, this.coverUrl});
  final int storeCount;
  final bool loading;
  final VoidCallback onExplore;
  final String? coverUrl;

  @override
  Widget build(BuildContext context) {
    final photo = coverUrl != null && coverUrl!.trim().isNotEmpty;
    return Semantics(
      label: 'Browse Karlivery restaurants',
      button: true,
      child: Material(
        color: const Color(0xFF382019),
        borderRadius: BorderRadius.circular(20),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onExplore,
          child: SizedBox(
            height: 148,
            child: Image.asset(
              'assets/branding/karlivery_food_banner.png',
              fit: BoxFit.cover,
              alignment: Alignment.center,
              filterQuality: FilterQuality.high,
            ),
          ),
        ),
      ),
    );
  }
}

class _EditorialPhotoFallback extends StatelessWidget {
  const _EditorialPhotoFallback();
  @override
  Widget build(BuildContext context) => const DecoratedBox(
    decoration: BoxDecoration(gradient: LinearGradient(
      begin: Alignment.topLeft, end: Alignment.bottomRight,
      colors: [Color(0xFF6A3325), Color(0xFFB74B34), Color(0xFF281B1A)],
    )),
    child: SizedBox.expand(),
  );
}

/// Real desktop/tablet navigation for the customer PWA, instead of a stretched phone tab bar.
class KarliveryCustomerWebRail extends StatelessWidget {
  const KarliveryCustomerWebRail({super.key, required this.selected,
    required this.onTap, required this.basketCount});
  final int selected;
  final ValueChanged<int> onTap;
  final int basketCount;

  static const sections = <(IconData, IconData, String)>[
    (Icons.home_outlined, Icons.home_rounded, 'Discover'),
    (Icons.receipt_long_outlined, Icons.receipt_long_rounded, 'My orders'),
    (Icons.shopping_bag_outlined, Icons.shopping_bag_rounded, 'My basket'),
    (Icons.chat_bubble_outline_rounded, Icons.chat_bubble_rounded, 'Messages'),
    (Icons.person_outline_rounded, Icons.person_rounded, 'My account'),
  ];

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    return SafeArea(child: Container(
      width: 252,
      margin: const EdgeInsets.fromLTRB(18, 16, 0, 16),
      decoration: BoxDecoration(color: scheme.surface,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: Theme.of(context).dividerColor)),
      clipBehavior: Clip.antiAlias,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(
          padding: const EdgeInsets.fromLTRB(18, 27, 18, 23),
          decoration: const BoxDecoration(gradient: LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [AppTheme.deepRed, AppTheme.red])),
          child: Row(children: [
            ClipRRect(borderRadius: BorderRadius.circular(12),
              child: Image.asset('assets/branding/karlivery_app_icon.png', width: 44, height: 44)),
            const SizedBox(width: 12),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Karlivery', style: TextStyle(color: Colors.white,
                  fontWeight: FontWeight.w700, fontSize: 20, letterSpacing: -.7)),
                Text('YOUR TOWN. YOUR FOOD.', style: TextStyle(color: AppTheme.yellow,
                  fontWeight: FontWeight.w700, fontSize: 12, letterSpacing: .5)),
              ])),
          ]),
        ),
        Expanded(child: ListView(padding: EdgeInsets.zero, children: [
        const Padding(padding: EdgeInsets.fromLTRB(22, 25, 16, 11),
          child: Text('EXPLORE KARLIVERY', style: TextStyle(
            color: AppTheme.muted, fontSize: 12,
            letterSpacing: 1, fontWeight: FontWeight.w700))),
        ...List.generate(sections.length, (i) {
          final item = sections[i];
          final active = i == selected;
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
            child: Material(
              color: active ? (dark ? const Color(0xFF4A242F) : AppTheme.softRed) : Colors.transparent,
              borderRadius: BorderRadius.circular(15),
              child: InkWell(
                borderRadius: BorderRadius.circular(15),
                onTap: () => onTap(i),
                child: Padding(padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 15),
                  child: Row(children: [
                    Icon(active ? item.$2 : item.$1,
                      color: active ? (dark ? AppTheme.yellow : AppTheme.deepRed) : scheme.onSurfaceVariant, size: 21),
                    const SizedBox(width: 13),
                    Expanded(child: Text(item.$3, style: TextStyle(
                      color: active ? (dark ? AppTheme.yellow : AppTheme.deepRed) : scheme.onSurface,
                      fontWeight: active ? FontWeight.w700 : FontWeight.w700,
                      fontSize: 13))),
                    if (i == 2 && basketCount > 0)
                      CircleAvatar(radius: 11, backgroundColor: AppTheme.yellow,
                        child: Text('$basketCount', style: const TextStyle(
                          fontSize: 12, fontWeight: FontWeight.w700, color: AppTheme.ink))),
                  ])),
              ),
            ),
          );
        }),
        const SizedBox(height: 22),
        Padding(padding: const EdgeInsets.all(19), child: Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(color: AppTheme.softYellow,
            borderRadius: BorderRadius.circular(17)),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(Icons.favorite_rounded, color: AppTheme.deepRed, size: 22),
              SizedBox(height: 7),
              Text('Made for our town.', style: TextStyle(
                color: AppTheme.ink, fontSize: 13, fontWeight: FontWeight.w700)),
              SizedBox(height: 4),
              Text('Good food, closer to you.', style: TextStyle(
                color: AppTheme.ink, fontSize: 12)),
            ]),
        )),
      ])),
      ]),
    ));
  }
}
