import 'dart:async';

import 'package:flutter/material.dart';
import '../design_system/k_components.dart';

import '../theme/app_theme.dart';
import 'nova_headline.dart';
import 'brand.dart';

/// Shared Karlivery visual system used by all role dashboards.
/// The goal is to keep every screen feeling like one product instead of a
/// collection of unrelated pages.
class KDashboardScaffold extends StatefulWidget {
  final PreferredSizeWidget? appBar;
  final Widget body;
  final Widget? bottomNavigationBar;

  const KDashboardScaffold({
    super.key,
    this.appBar,
    required this.body,
    this.bottomNavigationBar,
  });

  @override
  State<KDashboardScaffold> createState() => _KDashboardScaffoldState();
}

class _KDashboardScaffoldState extends State<KDashboardScaffold> {
  Timer? _tabTimer;
  bool _tabLoading = false;

  @override
  void dispose() {
    _tabTimer?.cancel();
    super.dispose();
  }

  void _selectTab(NavigationBar nav, int value) {
    if (value == nav.selectedIndex) return;
    _tabTimer?.cancel();
    setState(() => _tabLoading = true);
    nav.onDestinationSelected?.call(value);
    _tabTimer = Timer(
      const Duration(milliseconds: 90),
      () {
        if (mounted) setState(() => _tabLoading = false);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final nav = widget.bottomNavigationBar;
    final wide = MediaQuery.sizeOf(context).width >= 1000 && nav is NavigationBar;

    final scaffold = Scaffold(
      extendBody: !wide && nav is NavigationBar,
      backgroundColor: Colors.transparent,
      appBar: widget.appBar,
      body: Stack(
        children: [
          const Positioned.fill(child: _KAppBackdrop()),
          Positioned.fill(
            child: wide
                ? Row(
                    children: [
                      _DesktopNavigation(
                        nav: nav,
                        onDestinationSelected: (value) => _selectTab(nav, value),
                      ),
                      Expanded(child: widget.body),
                    ],
                  )
                : widget.body,
          ),
        ],
      ),
      bottomNavigationBar: !wide && nav is NavigationBar
          ? _FloatingNavigation(
              nav: nav,
              onDestinationSelected: (value) => _selectTab(nav, value),
            )
          : widget.bottomNavigationBar,
    );

    final page = Stack(
      children: [
        scaffold,
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          child: IgnorePointer(
            child: AnimatedOpacity(
              opacity: _tabLoading ? 1 : 0,
              duration: const Duration(milliseconds: 60),
              child: const LinearProgressIndicator(minHeight: 2.5),
            ),
          ),
        ),
      ],
    );
    // The native back gesture must not unexpectedly kill a role dashboard.
    // On a nested tab go to the workspace landing tab; on the landing tab
    // remain inside Karlivery and offer the visible sign-out action.
    if (nav is! NavigationBar) return page;
    return PopScope<Object?>(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop || !mounted) return;
        if (nav.selectedIndex != 0) {
          _selectTab(nav, 0);
        } else {
          ScaffoldMessenger.maybeOf(context)?.showSnackBar(
            const SnackBar(content: Text('You are already on your Karlivery home. Use your account menu to sign out.')),
          );
        }
      },
      child: page,
    );
  }
}

/// Builds dashboard tabs only when the user opens them for the first time.
/// This prevents hidden tabs from firing Supabase queries during app startup.
class KLazyIndexedStack extends StatefulWidget {
  final int index;
  final List<WidgetBuilder> builders;

  const KLazyIndexedStack({
    super.key,
    required this.index,
    required this.builders,
  });

  @override
  State<KLazyIndexedStack> createState() => _KLazyIndexedStackState();
}

class _KLazyIndexedStackState extends State<KLazyIndexedStack> {
  late List<Widget?> _children;

  @override
  void initState() {
    super.initState();
    _children = List<Widget?>.filled(widget.builders.length, null);
  }

  @override
  void didUpdateWidget(covariant KLazyIndexedStack oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.builders.length != widget.builders.length) {
      final previous = _children;
      _children = List<Widget?>.filled(widget.builders.length, null);
      for (var i = 0; i < previous.length && i < _children.length; i++) {
        _children[i] = previous[i];
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.builders.isEmpty) return const SizedBox.shrink();
    final safeIndex = widget.index < 0
        ? 0
        : (widget.index >= widget.builders.length
            ? widget.builders.length - 1
            : widget.index);
    _children[safeIndex] ??= widget.builders[safeIndex](context);

    return IndexedStack(
      index: safeIndex,
      children: List<Widget>.generate(
        widget.builders.length,
        (i) => _children[i] ?? const SizedBox.shrink(),
      ),
    );
  }
}

class _KAppBackdrop extends StatelessWidget {
  const _KAppBackdrop();
  @override
  Widget build(BuildContext context) => ColoredBox(
    color: Theme.of(context).scaffoldBackgroundColor,
  );
}

class _GlowOrb extends StatelessWidget {
  final double size;
  final Color color;

  const _GlowOrb({required this.size, required this.color});

  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(shape: BoxShape.circle, color: color),
      );
}

/// NOVA / 10: common role navigation (seller/rider/admin), with a
/// real destination callback and no decorative dead actions.
class _FloatingNavigation extends StatelessWidget {
  final NavigationBar nav;
  final ValueChanged<int> onDestinationSelected;
  const _FloatingNavigation({required this.nav, required this.onDestinationSelected});

  @override
  Widget build(BuildContext context) {
    return SafeArea(top: false,
      minimum: EdgeInsets.zero,
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.zero,
          border: Border(top: BorderSide(color: Theme.of(context).dividerColor)),
        ),
        child: NavigationBarTheme(
          data: NavigationBarThemeData(
            height: 66, backgroundColor: Colors.transparent,
            surfaceTintColor: Colors.transparent,
            indicatorColor: Colors.transparent,
            indicatorShape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)),
            iconTheme: WidgetStateProperty.resolveWith((states) => IconThemeData(
              size: states.contains(WidgetState.selected) ? 24 : 22,
              color: states.contains(WidgetState.selected)
                ? Theme.of(context).colorScheme.primary
                : Theme.of(context).colorScheme.onSurfaceVariant)),
            labelTextStyle: WidgetStateProperty.resolveWith((states) => TextStyle(
              fontSize: 12, fontWeight: FontWeight.w600,
              color: states.contains(WidgetState.selected)
                ? Theme.of(context).colorScheme.primary
                : Theme.of(context).colorScheme.onSurfaceVariant)),
          ),
          child: NavigationBar(
            selectedIndex: nav.selectedIndex,
            onDestinationSelected: onDestinationSelected,
            destinations: nav.destinations,
          ),
        ),
      ),
    );
  }
}

class _DesktopNavigation extends StatelessWidget {
  final NavigationBar nav;
  final ValueChanged<int> onDestinationSelected;

  const _DesktopNavigation({
    required this.nav,
    required this.onDestinationSelected,
  });

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return SafeArea(
      child: Container(
        width: 248,
        margin: const EdgeInsets.fromLTRB(14, 14, 0, 14),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: Theme.of(context).dividerColor),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: dark ? .24 : .08),
              blurRadius: 30,
              offset: const Offset(0, 12),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(26),
          child: NavigationRail(
            backgroundColor: Colors.transparent,
            selectedIconTheme: IconThemeData(color: Theme.of(context).colorScheme.primary),
            unselectedIconTheme: IconThemeData(color: Theme.of(context).colorScheme.onSurfaceVariant),
            selectedLabelTextStyle: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w700),
            unselectedLabelTextStyle: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
            extended: true,
            minExtendedWidth: 248,
            selectedIndex: nav.selectedIndex,
            onDestinationSelected: onDestinationSelected,
            indicatorColor: dark ? const Color(0xFF4A242F) : AppTheme.softRed,
            leading: Padding(
              padding: const EdgeInsets.fromLTRB(18, 24, 18, 24),
              child: Row(
                children: [
                  KIconTile(
                    icon: Icons.grid_view_rounded,
                    color: AppTheme.red,
                    size: 38,
                  ),
                  SizedBox(width: 10),
                  // The desktop rail stays responsive when Windows text scaling changes.
                  Expanded(
                    child: Text(
                      'KARLIVERY',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.onSurface,
                        fontWeight: FontWeight.w700,
                        fontSize: 12,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            destinations: nav.destinations
                .whereType<NavigationDestination>()
                .map(
                  (d) => NavigationRailDestination(
                    icon: d.icon,
                    selectedIcon: d.selectedIcon,
                    label: Text(d.label),
                  ),
                )
                .toList(),
          ),
        ),
      ),
    );
  }
}

class KPageHeader extends StatelessWidget {
  final String eyebrow;
  final String title;
  final String subtitle;
  final IconData icon;
  final Widget? trailing;

  const KPageHeader({
    super.key,
    required this.eyebrow,
    required this.title,
    required this.subtitle,
    required this.icon,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) => NovaHeadline(
    eyebrow: eyebrow, title: title, subtitle: subtitle,
    icon: icon, trailing: trailing,
  );
}

class KIconTile extends StatelessWidget {
  final IconData icon;
  final Color color;
  final double size;
  const KIconTile({super.key, required this.icon,
    this.color = AppTheme.red, this.size = 44});
  @override
  Widget build(BuildContext context) => KDSIconTile(
    icon: icon, color: color, size: size);
}

class KMetricCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color? accent;
  const KMetricCard({super.key, required this.label, required this.value,
    required this.icon, this.accent});
  @override
  Widget build(BuildContext context) => KDSStatCard(
    label: label, value: value, icon: icon, accent: accent);
}

class KMetricGrid extends StatelessWidget {
  final List<Widget> children;

  const KMetricGrid({super.key, required this.children});

  @override
  Widget build(BuildContext context) => LayoutBuilder(
        builder: (context, box) {
          final scale = MediaQuery.textScalerOf(context).scale(1);
          final columns = box.maxWidth >= 900 && scale < 1.4
              ? 4
              : box.maxWidth >= 340 && scale < 1.6
                  ? 2
                  : 1;
          final width = (box.maxWidth - (columns - 1) * 12) / columns;
          return Wrap(
            spacing: 12,
            runSpacing: 12,
            children: children
                .map((c) => SizedBox(width: width, child: c))
                .toList(),
          );
        },
      );
}

class KStatusPill extends StatelessWidget {
  final String text;
  final Color color;
  final IconData? icon;
  const KStatusPill({super.key, required this.text, required this.color, this.icon});
  @override
  Widget build(BuildContext context) => KDSStatusBadge(
    label: text, color: color, icon: icon);
}

class KSectionTitle extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget? trailing;
  const KSectionTitle({super.key, required this.title, this.subtitle, this.trailing});
  @override
  Widget build(BuildContext context) => KDSSectionHeading(
    title: title, subtitle: subtitle, trailing: trailing);
}

class KEmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const KEmptyState({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(30),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface.withValues(alpha: .96),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Theme.of(context).dividerColor),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: dark ? .14 : .035),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          KIconTile(
            icon: icon,
            color: Theme.of(context).colorScheme.primary,
            size: 64,
          ),
          const SizedBox(height: 16),
          Text(
            title,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
          ),
          const SizedBox(height: 6),
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: Text(
              subtitle,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ),
        ],
      ),
    );
  }
}

/// Reusable premium panel for auth, settings and other high-focus surfaces.
class KPremiumPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;

  const KPremiumPanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(24),
  });

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface.withValues(alpha: .98),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: dark ? Colors.white.withValues(alpha: .12) : const Color(0xFFF0E8E4)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: dark ? .22 : .06),
            blurRadius: 42,
            offset: const Offset(0, 18),
          ),
        ],
      ),
      child: child,
    );
  }
}


class KAuthBackdrop extends StatelessWidget {
  final Widget child;

  const KAuthBackdrop({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Stack(
      children: [
        Positioned.fill(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: dark
                    ? const [Color(0xFF0F0A0B), Color(0xFF181012), Color(0xFF10121B)]
                    : const [Color(0xFFFFF8F4), Color(0xFFFFFDFC), Color(0xFFFFF0E6)],
              ),
            ),
          ),
        ),
        Positioned(
          top: -100,
          right: -90,
          child: _GlowOrb(
            size: 290,
            color: AppTheme.yellow.withValues(alpha: dark ? .08 : .14),
          ),
        ),
        Positioned(
          bottom: -150,
          left: -110,
          child: _GlowOrb(
            size: 330,
            color: AppTheme.red.withValues(alpha: dark ? .08 : .09),
          ),
        ),
        Positioned.fill(child: child),
      ],
    );
  }
}

class KAuthHero extends StatelessWidget {
  final String eyebrow;
  final String title;
  final String description;
  final List<(IconData, String, String)> features;
  final bool compact;

  const KAuthHero({
    super.key,
    required this.eyebrow,
    required this.title,
    required this.description,
    required this.features,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    final content = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const KarliveryWordmark(light: true),
        if (!compact) const Spacer() else const SizedBox(height: 28),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
          decoration: BoxDecoration(
            color: AppTheme.yellow,
            borderRadius: BorderRadius.circular(999),
          ),
          child: Text(
            eyebrow.toUpperCase(),
            style: const TextStyle(
              color: Color(0xFF421114),
              fontSize: 12,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.2,
            ),
          ),
        ),
        const SizedBox(height: 18),
        Text(
          title,
          style: TextStyle(
            color: Colors.white,
            fontSize: compact ? 30 : 46,
            height: 1.02,
            fontWeight: FontWeight.w700,
            letterSpacing: compact ? -1.0 : -1.7,
          ),
        ),
        const SizedBox(height: 15),
        ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 520),
          child: Text(
            description,
            style: TextStyle(
              color: const Color(0xFFFFE9E6),
              fontSize: compact ? 14 : 16,
              height: 1.5,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        const SizedBox(height: 24),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: features
              .map(
                (feature) => Container(
                  constraints: BoxConstraints(maxWidth: compact ? 220 : 245),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: .10),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: Colors.white.withValues(alpha: .13)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          color: AppTheme.yellow,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(feature.$1, color: AppTheme.crimson, size: 20),
                      ),
                      const SizedBox(width: 10),
                      Flexible(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              feature.$2,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w700,
                                fontSize: 12.5,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              feature.$3,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Color(0xFFFFCFCB),
                                fontWeight: FontWeight.w600,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              )
              .toList(),
        ),
      ],
    );

    return Container(
      height: compact ? null : 650,
      padding: EdgeInsets.all(compact ? 22 : 40),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppTheme.red, AppTheme.deepRed, AppTheme.crimson],
        ),
        borderRadius: BorderRadius.circular(compact ? 28 : 38),
        boxShadow: [
          BoxShadow(
            color: AppTheme.red.withValues(alpha: .20),
            blurRadius: 34,
            offset: const Offset(0, 14),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            top: -90,
            right: -70,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppTheme.yellow.withValues(alpha: .18),
              ),
            ),
          ),
          Positioned(
            bottom: -80,
            right: 30,
            child: Container(
              width: 180,
              height: 180,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white.withValues(alpha: .09), width: 22),
              ),
            ),
          ),
          // Keep the content non-positioned so the Stack has a real intrinsic
          // height on compact/mobile auth screens. A Positioned.fill child
          // inside a SingleChildScrollView receives an unbounded height and can
          // collapse or throw a RenderBox layout exception, resulting in a blank
          // login/register screen.
          content,
        ],
      ),
    );
  }
}

class KarliveryLoader extends StatefulWidget {
  final String? message;
  final double size;

  const KarliveryLoader({
    super.key,
    this.message,
    this.size = 82,
  });

  @override
  State<KarliveryLoader> createState() => _KarliveryLoaderState();
}

class _KarliveryLoaderState extends State<KarliveryLoader>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _pulse;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 650),
    )..repeat(reverse: true);
    _pulse = Tween<double>(begin: .94, end: 1.04).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOutCubic),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: widget.size + 22,
            height: widget.size + 22,
            child: Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: widget.size + 16,
                  height: widget.size + 16,
                  child: const CircularProgressIndicator(
                    strokeWidth: 3.2,
                    color: AppTheme.red,
                    backgroundColor: AppTheme.softYellow,
                  ),
                ),
                ScaleTransition(
                  scale: _pulse,
                  child: KarliveryMark(size: widget.size),
                ),
              ],
            ),
          ),
          if (widget.message != null) ...[
            const SizedBox(height: 18),
            Text(
              widget.message!,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
            ),
          ],
        ],
      );
}

class KLoadingState extends StatefulWidget {
  final String message;

  const KLoadingState({
    super.key,
    this.message = 'Loading Karlivery…',
  });

  @override
  State<KLoadingState> createState() => _KLoadingStateState();
}

class _KLoadingStateState extends State<KLoadingState>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _opacity;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 760),
    )..repeat(reverse: true);
    _opacity = Tween<double>(begin: .48, end: .82).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final surface = Theme.of(context).colorScheme.surfaceContainerHighest;
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 620),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  const KarliveryMark(size: 34),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      widget.message,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              ClipRRect(
                borderRadius: BorderRadius.circular(99),
                child: const LinearProgressIndicator(minHeight: 3),
              ),
              const SizedBox(height: 18),
              FadeTransition(
                opacity: _opacity,
                child: Column(
                  children: [
                    _KLoadingSkeleton(color: surface, height: 82),
                    const SizedBox(height: 12),
                    _KLoadingSkeleton(color: surface, height: 82),
                    const SizedBox(height: 12),
                    _KLoadingSkeleton(color: surface, height: 58),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _KLoadingSkeleton extends StatelessWidget {
  final Color color;
  final double height;

  const _KLoadingSkeleton({required this.color, required this.height});

  @override
  Widget build(BuildContext context) => Container(
        height: height,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(22),
        ),
      );
}

/// Compact, low-contrast release/update strip shared by role dashboards.
/// No marketing-only promises; highlights real actions available in the app.
class KWorkspaceUpdateStrip extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const KWorkspaceUpdateStrip({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: Theme.of(context).colorScheme.surface,
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: AppTheme.line),
    ),
    child: Row(children: [
      Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          color: AppTheme.softYellow,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Icon(icon, color: AppTheme.deepRed, size: 23),
      ),
      const SizedBox(width: 12),
      Expanded(child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: Theme.of(context).textTheme.titleSmall),
          const SizedBox(height: 2),
          Text(subtitle,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(fontSize: 12)),
        ],
      )),
    ]),
  );
}
