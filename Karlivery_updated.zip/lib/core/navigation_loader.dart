import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

// Kept for existing router integration; destination screens own loading states.
final ValueNotifier<int> karliveryNavigationPulse = ValueNotifier<int>(0);

class KarliveryNavigatorObserver extends NavigatorObserver {
  void _pulse() => karliveryNavigationPulse.value++;

  @override
  void didPush(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didPush(route, previousRoute);
    _pulse();
  }

  @override
  void didPop(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didPop(route, previousRoute);
    _pulse();
  }

  @override
  void didReplace({Route<dynamic>? newRoute, Route<dynamic>? oldRoute}) {
    super.didReplace(newRoute: newRoute, oldRoute: oldRoute);
    _pulse();
  }
}

final KarliveryNavigatorObserver karliveryNavigatorObserver =
    KarliveryNavigatorObserver();

/// No global overlay: it previously blanketed the app during navigation.
class KarliveryNavigationOverlay extends StatelessWidget {
  final GoRouter router;
  final Widget child;

  const KarliveryNavigationOverlay({
    super.key,
    required this.router,
    required this.child,
  });

  @override
  Widget build(BuildContext context) => child;
}
