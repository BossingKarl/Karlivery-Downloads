/// Stable, newest-first rows for reverse-scrolling chat lists.
/// In Flutter `ListView(reverse: true)`, index 0 is visually at the bottom.
List<Map<String, dynamic>> newestFirstChatMessages(
  Iterable<Map<String, dynamic>> source,
) {
  final tagged = source.toList().asMap().entries.toList();
  tagged.sort((left, right) {
    final a = DateTime.tryParse(left.value['created_at']?.toString() ?? '');
    final b = DateTime.tryParse(right.value['created_at']?.toString() ?? '');
    final order = (b ?? DateTime.fromMillisecondsSinceEpoch(0))
        .compareTo(a ?? DateTime.fromMillisecondsSinceEpoch(0));
    return order == 0 ? right.key.compareTo(left.key) : order;
  });
  return tagged.map((entry) => entry.value).toList(growable: false);
}
