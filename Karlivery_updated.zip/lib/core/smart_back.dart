import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

/// KARLIVERY_EVOLVE09_SAFE_BACK
/// Consistent system back & toolbar back for standalone app destinations.
/// A route opened through push() pops; a deep-linked route has a safe parent.
class KarliveryBack {
  static void navigate(BuildContext context, String fallback) {
    if (!context.mounted) return;
    final router = GoRouter.of(context);
    if (router.canPop()) {
      router.pop();
    } else {
      router.go(fallback);
    }
  }
}

class KarliveryBackButton extends StatelessWidget {
  const KarliveryBackButton({super.key, required this.fallback});
  final String fallback;

  @override
  Widget build(BuildContext context) => IconButton(
    tooltip: 'Back',
    icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 19),
    onPressed: () => KarliveryBack.navigate(context, fallback),
  );
}

/// PopScope is attached only to detail routes, not dialogs or login flow.
/// It consumes a root system-back only when there is no previous GoRouter page.
class KarliveryRootGuard extends StatelessWidget {
  const KarliveryRootGuard({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) => PopScope<Object?>(
    canPop: false,
    onPopInvokedWithResult: (didPop, _) {
      if (didPop || !context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Use Karlivery navigation to switch pages or sign out.')),
      );
    },
    child: child,
  );
}

class KarliveryBackScope extends StatelessWidget {
  const KarliveryBackScope({super.key, required this.fallback, required this.child});
  final String fallback;
  final Widget child;

  @override
  Widget build(BuildContext context) => PopScope<Object?>(
    canPop: GoRouter.of(context).canPop(),
    onPopInvokedWithResult: (didPop, _) {
      if (didPop) return;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (context.mounted) KarliveryBack.navigate(context, fallback);
      });
    },
    child: child,
  );
}
