import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class KarliveryMark extends StatelessWidget {
  final double size;
  const KarliveryMark({super.key, this.size = 72});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * .30),
        boxShadow: [
          BoxShadow(
            color: AppTheme.red.withValues(alpha: .18),
            blurRadius: 26,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(size * .30),
        child: Image.asset(
          'assets/branding/karlivery_app_icon.png',
          width: size,
          height: size,
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}

class KarliveryWordmark extends StatelessWidget {
  final bool compact;
  final bool light;
  const KarliveryWordmark({
    super.key,
    this.compact = false,
    this.light = false,
  });

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final titleColor =
        light ? Colors.white : (dark ? Colors.white : AppTheme.ink);
    final subColor = light
        ? const Color(0xFFFFF1C9)
        : Theme.of(context).textTheme.bodyMedium?.color;

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        KarliveryMark(size: compact ? 38 : 48),
        SizedBox(width: compact ? 9 : 12),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Karlivery',
              style: TextStyle(
                fontSize: compact ? 20 : 25,
                fontWeight: FontWeight.w700,
                letterSpacing: -1,
                color: titleColor,
              ),
            ),
            if (!compact)
              Text(
                'GOOD FOOD. CLOSER TO YOU.',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: subColor,
                ),
              ),
          ],
        ),
      ],
    );
  }
}

/// Editorial heading shared by basket, settings and role secondary pages.
class PageTitle extends StatelessWidget {
  final String title;
  final String? subtitle;
  const PageTitle(this.title, {super.key, this.subtitle});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(width: 6, height: subtitle == null ? 57 : 75,
        decoration: BoxDecoration(
          gradient: const LinearGradient(begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [AppTheme.yellow, AppTheme.red]),
          borderRadius: BorderRadius.circular(40)),
      ),
      const SizedBox(width: 14),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('YOUR KARLIVERY', style: TextStyle(
          fontSize: 12, letterSpacing: 1.2,
          color: Theme.of(context).colorScheme.primary,
          fontWeight: FontWeight.w700)),
        const SizedBox(height: 5),
        Text(title, style: Theme.of(context).textTheme.headlineSmall?.copyWith(
          fontSize: 25, fontWeight: FontWeight.w700,
          letterSpacing: -.9, height: 1.07)),
        if (subtitle != null) ...[
          const SizedBox(height: 6),
          Text(subtitle!, style: Theme.of(context).textTheme.bodySmall?.copyWith(
            height: 1.4, fontSize: 12.5)),
        ],
      ])),
    ]),
  );
}

class KarliveryPill extends StatelessWidget {
  final IconData icon;
  final String text;
  final Color? color;
  const KarliveryPill({
    super.key,
    required this.icon,
    required this.text,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final c = color ?? AppTheme.red;
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 9,
      ),
      decoration: BoxDecoration(
        color: c.withValues(alpha: .10),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 17, color: c),
          const SizedBox(width: 7),
          Text(
            text,
            style: TextStyle(
              fontWeight: FontWeight.w700,
              color: c,
              fontSize: 12.5,
            ),
          ),
        ],
      ),
    );
  }
}
