import 'package:flutter/material.dart';
import '../design_system/k_components.dart';
import '../theme/app_theme.dart';

/// V21 seller storefront control; callback remains wired to the existing backend.
class KarliveryStoreStatusCard extends StatelessWidget {
  const KarliveryStoreStatusCard({super.key, required this.acceptingOrders,
    required this.withinHours, required this.onChanged});
  final bool acceptingOrders;
  final bool withinHours;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    final enabled = acceptingOrders && withinHours;
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      padding: const EdgeInsets.fromLTRB(17, 16, 12, 17),
      child: Row(children: [
        Container(
          width: 58, height: 58,
          decoration: BoxDecoration(
            color: enabled ? const Color(0xFFE2F7EB) : AppTheme.softYellow,
            borderRadius: BorderRadius.circular(19)),
          child: Icon(enabled ? Icons.storefront_rounded : Icons.nights_stay_rounded,
            color: enabled ? const Color(0xFF11764D) : AppTheme.deepRed, size: 29),
        ),
        const SizedBox(width: 13),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(enabled ? 'Ready to take orders' : acceptingOrders
            ? 'Outside opening hours' : 'Your storefront is paused',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w700, fontSize: 14)),
          const SizedBox(height: 4),
          Text(enabled ? 'Customers can order while your store is open.'
              : acceptingOrders
                ? 'Your configured hours control ordering availability.'
                : 'Switch on to accept orders during opening hours.',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(fontSize: 12)),
        ])),
        const SizedBox(width: 6),
        Switch(value: acceptingOrders, onChanged: onChanged,
          activeTrackColor: AppTheme.deepRed),
      ]),
    );
  }
}

/// Genuine dashboard link — used for navigation, not a decorative card.
class KarliveryQuickAction extends StatelessWidget {
  const KarliveryQuickAction({super.key, required this.icon,
    required this.title, required this.caption, required this.onPressed});
  final IconData icon;
  final String title;
  final String caption;
  final VoidCallback onPressed;
  @override
  Widget build(BuildContext context) => KDSActionTile(
    icon: icon, title: title, subtitle: caption, onTap: onPressed);
}

/// Priority queue callout for seller & rider; keeps the one real action
/// comfortably tappable on narrow devices instead of squeezing it beside copy.
class KarliveryNextStepPanel extends StatelessWidget {
  const KarliveryNextStepPanel({super.key, required this.icon,
    required this.eyebrow, required this.title, required this.message,
    this.action, this.onPressed});
  final IconData icon;
  final String eyebrow;
  final String title;
  final String message;
  final String? action;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(19),
    decoration: BoxDecoration(
      color: AppTheme.softYellow,
      borderRadius: BorderRadius.circular(23),
      border: Border.all(color: const Color(0xFFF5E09B)),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(width: 49, height: 49,
          decoration: BoxDecoration(color: Colors.white,
            borderRadius: BorderRadius.circular(16)),
          child: Icon(icon, color: AppTheme.deepRed, size: 25)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(eyebrow, style: const TextStyle(
            color: AppTheme.deepRed, letterSpacing: 1,
            fontSize: 12, fontWeight: FontWeight.w700)),
          const SizedBox(height: 5),
          Text(title, style: const TextStyle(color: AppTheme.ink,
            fontSize: 16, height: 1.13, fontWeight: FontWeight.w700)),
          const SizedBox(height: 7),
          Text(message, style: const TextStyle(color: Color(0xFF685347),
            height: 1.4, fontSize: 12.5)),
        ])),
      ]),
      if (action != null && onPressed != null) ...[
        const SizedBox(height: 15),
        Align(alignment: Alignment.centerRight,
          child: FilledButton.icon(
            onPressed: onPressed,
            style: FilledButton.styleFrom(
              backgroundColor: AppTheme.deepRed,
              foregroundColor: Colors.white,
              minimumSize: const Size(0, 46)),
            icon: const Icon(Icons.arrow_forward_rounded, size: 18),
            label: Text(action!),
          )),
      ],
    ]),
  );
}
