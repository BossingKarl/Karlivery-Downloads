import 'package:flutter/material.dart';
import '../design_system/k_components.dart';

import '../services/cart.dart';
import '../theme/app_theme.dart';
import 'utils.dart';
import '../design_system/k_network_image.dart';
import '../design_system/k_tokens.dart';

/// KARLIVERY_FUTURE_FOOD_V20_0_8_0
/// EVOLVE / 09 high-contrast editorial design system. Backend data/fees/navigation remain owned
/// by existing customer feature code. No demo restaurants or invented prices.
class FutureFoodStyle {
  static const ink = AppTheme.ink;
  static const pop = AppTheme.red;
  static const lime = AppTheme.yellow;
  static const snow = AppTheme.cream;
  static const muted = AppTheme.muted;
  static BorderRadius corners([double radius = 25]) =>
      BorderRadius.circular(radius);
}

/// V23: clean app-like navigation. Uses the original index/order and callbacks.
class FutureBottomBar extends StatelessWidget {
  const FutureBottomBar({super.key, required this.selected, required this.onTap});
  final int selected;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    const items = <(IconData, IconData, String)>[
      (Icons.home_outlined, Icons.home_rounded, 'Home'),
      (Icons.receipt_long_outlined, Icons.receipt_long_rounded, 'Orders'),
      (Icons.shopping_bag_outlined, Icons.shopping_bag_rounded, 'Cart'),
      (Icons.chat_bubble_outline_rounded, Icons.chat_bubble_rounded, 'Chats'),
      (Icons.person_outline_rounded, Icons.person_rounded, 'Profile'),
    ];
    return SafeArea(
      top: false,
      child: Container(
        decoration: BoxDecoration(color: scheme.surface,
          border: Border(top: BorderSide(color: scheme.outlineVariant.withValues(alpha: .65)))),
        padding: const EdgeInsets.fromLTRB(6, 6, 6, 2),
        child: Row(children: [
          for (var i = 0; i < items.length; i++)
            Expanded(child: Semantics(
              button: true, selected: selected == i,
              label: items[i].$3,
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () => onTap(i),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 5),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Badge(
                      isLabelVisible: i == 2 && CartService.instance.count > 0,
                      label: Text('${CartService.instance.count}'),
                      child: Icon(selected == i ? items[i].$2 : items[i].$1,
                        size: 20,
                        color: selected == i ? AppTheme.red : scheme.onSurfaceVariant),
                    ),
                    const SizedBox(height: 5),
                    Text(items[i].$3, style: TextStyle(
                      fontSize: 12,
                      fontWeight: selected == i ? FontWeight.w600 : FontWeight.w400,
                      color: selected == i ? AppTheme.red : scheme.onSurfaceVariant)),
                  ]),
                ),
              ),
            )),
        ]),
      ),
    );
  }
}

class FutureFoodHeadline extends StatelessWidget {
  const FutureFoodHeadline({super.key, required this.title, required this.eyebrow,
    this.trailing, this.subtitle});
  final String title;
  final String eyebrow;
  final String? subtitle;
  final Widget? trailing;
  @override
  Widget build(BuildContext context) => KDSSectionHeading(
    eyebrow: eyebrow, title: title, subtitle: subtitle, trailing: trailing);
}

/// Full-bleed, swipeable spotlight, sourced from actual featured dishes.
/// In the absence of saved dishes the feature disappears rather than creating
/// fake food, restaurants, offers or prices.
class FutureFoodSpotlight extends StatelessWidget {
  const FutureFoodSpotlight({super.key, required this.dishes, required this.onOpenStore,
    this.isSearch = false});
  final List<Map<String, dynamic>> dishes;
  final ValueChanged<String> onOpenStore;
  final bool isSearch;

  @override
  Widget build(BuildContext context) {
    final items = dishes.where((dish) =>
        '${dish['name'] ?? ''}'.trim().isNotEmpty &&
        '${dish['_store_id'] ?? dish['store_id'] ?? ''}'.trim().isNotEmpty &&
        dish['is_available'] != false).take(10).toList();
    if (items.isEmpty) return const SizedBox.shrink();
    final scheme = Theme.of(context).colorScheme;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      FutureFoodHeadline(
        eyebrow: isSearch ? 'MENU MATCHES' : 'FROM YOUR LOCAL SHOPS',
        title: isSearch ? 'Dishes matching your search' : 'What sounds delicious?'),
      const SizedBox(height: 12),
      SizedBox(height: 223, child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        separatorBuilder: (_, _) => const SizedBox(width: 11),
        itemBuilder: (context, index) {
          final dish = items[index];
          final url = '${dish['image_url'] ?? ''}'.trim();
          final storeId = '${dish['_store_id'] ?? dish['store_id'] ?? ''}';
          final price = num.tryParse('${dish['price'] ?? ''}');
          return SizedBox(width: 183, child: Material(
            color: scheme.surface,
            clipBehavior: Clip.antiAlias,
            borderRadius: BorderRadius.circular(18),
            child: InkWell(
              onTap: () => onOpenStore(storeId),
              child: Container(
                decoration: BoxDecoration(border: Border.all(color: scheme.outlineVariant),
                    borderRadius: BorderRadius.circular(18)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  SizedBox(height: 132, width: double.infinity,
                    child: Stack(fit: StackFit.expand, children: [
                      if (url.isNotEmpty)
                        KNetImage(url, fit: BoxFit.cover,
                            errorBuilder: (_, _, _) => const _FuturePhotoFallback())
                      else const _FuturePhotoFallback(),
                      Positioned(top: 8, left: 8,
                        child: DecoratedBox(decoration: BoxDecoration(
                          color: AppTheme.yellow,
                          borderRadius: BorderRadius.circular(50)),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                            child: Text(isSearch ? 'MENU MATCH' : 'LOCAL PICK',
                              style: const TextStyle(color: AppTheme.ink,
                                fontWeight: FontWeight.w700, fontSize: 12)),
                          ))),
                    ])),
                  Padding(padding: const EdgeInsets.fromLTRB(10, 9, 10, 7),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('${dish['name']}', maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5)),
                      const SizedBox(height: 3),
                      Text(price == null ? 'View menu' : money(price),
                        style: const TextStyle(fontWeight: FontWeight.w700,
                          color: AppTheme.red, fontSize: 12)),
                      const SizedBox(height: 4),
                      const Row(children: [Expanded(child: Text('Explore restaurant',
                        maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600))),
                        SizedBox(width: 4), Icon(Icons.arrow_forward_rounded, size: 13)]),
                    ])),
                ]),
              ),
            ),
          ));
        },
      )),
    ]);
  }
}

/// Image-like emoji food tiles sized for mobile browsing. Retains exact original
/// keyword search values and onSelect callback so backend search is untouched.
class FutureFoodCategories extends StatelessWidget {
  const FutureFoodCategories({super.key, required this.query, required this.onSelect});
  final String query;
  final ValueChanged<String> onSelect;
  static const entries = <(String, String, String)>[
    ('All', '', '🍽️'),
    ('Meals', 'rice', '🍱'),
    ('Burgers', 'burger', '🍔'),
    ('Noodles', 'noodle', '🍜'),
    ('Drinks', 'drink', '🥤'),
    ('Snacks', 'snack', '🍟'),
  ];
  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return SizedBox(
      height: 112,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: entries.length,
        separatorBuilder: (_, _) => const SizedBox(width: 10),
        itemBuilder: (context, i) {
          final category = entries[i];
          final active = query == category.$2;
          return Material(
            color: active ? AppTheme.red : scheme.surface,
            borderRadius: BorderRadius.circular(18),
            child: InkWell(
              onTap: () => onSelect(category.$2),
              borderRadius: BorderRadius.circular(18),
              child: Container(
                width: 79,
                padding: const EdgeInsets.symmetric(vertical: 9),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: active ? AppTheme.red : scheme.outlineVariant),
                ),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text(category.$3, style: const TextStyle(fontSize: 28)),
                  const SizedBox(height: 3),
                  Text(category.$1, style: TextStyle(fontSize: 12,
                    color: active ? Colors.white : scheme.onSurface,
                    fontWeight: FontWeight.w700)),
                ]),
              ),
            ),
          );
        },
      ),
    );
  }
}

/// V23 premium, image-first store tile. Compact mode permits two real store
/// cards side by side on phone, without modifying the store or order models.
class FutureFoodStoreCard extends StatelessWidget {
  const FutureFoodStoreCard({super.key, required this.store,
    required this.dishes, required this.onTap});
  final Map<String, dynamic> store;
  final List<Map<String, dynamic>> dishes;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (context, bounds) {
    final compact = bounds.maxWidth < 235;
    final name = '${store['name'] ?? 'Local kitchen'}';
    final logo = '${store['logo_url'] ?? ''}'.trim();
    final photo = dishes.isEmpty ? '' : '${dishes.first['image_url'] ?? ''}'.trim();
    final open = store['is_open'] == true;
    final rating = num.tryParse('${store['rating_avg'] ?? ''}');
    final count = int.tryParse('${store['rating_count'] ?? 0}') ?? 0;
    final fee = num.tryParse('${store['delivery_fee_preview'] ?? ''}');
    final distance = num.tryParse('${store['distance_km'] ?? ''}');
    final etaMin = int.tryParse('${store['eta_min_minutes'] ?? ''}');
    final etaMax = int.tryParse('${store['eta_max_minutes'] ?? ''}');
    final eta = etaMin == null
        ? null
        : (etaMax == null || etaMax <= etaMin
            ? '$etaMin min'
            : '$etaMin–$etaMax min');
    final area = '${store['barangay'] ?? ''}'.trim();
    final scheme = Theme.of(context).colorScheme;
    final image = photo.isNotEmpty ? photo : logo;
    return Material(
      color: scheme.surface,
      borderRadius: BorderRadius.circular(19),
      clipBehavior: Clip.antiAlias,
      child: InkWell(onTap: onTap, child: Container(
        decoration: BoxDecoration(border: Border.all(color: scheme.outlineVariant),
          borderRadius: BorderRadius.circular(19)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          AspectRatio(
            aspectRatio: compact ? 1.25 : 1.65,
            child: Stack(fit: StackFit.expand, children: [
              if (image.isNotEmpty)
                KNetImage(image, fit: BoxFit.cover,
                  errorBuilder: (_, _, _) => const _FuturePhotoFallback())
              else const _FuturePhotoFallback(),
              Positioned(left: 7, bottom: 7, child: Container(
                padding: EdgeInsets.symmetric(horizontal: compact ? 7 : 9, vertical: 5),
                decoration: BoxDecoration(
                  color: open ? KPalette.openBadge : KPalette.closedBadge,
                  borderRadius: BorderRadius.circular(50)),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Container(width: 6, height: 6,
                    decoration: BoxDecoration(color: open ? const Color(0xFF8CFFAB) : Colors.white70,
                      shape: BoxShape.circle)),
                  const SizedBox(width: 5),
                  Text(open ? 'Open' : 'Closed', style: const TextStyle(
                    fontSize: 12, fontWeight: FontWeight.w700, color: Colors.white)),
                ]),
              )),
              if (rating != null && count > 0)
                Positioned(top: 7, right: 7, child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
                  decoration: BoxDecoration(color: scheme.surface,
                    borderRadius: BorderRadius.circular(8)),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.star_rounded, size: 13, color: KPalette.star),
                    const SizedBox(width: 2),
                    Text(rating.toStringAsFixed(1), style: const TextStyle(
                      fontSize: 12, fontWeight: FontWeight.w700)),
                  ]),
                )),
            ]),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(compact ? 10 : 13, 10, compact ? 10 : 13, 12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(name, maxLines: compact ? 2 : 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: compact ? 13 : 16,
                  height: 1.19, fontWeight: FontWeight.w700, letterSpacing: -.25)),
              const SizedBox(height: 5),
              if (area.isNotEmpty)
                Text(area, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: compact ? 10 : 11,
                    color: scheme.onSurfaceVariant)),
              const SizedBox(height: 7),
              Wrap(spacing: 8, runSpacing: 4, children: [
                if (eta != null)
                  _FutureMeta(Icons.schedule_rounded, eta),
                if (distance != null)
                  _FutureMeta(Icons.near_me_rounded, '${distance.toStringAsFixed(1)} km'),
                if (fee != null)
                  _FutureMeta(Icons.delivery_dining_rounded, money(fee)),
              ]),
            ]),
          ),
        ]),
      )),
    );
  });
}

class _FutureMeta extends StatelessWidget {
  const _FutureMeta(this.icon, this.text);
  final IconData icon;
  final String text;
  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
    Icon(icon, size: 14, color: FutureFoodStyle.pop),
    const SizedBox(width: 3),
    Text(text, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
  ]);
}

class FutureFoodPabiliEntry extends StatelessWidget {
  const FutureFoodPabiliEntry({super.key, required this.onTap});
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Material(
    color: const Color(0xFFFFE6AA),
    clipBehavior: Clip.antiAlias,
    borderRadius: FutureFoodStyle.corners(22),
    child: InkWell(onTap: onTap, child: Padding(
      padding: const EdgeInsets.fromLTRB(15, 13, 13, 13),
      child: Row(children: [
        Container(width: 48, height: 48,
          decoration: BoxDecoration(color: FutureFoodStyle.lime,
            borderRadius: FutureFoodStyle.corners(15)),
          child: const Icon(Icons.shopping_basket_rounded,
            color: FutureFoodStyle.ink, size: 27)),
        const SizedBox(width: 12),
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Pabili with Karlivery', style: TextStyle(color: FutureFoodStyle.ink,
            fontSize: 16, letterSpacing: -.3, fontWeight: FontWeight.w700)),
          SizedBox(height: 4),
          Text('Need something else? We got you.', style: TextStyle(
            color: FutureFoodStyle.muted, fontSize: 12)),
        ])),
        const Icon(Icons.arrow_outward_rounded,
          color: FutureFoodStyle.pop, size: 25),
      ]),
    )),
  );
}

class _FuturePhotoFallback extends StatelessWidget {
  const _FuturePhotoFallback();
  @override
  Widget build(BuildContext context) => DecoratedBox(
    decoration: const BoxDecoration(gradient: LinearGradient(
      begin: Alignment.topLeft, end: Alignment.bottomRight,
      colors: [Color(0xFFFFD5C5), Color(0xFFFFE6B0)],
    )),
    child: Center(child: Icon(Icons.ramen_dining_rounded,
      size: 58, color: FutureFoodStyle.lime.withValues(alpha: .8))),
  );
}
