import 'package:flutter/material.dart';
import '../design_system/k_components.dart';

/// Universal role header. Data and callbacks remain with the feature screens.
class NovaHeadline extends StatelessWidget {
  final String eyebrow;
  final String title;
  final String subtitle;
  final IconData icon;
  final Widget? trailing;
  const NovaHeadline({super.key, required this.eyebrow, required this.title,
    required this.subtitle, required this.icon, this.trailing});

  @override
  Widget build(BuildContext context) {
    final kind = eyebrow.toLowerCase();
    final workspace = kind.contains('rider') ? KDSWorkspace.rider
      : kind.contains('admin') ? KDSWorkspace.admin
      : kind.contains('seller') || kind.contains('store') ? KDSWorkspace.seller
      : KDSWorkspace.customer;
    return KDSWorkspaceHero(workspace: workspace, eyebrow: eyebrow,
      title: title, subtitle: subtitle, icon: icon, trailing: trailing);
  }
}
