import 'package:flutter/foundation.dart';

class AppConfig {
  static const String appName = 'Karlivery';
  static const String appVersion = '24.0.0';
  static const String tagline = 'Fast food delivery around your community.';
  static const String adminAlias = 'KAdmin';
  static const String adminEmail = 'kadmin@karlivery.app';

  static const String supabaseUrl =
      'https://tohcpqxouoqxxvzcmejm.supabase.co';

  static const String supabasePublishableKey =
      'sb_publishable_JmX_FaCjgw3vkRzM5ASV-w__vqh9IXd';

  static const String authRedirectScheme = 'com.karlivery';
  static const String authRedirectHost = 'login-callback';
  static const String webUrl =
      'https://karlivery.pages.dev';

  static String get authRedirectUrl => kIsWeb
      ? '$webUrl/'
      : 'com.karlivery://login-callback/';
}
