class PushConfig {
  PushConfig._();

  // Run SETUP_PHONE_NOTIFICATIONS.ps1 to fill this automatically.
  // A OneSignal App ID is a public application identifier, not a REST secret.
  static const String oneSignalAppId = 'ecf8f21b-e25c-436d-9879-7a7571fc1a6b';

  static bool get enabled =>
      oneSignalAppId.isNotEmpty &&
      oneSignalAppId != 'PASTE_ONESIGNAL_APP_ID_HERE';
}
