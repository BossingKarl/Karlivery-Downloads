import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/smart_back.dart';

import '../../services/pasabuy_service.dart';
import '../shared/order_receipt_screen.dart';
import '../../design_system/k_network_image.dart';

class PasabuyOrderDetailScreen extends StatefulWidget {
  final String orderId;
  const PasabuyOrderDetailScreen({super.key, required this.orderId});

  @override
  State<PasabuyOrderDetailScreen> createState() => _PasabuyOrderDetailScreenState();
}

class _PasabuyOrderDetailScreenState extends State<PasabuyOrderDetailScreen> {
  Map<String, dynamic>? order;
  List<Map<String, dynamic>> items = [];
  bool loading = true;
  bool busy = false;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    if (mounted) setState(() => loading = true);
    try {
      order = await PasabuyService.orderById(widget.orderId);
      items = await PasabuyService.orderItems(widget.orderId);
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return Scaffold(
        appBar: AppBar(leading: const KarliveryBackButton(fallback: '/pasabuy'), title: const Text('Pabili order')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }
    final o = order;
    if (o == null) {
      return Scaffold(
        appBar: AppBar(leading: const KarliveryBackButton(fallback: '/pasabuy'), title: const Text('Pabili order')),
        body: const Center(child: Text('This Pabili order is unavailable.')),
      );
    }

    final rider = o['profiles'] is Map ? Map<String, dynamic>.from(o['profiles']) : null;
    final hasRider = o['rider_id'] != null;
    final payment = (o['payment_method'] ?? 'cod').toString();
    final paymentStatus = (o['payment_status'] ?? '').toString();
    final total = double.tryParse(o['total_amount']?.toString() ?? '') ?? 0;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Pabili with Karlivery'),
        leading: IconButton(
          tooltip: 'Back to Pabili',
          onPressed: () => KarliveryBack.navigate(context, '/pasabuy'),
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
        ),
        actions: [
          IconButton(onPressed: load, icon: const Icon(Icons.refresh_rounded)),
        ],
      ),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.fromLTRB(16, 6, 16, 10),
        child: OutlinedButton.icon(
          onPressed: () => context.go('/pasabuy'),
          icon: const Icon(Icons.storefront_rounded),
          label: const Text('Back to Pabili stores and orders'),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 30),
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(28),
                gradient: const LinearGradient(
                  colors: [Color(0xFFE51C23), Color(0xFFFFA726)],
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    o['pasabuy_shops'] is Map ? (o['pasabuy_shops']['name'] ?? 'Pabili store').toString() : 'Pabili store',
                    style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 6),
                  Text('Reference ${o['id']}', style: const TextStyle(color: Colors.white70)),
                  const SizedBox(height: 14),
                  Text(
                    (o['status'] ?? 'Waiting for Rider').toString(),
                    style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    hasRider
                        ? 'Your Karlivery rider is connected. Chat and live tracking are now available.'
                        : 'Waiting for an available Karlivery rider. No GCash should be sent until a rider accepts.',
                    style: const TextStyle(color: Colors.white),
                  ),
                ],
              ),
            ),
            if ((o['status'] ?? '').toString().toLowerCase() == 'delivered') ...[
              const SizedBox(height: 14),
              FilledButton.icon(
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => OrderReceiptScreen(orderId: widget.orderId, isPabili: true),
                )),
                icon: const Icon(Icons.receipt_long_rounded),
                label: const Text('View Pabili completion receipt'),
              ),
            ],
            const SizedBox(height: 14),
            _StatusTimeline(status: (o['status'] ?? '').toString()),
            const SizedBox(height: 14),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Order summary', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 10),
                    for (final item in items)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Text('${item['quantity']}x ${item['item_name']}'),
                            ),
                            Text('₱${((double.tryParse(item['item_price']?.toString() ?? '') ?? 0) * (int.tryParse(item['quantity']?.toString() ?? '') ?? 1)).toStringAsFixed(0)}'),
                          ],
                        ),
                      ),
                    if ((o['custom_request'] ?? '').toString().trim().isNotEmpty) ...[
                      const Divider(),
                      Text('Custom request: ${o['custom_request']}'),
                      if ((double.tryParse(o['custom_request_amount']?.toString() ?? '') ?? 0) > 0)
                        Text('Custom request estimate: ₱${(double.tryParse(o['custom_request_amount']?.toString() ?? '') ?? 0).toStringAsFixed(0)}'),
                    ],
                    const Divider(),
                    _MoneyRow(label: 'Subtotal', value: o['subtotal']),
                    _MoneyRow(label: 'Pabili handling fee', value: o['handling_fee']),
                    _MoneyRow(label: 'Delivery fee', value: o['delivery_fee']),
                    const Divider(),
                    _MoneyRow(label: 'Total', value: total, strong: true),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            if (hasRider)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Your Karlivery rider', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                      const SizedBox(height: 8),
                      Text(rider?['full_name']?.toString() ?? 'Assigned rider'),
                      if ((rider?['phone'] ?? '').toString().isNotEmpty)
                        Text(rider!['phone'].toString()),
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          FilledButton.tonalIcon(
                            onPressed: () => context.push('/pasabuy/chat/${widget.orderId}'),
                            icon: const Icon(Icons.chat_bubble_rounded),
                            label: const Text('Chat rider'),
                          ),
                          FilledButton.tonalIcon(
                            onPressed: () => context.push('/pasabuy/track/${widget.orderId}'),
                            icon: const Icon(Icons.map_rounded),
                            label: const Text('Live tracking'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            if (payment == 'rider_gcash') ...[
              const SizedBox(height: 14),
              _RiderGcashCard(
                order: o,
                rider: rider,
                busy: busy,
                onSubmit: hasRider && paymentStatus != 'paid' ? _submitGcash : null,
              ),
            ] else ...[
              const SizedBox(height: 14),
              const Card(
                child: ListTile(
                  leading: Icon(Icons.payments_outlined),
                  title: Text('Cash on Delivery'),
                  subtitle: Text('Pay the assigned rider when the Pabili order arrives.'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _submitGcash() async {
    final o = order;
    if (o == null || o['rider_id'] == null) return;
    final reference = TextEditingController();
    PlatformFile? proof;

    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: const Text('Confirm GCash sent to rider'),
          content: SizedBox(
            width: 430,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: reference,
                  decoration: const InputDecoration(labelText: 'GCash reference number'),
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: () async {
                    final result = await FilePicker.platform.pickFiles(type: FileType.image, withData: true);
                    if (result != null) setDialogState(() => proof = result.files.single);
                  },
                  icon: const Icon(Icons.receipt_long_rounded),
                  label: Text(proof == null ? 'Attach proof screenshot' : proof!.name),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('I sent the payment'),
            ),
          ],
        ),
      ),
    );

    if (ok != true) {
      reference.dispose();
      return;
    }
    if (reference.text.trim().isEmpty) {
      reference.dispose();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter the GCash reference number.')));
      }
      return;
    }

    setState(() => busy = true);
    try {
      String? proofPath;
      if (proof?.bytes != null) {
        proofPath = await PasabuyService.uploadPasabuyPaymentProof(
          orderId: widget.orderId,
          bytes: proof!.bytes!,
          extension: (proof!.extension ?? 'jpg').toLowerCase(),
        );
      }
      await PasabuyService.customerConfirmGcashSent(
        orderId: widget.orderId,
        reference: reference.text,
        proofPath: proofPath,
      );
      await load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('GCash marked sent. Waiting for the rider to confirm receipt.')),
        );
      }
    } finally {
      reference.dispose();
      if (mounted) setState(() => busy = false);
    }
  }
}

class _RiderGcashCard extends StatelessWidget {
  final Map<String, dynamic> order;
  final Map<String, dynamic>? rider;
  final bool busy;
  final Future<void> Function()? onSubmit;

  const _RiderGcashCard({required this.order, required this.rider, required this.busy, required this.onSubmit});

  @override
  Widget build(BuildContext context) {
    final status = (order['payment_status'] ?? '').toString();
    final number = rider?['rider_gcash_number']?.toString() ?? '';
    final qr = rider?['rider_gcash_qr_url']?.toString() ?? '';
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('GCash directly to rider', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 7),
            if (rider == null)
              const Text('Wait for a rider to accept. Karlivery will reveal only the assigned rider’s GCash details.')
            else ...[
              Text(number.isEmpty ? 'Rider has not added a GCash number yet.' : number, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 18)),
              if (qr.isNotEmpty) ...[
                const SizedBox(height: 12),
                Center(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: KNetImage(qr, height: 210, fit: BoxFit.contain),
                  ),
                ),
              ],
              const SizedBox(height: 10),
              Text(
                status == 'paid'
                    ? 'Rider confirmed receiving your GCash payment.'
                    : status == 'customer_sent'
                        ? 'You marked GCash sent. Waiting for rider confirmation.'
                        : 'Send only to the rider details shown here. Never send Pabili GCash before a rider is assigned.',
              ),
              if (onSubmit != null && status != 'customer_sent') ...[
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: busy ? null : onSubmit,
                    icon: const Icon(Icons.upload_file_rounded),
                    label: const Text('Submit GCash reference / proof'),
                  ),
                ),
              ],
            ],
          ],
        ),
      ),
    );
  }
}

class _StatusTimeline extends StatelessWidget {
  final String status;
  const _StatusTimeline({required this.status});

  @override
  Widget build(BuildContext context) {
    const steps = ['Waiting for Rider', 'Rider Accepted', 'Buying in Progress', 'Purchased', 'On the Way', 'Delivered'];
    final current = steps.indexOf(status);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Pabili progress', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            for (var i = 0; i < steps.length; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 9),
                child: Row(
                  children: [
                    Icon(
                      i <= current ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
                      color: i <= current ? const Color(0xFFE51C23) : Colors.grey,
                    ),
                    const SizedBox(width: 8),
                    Text(steps[i], style: TextStyle(fontWeight: i == current ? FontWeight.w700 : FontWeight.w500)),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _MoneyRow extends StatelessWidget {
  final String label;
  final dynamic value;
  final bool strong;
  const _MoneyRow({required this.label, required this.value, this.strong = false});

  @override
  Widget build(BuildContext context) {
    final amount = value is num ? value.toDouble() : double.tryParse(value?.toString() ?? '') ?? 0;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(child: Text(label, style: TextStyle(fontWeight: strong ? FontWeight.w700 : FontWeight.w500))),
          Text('₱${amount.toStringAsFixed(0)}', style: TextStyle(fontWeight: strong ? FontWeight.w700 : FontWeight.w600)),
        ],
      ),
    );
  }
}
