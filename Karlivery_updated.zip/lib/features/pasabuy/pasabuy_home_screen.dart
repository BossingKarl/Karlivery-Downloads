import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/smart_back.dart';

import '../../core/karlivery_2026.dart';
import '../../core/nova_headline.dart';
import '../../services/pasabuy_cart.dart';
import '../../services/pasabuy_service.dart';
import '../../design_system/k_network_image.dart';

class PasabuyHomeScreen extends StatefulWidget {
  const PasabuyHomeScreen({super.key});

  @override
  State<PasabuyHomeScreen> createState() => _PasabuyHomeScreenState();
}

class _PasabuyHomeScreenState extends State<PasabuyHomeScreen> {
  List<Map<String, dynamic>> shops = [];
  List<Map<String, dynamic>> myOrders = [];
  bool loading = true;
  String query = '';

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() => loading = true);
    try {
      shops = await PasabuyService.listShops();
    } catch (e) {
      shops = [];
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not load Pabili stores: $e')),
        );
      }
    }
    try {
      myOrders = await PasabuyService.myOrders();
    } catch (_) {
      myOrders = [];
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final filtered = shops.where((shop) {
      final haystack = '${shop['name'] ?? ''} ${shop['description'] ?? ''} ${shop['location_label'] ?? ''}'.toLowerCase();
      return haystack.contains(query.toLowerCase());
    }).toList();

    return Scaffold(
      appBar: AppBar(
        leading: const KarliveryBackButton(fallback: '/customer'),
        title: const Text('Pabili with Karlivery'),
        actions: [
          IconButton(
            tooltip: 'Basket',
            onPressed: () => context.push('/pasabuy/checkout'),
            icon: AnimatedBuilder(
              animation: PasabuyCartService.instance,
              builder: (_, _) => Badge(
                isLabelVisible: PasabuyCartService.instance.count > 0,
                label: Text('${PasabuyCartService.instance.count}'),
                child: const Icon(Icons.shopping_bag_outlined),
              ),
            ),
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
                children: [
                  NovaHeadline(
                    eyebrow: 'PABILI WITH KARLIVERY',
                    title: 'Need it? We got you.',
                    subtitle: 'Browse pickup locations, pick what you want, and leave the run to your rider.',
                    icon: Icons.shopping_basket_rounded,
                    trailing: Chip(label: Text('${myOrders.length} previous orders')),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    onChanged: (value) => setState(() => query = value),
                    decoration: const InputDecoration(
                      prefixIcon: Icon(Icons.search_rounded),
                      hintText: 'Search Pabili stores or places',
                    ),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => context.push('/pasabuy/checkout'),
                          icon: const Icon(Icons.shopping_bag_outlined),
                          label: const Text('Open basket'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: myOrders.isEmpty ? null : () => context.push('/pasabuy/order/${myOrders.first['id']}'),
                          icon: const Icon(Icons.receipt_long_outlined),
                          label: Text(myOrders.isEmpty ? 'No orders yet' : 'Latest order'),
                        ),
                      ),
                    ],
                  ),
                  if (myOrders.isNotEmpty) ...[
                    const SizedBox(height: 18),
                    Text(
                      'Recent pasabuy orders',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 10),
                    SizedBox(
                      height: 132,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        itemCount: myOrders.length,
                        separatorBuilder: (_, _) => const SizedBox(width: 12),
                        itemBuilder: (context, index) {
                          final order = myOrders[index];
                          return _OrderSnippet(
                            order: order,
                            onTap: () => context.push('/pasabuy/order/${order['id']}'),
                          );
                        },
                      ),
                    ),
                  ],
                  const SizedBox(height: 18),
                  K26Section(
                    title: 'Pick your spot',
                    detail: 'Browse available Pabili pickup locations.',
                    trailing: Text('${filtered.length} found',
                      style: Theme.of(context).textTheme.bodySmall),
                  ),
                  const SizedBox(height: 12),
                  if (filtered.isEmpty)
                    const Card(
                      child: Padding(
                        padding: EdgeInsets.all(20),
                        child: Text('No pasabuy store matches your search yet.'),
                      ),
                    )
                  else
                    for (final shop in filtered)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 14),
                        child: _ShopCard(
                          shop: shop,
                          onTap: () => context.push('/pasabuy/shop/${shop['id']}'),
                        ),
                      ),
                ],
              ),
            ),
    );
  }
}

class _OrderSnippet extends StatelessWidget {
  final Map<String, dynamic> order;
  final VoidCallback onTap;
  const _OrderSnippet({required this.order, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final status = order['status']?.toString() ?? 'Pending';
    final idText = order['id']?.toString() ?? '—';
    final shortId = idText.length > 8 ? idText.substring(0, 8) : idText;
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: onTap,
      child: Ink(
        width: 240,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: .4),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primaryContainer,
                borderRadius: BorderRadius.circular(999),
              ),
              child: Text(status, style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
            const Spacer(),
            Text(
              order['shop_name']?.toString() ?? 'Pabili order',
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 6),
            Text('Order #$shortId', style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
    );
  }
}

class _ShopCard extends StatelessWidget {
  final Map<String, dynamic> shop;
  final VoidCallback onTap;
  const _ShopCard({required this.shop, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final cover = PasabuyService.shopCoverImage(shop);
    final logoImage = PasabuyService.shopLogoImage(shop);
    final photos = PasabuyService.shopMenuImages(shop).length;

    return InkWell(
      borderRadius: BorderRadius.circular(28),
      onTap: onTap,
      child: Ink(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          color: Theme.of(context).colorScheme.surface,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: .045),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
              child: SizedBox(
                height: 176,
                width: double.infinity,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    if (cover != null) _SmartImage(path: cover, fit: BoxFit.cover),
                    const DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                          colors: [Color(0xCC000000), Color(0x22000000)],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 58,
                            height: 58,
                            padding: const EdgeInsets.all(7),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(18),
                            ),
                            clipBehavior: Clip.antiAlias,
                            child: logoImage != null ? _SmartImage(path: logoImage, fit: BoxFit.contain) : const Icon(Icons.storefront_rounded),
                          ),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                            decoration: BoxDecoration(
                              color: Colors.white.withValues(alpha: .18),
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Text(
                              '$photos photo${photos == 1 ? '' : 's'}',
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    shop['name']?.toString() ?? 'Pabili store',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    shop['description']?.toString() ?? '',
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _InfoPill(icon: Icons.place_outlined, text: PasabuyService.townLabel(shop)),
                    ],
                  ),
                  const Text('Queue and travel times may vary.', style: TextStyle(fontSize: 12, color: Color(0xFF807A75))),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: onTap,
                      icon: const Icon(Icons.open_in_new_rounded),
                      label: const Text('Browse photos & request'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoPill extends StatelessWidget {
  final IconData icon;
  final String text;
  const _InfoPill({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    if (text.trim().isEmpty) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: .45),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 15),
          const SizedBox(width: 6),
          Flexible(child: Text(text, overflow: TextOverflow.ellipsis)),
        ],
      ),
    );
  }
}

class _SmartImage extends StatelessWidget {
  final String path;
  final BoxFit fit;
  const _SmartImage({required this.path, this.fit = BoxFit.cover});

  @override
  Widget build(BuildContext context) {
    if (path.startsWith('https://')) {
      return KNetImage(
        path,
        fit: fit,
        errorBuilder: (context, error, stackTrace) => const ColoredBox(
          color: Colors.black12,
          child: Center(child: Icon(Icons.image_not_supported_outlined)),
        ),
      );
    }
    return Image.asset(
      path,
      fit: fit,
      errorBuilder: (context, error, stackTrace) => const ColoredBox(
        color: Colors.black12,
        child: Center(child: Icon(Icons.image_not_supported_outlined)),
      ),
    );
  }
}
