import '../../core/smart_back.dart';
import 'package:flutter/material.dart';

import '../../core/chat_timeline.dart';
import '../../services/backend.dart';
import '../../services/pasabuy_service.dart';
import '../../theme/app_theme.dart';

class PasabuyChatScreen extends StatefulWidget {
  final String orderId;
  const PasabuyChatScreen({super.key, required this.orderId});

  @override
  State<PasabuyChatScreen> createState() => _PasabuyChatScreenState();
}

class _PasabuyChatScreenState extends State<PasabuyChatScreen> {
  final controller = TextEditingController();
  final scroll = ScrollController();
  bool sending = false;
  late Stream<List<Map<String, dynamic>>> messages;

  @override
  void initState() {
    super.initState();
    messages = PasabuyService.watchChat(widget.orderId);
  }

  void reconnect() {
    setState(() => messages = PasabuyService.watchChat(widget.orderId));
  }

  @override
  void dispose() {
    controller.dispose();
    scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final myId = Backend.user?.id;
    return Scaffold(
      appBar: AppBar(
          leading: const KarliveryBackButton(fallback: '/pasabuy'),
        title: const Text('Pabili conversation'),
        actions: [IconButton(onPressed: reconnect, icon: const Icon(Icons.refresh_rounded), tooltip: 'Refresh messages')],
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<List<Map<String, dynamic>>>(
              stream: messages,
              builder: (context, snap) {
                if (snap.hasError) {
                  return Center(
                    child: Padding(
                      padding: const EdgeInsets.all(22),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.wifi_off_rounded, size: 42),
                          const SizedBox(height: 12),
                          const Text('Could not load Pabili messages.', textAlign: TextAlign.center),
                          const SizedBox(height: 8),
                          SelectableText(snap.error.toString(), textAlign: TextAlign.center),
                          const SizedBox(height: 12),
                          OutlinedButton.icon(
                            onPressed: reconnect,
                            icon: const Icon(Icons.refresh_rounded),
                            label: const Text('Retry chat'),
                          ),
                        ],
                      ),
                    ),
                  );
                }
                final rows = snap.data ?? const <Map<String, dynamic>>[];
                if (snap.connectionState == ConnectionState.waiting && rows.isEmpty) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (rows.isEmpty) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'Start the conversation. Use chat to confirm substitutions, availability, landmarks, or arrival details.',
                        textAlign: TextAlign.center,
                      ),
                    ),
                  );
                }
                // Supabase orders ascending; reverse both data and scroll direction
                // so the newest message remains at the BOTTOM like modern chat.
                final latestFirst = newestFirstChatMessages(rows);
                return ListView.builder(
                  controller: scroll,
                  reverse: true,
                  keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                  padding: const EdgeInsets.fromLTRB(16, 18, 16, 20),
                  itemCount: latestFirst.length,
                  itemBuilder: (context, index) {
                    final row = latestFirst[index];
                    final mine = row['sender_id']?.toString() == myId;
                    return Align(
                      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        constraints: const BoxConstraints(maxWidth: 420),
                        margin: const EdgeInsets.only(bottom: 9),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                        decoration: BoxDecoration(
                          color: mine
                              ? AppTheme.softRed
                              : Theme.of(context).colorScheme.surfaceContainerHighest,
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              mine ? 'You' : (row['sender_role'] ?? 'Karlivery').toString(),
                              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
                            ),
                            const SizedBox(height: 3),
                            Text(row['message']?.toString() ?? ''),
                            const SizedBox(height: 5),
                            Text(
                              _messageTime(row['created_at']),
                              style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: controller,
                      minLines: 1,
                      maxLines: 4,
                      maxLength: 2000,
                      decoration: const InputDecoration(
                        hintText: 'Message your customer or assigned rider…',
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: sending ? null : _send,
                    icon: sending
                        ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.send_rounded),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _messageTime(dynamic raw) {
    final time = DateTime.tryParse(raw?.toString() ?? '')?.toLocal();
    if (time == null) return '';
    final hour = time.hour % 12 == 0 ? 12 : time.hour % 12;
    return '$hour:${time.minute.toString().padLeft(2, '0')} ${time.hour >= 12 ? 'PM' : 'AM'}';
  }

  Future<void> _send() async {
    final text = controller.text.trim();
    if (text.isEmpty) return;
    setState(() => sending = true);
    try {
      await PasabuyService.sendMessage(widget.orderId, text);
      if (mounted) {
        controller.clear();
        if (scroll.hasClients) {
          scroll.animateTo(0, duration: const Duration(milliseconds: 220), curve: Curves.easeOut);
        }
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Pabili message not sent: $error')),
        );
      }
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }
}
