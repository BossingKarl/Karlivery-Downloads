import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/smart_back.dart';

import '../../services/backend.dart';
import '../../services/pasabuy_cart.dart';
import '../../services/pasabuy_service.dart';

class PasabuyCheckoutScreen extends StatefulWidget {
  const PasabuyCheckoutScreen({super.key});

  @override
  State<PasabuyCheckoutScreen> createState() => _PasabuyCheckoutScreenState();
}

class _PasabuyCheckoutScreenState extends State<PasabuyCheckoutScreen> {
  List<Map<String, dynamic>> addresses = [];
  String? addressId;
  String paymentMethod = 'cod';
  final notesController = TextEditingController();
  final customRequestController = TextEditingController();
  final customAmountController = TextEditingController();
  bool submitting = false;
  Map<String, dynamic>? _deliveryQuote;
  String? _quotedShopId;
  String? _quotedAddressId;
  String? _quoteError;
  bool _loadingQuote = false;
  int _quoteSequence = 0;


  @override
  void initState() {
    super.initState();
    final cart = PasabuyCartService.instance;
    customRequestController.text = cart.customRequest;
    customAmountController.text = cart.customRequestAmount > 0 ? cart.customRequestAmount.toStringAsFixed(0) : '';
    load();
  }

  @override
  void dispose() {
    notesController.dispose();
    customRequestController.dispose();
    customAmountController.dispose();
    super.dispose();
  }

  Future<void> load() async {
    try {
      addresses = await Backend.myAddresses();
      if (addresses.isNotEmpty) addressId ??= addresses.first['id']?.toString();
      if (mounted) setState(() {});
      await _refreshQuote();
    } catch (_) {}
  }

  Future<void> _refreshQuote() async {
    final shopId = PasabuyCartService.instance.shopId;
    final selected = addressId;
    final request = ++_quoteSequence;
    if (!mounted) return;
    setState(() {
      _loadingQuote = true;
      _deliveryQuote = null;
      _quotedShopId = null;
      _quotedAddressId = null;
      _quoteError = null;
    });
    if (shopId == null || selected == null) {
      if (mounted && request == _quoteSequence) {
        setState(() {
          _loadingQuote = false;
          _quoteError = 'Select a pickup shop and a saved GPS delivery address.';
        });
      }
      return;
    }
    try {
      final quote = await PasabuyService.deliveryQuote(
        shopId: shopId, addressId: selected);
      if (!mounted || request != _quoteSequence) return;
      setState(() {
        _deliveryQuote = quote;
        _quotedShopId = shopId;
        _quotedAddressId = selected;
        _loadingQuote = false;
      });
    } catch (error) {
      if (!mounted || request != _quoteSequence) return;
      setState(() {
        _loadingQuote = false;
        _quoteError = error.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final cart = PasabuyCartService.instance;
    return AnimatedBuilder(
      animation: cart,
      builder: (_, _) {
        final activeQuote = !_loadingQuote && _quotedShopId == cart.shopId &&
                _quotedAddressId == addressId ? _deliveryQuote : null;
        double? quoteNumber(String key) =>
            double.tryParse(activeQuote?[key]?.toString() ?? '');
        final quotedFee = quoteNumber('delivery_fee');
        final distanceKm = quoteNumber('delivery_distance_km');
        final includedKm = quoteNumber('included_radius_km');
        final stepKm = quoteNumber('step_distance_km');
        final baseFee = quoteNumber('base_fee');
        final stepFee = quoteNumber('step_fee');
        final extraSteps = quoteNumber('extra_steps')?.toInt();
        final subtotal = cart.subtotal;
        final deliveryFee = quotedFee ?? 0.0;
        final total = subtotal + PasabuyService.handlingFee + deliveryFee;
        final basketIsEmpty = cart.lines.isEmpty && cart.customRequest.trim().isEmpty;

        return Scaffold(
          appBar: AppBar(leading: const KarliveryBackButton(fallback: '/pasabuy'), title: const Text('Pabili basket')),
          body: basketIsEmpty
              ? const Center(child: Text('Your pasabuy basket is empty.'))
              : ListView(
                  padding: const EdgeInsets.fromLTRB(18, 12, 18, 24),
                  children: [
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    cart.shopName ?? 'Pabili store',
                                    style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                                  ),
                                ),
                                TextButton.icon(
                                  onPressed: cart.clear,
                                  icon: const Icon(Icons.delete_outline_rounded),
                                  label: const Text('Clear all'),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            if (cart.lines.isNotEmpty) ...[
                              Text(
                                'Menu items',
                                style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
                              ),
                              const SizedBox(height: 10),
                              for (final line in cart.lines)
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 12),
                                  child: _BasketLine(
                                    line: line,
                                    onMinus: () => cart.changeQuantity(line.key, -1),
                                    onPlus: () => cart.changeQuantity(line.key, 1),
                                    onRemove: () => cart.remove(line.key),
                                  ),
                                ),
                              const Divider(height: 24),
                            ],
                            _CustomRequestCard(
                              request: cart.customRequest,
                              amount: cart.customRequestAmount,
                              onEdit: () => _editCustomRequest(cart),
                              onRemove: cart.customRequest.trim().isEmpty
                                  ? null
                                  : () {
                                      cart.setCustomRequest('');
                                      cart.setCustomRequestAmount(0);
                                    },
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Delivery address',
                              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                            ),
                            const SizedBox(height: 10),
                            if (addresses.isEmpty)
                              const Text('No saved address found yet. Add one from your customer account before placing pasabuy orders.')
                            else
                              DropdownButtonFormField<String>(
                                initialValue: addressId,
                                items: [
                                  for (final address in addresses)
                                    DropdownMenuItem(
                                      value: address['id']?.toString(),
                                      child: Text(
                                        '${address['label'] ?? 'Address'} • ${address['address_line'] ?? ''}, ${address['barangay'] ?? ''}',
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                ],
                                onChanged: (value) {
                                  setState(() => addressId = value);
                                  _refreshQuote();
                                },
                              ),
                            const SizedBox(height: 14),
                            Text(
                              'Payment method',
                              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                            ),
                            RadioGroup<String>(
                              groupValue: paymentMethod,
                              onChanged: (value) {
                                if (value == null) return;
                                setState(() => paymentMethod = value);
                              },
                              child: const Column(
                                children: [
                                  RadioListTile<String>(
                                    contentPadding: EdgeInsets.zero,
                                    value: 'cod',
                                    title: Text('Cash on Delivery'),
                                    subtitle: Text('Pay once the rider arrives with your order.'),
                                  ),
                                  RadioListTile<String>(
                                    contentPadding: EdgeInsets.zero,
                                    value: 'rider_gcash',
                                    title: Text('GCash to assigned rider'),
                                    subtitle: Text('After a rider accepts, Karlivery will show that rider’s GCash details so you can pay the correct person.'),
                                  ),
                                ],
                              ),
                            ),
                            TextField(
                              controller: notesController,
                              minLines: 2,
                              maxLines: 4,
                              decoration: const InputDecoration(
                                labelText: 'Notes for your order',
                                hintText: 'Landmarks, substitutions, reminder for rider, etc.',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Fee summary',
                              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                            ),
                            if (!PasabuyService.hasConfirmedPickup(cart.shop))
                              const Padding(
                                padding: EdgeInsets.only(bottom: 12),
                                child: Text('Pickup pin pending admin confirmation. Orders cannot be placed until it is verified.', style: TextStyle(color: Color(0xFFB91C1C), fontWeight: FontWeight.w600)),
                              ),
                            const SizedBox(height: 12),
                            _SummaryRow(label: 'Subtotal', value: subtotal),
                            _SummaryRow(label: 'Handling fee', value: PasabuyService.handlingFee),
                            if (distanceKm != null) ...[
                              const SizedBox(height: 8),
                              Row(children: [
                                const Expanded(child: Text('Store → customer (GPS)')),
                                Text('${distanceKm.toStringAsFixed(2)} km',
                                    style: const TextStyle(fontWeight: FontWeight.w700)),
                              ]),
                            ],
                            _SummaryRow(
                              label: quotedFee == null ? 'Delivery fee (GPS required)' : 'Delivery fee (straight-line estimate)',
                              value: deliveryFee,
                            ),
                            const SizedBox(height: 8),
                            Text(
                              quotedFee == null
                                  ? 'Choose an address with a map pin. An admin must confirm the exact pickup location before checkout.'
                                  : '₱${baseFee?.toStringAsFixed(0) ?? '-'} for the first ${includedKm?.toStringAsFixed(1) ?? '-'} km, +₱${stepFee?.toStringAsFixed(0) ?? '-'} per started ${stepKm?.toStringAsFixed(1) ?? '-'} km (${extraSteps ?? 0} extra steps). Pabili handling ₱20. GPS straight-line, not driving distance.',
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                            if (_loadingQuote)
                              const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: LinearProgressIndicator()),
                            if (_quoteError != null) ...[
                              Text(_quoteError!, style: const TextStyle(color: Colors.redAccent)),
                              TextButton.icon(
                                onPressed: _refreshQuote,
                                icon: const Icon(Icons.refresh_rounded),
                                label: const Text('Retry delivery quote'),
                              ),
                            ],
                            const Divider(height: 24),
                            _SummaryRow(label: 'Total', value: total, strong: true),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
          bottomNavigationBar: basketIsEmpty
              ? null
              : SafeArea(
                  minimum: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                  child: FilledButton(
                    onPressed: submitting || _loadingQuote || cart.shopId == null || addresses.isEmpty || quotedFee == null || !PasabuyService.hasConfirmedPickup(cart.shop) ? null : () => _submit(cart),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 15),
                      child: submitting
                          ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))
                          : Text('Place pasabuy order • ₱${total.toStringAsFixed(0)}'),
                    ),
                  ),
                ),
        );
      },
    );
  }

  Future<void> _editCustomRequest(PasabuyCartService cart) async {
    customRequestController.text = cart.customRequest;
    customAmountController.text = cart.customRequestAmount > 0 ? cart.customRequestAmount.toStringAsFixed(0) : '';

    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          left: 18,
          right: 18,
          top: 18,
          bottom: MediaQuery.of(context).viewInsets.bottom + 18,
        ),
        child: SafeArea(
          top: false,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Edit typed pasabuy order',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 8),
                const Text('Update the exact order description or the estimated amount before checkout.'),
                const SizedBox(height: 14),
                TextField(
                  controller: customRequestController,
                  minLines: 3,
                  maxLines: 6,
                  decoration: const InputDecoration(
                    labelText: 'Typed order',
                    hintText: 'Example: 2pc chicken with fries, 1 float, no mayo',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: customAmountController,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(
                    labelText: 'Estimated item amount',
                    prefixText: '₱ ',
                  ),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: () {
                      if (customRequestController.text.trim().isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Type your order or use Remove in your basket.')),
                        );
                        return;
                      }
                      Navigator.pop(context, true);
                    },
                    child: const Text('Save changes'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );

    if (saved == true) {
      cart.setCustomRequest(customRequestController.text);
      cart.setCustomRequestAmount(double.tryParse(customAmountController.text.trim()) ?? 0);
      if (mounted) setState(() {});
    }
  }

  Future<void> _submit(PasabuyCartService cart) async {
    setState(() => submitting = true);
    try {
      if (addressId == null) throw StateError('Select a delivery address with a GPS pin.');
      // Revalidate immediately. A rate changed by admin must be reviewed
      // before we submit; the database trigger is still authoritative.
      final freshQuote = await PasabuyService.deliveryQuote(
        shopId: cart.shopId!, addressId: addressId!);
      final latest = double.tryParse(freshQuote['delivery_fee']?.toString() ?? '');
      final shown = double.tryParse(_deliveryQuote?['delivery_fee']?.toString() ?? '');
      if (latest == null || shown == null ||
          (latest - shown).abs() > 0.001 ||
          _quotedShopId != cart.shopId || _quotedAddressId != addressId) {
        if (mounted) {
          setState(() {
            _deliveryQuote = freshQuote;
            _quotedShopId = cart.shopId;
            _quotedAddressId = addressId;
          });
        }
        throw StateError('Delivery rates changed. Review the updated fee and tap Place order again.');
      }

      final orderId = await PasabuyService.createOrder(
        shopId: cart.shopId!,
        paymentMethod: paymentMethod,
        addressId: addressId,
        deliveryFee: latest,
        customRequest: cart.customRequest,
        customRequestAmount: cart.customRequestAmount,
        notes: notesController.text,
        items: cart.lines
            .map(
              (line) => {
                'name': line.item['name'],
                'quantity': line.quantity,
                'unit_price': line.unitPrice,
                'note': line.note,
                'addons': line.addons,
              },
            )
            .toList(),
      );

      cart.clear();
      if (!mounted) return;

      await showDialog<void>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Pabili order placed'),
          content: Text(
            'Reference: $orderId\n\nKarlivery is now waiting for an available rider. Chat, rider GCash and live tracking unlock after a rider accepts.',
          ),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Track order'),
            ),
          ],
        ),
      );

      if (mounted) context.go('/pasabuy/order/$orderId'); // Order details has explicit navigation back to Pabili.
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not place pasabuy order: $e')),
      );
    } finally {
      if (mounted) setState(() => submitting = false);
    }
  }
}

class _BasketLine extends StatelessWidget {
  final PasabuyCartLine line;
  final VoidCallback onMinus;
  final VoidCallback onPlus;
  final VoidCallback onRemove;

  const _BasketLine({
    required this.line,
    required this.onMinus,
    required this.onPlus,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: .4),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  line.item['name']?.toString() ?? 'Item',
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
                if (line.addons.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(
                    line.addons.map((addon) => addon['name']).join(', '),
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
                if (line.note.trim().isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text('Note: ${line.note}', style: Theme.of(context).textTheme.bodySmall),
                ],
                const SizedBox(height: 10),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton.filledTonal(onPressed: onMinus, icon: const Icon(Icons.remove_rounded)),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Text('${line.quantity}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    ),
                    IconButton.filledTonal(onPressed: onPlus, icon: const Icon(Icons.add_rounded)),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('₱${line.subtotal.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 16),
              TextButton.icon(
                onPressed: onRemove,
                icon: const Icon(Icons.close_rounded),
                label: const Text('Remove'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _CustomRequestCard extends StatelessWidget {
  final String request;
  final double amount;
  final VoidCallback onEdit;
  final VoidCallback? onRemove;

  const _CustomRequestCard({
    required this.request,
    required this.amount,
    required this.onEdit,
    this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    final hasRequest = request.trim().isNotEmpty;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: .35),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'Typed order for rider',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
                ),
              ),
              TextButton.icon(
                onPressed: onEdit,
                icon: const Icon(Icons.edit_outlined),
                label: Text(hasRequest ? 'Edit' : 'Add'),
              ),
              if (hasRequest && onRemove != null)
                TextButton.icon(
                  onPressed: onRemove,
                  icon: const Icon(Icons.delete_outline_rounded),
                  label: const Text('Remove'),
                ),
            ],
          ),
          Text(
            hasRequest ? request : 'No typed request yet. Add one so the rider knows exactly what to buy.',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          if (amount > 0) ...[
            const SizedBox(height: 10),
            Text('Estimated amount: ₱${amount.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.w700)),
          ],
        ],
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  final String label;
  final double value;
  final bool strong;

  const _SummaryRow({required this.label, required this.value, this.strong = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(fontWeight: strong ? FontWeight.w700 : FontWeight.w500),
            ),
          ),
          Text(
            '₱${value.toStringAsFixed(0)}',
            style: TextStyle(fontWeight: strong ? FontWeight.w700 : FontWeight.w600),
          ),
        ],
      ),
    );
  }
}
