import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../../services/pasabuy_service.dart';
import '../../design_system/k_network_image.dart';

class AdminPasabuyStudioScreen extends StatefulWidget {
  const AdminPasabuyStudioScreen({super.key});

  @override
  State<AdminPasabuyStudioScreen> createState() => _AdminPasabuyStudioScreenState();
}

class _AdminPasabuyStudioScreenState extends State<AdminPasabuyStudioScreen> {
  List<Map<String, dynamic>> shops = [];
  String? selectedShopId;
  bool loading = true;
  bool uploading = false;

  Map<String, dynamic>? get selectedShop {
    for (final shop in shops) {
      if (shop['id']?.toString() == selectedShopId) return shop;
    }
    return null;
  }

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    try {
      final rows = await PasabuyService.listAdminShops();
      if (!mounted) return;
      setState(() {
        shops = rows;
        if (shops.every((s) => s['id']?.toString() != selectedShopId)) {
          selectedShopId = shops.isEmpty ? null : shops.first['id']?.toString();
        }
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Cannot load Pabili with Karlivery stores: $e')));
    }
  }

  Future<void> editShop() async {
    final current = selectedShop;
    if (current == null) return;
    final name = TextEditingController(text: current['name']?.toString() ?? '');
    final desc = TextEditingController(text: current['description']?.toString() ?? '');
    final brand = TextEditingController(text: current['brand']?.toString() ?? 'custom');
    final source = TextEditingController(text: current['source']?.toString() ?? 'Karlivery');
    final position = TextEditingController(text: current['sort_order']?.toString() ?? '0');
    final town = TextEditingController(text: current['location_label']?.toString() ?? '');
    final logo = TextEditingController(text: current['logo_url']?.toString() ?? '');
    final cover = TextEditingController(text: current['cover_image_url']?.toString() ?? '');
    final lat = TextEditingController(text: current['latitude']?.toString() ?? '');
    final lng = TextEditingController(text: current['longitude']?.toString() ?? '');
    final active = current['is_active'] != false;
    var isActive = active;
    var confirmed = current['coordinate_source']?.toString() == 'admin_confirmed';
    final controllers = [name, desc, town, logo, cover, lat, lng, brand, source, position];
    final ok = await showDialog<bool>(context: context, builder: (ctx) => StatefulBuilder(
      builder: (ctx, update) => AlertDialog(
        title: const Text('Pabili with Karlivery · Store settings'),
        content: SizedBox(width: 460, child: SingleChildScrollView(child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Store name')),
            const SizedBox(height: 10),
            TextField(controller: desc, minLines: 2, maxLines: 3, decoration: const InputDecoration(labelText: 'Customer-facing description')),
            const SizedBox(height: 10),
            TextField(controller: brand, decoration: const InputDecoration(labelText: 'Brand / category key')),
            const SizedBox(height: 10),
            TextField(controller: source, decoration: const InputDecoration(labelText: 'Store source / reference note')),
            const SizedBox(height: 10),
            TextField(controller: position, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Display order')),
            const SizedBox(height: 10),
            TextField(controller: town, decoration: const InputDecoration(labelText: 'Pickup address / landmark')),
            const SizedBox(height: 10),
            TextField(controller: logo, decoration: const InputDecoration(labelText: 'Logo HTTPS URL (optional)')),
            const SizedBox(height: 10),
            TextField(controller: cover, decoration: const InputDecoration(labelText: 'Cover HTTPS URL (optional)')),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: TextField(controller: lat, keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true), decoration: const InputDecoration(labelText: 'Pickup latitude'))),
              const SizedBox(width: 12),
              Expanded(child: TextField(controller: lng, keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true), decoration: const InputDecoration(labelText: 'Pickup longitude'))),
            ]),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: const Text('Exact pickup pin verified'),
              subtitle: const Text('Turn on only after confirming the restaurant entrance on a map.'),
              value: confirmed,
              onChanged: (v) => update(() => confirmed = v),
            ),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: const Text('Accept Pabili orders'),
              value: isActive,
              onChanged: (v) => update(() => isActive = v),
            ),
          ],
        ))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () {
            final lt = double.tryParse(lat.text.trim());
            final lg = double.tryParse(lng.text.trim());
            if (name.text.trim().isEmpty) {
              ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(content: Text('Store name is required.')));
              return;
            }
            if (confirmed && (lt == null || lg == null || lt.abs() > 90 || lg.abs() > 180)) {
              ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(content: Text('Valid GPS coordinates required for confirmed pickup.')));
              return;
            }
            Navigator.pop(ctx, true);
          }, child: const Text('Save store')),
        ],
      ),
    ));
    if (ok == true) {
      try {
        await PasabuyService.updateShop(id: current['id'].toString(), values: {
          'name': name.text.trim(), 'brand': brand.text.trim(),
          'source': source.text.trim(), 'sort_order': int.tryParse(position.text.trim()) ?? 0,
          'description': desc.text.trim(),
          'location_label': town.text.trim(), 'logo_url': logo.text.trim(),
          'cover_image_url': cover.text.trim(),
          'latitude': double.tryParse(lat.text.trim()), 'longitude': double.tryParse(lng.text.trim()),
          'coordinate_source': confirmed ? 'admin_confirmed' : 'town_center_estimate',
          'is_active': isActive,
        });
        await load();
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Save failed: $e')));
      }
    }
    for (final c in controllers) { c.dispose(); }
  }

  Future<void> uploadPhotos() async {
    final shop = selectedShop;
    if (shop == null || uploading) return;
    final result = await FilePicker.platform.pickFiles(type: FileType.image, allowMultiple: true, withData: true);
    if (result == null || result.files.isEmpty) return;
    setState(() => uploading = true);
    try {
      final existing = List<String>.from((shop['menu_image_urls'] is List ? shop['menu_image_urls'] : <String>[]).map((v) => v.toString()));
      for (final file in result.files) {
        final bytes = file.bytes;
        if (bytes == null) throw Exception('Could not read ${file.name}. Please select a smaller image.');
        existing.add(await PasabuyService.uploadGalleryImage(shopId: shop['id'].toString(), filename: file.name, bytes: bytes));
      }
      await _saveGallery(existing);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Upload failed: $e')));
    } finally {
      if (mounted) setState(() => uploading = false);
    }
  }

  Future<void> _saveGallery(List<String> urls, {bool useBundled = false}) async {
    final shop = selectedShop;
    if (shop == null) return;
    try {
      await PasabuyService.updateShop(id: shop['id'].toString(), values: {
        'menu_image_urls': urls,
        'show_bundled_gallery': useBundled,
      });
      await load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gallery save failed: $e')));
    }
  }

  Future<void> createStore() async {
    final name = TextEditingController();
    final town = TextEditingController();
    final approved = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Add a Pabili store'),
        content: SingleChildScrollView(child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Restaurant / store name')),
            const SizedBox(height: 12),
            TextField(controller: town, decoration: const InputDecoration(labelText: 'Town or pickup address')),
            const SizedBox(height: 8),
            const Text('New stores are hidden until you verify the pickup pin and gallery.'),
          ],
        )),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Create store')),
        ],
      ),
    );
    final storeName = name.text.trim();
    final location = town.text.trim();
    name.dispose();
    town.dispose();
    if (approved != true || storeName.isEmpty || !mounted) return;
    try {
      var maxOrder = 0;
      for (final s in shops) {
        final order = int.tryParse('${s['sort_order'] ?? 0}') ?? 0;
        if (order > maxOrder) maxOrder = order;
      }
      final id = await PasabuyService.createShop(
        name: storeName,
        locationLabel: location,
        sortOrder: maxOrder + 1,
      );
      selectedShopId = id;
      await load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Create failed: $e')));
    }
  }

  Future<void> uploadBrandPhoto(String column) async {
    final shop = selectedShop;
    if (shop == null || uploading) return;
    final result = await FilePicker.platform.pickFiles(type: FileType.image, withData: true);
    if (result == null || result.files.isEmpty) return;
    final file = result.files.first;
    if (file.bytes == null) return;
    setState(() => uploading = true);
    try {
      final url = await PasabuyService.uploadGalleryImage(
        shopId: shop['id'].toString(),
        filename: file.name,
        bytes: file.bytes!,
      );
      await PasabuyService.updateShop(id: shop['id'].toString(), values: {column: url});
      await load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Image upload failed: $e')));
    } finally {
      if (mounted) setState(() => uploading = false);
    }
  }

  Future<void> replaceGalleryPhoto(int index, List<String> overrides) async {
    final shop = selectedShop;
    if (shop == null || uploading || overrides.isEmpty) return;
    final result = await FilePicker.platform.pickFiles(type: FileType.image, withData: true);
    if (result == null || result.files.isEmpty || result.files.first.bytes == null) return;
    setState(() => uploading = true);
    try {
      final file = result.files.first;
      final url = await PasabuyService.uploadGalleryImage(
        shopId: shop['id'].toString(), filename: file.name, bytes: file.bytes!,
      );
      final updated = List<String>.from(overrides);
      updated[index] = url;
      await _saveGallery(updated);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Replace failed: $e')));
    } finally {
      if (mounted) setState(() => uploading = false);
    }
  }

  Future<void> toggleStoreActive() async {
    final shop = selectedShop;
    if (shop == null) return;
    final currentlyActive = shop['is_active'] == true;
    final approved = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: Text(currentlyActive ? 'Hide this store?' : 'Show this store?'),
      content: Text(currentlyActive
          ? 'The store will disappear from customer Pabili listings. Previous orders will remain.'
          : 'Confirm that images, address, and exact pickup pin are ready before accepting orders.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(currentlyActive ? 'Hide store' : 'Show store')),
      ],
    ));
    if (approved != true || !mounted) return;
    if (!currentlyActive && !PasabuyService.hasConfirmedPickup(shop)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Confirm the exact GPS pickup pin before activating this store.')));
      return;
    }
    try {
      await PasabuyService.updateShop(id: shop['id'].toString(), values: {'is_active': !currentlyActive});
      await load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Update failed: $e')));
    }
  }

  Future<void> addUrl() async {
    final controller = TextEditingController();
    final url = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Add gallery photo URL'),
      content: TextField(controller: controller, decoration: const InputDecoration(hintText: 'https://...')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('Add')),
      ],
    ));
    controller.dispose();
    if (url == null || !url.startsWith('https://')) return;
    final shop = selectedShop;
    if (shop == null) return;
    final urls = List<String>.from((shop['menu_image_urls'] is List ? shop['menu_image_urls'] : <String>[]).map((v) => v.toString()));
    if (!urls.contains(url)) urls.add(url);
    await _saveGallery(urls);
  }

  Widget _shopImage(String? source) {
    if (source == null || source.isEmpty) {
      return const ColoredBox(color: Color(0xFFFFF2D5), child: Icon(Icons.storefront_rounded));
    }
    return source.startsWith('https://')
        ? KNetImage(source, fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) => const Icon(Icons.broken_image_outlined))
        : Image.asset(source, fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) => const Icon(Icons.broken_image_outlined));
  }

  @override
  Widget build(BuildContext context) {
    final shop = selectedShop;
    final gallery = shop == null ? <String>[] : PasabuyService.shopMenuImages(shop);
    final overrides = shop?['menu_image_urls'] is List ? List<String>.from((shop!['menu_image_urls'] as List).map((e) => e.toString())) : <String>[];
    return Scaffold(
      appBar: AppBar(title: const Text('Pabili with Karlivery · Studio'), actions: [
        IconButton(onPressed: load, tooltip: 'Refresh stores', icon: const Icon(Icons.refresh_rounded)),
      ]),
      body: loading ? const Center(child: CircularProgressIndicator()) : ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: const Color(0xFFB91C1C), borderRadius: BorderRadius.circular(24),
            ),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('PABILI WITH KARLIVERY', style: TextStyle(color: Color(0xFFFFD65C), fontSize: 12, letterSpacing: 2, fontWeight: FontWeight.w700)),
              SizedBox(height: 10),
              Text('Stores & photo galleries', style: TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.w700)),
              SizedBox(height: 8),
              Text('Edit the actual customer-facing store, gallery, pickup pin and availability. Orders use typed requests—not item catalogs.', style: TextStyle(color: Colors.white70, height: 1.4)),
            ]),
          ),
          const SizedBox(height: 22),
          FilledButton.icon(onPressed: createStore, icon: const Icon(Icons.add_business_rounded), label: const Text('Add a store')),
          const SizedBox(height: 12),
          if (shops.isEmpty)
            const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('No stores available. Add a store above, or check the Supabase table permissions.')))
          else ...[
            DropdownButtonFormField<String>(
              key: ValueKey(selectedShopId),
              initialValue: selectedShopId,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'Manage restaurant', prefixIcon: Icon(Icons.storefront_outlined)),
              items: [for (final s in shops) DropdownMenuItem(value: s['id']?.toString(), child: Text(s['name']?.toString() ?? 'Store', overflow: TextOverflow.ellipsis))],
              onChanged: (v) => setState(() => selectedShopId = v),
            ),
            const SizedBox(height: 12),
            Wrap(spacing: 8, runSpacing: 8, children: [
              FilledButton.tonalIcon(onPressed: editShop, icon: const Icon(Icons.tune_rounded), label: const Text('Edit store details')),
              OutlinedButton.icon(onPressed: toggleStoreActive, icon: Icon(shop?['is_active'] == true ? Icons.visibility_off_outlined : Icons.visibility_outlined), label: Text(shop?['is_active'] == true ? 'Hide store' : 'Show store')),
            ]),
            const SizedBox(height: 16),
            Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Pickup location', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                Text(PasabuyService.townLabel(shop)),
                const SizedBox(height: 8),
                Text(PasabuyService.hasConfirmedPickup(shop) ? 'Verified store entrance pin' : 'Town-center estimate — confirm exact branch GPS before accepting orders', style: const TextStyle(color: Color(0xFF9F2929))),
              ],
            ))),
            const SizedBox(height: 18),
            Text('Store branding', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            Row(children: [
              ClipRRect(borderRadius: BorderRadius.circular(16), child: SizedBox(
                width: 72, height: 72,
                child: _shopImage(PasabuyService.shopLogoImage(shop)),
              )),
              const SizedBox(width: 10),
              Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(16), child: SizedBox(
                height: 90, child: _shopImage(PasabuyService.shopCoverImage(shop)),
              ))),
            ]),
            const SizedBox(height: 12),
            Wrap(spacing: 10, runSpacing: 8, children: [
              FilledButton.tonalIcon(onPressed: uploading ? null : () => uploadBrandPhoto('logo_url'), icon: const Icon(Icons.add_a_photo_outlined), label: const Text('Upload logo')),
              FilledButton.tonalIcon(onPressed: uploading ? null : () => uploadBrandPhoto('cover_image_url'), icon: const Icon(Icons.wallpaper_rounded), label: const Text('Upload cover')),
              if ((shop?['logo_url']?.toString() ?? '').isNotEmpty)
                OutlinedButton(onPressed: () async {
                  final current = selectedShop;
                  if (current == null) return;
                  await PasabuyService.updateShop(id: current['id'].toString(), values: {'logo_url': null});
                  await load();
                }, child: const Text('Reset logo')),
              if ((shop?['cover_image_url']?.toString() ?? '').isNotEmpty)
                OutlinedButton(onPressed: () async {
                  final current = selectedShop;
                  if (current == null) return;
                  await PasabuyService.updateShop(id: current['id'].toString(), values: {'cover_image_url': null});
                  await load();
                }, child: const Text('Reset cover')),
            ]),
            const SizedBox(height: 8),
            const Text('Logo and cover uploads replace the images displayed to customers. Store settings also accept HTTPS URLs.'),
            const SizedBox(height: 18),
            Text('Photo gallery', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            const Text('Reorder or remove photos from the customer gallery. Uploaded pictures are saved to Supabase Storage.'),
            const SizedBox(height: 12),
            Wrap(spacing: 10, runSpacing: 8, children: [
              FilledButton.icon(onPressed: uploading ? null : uploadPhotos, icon: const Icon(Icons.add_photo_alternate_outlined), label: Text(uploading ? 'Uploading…' : 'Upload photos')),
              OutlinedButton.icon(onPressed: uploading ? null : addUrl, icon: const Icon(Icons.link_rounded), label: const Text('Add image URL')),
              OutlinedButton.icon(onPressed: uploading ? null : () => _saveGallery([], useBundled: true), icon: const Icon(Icons.restart_alt_rounded), label: const Text('Use bundled images')),
              OutlinedButton.icon(onPressed: uploading ? null : () => _saveGallery([]), icon: const Icon(Icons.hide_image_outlined), label: const Text('Clear gallery')),
            ]),
            const SizedBox(height: 12),
            if (gallery.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('No gallery photos yet. Upload images to make this store ready.'))),
            for (var i = 0; i < gallery.length; i++) Card(
              child: ListTile(
                leading: ClipRRect(borderRadius: BorderRadius.circular(10), child: SizedBox(width: 58, height: 58, child: gallery[i].startsWith('https://')
                  ? KNetImage(gallery[i], fit: BoxFit.cover, errorBuilder: (context, error, stackTrace) => const Icon(Icons.broken_image_outlined))
                  : Image.asset(gallery[i], fit: BoxFit.cover, errorBuilder: (context, error, stackTrace) => const Icon(Icons.broken_image_outlined)))),
                title: Text('Photo ${i + 1}', style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(overrides.isEmpty ? 'Bundled photo (read-only)' : 'Live gallery image', maxLines: 1),
                trailing: overrides.isEmpty ? null : PopupMenuButton<String>(
                  tooltip: 'Photo options',
                  onSelected: (action) {
                    if (action == 'up' && i > 0) {
                      final a = List<String>.from(overrides); final x = a.removeAt(i); a.insert(i - 1, x); _saveGallery(a);
                    } else if (action == 'down' && i < overrides.length - 1) {
                      final a = List<String>.from(overrides); final x = a.removeAt(i); a.insert(i + 1, x); _saveGallery(a);
                    } else if (action == 'replace') {
                      replaceGalleryPhoto(i, overrides);
                    } else if (action == 'delete') {
                      final a = List<String>.from(overrides)..removeAt(i); _saveGallery(a);
                    }
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'up', child: Text('Move up')),
                    PopupMenuItem(value: 'down', child: Text('Move down')),
                    PopupMenuItem(value: 'replace', child: Text('Replace photo')),
                    PopupMenuItem(value: 'delete', child: Text('Remove photo')),
                  ],
                ),

              ),
            ),
            const SizedBox(height: 20),
            const Text('Photo removal hides the image from customers but keeps the Storage file until manually reviewed. Stores can be hidden without deleting previous orders.', style: TextStyle(fontSize: 12, color: Color(0xFF827C77))),
          ],
        ],
      ),
    );
  }
}
