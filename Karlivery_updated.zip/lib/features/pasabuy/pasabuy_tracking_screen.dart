import '../../core/smart_back.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../services/backend.dart';
import '../../services/pasabuy_service.dart';

/// Realtime Pabili tracking. GPS coordinates are obtained from the assigned
/// rider's authenticated upserts, never inferred or simulated.
class PasabuyTrackingScreen extends StatefulWidget {
  final String orderId;
  const PasabuyTrackingScreen({super.key, required this.orderId});

  @override
  State<PasabuyTrackingScreen> createState() => _PasabuyTrackingScreenState();
}

class _PasabuyTrackingScreenState extends State<PasabuyTrackingScreen> {
  final MapController _mapController = MapController();
  late final Stream<Map<String, dynamic>?> _riderStream;
  LatLng? _destination;
  String _addressLabel = '';
  String? _destinationError;
  bool _loading = true;
  bool _isAssignedRider = false;
  bool _followRider = true;
  LatLng? _previousCameraPoint;

  static const _red = Color(0xFFE51C23);

  @override
  void initState() {
    super.initState();
    _riderStream = PasabuyService.watchRiderLocation(widget.orderId);
    _loadDestination();
  }

  Future<void> _loadDestination() async {
    if (mounted) {
      setState(() {
        _loading = true;
        _destinationError = null;
      });
    }
    try {
      final result = await PasabuyService.trackingDestination(widget.orderId);
      final lat = double.tryParse(result['latitude']?.toString() ?? '');
      final lng = double.tryParse(result['longitude']?.toString() ?? '');
      if (lat == null || lng == null || lat.abs() > 90 || lng.abs() > 180) {
        throw StateError('This delivery address does not have a valid GPS pin.');
      }
      final order = await PasabuyService.orderById(widget.orderId);
      if (!mounted) return;
      setState(() {
        _destination = LatLng(lat, lng);
        _addressLabel = (result['address_label'] ?? '').toString();
        final currentUser = Backend.user?.id;
        _isAssignedRider = currentUser != null &&
            order?['rider_id']?.toString() == currentUser;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _destinationError = error.toString();
      });
    }
  }

  DateTime? _lastUpdate(dynamic value) =>
      DateTime.tryParse(value?.toString() ?? '')?.toLocal();

  String _locationStatus(dynamic value) {
    final time = _lastUpdate(value);
    if (time == null) return 'No verified GPS timestamp';
    final elapsed = DateTime.now().difference(time);
    if (elapsed.isNegative || elapsed.inSeconds < 60) return 'Updated just now';
    if (elapsed.inMinutes < 60) return 'Updated ${elapsed.inMinutes} min ago';
    return 'Updated ${elapsed.inHours} h ago';
  }

  Future<void> _navigateToCustomer() async {
    final destination = _destination;
    if (destination == null) return;
    final uri = Uri.https('www.google.com', '/maps/dir/', {
      'api': '1',
      'destination': '${destination.latitude},${destination.longitude}',
      'travelmode': 'driving',
    });
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not open directions. Install or enable a map app.')),
        );
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not open directions: $error')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          leading: const KarliveryBackButton(fallback: '/pasabuy'),
          title: const Text('Pabili live tracking'),
          actions: [
            IconButton(
              tooltip: _followRider ? 'Pause automatic map follow' : 'Follow rider on map',
              onPressed: () => setState(() { _followRider = !_followRider; _previousCameraPoint = null; }),
              icon: Icon(_followRider ? Icons.gps_fixed_rounded : Icons.gps_not_fixed_rounded),
            ),
            IconButton(
              tooltip: 'Refresh destination',
              onPressed: _loadDestination,
              icon: const Icon(Icons.refresh_rounded),
            ),
          ],
        ),
        body: StreamBuilder<Map<String, dynamic>?>(
          stream: _riderStream,
          builder: (context, snapshot) {
            final raw = snapshot.data;
            final lat = double.tryParse(raw?['latitude']?.toString() ?? '');
            final lng = double.tryParse(raw?['longitude']?.toString() ?? '');
            final rider = lat != null && lng != null &&
                    lat.abs() <= 90 && lng.abs() <= 180
                ? LatLng(lat, lng)
                : null;
            final destination = _destination;
            final updated = _lastUpdate(raw?['updated_at']);
            final stale = updated == null ||
                DateTime.now().difference(updated) > const Duration(minutes: 2);
            final center = rider != null && destination != null
                ? LatLng(
                    (rider.latitude + destination.latitude) / 2,
                    (rider.longitude + destination.longitude) / 2,
                  )
                : rider ?? destination;

            if (_followRider && rider != null && center != null &&
                (_previousCameraPoint == null ||
                    (_previousCameraPoint!.latitude - rider.latitude).abs() > 0.00004 ||
                    (_previousCameraPoint!.longitude - rider.longitude).abs() > 0.00004)) {
              _previousCameraPoint = rider;
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (!mounted || !_followRider) return;
                try { _mapController.move(center, 13.5); } catch (_) {
                  // Map may not have attached on the very first frame.
                }
              });
            }

            if (_loading && center == null) {
              return const Center(child: CircularProgressIndicator());
            }
            if (center == null) {
              return _Notice(
                icon: Icons.location_off_rounded,
                heading: 'Tracking map unavailable',
                details: _destinationError ?? (snapshot.hasError
                    ? 'Unable to read rider GPS. Check your connection and tracking permissions.'
                    : 'Waiting for the rider and delivery address GPS pins.'),
                onRetry: _loadDestination,
              );
            }

            return Column(
              children: [
                Expanded(
                  child: Stack(
                    children: [
                      FlutterMap(
                        mapController: _mapController,
                        options: MapOptions(initialCenter: center, initialZoom: 14),
                        children: [
                          TileLayer(
                            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                            userAgentPackageName: 'com.karl.karl_delivery',
                          ),
                          if (rider != null && destination != null)
                            PolylineLayer(polylines: [
                              Polyline(
                                points: [rider, destination],
                                strokeWidth: 3,
                                color: _red.withValues(alpha: .75),
                              ),
                            ]),
                          MarkerLayer(markers: [
                            if (rider != null)
                              Marker(
                                point: rider,
                                width: 60,
                                height: 60,
                                child: const _MarkerBubble(
                                  icon: Icons.delivery_dining_rounded,
                                  color: _red,
                                ),
                              ),
                            if (destination != null)
                              Marker(
                                point: destination,
                                width: 60,
                                height: 60,
                                child: const _MarkerBubble(
                                  icon: Icons.home_rounded,
                                  color: Color(0xFF7A0E18),
                                ),
                              ),
                          ]),
                          const RichAttributionWidget(
                            attributions: [TextSourceAttribution('OpenStreetMap contributors')],
                          ),
                        ],
                      ),
                      Positioned(
                        right: 12,
                        top: 12,
                        child: FloatingActionButton.small(
                          heroTag: 'pabili_center_${widget.orderId}',
                          tooltip: 'Center map',
                          onPressed: () => _mapController.move(center, 14),
                          child: const Icon(Icons.center_focus_strong_rounded),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.fromLTRB(18, 14, 18, 20),
                  decoration: BoxDecoration(color: Theme.of(context).colorScheme.surface),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(children: [
                        Icon(
                          snapshot.hasError ? Icons.error_outline_rounded
                              : rider == null ? Icons.location_searching_rounded
                              : stale ? Icons.sync_problem_rounded : Icons.radar_rounded,
                          color: snapshot.hasError || stale ? Colors.orange.shade800 : _red,
                        ),
                        const SizedBox(width: 9),
                        Expanded(
                          child: Text(
                            snapshot.hasError
                                ? 'Unable to load live rider GPS'
                                : rider == null
                                    ? 'Waiting for rider to share location'
                                    : stale ? 'Rider GPS is delayed' : 'Rider location available',
                            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
                          ),
                        ),
                      ]),
                      const SizedBox(height: 6),
                      if (rider != null)
                        Text(_locationStatus(raw?['updated_at']))
                      else
                        const Text('Rider must accept the order, enable precise location, and keep Karlivery open. Updates refresh about every 12 seconds while this map is open.'),
                      if (_addressLabel.isNotEmpty) ...[
                        const SizedBox(height: 7),
                        Text('Customer destination: $_addressLabel'),
                      ],
                      if (_destinationError != null) ...[
                        const SizedBox(height: 7),
                        Text('Destination issue: $_destinationError',
                            style: const TextStyle(color: Colors.deepOrange)),
                      ],
                      if (snapshot.hasError) ...[
                        const SizedBox(height: 7),
                        const Text('Check Supabase tracking permissions and Realtime, then reopen this map.',
                            style: TextStyle(color: Colors.deepOrange)),
                      ],
                      if (rider != null && destination != null) ...[
                        const SizedBox(height: 8),
                        const Text('Map follows the latest GPS point. The line is direct distance, not a driving route.'),
                      ],
                      if (_isAssignedRider && destination != null) ...[
                        const SizedBox(height: 10),
                        FilledButton.icon(
                          onPressed: _navigateToCustomer,
                          icon: const Icon(Icons.directions_rounded),
                          label: const Text('Navigate to customer'),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      );
}

class _Notice extends StatelessWidget {
  const _Notice({
    required this.icon,
    required this.heading,
    required this.details,
    required this.onRetry,
  });
  final IconData icon;
  final String heading;
  final String details;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 58, color: const Color(0xFFE51C23)),
            const SizedBox(height: 12),
            Text(heading, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text(details, textAlign: TextAlign.center),
            const SizedBox(height: 14),
            OutlinedButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('Retry'),
            ),
          ]),
        ),
      );
}

class _MarkerBubble extends StatelessWidget {
  final IconData icon;
  final Color color;
  const _MarkerBubble({required this.icon, required this.color});

  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white,
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .18), blurRadius: 12)],
        ),
        child: Icon(icon, color: color, size: 34),
      );
}
