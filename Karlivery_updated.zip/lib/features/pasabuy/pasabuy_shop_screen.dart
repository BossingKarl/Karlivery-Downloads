import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/smart_back.dart';

import '../../services/pasabuy_cart.dart';
import '../../services/pasabuy_service.dart';
import '../../design_system/k_network_image.dart';

class PasabuyShopScreen extends StatefulWidget {
  final String shopId;
  const PasabuyShopScreen({super.key, required this.shopId});

  @override
  State<PasabuyShopScreen> createState() => _PasabuyShopScreenState();
}

class _PasabuyShopScreenState extends State<PasabuyShopScreen> {
  Map<String, dynamic>? shop;
  bool loading = true;
  String? loadError;

  final requestController = TextEditingController();
  final amountController = TextEditingController();
  final storeNameController = TextEditingController();
  final storeLocationController = TextEditingController();

  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  void dispose() {
    requestController.dispose();
    amountController.dispose();
    storeNameController.dispose();
    storeLocationController.dispose();
    super.dispose();
  }

  Future<void> load() async {
    if (mounted) {
      setState(() {
      loading = true;
      loadError = null;
      });
    }
    try {
      shop = await PasabuyService.shopById(widget.shopId);
      if (shop == null) { loadError = 'This Pabili shop is unavailable right now.'; }
      _loadDraftFromCart();
    } catch (_) {
      loadError = 'Unable to load this Pabili shop. Check your connection and retry.';
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  bool get _isOtherStore => widget.shopId == 'pasabuy-other-store';

  void _loadDraftFromCart() {
    final cart = PasabuyCartService.instance;
    if (cart.shopId != widget.shopId && !(_isOtherStore && cart.shopId == widget.shopId)) return;

    if (_isOtherStore) {
      final raw = cart.customRequest.trim();
      if (raw.startsWith('STORE:')) {
        final parts = raw.split('|');
        if (parts.length >= 3) {
          storeNameController.text = parts[0].replaceFirst('STORE:', '').trim();
          storeLocationController.text = parts[1].replaceFirst('LOCATION:', '').trim();
          requestController.text = parts.sublist(2).join('|').replaceFirst('BUY:', '').trim();
        }
      }
    } else {
      requestController.text = cart.customRequest;
    }
    amountController.text = cart.customRequestAmount > 0 ? cart.customRequestAmount.toStringAsFixed(0) : '';
  }

  @override
  Widget build(BuildContext context) {
    final menuPhotos = PasabuyService.shopMenuImages(shop);

    return Scaffold(
      appBar: AppBar(
        leading: const KarliveryBackButton(fallback: '/pasabuy'),
        title: Text(shop?['name']?.toString() ?? 'Pabili store'),
        actions: [
          IconButton(
            tooltip: 'Basket',
            onPressed: () => context.push('/pasabuy/checkout'),
            icon: AnimatedBuilder(
              animation: PasabuyCartService.instance,
              builder: (_, _) => Badge(
                isLabelVisible: PasabuyCartService.instance.count > 0,
                label: Text('${PasabuyCartService.instance.count}'),
                child: const Icon(Icons.shopping_bag_outlined),
              ),
            ),
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : loadError != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.wifi_off_rounded, size: 44),
                        const SizedBox(height: 12),
                        Text(loadError!, textAlign: TextAlign.center),
                        const SizedBox(height: 16),
                        FilledButton.icon(
                          onPressed: load,
                          icon: const Icon(Icons.refresh_rounded),
                          label: const Text('Try again'),
                        ),
                      ],
                    ),
                  ),
                )
              : RefreshIndicator(
              onRefresh: load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 26),
                children: [
                  if (shop != null) _ShopHero(shop: shop!),
                  const SizedBox(height: 16),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'How photo-menu ordering works',
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                          ),
                          const SizedBox(height: 10),
                          const _StepRow(number: '1', text: 'Choose a restaurant and browse its photos.'),
                          const _StepRow(number: '2', text: 'Type what to buy, then review your basket and fees.'),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  if (menuPhotos.isNotEmpty) ...[
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            'Menu photos',
                            style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700),
                          ),
                        ),
                        TextButton.icon(
                          onPressed: () => _openGallery(menuPhotos, initialIndex: 0),
                          icon: const Icon(Icons.open_in_full_rounded),
                          label: const Text('View all'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    SizedBox(
                      height: 200,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        itemCount: menuPhotos.length,
                        separatorBuilder: (_, _) => const SizedBox(width: 12),
                        itemBuilder: (context, index) {
                          final path = menuPhotos[index];
                          return _MenuPreviewCard(
                            imagePath: path,
                            index: index,
                            total: menuPhotos.length,
                            onTap: () => _openGallery(menuPhotos, initialIndex: index),
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Use the store photo gallery as a guide. Final item availability and prices are confirmed by the rider. Queue times may vary.',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                    const SizedBox(height: 16),
                  ],
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  _isOtherStore ? 'Type your custom store order' : 'Type your order for the rider',
                                  style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                                ),
                              ),
                              TextButton.icon(
                                onPressed: _fillSample,
                                icon: const Icon(Icons.auto_awesome_outlined),
                                label: const Text('Sample'),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            _isOtherStore
                                ? 'Use this if the store is not yet listed in Karlivery. Include the exact store and location so the rider knows where to go.'
                                : 'Instead of tapping dozens of buttons, just type the exact items you want after checking the menu photos.',
                          ),
                          const SizedBox(height: 14),
                          if (_isOtherStore) ...[
                            TextField(
                              controller: storeNameController,
                              decoration: const InputDecoration(
                                labelText: 'Store name',
                                hintText: 'Example: McDo Mangatarem or any local branch',
                              ),
                            ),
                            const SizedBox(height: 12),
                            TextField(
                              controller: storeLocationController,
                              decoration: const InputDecoration(
                                labelText: 'Store location / landmark',
                                hintText: 'Street, town or nearby landmark',
                              ),
                            ),
                            const SizedBox(height: 12),
                          ],
                          TextField(
                            controller: requestController,
                            minLines: 4,
                            maxLines: 7,
                            decoration: const InputDecoration(
                              labelText: 'Typed order',
                              hintText: 'Example: 2x C1 Chickenjoy spicy, 1 peach mango pie, 1 medium iced tea, extra gravy if available',
                              alignLabelWithHint: true,
                            ),
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            controller: amountController,
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                            decoration: const InputDecoration(
                              labelText: 'Estimated item amount',
                              prefixText: '₱ ',
                              hintText: 'Optional but recommended',
                            ),
                          ),
                          const SizedBox(height: 14),
                          Row(
                            children: [
                              Expanded(
                                child: OutlinedButton.icon(
                                  onPressed: _clearComposer,
                                  icon: const Icon(Icons.restart_alt_rounded),
                                  label: const Text('Clear'),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                flex: 2,
                                child: FilledButton.icon(
                                  onPressed: _saveRequest,
                                  icon: const Icon(Icons.shopping_bag_rounded),
                                  label: const Text('Save to basket'),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  AnimatedBuilder(
                    animation: PasabuyCartService.instance,
                    builder: (_, _) {
                      final cart = PasabuyCartService.instance;
                      if (cart.customRequest.trim().isEmpty) return const SizedBox.shrink();
                      return Card(
                        color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: .3),
                        child: ListTile(
                          leading: const CircleAvatar(child: Icon(Icons.check_rounded)),
                          title: const Text('Current typed order saved', style: TextStyle(fontWeight: FontWeight.w700)),
                          subtitle: Text(
                            cart.customRequest,
                            maxLines: 4,
                            overflow: TextOverflow.ellipsis,
                          ),
                          trailing: Text('₱${cart.customRequestAmount.toStringAsFixed(0)}'),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 16),
                  Card(
                    child: ListTile(
                      leading: const CircleAvatar(child: Icon(Icons.local_shipping_outlined)),
                      title: const Text('Pabili delivery fee guide', style: TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: const Text('First 3 km ₱50, then +₱15 per additional started 2 km, plus ₱20 handling. Delivery fee requires confirmed store and customer GPS pins; no fixed arrival time.'),
                    ),
                  ),
                ],
              ),
            ),
      bottomNavigationBar: AnimatedBuilder(
        animation: PasabuyCartService.instance,
        builder: (_, _) {
          final cart = PasabuyCartService.instance;
          if (cart.lines.isEmpty && cart.customRequest.trim().isEmpty) return const SizedBox.shrink();
          return SafeArea(
            minimum: const EdgeInsets.fromLTRB(16, 0, 16, 14),
            child: FilledButton.icon(
              style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16)),
              onPressed: () => context.push('/pasabuy/checkout'),
              icon: const Icon(Icons.shopping_bag_rounded),
              label: Text('Review basket • ${cart.count} saved entr${cart.count == 1 ? 'y' : 'ies'}'),
            ),
          );
        },
      ),
    );
  }

  void _fillSample() {
    if (_isOtherStore) {
      storeNameController.text = storeNameController.text.trim().isEmpty ? 'Sample Store Name' : storeNameController.text;
      storeLocationController.text = storeLocationController.text.trim().isEmpty ? 'Town proper / landmark' : storeLocationController.text;
    }
    requestController.text = '1 chicken meal, 1 fries, 1 float, less ice if available';
    amountController.text = amountController.text.trim().isEmpty ? '250' : amountController.text;
    setState(() {});
  }

  void _clearComposer() {
    requestController.clear();
    amountController.clear();
    if (_isOtherStore) {
      storeNameController.clear();
      storeLocationController.clear();
    }
    setState(() {});
  }

  Future<void> _saveRequest() async {
    final request = requestController.text.trim();
    if (request.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please type the order first.')));
      return;
    }
    if (_isOtherStore && (storeNameController.text.trim().isEmpty || storeLocationController.text.trim().isEmpty)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please enter the custom store name and location.')));
      return;
    }

    final cart = PasabuyCartService.instance;
    if (shop == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Shop details are unavailable. Please reload before saving.')),
      );
      return;
    }
    if (!cart.isEmpty && cart.shopId != widget.shopId) {
      final replace = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Replace your Pabili request?'),
          content: Text(
            'You still have a request for ${cart.shopName ?? 'another shop'}. '
            'Saving this request will replace that basket.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Keep request'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Replace request'),
            ),
          ],
        ),
      );
      if (!mounted || replace != true) return;
      cart.clear();
    }
    cart.setShop(shop!);
    final builtRequest = _isOtherStore
        ? 'STORE: ${storeNameController.text.trim()} | LOCATION: ${storeLocationController.text.trim()} | BUY: $request'
        : request;
    cart.setCustomRequest(builtRequest);
    cart.setCustomRequestAmount(double.tryParse(amountController.text.trim()) ?? 0);

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Typed order saved to your pasabuy basket.')),
    );
    setState(() {});
  }

  Future<void> _openGallery(List<String> images, {required int initialIndex}) async {
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (context) => Dialog.fullscreen(
        child: _GalleryViewer(images: images, initialIndex: initialIndex),
      ),
    );
  }
}

class _ShopHero extends StatelessWidget {
  final Map<String, dynamic> shop;
  const _ShopHero({required this.shop});

  @override
  Widget build(BuildContext context) {
    final cover = PasabuyService.shopCoverImage(shop);
    final logoImage = PasabuyService.shopLogoImage(shop);
    return Container(
      height: 240,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        color: Colors.black,
      ),
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (cover != null) _SmartImage(path: cover, fit: BoxFit.cover),
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.bottomLeft,
                end: Alignment.topRight,
                colors: [Color(0xD9000000), Color(0x55000000)],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 62,
                      height: 62,
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(18),
                      ),
                      clipBehavior: Clip.antiAlias,
                      child: logoImage != null ? _SmartImage(path: logoImage, fit: BoxFit.contain) : const Icon(Icons.storefront_rounded),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: .18),
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: Colors.white24),
                      ),
                      child: const Text(
                        'Karlivery photo menu',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                Text(
                  shop['name']?.toString() ?? 'Pabili store',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                      ),
                ),
                const SizedBox(height: 6),
                Text(
                  shop['description']?.toString() ?? '',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, height: 1.35),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _HeroChip(icon: Icons.place_outlined, label: PasabuyService.townLabel(shop)),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _HeroChip extends StatelessWidget {
  final IconData icon;
  final String label;
  const _HeroChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    if (label.trim().isEmpty) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: .16),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.white24),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 15, color: Colors.white),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(color: Colors.white)),
        ],
      ),
    );
  }
}

class _StepRow extends StatelessWidget {
  final String number;
  final String text;
  const _StepRow({required this.number, required this.text});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(radius: 14, child: Text(number, style: const TextStyle(fontWeight: FontWeight.w700))),
            const SizedBox(width: 10),
            Expanded(child: Text(text)),
          ],
        ),
      );
}

class _MenuPreviewCard extends StatelessWidget {
  final String imagePath;
  final int index;
  final int total;
  final VoidCallback onTap;
  const _MenuPreviewCard({required this.imagePath, required this.index, required this.total, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(24),
      onTap: onTap,
      child: Ink(
        width: 160,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          color: Theme.of(context).colorScheme.surface,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: .08),
              blurRadius: 18,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
                child: _SmartImage(path: imagePath, fit: BoxFit.cover),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: Text('Photo ${index + 1} of $total', style: const TextStyle(fontWeight: FontWeight.w700)),
                  ),
                  const Icon(Icons.zoom_in_rounded),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GalleryViewer extends StatefulWidget {
  final List<String> images;
  final int initialIndex;
  const _GalleryViewer({required this.images, required this.initialIndex});

  @override
  State<_GalleryViewer> createState() => _GalleryViewerState();
}

class _GalleryViewerState extends State<_GalleryViewer> {
  late final PageController controller;
  late int index;

  @override
  void initState() {
    super.initState();
    index = widget.initialIndex;
    controller = PageController(initialPage: widget.initialIndex);
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text('Menu photo ${index + 1} / ${widget.images.length}'),
      ),
      body: PageView.builder(
        controller: controller,
        itemCount: widget.images.length,
        onPageChanged: (value) => setState(() => index = value),
        itemBuilder: (_, i) => InteractiveViewer(
          minScale: 0.8,
          maxScale: 4,
          child: Center(
            child: _SmartImage(path: widget.images[i], fit: BoxFit.contain),
          ),
        ),
      ),
    );
  }
}

class _SmartImage extends StatelessWidget {
  final String path;
  final BoxFit fit;
  const _SmartImage({required this.path, this.fit = BoxFit.cover});

  @override
  Widget build(BuildContext context) {
    if (path.startsWith('https://')) {
      return KNetImage(path, fit: fit, errorBuilder: (context, error, stackTrace) => const ColoredBox(color: Colors.black12, child: Center(child: Icon(Icons.image_not_supported_outlined))));
    }
    return Image.asset(path, fit: fit, errorBuilder: (context, error, stackTrace) => const ColoredBox(color: Colors.black12, child: Center(child: Icon(Icons.image_not_supported_outlined))));
  }
}
