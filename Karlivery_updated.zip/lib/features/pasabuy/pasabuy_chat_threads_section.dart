import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../services/pasabuy_service.dart';

/// Standalone Pabili inbox section used by customer and rider Messages tabs.
/// Regular food-order threads continue to use their existing message system.
class PasabuyChatThreadsSection extends StatefulWidget {
  final bool forRider;
  const PasabuyChatThreadsSection({super.key, required this.forRider});

  @override
  State<PasabuyChatThreadsSection> createState() =>
      _PasabuyChatThreadsSectionState();
}

class _PasabuyChatThreadsSectionState extends State<PasabuyChatThreadsSection> {
  late Future<List<Map<String, dynamic>>> future;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  void _reload() {
    future = PasabuyService.pabiliChatOrders(forRider: widget.forRider);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 20),
        Row(
          children: [
            const Icon(Icons.shopping_bag_outlined, color: Color(0xFFE51C23)),
            const SizedBox(width: 9),
            Expanded(
              child: Text('Pabili with Karlivery', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
            ),
            IconButton(
              onPressed: () => setState(_reload),
              tooltip: 'Refresh Pabili conversations',
              icon: const Icon(Icons.refresh_rounded),
            ),
          ],
        ),
        const SizedBox(height: 5),
        Text(
          widget.forRider ? 'Customers who assigned you a Pabili order' : 'Message the rider handling your Pabili order',
          style: theme.textTheme.bodySmall,
        ),
        const SizedBox(height: 10),
        FutureBuilder<List<Map<String, dynamic>>>(
          future: future,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Padding(
                padding: EdgeInsets.all(14),
                child: Center(child: CircularProgressIndicator()),
              );
            }
            if (snapshot.hasError) {
              return Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Could not load Pabili conversations.'),
                      const SizedBox(height: 6),
                      SelectableText('${snapshot.error}'),
                      TextButton(onPressed: () => setState(_reload), child: const Text('Retry')),
                    ],
                  ),
                ),
              );
            }
            final orders = snapshot.data ?? const <Map<String, dynamic>>[];
            if (orders.isEmpty) {
              return const Card(
                child: ListTile(
                  leading: Icon(Icons.chat_bubble_outline_rounded),
                  title: Text('No Pabili conversations yet'),
                  subtitle: Text('Chat becomes available when a rider accepts a Pabili order.'),
                ),
              );
            }
            return Column(
              children: orders.map((order) {
                final id = order['id']?.toString() ?? '';
                final status = order['status']?.toString() ?? 'Pabili order';
                final shop = order['pasabuy_shops'];
                final shopName = shop is Map ? (shop['name']?.toString() ?? 'Pabili store') : 'Pabili store';
                final assigned = order['rider_id'] != null;
                final enabled = assigned && id.isNotEmpty;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Card(
                    child: ListTile(
                      onTap: enabled ? () => context.push('/pasabuy/chat/$id') : null,
                      leading: const CircleAvatar(
                        backgroundColor: Color(0xFFFFF4D6),
                        child: Icon(Icons.mark_chat_unread_outlined, color: Color(0xFFE51C23)),
                      ),
                      title: Text(shopName, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text(assigned ? 'Pabili • $status' : 'Waiting for an assigned rider'),
                      trailing: Icon(enabled ? Icons.chevron_right_rounded : Icons.lock_clock_outlined),
                    ),
                  ),
                );
              }).toList(),
            );
          },
        ),
      ],
    );
  }
}
