import 'dart:async';

import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'hydration_card.dart';
import 'package:geolocator/geolocator.dart';
import 'package:go_router/go_router.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/brand.dart';
import '../../core/modern_ui.dart';
import '../../core/role_panels.dart';
import '../../core/nova_headline.dart';
import '../../core/utils.dart';
import '../../services/backend.dart';
import '../../services/integration_service.dart';
import '../../services/pasabuy_service.dart';
import '../../services/pasabuy_gps_session.dart';
import '../../services/theme_controller.dart';
import '../../theme/app_theme.dart';
import '../shared/notification_center_screen.dart';
import '../shared/change_password_dialog.dart';
import '../pasabuy/pasabuy_chat_threads_section.dart';
import '../../design_system/k_network_image.dart';

class RiderDashboard extends StatefulWidget {
  const RiderDashboard({super.key});

  @override
  State<RiderDashboard> createState() => _RiderDashboardState();
}

class _RiderDashboardState extends State<RiderDashboard> {
  int tab = 0;
  bool online = false;
  bool loading = true;
  List<Map<String, dynamic>> available = [];
  List<Map<String, dynamic>> assigned = [];
  List<Map<String, dynamic>> pasabuyAvailable = [];
  List<Map<String, dynamic>> pasabuyAssigned = [];
  String? trackingOrderId;
  String? trackingPasabuyOrderId;
  StreamSubscription<Position>? trackingSub;
  final _gps = PasabuyGpsSession.instance;

  @override
  void initState() {
    super.initState();
    trackingPasabuyOrderId = _gps.orderId;
    _gps.addListener(_syncGps);
    load();
  }

  @override
  void dispose() {
    trackingSub?.cancel();
    _gps.removeListener(_syncGps);
    super.dispose();
  }

  Future<void> load() async {
    if (mounted) setState(() => loading = true);
    try {
      final result = await Future.wait([
        Backend.riderAvailableOrders(),
        Backend.riderAssignedOrders(),
        PasabuyService.riderAvailableOrders(),
        PasabuyService.riderAssignedOrders(),
        Backend.myProfile(),
      ]);
      available = result[0] as List<Map<String, dynamic>>;
      assigned = result[1] as List<Map<String, dynamic>>;
      pasabuyAvailable = result[2] as List<Map<String, dynamic>>;
      pasabuyAssigned = result[3] as List<Map<String, dynamic>>;
      final profile = result[4] as Map<String, dynamic>?;
      online = profile?['is_online'] == true;
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not load rider dashboard: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<bool> _ensureLocationPermission() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Turn on device location first.')),
        );
      }
      return false;
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Location permission is required for live tracking.'),
          ),
        );
      }
      return false;
    }
    return true;
  }

  Future<void> startTracking(String orderId) async {
    if (!await _ensureLocationPermission()) return;
    await trackingSub?.cancel();
    if (mounted) setState(() => trackingOrderId = orderId);

    const settings = LocationSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 10,
    );

    trackingSub = Geolocator.getPositionStream(
      locationSettings: settings,
    ).listen((p) async {
      try {
        await Backend.updateRiderLocation(
          orderId: orderId,
          latitude: p.latitude,
          longitude: p.longitude,
          heading: p.heading,
          speed: p.speed,
        );
      } catch (_) {
        // A temporary network failure should not kill the rider UI.
      }
    });
  }

  Future<void> stopTracking() async {
    await trackingSub?.cancel();
    trackingSub = null;
    if (mounted) setState(() => trackingOrderId = null);
  }

  void _syncGps() {
    if (mounted) setState(() => trackingPasabuyOrderId = _gps.orderId);
  }

  Future<void> startPasabuyTracking(String orderId) async {
    try {
      await _gps.start(orderId);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Live GPS sharing active. Keep Karlivery open while delivering.')),
        );
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Cannot share Pabili location: $error')),
        );
      }
    }
  }

  Future<void> stopPasabuyTracking() async {
    await _gps.stop();
  }

  Future<void> claimPasabuy(String id) async {
    try {
      await PasabuyService.claimOrder(id);
      await load();
      await startPasabuyTracking(id);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Cannot claim Pabili order: $e')),
        );
      }
    }
  }

  Future<void> updatePasabuyStatus(String id, String status) async {
    try {
      // KARLIVERY_NO_EMAIL_RECEIPTS_2026
      await PasabuyService.updateStatus(id, status);
      if (status == 'Delivered' && trackingPasabuyOrderId == id) {
        await stopPasabuyTracking();
      }
      await load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Cannot update Pabili order: $e')),
        );
      }
    }
  }

  Future<void> setOnline(bool value) async {
    try {
      await Backend.setRiderOnline(value);
      if (!value) {
        await stopTracking();
        await stopPasabuyTracking();
      }
      if (mounted) setState(() => online = value);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Availability update failed: $e')),
        );
      }
    }
  }

  Future<void> claim(String id) async {
    try {
      await Backend.claimOrder(id);
      await load();
      await startTracking(id);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Cannot claim order: $e')),
        );
      }
    }
  }

  Future<void> updateStatus(String id, String status) async {
    try {
      await Backend.riderStatus(id, status);

      if (status == 'delivered' && trackingOrderId == id) {
        await stopTracking();
      }
      await load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Cannot update order: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _RiderHome(
        online: online,
        loading: loading,
        available: available,
        assigned: assigned,
        pasabuyAvailable: pasabuyAvailable,
        pasabuyAssigned: pasabuyAssigned,
        trackingOrderId: trackingOrderId,
        trackingPasabuyOrderId: trackingPasabuyOrderId,
        onOnline: setOnline,
        onRefresh: load,
        onClaim: claim,
        onTrack: (id) => trackingOrderId == id
            ? stopTracking()
            : startTracking(id),
        onStatus: updateStatus,
        onPasabuyClaim: claimPasabuy,
        onPasabuyTrack: (id) => trackingPasabuyOrderId == id
            ? stopPasabuyTracking()
            : startPasabuyTracking(id),
        onPasabuyStatus: updatePasabuyStatus,
      ),
      const _RiderMessagesTab(),
      const _RiderHistoryTab(),
      _RiderAccountTab(
        online: online,
        onSignOut: () async {
          await stopTracking();
          await stopPasabuyTracking();
          await Backend.logout();
          if (context.mounted) context.go('/login');
        },
      ),
    ];

    return KDashboardScaffold(
      appBar: AppBar(
        toolbarHeight: 68,
        titleSpacing: 10,
        title: MediaQuery.sizeOf(context).width < 520
            ? const KarliveryMark(size: 40)
            : const KarliveryWordmark(compact: true),
        actions: MediaQuery.sizeOf(context).width < 520
            ? [
                const NotificationBell(),
                PopupMenuButton<String>(
                  tooltip: 'More',
                  onSelected: (value) async {
                    if (value == 'help') {
                      if (context.mounted) context.push('/help?role=rider');
                    } else if (value == 'refresh') {
                      await load();
                    }
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(
                      value: 'help',
                      child: ListTile(
                        leading: Icon(Icons.help_outline_rounded),
                        title: Text('Help'),
                        contentPadding: EdgeInsets.zero,
                      ),
                    ),
                    PopupMenuItem(
                      value: 'refresh',
                      child: ListTile(
                        leading: Icon(Icons.refresh_rounded),
                        title: Text('Refresh'),
                        contentPadding: EdgeInsets.zero,
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: 4),
              ]
            : [
                IconButton(
                  tooltip: 'Help',
                  onPressed: () => context.push('/help?role=rider'),
                  icon: const Icon(Icons.help_outline_rounded),
                ),
                const NotificationBell(),
                if (tab == 0)
                  IconButton(
                    tooltip: 'Refresh',
                    onPressed: load,
                    icon: const Icon(Icons.refresh_rounded),
                  ),
                const SizedBox(width: 6),
              ],
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1100),
          child: IndexedStack(index: tab, children: pages),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.two_wheeler_outlined),
            selectedIcon: Icon(Icons.two_wheeler_rounded),
            label: 'Deliveries',
          ),
          NavigationDestination(
            icon: Icon(Icons.chat_bubble_outline_rounded),
            selectedIcon: Icon(Icons.chat_bubble_rounded),
            label: 'Messages',
          ),
          NavigationDestination(
            icon: Icon(Icons.archive_outlined),
            selectedIcon: Icon(Icons.archive_rounded),
            label: 'History',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline_rounded),
            selectedIcon: Icon(Icons.person_rounded),
            label: 'Account',
          ),
        ],
      ),
    );
  }
}

class _RiderHome extends StatelessWidget {
  final bool online;
  final bool loading;
  final List<Map<String, dynamic>> available;
  final List<Map<String, dynamic>> assigned;
  final List<Map<String, dynamic>> pasabuyAvailable;
  final List<Map<String, dynamic>> pasabuyAssigned;
  final String? trackingOrderId;
  final String? trackingPasabuyOrderId;
  final Future<void> Function(bool) onOnline;
  final Future<void> Function() onRefresh;
  final Future<void> Function(String) onClaim;
  final Future<void> Function(String) onTrack;
  final Future<void> Function(String, String) onStatus;
  final Future<void> Function(String) onPasabuyClaim;
  final Future<void> Function(String) onPasabuyTrack;
  final Future<void> Function(String, String) onPasabuyStatus;

  const _RiderHome({
    required this.online,
    required this.loading,
    required this.available,
    required this.assigned,
    required this.pasabuyAvailable,
    required this.pasabuyAssigned,
    required this.trackingOrderId,
    required this.trackingPasabuyOrderId,
    required this.onOnline,
    required this.onRefresh,
    required this.onClaim,
    required this.onTrack,
    required this.onStatus,
    required this.onPasabuyClaim,
    required this.onPasabuyTrack,
    required this.onPasabuyStatus,
  });

  @override
  Widget build(BuildContext context) => SafeArea(
        child: RefreshIndicator(
          onRefresh: onRefresh,
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 110),
            children: [
              NovaHeadline(
                eyebrow: 'KARLIVERY / RIDER',
                title: online ? 'Ready for the next delivery?' : 'Your shift, your pace.',
                subtitle: online
                    ? 'Your route, requests, live location and customers in one place.'
                    : 'Switch online when you are ready to take new requests.',
                icon: Icons.two_wheeler_rounded,
                trailing: Switch(
                  value: online,
                  onChanged: loading ? null : onOnline,
                ),
              ),
              const SizedBox(height: 14),
              AnimatedBuilder(
                animation: PasabuyGpsSession.instance,
                builder: (context, _) {
                  final gps = PasabuyGpsSession.instance;
                  return KWorkspaceUpdateStrip(
                    icon: gps.lastError != null ? Icons.sync_problem_rounded
                        : gps.orderId != null ? Icons.my_location_rounded : Icons.route_rounded,
                    title: gps.lastError != null ? 'GPS needs attention'
                        : gps.orderId != null ? 'Pabili location sharing' : 'Live delivery tools',
                    subtitle: gps.lastError != null ? gps.lastError!
                        : gps.orderId != null
                            ? 'Sharing with this order while Karlivery remains open.'
                            : 'Share location after accepting a Pabili job. Chat and Maps are one tap away.',
                  );
                },
              ),
              const SizedBox(height: 12),
              const RiderHydrationCard(),
              const SizedBox(height: 14),
              _RiderNextAction(
                online: online,
                assigned: assigned,
                available: available,
                onOnline: onOnline,
                onClaim: onClaim,
                onStatus: onStatus,
              ),
              const SizedBox(height: 14),
              KMetricGrid(children: [
                KMetricCard(label: 'Active deliveries', value: '${assigned.length + pasabuyAssigned.length}', icon: Icons.route_outlined),
                KMetricCard(label: 'Ready to claim', value: '${available.length + pasabuyAvailable.length}', icon: Icons.inventory_2_outlined, accent: const Color(0xFF087E93)),
              ]),
              const SizedBox(height: 24),
              KSectionTitle(
                title: 'My active deliveries',
                subtitle: 'Your claimed orders and delivery actions',
                trailing: KStatusPill(
                  text: '${assigned.length}',
                  color: AppTheme.red,
                  icon: Icons.delivery_dining_rounded,
                ),
              ),
              const SizedBox(height: 10),
              if (loading && assigned.isEmpty)
                const KLoadingState(message: 'Checking delivery queue…')
              else if (assigned.isEmpty)
                const KEmptyState(
                  icon: Icons.route_outlined,
                  title: 'No active delivery',
                  subtitle: 'Claim a ready order below when you are online.',
                )
              else
                ...assigned.map(
                  (o) => Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: _ActiveDeliveryCard(
                      order: o,
                      tracking: trackingOrderId == o['id'].toString(),
                      onTrack: onTrack,
                      onStatus: onStatus,
                      onRefresh: onRefresh,
                    ),
                  ),
                ),
              const SizedBox(height: 24),
              KSectionTitle(
                title: 'Pabili with Karlivery',
                subtitle: 'Buy-request jobs with customer chat, rider GCash and live tracking',
                trailing: KStatusPill(
                  text: '${pasabuyAssigned.length + pasabuyAvailable.length}',
                  color: const Color(0xFFE5A000),
                  icon: Icons.shopping_bag_rounded,
                ),
              ),
              const SizedBox(height: 10),
              if (pasabuyAssigned.isEmpty && pasabuyAvailable.isEmpty)
                const KEmptyState(
                  icon: Icons.shopping_bag_outlined,
                  title: 'No Pabili requests right now',
                  subtitle: 'New Pabili jobs will appear when customers place requests.',
                )
              else ...[
                for (final o in pasabuyAssigned)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: _ActivePasabuyCard(
                      order: o,
                      tracking: trackingPasabuyOrderId == o['id'].toString(),
                      onTrack: onPasabuyTrack,
                      onStatus: onPasabuyStatus,
                      onRefresh: onRefresh,
                    ),
                  ),
                if (online)
                  for (final o in pasabuyAvailable)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: _PasabuyClaimCard(order: o, onClaim: onPasabuyClaim),
                    ),
              ],
              const SizedBox(height: 24),
              KSectionTitle(
                title: 'Available to claim',

                subtitle: online
                    ? 'Ready orders waiting for a rider'
                    : 'Go online to claim new orders',
                trailing: KStatusPill(
                  text: '${available.length}',
                  color: online ? const Color(0xFF2E9D63) : AppTheme.muted,
                ),
              ),
              const SizedBox(height: 10),
              if (!online)
                const KEmptyState(
                  icon: Icons.power_settings_new_rounded,
                  title: 'Offline mode',
                  subtitle: 'Turn on availability above to claim new orders.',
                )
              else if (available.isEmpty)
                const KEmptyState(
                  icon: Icons.hourglass_empty_rounded,
                  title: 'No ready orders',
                  subtitle: 'New delivery requests will appear here when stores mark orders ready.',
                )
              else
                ...available.map(
                  (o) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: _ClaimCard(order: o, onClaim: onClaim),
                  ),
                ),
            ],
          ),
        ),
      );
}

class _RiderNextAction extends StatelessWidget {
  final bool online;
  final List<Map<String, dynamic>> assigned;
  final List<Map<String, dynamic>> available;
  final Future<void> Function(bool) onOnline;
  final Future<void> Function(String) onClaim;
  final Future<void> Function(String, String) onStatus;

  const _RiderNextAction({
    required this.online,
    required this.assigned,
    required this.available,
    required this.onOnline,
    required this.onClaim,
    required this.onStatus,
  });

  @override
  Widget build(BuildContext context) {
    IconData icon = Icons.check_circle_rounded;
    String title = 'You are all caught up';
    String message = 'Stay online if you want new ready orders to appear here.';
    String? action;
    VoidCallback? tap;

    if (!online) {
      icon = Icons.power_settings_new_rounded;
      title = 'Go online when you are ready';
      message = 'Karlivery will only let you claim new deliveries while your rider availability is online.';
      action = 'Go online';
      tap = () { onOnline(true); };
    } else if (assigned.isNotEmpty) {
      final order = assigned.first;
      final id = order['id'].toString();
      final status = (order['status'] ?? '').toString();
      if (status == 'assigned') {
        icon = Icons.storefront_rounded;
        title = 'Pick up ${order['order_no'] ?? 'your active order'}';
        message = 'Confirm the order with the restaurant, then mark it Picked up before leaving.';
        action = 'Mark picked up';
        tap = () { onStatus(id, 'picked_up'); };
      } else if (status == 'picked_up') {
        icon = Icons.route_rounded;
        title = 'Start the delivery';
        message = 'When you leave the store, update the order so the customer knows you are on the way.';
        action = 'Start delivery';
        tap = () { onStatus(id, 'delivering'); };
      } else if (status == 'delivering') {
        icon = Icons.home_rounded;
        title = 'Complete the handoff';
        message = 'Mark Delivered only after the customer has received the order.';
        action = 'Mark delivered';
        tap = () { onStatus(id, 'delivered'); };
      }
    } else if (available.isNotEmpty) {
      final order = available.first;
      icon = Icons.inventory_2_outlined;
      title = '${available.length} ready order${available.length == 1 ? '' : 's'} available';
      message = 'Review the first delivery request below. Claiming is first-come, first-served.';
      action = 'Claim first order';
      tap = () { onClaim(order['id'].toString()); };
    }

    return KarliveryNextStepPanel(
      icon: icon,
      eyebrow: 'YOUR NEXT STEP',
      title: title,
      message: message,
      action: action,
      onPressed: tap,
    );
  }
}

class _ActiveDeliveryCard extends StatelessWidget {
  final Map<String, dynamic> order;
  final bool tracking;
  final Future<void> Function(String) onTrack;
  final Future<void> Function(String, String) onStatus;
  final Future<void> Function() onRefresh;

  const _ActiveDeliveryCard({
    required this.order,
    required this.tracking,
    required this.onTrack,
    required this.onStatus,
    required this.onRefresh,
  });

  @override
  Widget build(BuildContext context) {
    final id = order['id'].toString();
    final status = (order['status'] ?? '').toString();
    final address = (order['delivery_address'] ?? '').toString();
    final phone = (order['recipient_phone'] ?? '').toString();
    final isStoreGcashDelivery = (order['payment_method'] ?? '').toString().toLowerCase() == 'gcash' &&
        (order['fulfillment'] ?? '').toString().toLowerCase() == 'delivery';
    final riderFeeStatus = (order['rider_fee_settlement_status'] ?? 'not_applicable').toString();
    final riderFee = double.tryParse(order['delivery_fee']?.toString() ?? '') ?? 0;
    final next = switch (status) {
      'assigned' => ('picked_up', 'Picked up'),
      'picked_up' => ('delivering', 'Start delivery'),
      'delivering' => ('delivered', 'Mark delivered'),
      _ => null,
    };

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: AppTheme.softRed,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Icon(
                    Icons.delivery_dining_rounded,
                    color: AppTheme.red,
                  ),
                ),
                const SizedBox(width: 11),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        (order['order_no'] ?? 'Order').toString(),
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 17,
                        ),
                      ),
                      Text(
                        '${order['stores']?['name'] ?? 'Store'} • ${money(num.tryParse(order['total']?.toString() ?? '0'))}',
                      ),
                    ],
                  ),
                ),
                KStatusPill(
                  text: niceStatus(status),
                  color: AppTheme.red,
                ),
              ],
            ),
            const SizedBox(height: 13),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppTheme.softYellow,
                borderRadius: BorderRadius.circular(18),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(
                    Icons.location_on_rounded,
                    color: AppTheme.deepRed,
                    size: 20,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      address.isEmpty ? 'Delivery address unavailable' : address,
                      style: const TextStyle(
                        color: AppTheme.deepRed,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                FilledButton.tonalIcon(
                  onPressed: () => context.push('/chat/$id'),
                  icon: const Icon(Icons.chat_bubble_rounded),
                  label: const Text('Chat'),
                ),
                FilledButton.tonalIcon(
                  onPressed: address.isEmpty
                      ? null
                      : () => IntegrationService.openNavigation(address),
                  icon: const Icon(Icons.navigation_rounded),
                  label: const Text('Navigate'),
                ),
                if (phone.isNotEmpty)
                  IconButton.filledTonal(
                    tooltip: 'Call customer',
                    onPressed: () => IntegrationService.call(phone),
                    icon: const Icon(Icons.call_rounded),
                  ),
                IconButton.filledTonal(
                  tooltip: tracking
                      ? 'Stop sharing live location'
                      : 'Share live location',
                  onPressed: () => onTrack(id),
                  icon: Icon(
                    tracking
                        ? Icons.location_off_rounded
                        : Icons.my_location_rounded,
                  ),
                ),
              ],
            ),
            if (isStoreGcashDelivery && riderFee > 0) ...[
              const SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: riderFeeStatus == 'received'
                      ? const Color(0xFFE8F7EF)
                      : AppTheme.softYellow,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      riderFeeStatus == 'received'
                          ? 'Delivery fee received • ₱${riderFee.toStringAsFixed(0)}'
                          : riderFeeStatus == 'sent'
                              ? 'Seller marked ₱${riderFee.toStringAsFixed(0)} delivery fee as sent'
                              : '₱${riderFee.toStringAsFixed(0)} delivery fee is owed to you by the store',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      riderFeeStatus == 'sent'
                          ? 'Confirm only after the amount is actually in your account/cash.'
                          : 'Karlivery records the settlement so the store and rider have the same audit trail.',
                      style: const TextStyle(fontSize: 12.5),
                    ),
                    if (riderFeeStatus == 'sent') ...[
                      const SizedBox(height: 8),
                      FilledButton.tonalIcon(
                        onPressed: () async {
                          try {
                            await Backend.riderConfirmDeliveryFeeReceived(id);
                            await onRefresh();
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Delivery fee receipt confirmed.')),
                              );
                            }
                          } catch (e) {
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('Could not confirm rider fee: $e')),
                              );
                            }
                          }
                        },
                        icon: const Icon(Icons.verified_rounded),
                        label: const Text('I received the delivery fee'),
                      ),
                    ],
                  ],
                ),
              ),
            ],
            if (tracking) ...[
              const SizedBox(height: 10),
              const KStatusPill(
                text: 'Live location sharing',
                color: Color(0xFF2E9D63),
                icon: Icons.radar_rounded,
              ),
            ],
            if (next != null) ...[
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () => onStatus(id, next.$1),
                  icon: const Icon(Icons.arrow_forward_rounded),
                  label: Text(next.$2),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _ClaimCard extends StatelessWidget {
  final Map<String, dynamic> order;
  final Future<void> Function(String) onClaim;
  const _ClaimCard({required this.order, required this.onClaim});

  @override
  Widget build(BuildContext context) {
    final address = (order['delivery_address'] ?? '').toString();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        (order['order_no'] ?? 'Order').toString(),
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        '${order['stores']?['name'] ?? 'Store'} • ${money(num.tryParse(order['total']?.toString() ?? '0'))}',
                      ),
                    ],
                  ),
                ),
                const KStatusPill(
                  text: 'READY',
                  color: Color(0xFF2E9D63),
                ),
              ],
            ),
            const SizedBox(height: 9),
            Text(
              address,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 11),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () => onClaim(order['id'].toString()),
                icon: const Icon(Icons.add_task_rounded),
                label: const Text('Claim delivery'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ActivePasabuyCard extends StatelessWidget {
  final Map<String, dynamic> order;
  final bool tracking;
  final Future<void> Function(String) onTrack;
  final Future<void> Function(String, String) onStatus;
  final Future<void> Function() onRefresh;

  const _ActivePasabuyCard({
    required this.order,
    required this.tracking,
    required this.onTrack,
    required this.onStatus,
    required this.onRefresh,
  });

  @override
  Widget build(BuildContext context) {
    final id = order['id'].toString();
    final status = (order['status'] ?? '').toString();
    final payment = (order['payment_method'] ?? 'cod').toString();
    final paymentStatus = (order['payment_status'] ?? '').toString();
    final shopName = order['pasabuy_shops'] is Map
        ? (order['pasabuy_shops']['name'] ?? 'Pabili store').toString()
        : 'Pabili store';
    final location = order['pasabuy_shops'] is Map
        ? (order['pasabuy_shops']['location_label'] ?? '').toString()
        : '';
    final next = switch (status) {
      'Rider Accepted' => ('Buying in Progress', 'Start buying'),
      'Buying in Progress' => ('Purchased', 'Items purchased'),
      'Purchased' => ('On the Way', 'Start delivery'),
      'On the Way' => ('Delivered', 'Mark delivered'),
      _ => null,
    };

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: AppTheme.softYellow,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Icon(Icons.shopping_bag_rounded, color: AppTheme.deepRed),
                ),
                const SizedBox(width: 11),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(shopName, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                      Text('${money(num.tryParse(order['total_amount']?.toString() ?? '0'))} • ${payment == 'rider_gcash' ? 'GCash to rider' : 'COD'}'),
                    ],
                  ),
                ),
                KStatusPill(text: status.toUpperCase(), color: const Color(0xFFE5A000)),
              ],
            ),
            if (location.isNotEmpty) ...[
              const SizedBox(height: 10),
              Text('Buy from: $location'),
            ],
            if ((order['custom_request'] ?? '').toString().trim().isNotEmpty) ...[
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppTheme.softYellow,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Text('Customer request: ${order['custom_request']}'),
              ),
            ],
            if (payment == 'rider_gcash') ...[
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFFEAF3FF),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      paymentStatus == 'paid'
                          ? 'GCash payment confirmed'
                          : paymentStatus == 'customer_sent'
                              ? 'Customer says GCash was sent'
                              : 'Waiting for customer GCash payment',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                    if (paymentStatus == 'customer_sent') ...[
                      const SizedBox(height: 5),
                      Text('Reference: ${order['gcash_reference_no'] ?? '-'}'),
                      const SizedBox(height: 8),
                      if ((order['gcash_proof_path'] ?? '').toString().isNotEmpty) ...[
                        OutlinedButton.icon(
                          onPressed: () async {
                            try {
                              final url = await PasabuyService.signedPasabuyPaymentProof(order['gcash_proof_path'].toString());
                              if (!context.mounted) return;
                              await showDialog<void>(
                                context: context,
                                builder: (ctx) => Dialog(
                                  child: Padding(
                                    padding: const EdgeInsets.all(12),
                                    child: InteractiveViewer(
                                      child: KNetImage(url, fit: BoxFit.contain),
                                    ),
                                  ),
                                ),
                              );
                            } catch (e) {
                              if (context.mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('Could not open Pabili GCash proof: $e')),
                                );
                              }
                            }
                          },
                          icon: const Icon(Icons.image_outlined),
                          label: const Text('View payment proof'),
                        ),
                        const SizedBox(height: 8),
                      ],
                      FilledButton.tonalIcon(
                        onPressed: () async {
                          try {
                            await PasabuyService.riderConfirmGcashReceived(id);
                            await onRefresh();
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Pabili GCash marked received.')),
                              );
                            }
                          } catch (e) {
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('Could not confirm GCash: $e')),
                              );
                            }
                          }
                        },
                        icon: const Icon(Icons.verified_rounded),
                        label: const Text('I received the GCash payment'),
                      ),
                    ],
                  ],
                ),
              ),
            ],
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                FilledButton.tonalIcon(
                  onPressed: () => context.push('/pasabuy/chat/$id'),
                  icon: const Icon(Icons.chat_bubble_rounded),
                  label: const Text('Chat customer'),
                ),
                FilledButton.tonalIcon(
                  onPressed: () => onTrack(id),
                  icon: Icon(tracking ? Icons.location_off_rounded : Icons.my_location_rounded),
                  label: Text(tracking ? 'Stop tracking' : 'Share location'),
                ),
                OutlinedButton.icon(
                  onPressed: () => context.push('/pasabuy/track/$id'),
                  icon: const Icon(Icons.map_outlined),
                  label: const Text('Live map'),
                ),
                OutlinedButton.icon(
                  onPressed: () async {
                    try {
                      final point = await PasabuyService.trackingDestination(id);
                      final lat = double.tryParse(point['latitude']?.toString() ?? '');
                      final lng = double.tryParse(point['longitude']?.toString() ?? '');
                      if (lat == null || lng == null || lat.abs() > 90 || lng.abs() > 180) {
                        throw StateError('Customer has no valid delivery pin.');
                      }
                      final uri = Uri.https('www.google.com', '/maps/dir/', {
                        'api': '1',
                        'destination': '$lat,$lng',
                        'travelmode': 'driving',
                      });
                      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
                        throw StateError('Unable to open Maps.');
                      }
                    } catch (error) {
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Navigation unavailable: $error')),
                        );
                      }
                    }
                  },
                  icon: const Icon(Icons.directions_rounded),
                  label: const Text('Navigate to customer'),
                ),
              ],
            ),
            if (next != null) ...[
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () => onStatus(id, next.$1),
                  icon: const Icon(Icons.arrow_forward_rounded),
                  label: Text(next.$2),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _PasabuyClaimCard extends StatelessWidget {
  final Map<String, dynamic> order;
  final Future<void> Function(String) onClaim;

  const _PasabuyClaimCard({required this.order, required this.onClaim});

  @override
  Widget build(BuildContext context) {
    final shopName = order['pasabuy_shops'] is Map
        ? (order['pasabuy_shops']['name'] ?? 'Pabili store').toString()
        : 'Pabili store';
    final payment = (order['payment_method'] ?? 'cod').toString();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('PABILI REQUEST', style: TextStyle(fontWeight: FontWeight.w700, color: AppTheme.deepRed, fontSize: 12, letterSpacing: .8)),
                      const SizedBox(height: 4),
                      Text(shopName, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    ],
                  ),
                ),
                KStatusPill(text: payment == 'rider_gcash' ? 'GCASH TO RIDER' : 'COD', color: const Color(0xFFE5A000)),
              ],
            ),
            const SizedBox(height: 8),
            Text('Order total: ${money(num.tryParse(order['total_amount']?.toString() ?? '0'))}'),
            const SizedBox(height: 4),
            const Text('Includes ₱10 Karlivery Pabili handling fee.'),
            if (payment == 'rider_gcash') ...[
              const SizedBox(height: 8),
              const Text('You need a rider GCash number in Account before accepting this job.', style: TextStyle(fontWeight: FontWeight.w600)),
            ],
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () => onClaim(order['id'].toString()),
                icon: const Icon(Icons.add_task_rounded),
                label: const Text('Accept Pabili'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RiderMessagesTab extends StatelessWidget {
  const _RiderMessagesTab();

  @override
  Widget build(BuildContext context) => SafeArea(
        child: FutureBuilder<List<Map<String, dynamic>>>(
          future: Backend.riderMessageOrders(),
          builder: (context, snap) {
            final rows = snap.data ?? [];
            return ListView(
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 110),
              children: [
                const KPageHeader(
                  eyebrow: 'Conversations',
                  title: 'Delivery messages',
                  subtitle: 'A cleaner place for customer instructions and arrival updates.',
                  icon: Icons.forum_rounded,
                ),
                const SizedBox(height: 18),
                if (snap.connectionState != ConnectionState.done)
                  const KLoadingState(message: 'Loading conversations…')
                else if (rows.isEmpty)
                  const KEmptyState(
                    icon: Icons.forum_outlined,
                    title: 'No conversations yet',
                    subtitle: 'Customer chats appear after you claim a delivery.',
                  )
                else
                  ...rows.map(
                    (o) => Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Card(
                        child: ListTile(
                          onTap: () => context.push('/chat/${o['id']}'),
                          contentPadding: const EdgeInsets.all(15),
                          leading: Container(
                            width: 48,
                            height: 48,
                            decoration: BoxDecoration(
                              color: AppTheme.softYellow,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: const Icon(
                              Icons.person_rounded,
                              color: AppTheme.deepRed,
                            ),
                          ),
                          title: Text(
                            (o['recipient_name'] ?? 'Customer').toString(),
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                          subtitle: Text(
                            '${o['order_no']} • ${niceStatus((o['status'] ?? '').toString())}',
                          ),
                          trailing: const Icon(Icons.chevron_right_rounded),
                        ),
                      ),
                    ),
                  ),
                const PasabuyChatThreadsSection(forRider: true),
              ],
            );
          },
        ),
      );
}

class _RiderHistoryTab extends StatelessWidget {
  const _RiderHistoryTab();

  @override
  Widget build(BuildContext context) => SafeArea(
        child: FutureBuilder<List<Map<String, dynamic>>>(
          future: Backend.riderArchivedOrders(),
          builder: (context, snap) {
            final rows = snap.data ?? [];
            return ListView(
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 110),
              children: [
                const KPageHeader(
                  eyebrow: 'Auto archive',
                  title: 'Delivery history',
                  subtitle: 'Delivered, completed or cancelled jobs are moved here automatically so your current workspace stays clean.',
                  icon: Icons.archive_rounded,
                ),
                const SizedBox(height: 18),
                if (snap.connectionState != ConnectionState.done)
                  const KLoadingState(message: 'Loading delivery history…')
                else if (rows.isEmpty)
                  const KEmptyState(
                    icon: Icons.archive_outlined,
                    title: 'No archived deliveries yet',
                    subtitle: 'Finished jobs will appear here automatically.',
                  )
                else
                  ...rows.map(
                    (order) => Card(
                      margin: const EdgeInsets.only(bottom: 10),
                      child: ListTile(
                        leading: const CircleAvatar(
                          child: Icon(Icons.delivery_dining_rounded),
                        ),
                        title: Text(
                          (order['order_no'] ?? 'Order').toString(),
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                        subtitle: Text(
                          '${order['stores']?['name'] ?? 'Store'} • ${niceStatus((order['status'] ?? '').toString())}\n${money(num.tryParse(order['total']?.toString() ?? '0'))}',
                        ),
                        isThreeLine: true,
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      );
}

class _RiderAccountTab extends StatelessWidget {
  final bool online;
  final Future<void> Function() onSignOut;
  const _RiderAccountTab({
    required this.online,
    required this.onSignOut,
  });

  @override
  Widget build(BuildContext context) => SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 110),
          children: [
            KPageHeader(
              eyebrow: 'Rider profile',
              title: online ? 'Online & available' : 'Currently offline',
              subtitle: 'Control appearance, understand location sharing and manage your session.',
              icon: Icons.person_rounded,
            ),
            const SizedBox(height: 18),
            Card(
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(Icons.circle_rounded),
                    title: const Text(
                      'Availability',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                    subtitle: Text(online ? 'Online' : 'Offline'),
                    trailing: KStatusPill(
                      text: online ? 'READY' : 'OFF',
                      color: online
                          ? const Color(0xFF2E9D63)
                          : AppTheme.muted,
                    ),
                  ),
                  const Divider(height: 1),
                  SwitchListTile(
                    value: ThemeController.isDark(context),
                    secondary: const Icon(Icons.dark_mode_rounded),
                    title: const Text(
                      'Dark mode',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                    subtitle: const Text('Light mode is the default experience'),
                    onChanged: ThemeController.setDark,
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.account_balance_wallet_outlined),
                    title: const Text(
                      'Pabili GCash',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                    subtitle: const Text(
                      'Customers choosing GCash for Pabili pay your rider GCash directly',
                    ),
                    trailing: const Icon(Icons.chevron_right_rounded),
                    onTap: () => _showRiderGcashDialog(context),
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.lock_reset_rounded),
                    title: const Text(
                      'Change password',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                    subtitle: const Text(
                      'Verify your current password and choose a new one',
                    ),
                    trailing: const Icon(Icons.chevron_right_rounded),
                    onTap: () => showAccountPasswordDialog(context),
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.help_center_rounded),
                    title: const Text(
                      'Rider help & delivery guide',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                    subtitle: const Text('Go online, claim, track and complete deliveries step by step'),
                    trailing: const Icon(Icons.chevron_right_rounded),
                    onTap: () => context.push('/help?role=rider'),
                  ),
                  const Divider(height: 1),
                  const ListTile(
                    leading: Icon(Icons.location_on_outlined),
                    title: Text(
                      'Live location privacy',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                    subtitle: Text(
                      'Your live location is shared only for an active delivery when you enable it.',
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            FilledButton.tonalIcon(
              onPressed: onSignOut,
              icon: const Icon(Icons.logout_rounded),
              label: const Text('Sign out'),
            ),
          ],
        ),
      );
}

Future<void> _showRiderGcashDialog(BuildContext context) async {
  final profile = await PasabuyService.riderGcashProfile();
  if (!context.mounted) return;
  final number = TextEditingController(text: profile?['rider_gcash_number']?.toString() ?? '');
  String? qrUrl = profile?['rider_gcash_qr_url']?.toString();
  bool busy = false;

  await showDialog<void>(
    context: context,
    builder: (dialogContext) => StatefulBuilder(
      builder: (dialogContext, setDialogState) => AlertDialog(
        title: const Text('Pabili rider GCash'),
        content: SizedBox(
          width: 430,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'For Pabili orders only, customers can pay directly to your GCash after you accept the job. Karlivery never asks the customer to send Pabili GCash before a rider is assigned.',
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: number,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(
                    labelText: 'Rider GCash number',
                    hintText: '09xxxxxxxxx',
                  ),
                ),
                const SizedBox(height: 12),
                if (qrUrl != null && qrUrl!.isNotEmpty)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: KNetImage(qrUrl!, height: 180, fit: BoxFit.contain),
                  ),
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed: busy
                      ? null
                      : () async {
                          final result = await FilePicker.platform.pickFiles(
                            type: FileType.image,
                            withData: true,
                          );
                          if (result == null || result.files.single.bytes == null) return;
                          setDialogState(() => busy = true);
                          try {
                            final file = result.files.single;
                            final ext = (file.extension ?? 'jpg').toLowerCase();
                            qrUrl = await PasabuyService.uploadRiderGcashQr(
                              bytes: file.bytes!,
                              extension: ext,
                            );
                          } finally {
                            if (dialogContext.mounted) setDialogState(() => busy = false);
                          }
                        },
                  icon: const Icon(Icons.qr_code_2_rounded),
                  label: Text(qrUrl == null || qrUrl!.isEmpty ? 'Upload GCash QR' : 'Replace GCash QR'),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: busy ? null : () => Navigator.pop(dialogContext), child: const Text('Cancel')),
          FilledButton(
            onPressed: busy
                ? null
                : () async {
                    final value = number.text.trim();
                    if (value.isEmpty) {
                      ScaffoldMessenger.of(dialogContext).showSnackBar(
                        const SnackBar(content: Text('Enter your rider GCash number first.')),
                      );
                      return;
                    }
                    setDialogState(() => busy = true);
                    try {
                      await PasabuyService.saveRiderGcash(number: value, qrUrl: qrUrl);
                      if (dialogContext.mounted) Navigator.pop(dialogContext);
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Rider GCash saved.')),
                        );
                      }
                    } catch (e) {
                      if (dialogContext.mounted) {
                        ScaffoldMessenger.of(dialogContext).showSnackBar(
                          SnackBar(content: Text('Could not save rider GCash: $e')),
                        );
                      }
                    } finally {
                      if (dialogContext.mounted) setDialogState(() => busy = false);
                    }
                  },
            child: busy
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Save'),
          ),
        ],
      ),
    ),
  );
  number.dispose();
}
