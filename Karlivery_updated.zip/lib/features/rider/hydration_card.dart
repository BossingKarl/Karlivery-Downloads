import 'package:flutter/material.dart';
import '../../core/modern_ui.dart';

/// A gentle reminder, not a timer, medical recommendation or notification.
class RiderHydrationCard extends StatelessWidget {
  const RiderHydrationCard({super.key});
  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final accent = dark ? const Color(0xFF8EDBEA) : const Color(0xFF087E93);
    return Semantics(container: true, child: Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: dark ? const Color(0xFF13333B) : const Color(0xFFEAF8FA),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: accent.withValues(alpha: .16)),
      ),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        KIconTile(icon: Icons.water_drop_outlined, color: accent),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Stay hydrated, ka-rider!', style: TextStyle(color: accent, fontSize: 17, fontWeight: FontWeight.w700)),
          const SizedBox(height: 5),
          Text('Magdala ng tubig at uminom regularly. Take a water break between deliveries—park safely first.',
            style: TextStyle(color: dark ? const Color(0xFFCCE9EE) : const Color(0xFF315861), height: 1.5)),
        ])),
      ]),
    ));
  }
}
