import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/brand.dart';
import '../../core/modern_ui.dart';
import '../../core/role_panels.dart';
import '../../core/nova_headline.dart';
import '../../core/utils.dart';
import '../../services/backend.dart';
import '../../services/store_schedule.dart';
import '../../services/integration_service.dart';
import '../../services/theme_controller.dart';
import '../../theme/app_theme.dart';
import '../shared/notification_center_screen.dart';
import '../shared/change_password_dialog.dart';
import '../../design_system/k_network_image.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  int section = 0;
  Map<String, int> metrics = {};
  List<Map<String, dynamic>> users = [];
  List<Map<String, dynamic>> stores = [];
  List<Map<String, dynamic>> orders = [];
  List<Map<String, dynamic>> live = [];
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    if (mounted) {
      setState(() {
        loading = true;
        error = null;
      });
    }
    try {
      final result = await Future.wait([
        Backend.adminMetrics(),
        Backend.adminUsers(),
        Backend.adminStores(),
        Backend.adminOrders(),
        Backend.adminLiveDeliveries(),
      ]);
      metrics = Map<String, int>.from(result[0] as Map);
      users = result[1] as List<Map<String, dynamic>>;
      stores = result[2] as List<Map<String, dynamic>>;
      orders = result[3] as List<Map<String, dynamic>>;
      live = result[4] as List<Map<String, dynamic>>;
    } catch (e) {
      error = e.toString();
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _handleTopBarAction(String value) async {
    switch (value) {
      case 'help':
        if (mounted) context.push('/help?role=admin');
        break;
      case 'announcement':
        if (mounted) context.push('/admin/announcement');
        break;
      case 'pasabuy':
        if (mounted) context.push('/admin/pasabuy');
        break;
      case 'refresh':
        await load();
        break;
      case 'theme':
        if (mounted) ThemeController.toggle(context);
        break;
      case 'logout':
        await Backend.logout();
        if (mounted) context.go('/login');
        break;
    }
  }

  List<Widget> _topBarActions(bool wide) {
    if (wide) {
      return [
        IconButton(
          tooltip: 'Help',
          onPressed: () => _handleTopBarAction('help'),
          icon: const Icon(Icons.help_outline_rounded),
        ),
        const NotificationBell(),
        IconButton(
          tooltip: 'Announcement',
          onPressed: () => _handleTopBarAction('announcement'),
          icon: const Icon(Icons.campaign_rounded),
        ),
        IconButton(
          tooltip: 'Pabili with Karlivery Studio',
          onPressed: () => _handleTopBarAction('pasabuy'),
          icon: const Icon(Icons.shopping_bag_outlined),
        ),
        IconButton(
          tooltip: 'Refresh',
          onPressed: () => _handleTopBarAction('refresh'),
          icon: const Icon(Icons.refresh_rounded),
        ),
        IconButton(
          tooltip: 'Theme',
          onPressed: () => _handleTopBarAction('theme'),
          icon: Icon(
            ThemeController.isDark(context)
                ? Icons.light_mode_rounded
                : Icons.dark_mode_rounded,
          ),
        ),
        IconButton(
          tooltip: 'Sign out',
          onPressed: () => _handleTopBarAction('logout'),
          icon: const Icon(Icons.logout_rounded),
        ),
        const SizedBox(width: 6),
      ];
    }

    return [
      const NotificationBell(),
      PopupMenuButton<String>(
        tooltip: 'More',
        onSelected: _handleTopBarAction,
        itemBuilder: (context) => [
          const PopupMenuItem(
            value: 'help',
            child: ListTile(
              leading: Icon(Icons.help_outline_rounded),
              title: Text('Help'),
              contentPadding: EdgeInsets.zero,
            ),
          ),
          const PopupMenuItem(
            value: 'announcement',
            child: ListTile(
              leading: Icon(Icons.campaign_rounded),
              title: Text('Announcement'),
              contentPadding: EdgeInsets.zero,
            ),
          ),
          const PopupMenuItem(
            value: 'pasabuy',
            child: ListTile(
              leading: Icon(Icons.shopping_bag_outlined),
              title: Text('Pabili with Karlivery Studio'),
              contentPadding: EdgeInsets.zero,
            ),
          ),
          const PopupMenuItem(
            value: 'refresh',
            child: ListTile(
              leading: Icon(Icons.refresh_rounded),
              title: Text('Refresh'),
              contentPadding: EdgeInsets.zero,
            ),
          ),
          PopupMenuItem(
            value: 'theme',
            child: ListTile(
              leading: Icon(
                ThemeController.isDark(context)
                    ? Icons.light_mode_rounded
                    : Icons.dark_mode_rounded,
              ),
              title: Text(
                ThemeController.isDark(context) ? 'Light mode' : 'Dark mode',
              ),
              contentPadding: EdgeInsets.zero,
            ),
          ),
          const PopupMenuDivider(),
          const PopupMenuItem(
            value: 'logout',
            child: ListTile(
              leading: Icon(Icons.logout_rounded),
              title: Text('Sign out'),
              contentPadding: EdgeInsets.zero,
            ),
          ),
        ],
      ),
      const SizedBox(width: 6),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.sizeOf(context).width >= 960;
    return KDashboardScaffold(
      appBar: AppBar(
        toolbarHeight: 72,
        titleSpacing: 10,
        title: wide
            ? const KarliveryWordmark(compact: true)
            : const KarliveryMark(size: 40),
        actions: _topBarActions(wide),
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1240),
          child: loading
              ? const KLoadingState(message: 'Loading admin workspace…')
              : error != null
                  ? _ErrorState(message: error!, retry: load)
                  : _body(),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: section,
        onDestinationSelected: (v) => setState(() => section = v),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.space_dashboard_outlined),
            selectedIcon: Icon(Icons.space_dashboard_rounded),
            label: 'Overview',
          ),
          NavigationDestination(
            icon: Icon(Icons.manage_accounts_outlined),
            selectedIcon: Icon(Icons.manage_accounts_rounded),
            label: 'Users',
          ),
          NavigationDestination(
            icon: Icon(Icons.storefront_outlined),
            selectedIcon: Icon(Icons.storefront_rounded),
            label: 'Stores',
          ),
          NavigationDestination(
            icon: Icon(Icons.receipt_long_outlined),
            selectedIcon: Icon(Icons.receipt_long_rounded),
            label: 'Orders',
          ),
          NavigationDestination(
            icon: Icon(Icons.hub_outlined),
            selectedIcon: Icon(Icons.hub_rounded),
            label: 'System',
          ),
        ],
      ),
    );
  }

  Widget _body() {
    switch (section) {
      case 1:
        return _UsersPage(users: users, refresh: load);
      case 2:
        return _StoresPage(stores: stores);
      case 3:
        return _OrdersPage(orders: orders);
      case 4:
        return const _SystemPage();
      default:
        return _OverviewPage(
          metrics: metrics,
          users: users,
          stores: stores,
          orders: orders,
          live: live,
          onOpenSection: (value) => setState(() => section = value),
        );
    }
  }
}

class _OverviewPage extends StatelessWidget {
  final Map<String, int> metrics;
  final List<Map<String, dynamic>> users;
  final List<Map<String, dynamic>> stores;
  final List<Map<String, dynamic>> orders;
  final List<Map<String, dynamic>> live;
  final ValueChanged<int> onOpenSection;

  const _OverviewPage({
    required this.metrics,
    required this.users,
    required this.stores,
    required this.orders,
    required this.live,
    required this.onOpenSection,
  });

  @override
  Widget build(BuildContext context) {
    final customers = users.where((u) => u['role'] == 'customer').length;
    final sellers = users.where((u) => u['role'] == 'store_owner').length;
    final riders = users.where((u) => u['role'] == 'rider').length;
    final openStores = stores.where((s) => s['is_approved'] == true && StoreSchedule.isOpenNow(s)).length;
    final pendingStores = stores.where((s) => s['is_approved'] != true).length;
    final gross = orders.fold<double>(
      0,
      (sum, o) => sum + (double.tryParse(o['total']?.toString() ?? '') ?? 0),
    );

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 100),
      children: [
        const NovaHeadline(
          eyebrow: 'KARLIVERY / ADMIN',
          title: 'Everything in one place.',
          subtitle: 'Your live command center for local food, people, orders, and deliveries.',
          icon: Icons.admin_panel_settings_rounded,
        ),
        const SizedBox(height: 14),
        LayoutBuilder(builder: (context, limits) {
          final width = limits.maxWidth;
          final columns = width >= 900 ? 4 : width >= 470 ? 2 : 1;
          final itemWidth = (width - (columns - 1) * 10) / columns;
          return Wrap(spacing: 10, runSpacing: 10, children: [
            SizedBox(width: itemWidth, child: KarliveryQuickAction(
              icon: Icons.person_add_alt_1_rounded,
              title: 'Accounts', caption: 'Manage users',
              onPressed: () => onOpenSection(1))),
            SizedBox(width: itemWidth, child: KarliveryQuickAction(
              icon: Icons.storefront_rounded,
              title: 'Stores', caption: 'Review approvals',
              onPressed: () => onOpenSection(2))),
            SizedBox(width: itemWidth, child: KarliveryQuickAction(
              icon: Icons.receipt_long_rounded,
              title: 'Orders', caption: 'Check activity',
              onPressed: () => onOpenSection(3))),
            SizedBox(width: itemWidth, child: KarliveryQuickAction(
              icon: Icons.campaign_rounded,
              title: 'Broadcast', caption: 'Send announcements',
              onPressed: () => context.push('/admin/announcement'))),
          ]);
        }),
        const SizedBox(height: 14),
        KMetricGrid(children: [
          KMetricCard(label: 'Registered users', value: '${metrics['users'] ?? users.length}', icon: Icons.people_alt_outlined),
          KMetricCard(label: 'Open stores', value: '$openStores', icon: Icons.storefront_outlined),
          KMetricCard(label: 'Live deliveries', value: '${live.length}', icon: Icons.delivery_dining_outlined, accent: const Color(0xFF087E93)),
          KMetricCard(label: 'Recent order value', value: money(gross), icon: Icons.payments_outlined, accent: const Color(0xFFB87915)),
        ]),
        const SizedBox(height: 22),
        if (pendingStores > 0) ...[
          Card(child: ListTile(
            leading: const KIconTile(icon: Icons.fact_check_outlined),
            title: Text('$pendingStores stores awaiting review'),
            subtitle: const Text('Review store details and approve eligible sellers.'),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => onOpenSection(2),
          )),
          const SizedBox(height: 22),
        ],
        const KSectionTitle(
          title: 'Account mix',
          subtitle: 'Public registration stays customer-only; seller and rider accounts are admin-created.',
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: _RoleSummary(
                icon: Icons.person_rounded,
                label: 'Customers',
                value: customers,
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _RoleSummary(
                icon: Icons.storefront_rounded,
                label: 'Sellers',
                value: sellers,
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _RoleSummary(
                icon: Icons.delivery_dining_rounded,
                label: 'Riders',
                value: riders,
              ),
            ),
          ],
        ),
        const SizedBox(height: 22),
        KSectionTitle(
          title: 'Live delivery activity',
          subtitle: live.isEmpty
              ? 'No rider is actively delivering right now.'
              : 'Orders currently assigned, picked up or on the way.',
        ),
        const SizedBox(height: 10),
        if (live.isEmpty)
          const KEmptyState(
            icon: Icons.route_outlined,
            title: 'No live deliveries',
            subtitle: 'Active rider jobs will appear here automatically.',
          )
        else
          ...live.take(5).map(
            (o) => Padding(
              padding: const EdgeInsets.only(bottom: 9),
              child: _OrderRow(order: o),
            ),
          ),
      ],
    );
  }
}

class _RoleSummary extends StatelessWidget {
  final IconData icon;
  final String label;
  final int value;
  const _RoleSummary({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 16),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: Theme.of(context).dividerColor),
        ),
        child: Column(
          children: [
            Icon(icon, color: AppTheme.red),
            const SizedBox(height: 7),
            Text(
              '$value',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
            ),
            Text(label, style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      );
}

class _UsersPage extends StatefulWidget {
  final List<Map<String, dynamic>> users;
  final Future<void> Function() refresh;
  const _UsersPage({required this.users, required this.refresh});

  @override
  State<_UsersPage> createState() => _UsersPageState();
}

class _UsersPageState extends State<_UsersPage> {
  String query = '';
  String roleFilter = 'all';
  bool busy = false;

  List<Map<String, dynamic>> get filtered => widget.users.where((u) {
        final hay = '${u['full_name']} ${u['email']} ${u['phone']}'.toLowerCase();
        final role = (u['role'] ?? '').toString();
        return hay.contains(query.toLowerCase()) &&
            (roleFilter == 'all' || role == roleFilter);
      }).toList();

  void message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> createUser() async {
    final fullName = TextEditingController();
    final email = TextEditingController();
    final phone = TextEditingController();
    final password = TextEditingController();
    var role = 'store_owner';
    var obscure = true;

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: const Text('Create managed account'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: fullName,
                  decoration: const InputDecoration(
                    labelText: 'Full name',
                    prefixIcon: Icon(Icons.badge_outlined),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: email,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    labelText: 'Email',
                    prefixIcon: Icon(Icons.email_outlined),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: phone,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(
                    labelText: 'Phone',
                    prefixIcon: Icon(Icons.phone_iphone_rounded),
                  ),
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  initialValue: role,
                  decoration: const InputDecoration(
                    labelText: 'Account type',
                    prefixIcon: Icon(Icons.work_outline_rounded),
                  ),
                  items: const [
                    DropdownMenuItem(
                      value: 'store_owner',
                      child: Text('Seller'),
                    ),
                    DropdownMenuItem(
                      value: 'rider',
                      child: Text('Rider'),
                    ),
                    DropdownMenuItem(
                      value: 'customer',
                      child: Text('Customer'),
                    ),
                  ],
                  onChanged: (v) => setLocal(() => role = v ?? 'store_owner'),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: password,
                  obscureText: obscure,
                  decoration: InputDecoration(
                    labelText: 'Temporary password',
                    helperText: 'At least 8 characters',
                    prefixIcon: const Icon(Icons.password_rounded),
                    suffixIcon: IconButton(
                      onPressed: () => setLocal(() => obscure = !obscure),
                      icon: Icon(
                        obscure
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Create account'),
            ),
          ],
        ),
      ),
    );

    if (ok != true) return;
    if (email.text.trim().isEmpty || password.text.length < 8) {
      message('Enter a valid email and password of at least 8 characters.');
      return;
    }

    setState(() => busy = true);
    try {
      await Backend.adminCreateUser(
        email: email.text,
        password: password.text,
        fullName: fullName.text,
        phone: phone.text,
        role: role,
      );
      await widget.refresh();
      message('Account created successfully.');
    } catch (e) {
      message('Create account failed: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> editUser(Map<String, dynamic> user) async {
    final fullName = TextEditingController(text: (user['full_name'] ?? '').toString());
    final email = TextEditingController(text: (user['email'] ?? '').toString());
    final phone = TextEditingController(text: (user['phone'] ?? '').toString());
    final password = TextEditingController();
    var role = (user['role'] ?? 'customer').toString();
    var status = (user['status'] ?? 'active').toString();

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Update account'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: fullName,
                decoration: const InputDecoration(labelText: 'Full name'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: email,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(labelText: 'Email'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: phone,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'Phone'),
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                initialValue: role,
                decoration: const InputDecoration(labelText: 'Role'),
                items: const [
                  DropdownMenuItem(value: 'customer', child: Text('Customer')),
                  DropdownMenuItem(value: 'store_owner', child: Text('Seller')),
                  DropdownMenuItem(value: 'rider', child: Text('Rider')),
                  DropdownMenuItem(value: 'admin', child: Text('Admin')),
                ],
                onChanged: (v) => role = v ?? role,
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                initialValue: status,
                decoration: const InputDecoration(labelText: 'Status'),
                items: const [
                  DropdownMenuItem(value: 'active', child: Text('Active')),
                  DropdownMenuItem(value: 'suspended', child: Text('Suspended')),
                  DropdownMenuItem(value: 'pending', child: Text('Pending')),
                  DropdownMenuItem(value: 'rejected', child: Text('Rejected')),
                ],
                onChanged: (v) => status = v ?? status,
              ),
              const SizedBox(height: 10),
              TextField(
                controller: password,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'New password',
                  helperText: 'Leave blank to keep the current password',
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Save changes'),
          ),
        ],
      ),
    );

    if (ok != true) return;
    try {
      await Backend.adminUpdateUser(
        userId: user['id'].toString(),
        email: email.text,
        fullName: fullName.text,
        phone: phone.text,
        role: role,
        status: status,
        password: password.text,
      );
      await widget.refresh();
      message('Account updated.');
    } catch (e) {
      message('Update failed: $e');
    }
  }

  Future<void> deleteUser(Map<String, dynamic> user) async {
    if ((user['role'] ?? '').toString() == 'admin') {
      message('Admin accounts are protected from this delete action.');
      return;
    }
    final name = (user['full_name'] ?? user['email'] ?? 'this user').toString();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        icon: const Icon(Icons.delete_forever_rounded, color: Colors.redAccent),
        title: const Text('Delete account permanently?'),
        content: Text(
          'Delete $name from authentication and profiles? Completed transaction history remains anonymized. Accounts with active orders cannot be deleted.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.redAccent),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete permanently'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Backend.adminDeleteUser(user['id'].toString());
      await widget.refresh();
      message('Account permanently deleted.');
    } catch (e) {
      message('Delete failed: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final items = filtered;
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 100),
      children: [
        KPageHeader(
          eyebrow: 'Secure account control',
          title: 'User management',
          subtitle: 'Create seller and rider accounts, update access, or permanently delete non-admin users.',
          icon: Icons.manage_accounts_rounded,
          trailing: IconButton.filled(
            style: IconButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: AppTheme.red,
            ),
            tooltip: 'Create account',
            onPressed: busy ? null : createUser,
            icon: const Icon(Icons.person_add_alt_1_rounded),
          ),
        ),
        const SizedBox(height: 16),
        TextField(
          onChanged: (v) => setState(() => query = v),
          decoration: const InputDecoration(
            hintText: 'Search name, email or phone',
            prefixIcon: Icon(Icons.search_rounded),
          ),
        ),
        const SizedBox(height: 10),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'all', label: Text('All')),
              ButtonSegment(value: 'customer', label: Text('Customers')),
              ButtonSegment(value: 'store_owner', label: Text('Sellers')),
              ButtonSegment(value: 'rider', label: Text('Riders')),
            ],
            selected: {roleFilter},
            onSelectionChanged: (v) => setState(() => roleFilter = v.first),
          ),
        ),
        const SizedBox(height: 16),
        if (items.isEmpty)
          const KEmptyState(
            icon: Icons.search_off_rounded,
            title: 'No users found',
            subtitle: 'Try another search or role filter.',
          )
        else
          ...items.map(
            (u) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(13),
                  child: Row(
                    children: [
                      Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          color: _roleColor((u['role'] ?? '').toString())
                              .withValues(alpha: .11),
                          borderRadius: BorderRadius.circular(17),
                        ),
                        child: Icon(
                          _roleIcon((u['role'] ?? '').toString()),
                          color: _roleColor((u['role'] ?? '').toString()),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              (u['full_name'] ?? u['email'] ?? 'User').toString(),
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 16,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              (u['email'] ?? '').toString(),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 7),
                            Wrap(
                              spacing: 6,
                              runSpacing: 6,
                              children: [
                                KStatusPill(
                                  text: niceStatus((u['role'] ?? '').toString()),
                                  color: _roleColor((u['role'] ?? '').toString()),
                                ),
                                KStatusPill(
                                  text: niceStatus((u['status'] ?? '').toString()),
                                  color: (u['status'] ?? '') == 'active'
                                      ? const Color(0xFF2E9D63)
                                      : Colors.orange,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      PopupMenuButton<String>(
                        onSelected: (value) {
                          if (value == 'edit') editUser(u);
                          if (value == 'delete') deleteUser(u);
                        },
                        itemBuilder: (_) => [
                          const PopupMenuItem(
                            value: 'edit',
                            child: ListTile(
                              contentPadding: EdgeInsets.zero,
                              leading: Icon(Icons.edit_rounded),
                              title: Text('Edit account'),
                            ),
                          ),
                          if ((u['role'] ?? '').toString() != 'admin')
                            const PopupMenuItem(
                              value: 'delete',
                              child: ListTile(
                                contentPadding: EdgeInsets.zero,
                                leading: Icon(
                                  Icons.delete_forever_rounded,
                                  color: Colors.redAccent,
                                ),
                                title: Text('Delete permanently'),
                              ),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }

  IconData _roleIcon(String role) => switch (role) {
        'store_owner' => Icons.storefront_rounded,
        'rider' => Icons.delivery_dining_rounded,
        'admin' => Icons.admin_panel_settings_outlined,
        _ => Icons.person_rounded,
      };

  Color _roleColor(String role) => switch (role) {
        'store_owner' => AppTheme.deepRed,
        'rider' => const Color(0xFF2E9D63),
        'admin' => const Color(0xFF6E44FF),
        _ => AppTheme.red,
      };
}

class _StoresPage extends StatelessWidget {
  final List<Map<String, dynamic>> stores;
  const _StoresPage({required this.stores});

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 100),
        children: [
          const KPageHeader(
            eyebrow: 'Marketplace',
            title: 'Stores',
            subtitle: 'Review seller branding, availability and payment readiness.',
            icon: Icons.storefront_rounded,
          ),
          const SizedBox(height: 16),
          if (stores.isEmpty)
            const KEmptyState(
              icon: Icons.store_mall_directory_outlined,
              title: 'No stores yet',
              subtitle: 'A seller store appears here after the seller creates it.',
            )
          else
            ...stores.map(
              (s) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(13),
                    child: Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(18),
                          child: SizedBox(
                            width: 64,
                            height: 64,
                            child: (s['logo_url'] ?? '').toString().isEmpty
                                ? ColoredBox(
                                    color: AppTheme.softYellow,
                                    child: const Icon(
                                      Icons.storefront_rounded,
                                      color: AppTheme.deepRed,
                                    ),
                                  )
                                : KNetImage(
                                    s['logo_url'].toString(),
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, _, _) => const ColoredBox(
                                      color: AppTheme.softYellow,
                                      child: Icon(Icons.storefront_rounded),
                                    ),
                                  ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                (s['name'] ?? 'Store').toString(),
                                style: const TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 16,
                                ),
                              ),
                              const SizedBox(height: 3),
                              Text('${s['barangay'] ?? ''} • ${s['address'] ?? ''}'),
                              const SizedBox(height: 7),
                              Wrap(
                                spacing: 6,
                                runSpacing: 6,
                                children: [
                                  KStatusPill(
                                    text: s['is_open'] == true ? 'OPEN' : 'CLOSED',
                                    color: s['is_open'] == true
                                        ? const Color(0xFF2E9D63)
                                        : AppTheme.muted,
                                  ),
                                  KStatusPill(
                                    text: (s['gcash_number'] ?? '').toString().isEmpty
                                        ? 'COD'
                                        : 'COD + GCASH',
                                    color: AppTheme.deepRed,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
        ],
      );
}

class _OrdersPage extends StatefulWidget {
  final List<Map<String, dynamic>> orders;
  const _OrdersPage({required this.orders});

  @override
  State<_OrdersPage> createState() => _OrdersPageState();
}

class _OrdersPageState extends State<_OrdersPage> {
  String filter = 'all';

  @override
  Widget build(BuildContext context) {
    final rows = widget.orders.where((o) {
      if (filter == 'all') return true;
      if (filter == 'active') {
        return !['completed', 'delivered', 'cancelled', 'rejected']
            .contains((o['status'] ?? '').toString());
      }
      return ['completed', 'delivered']
          .contains((o['status'] ?? '').toString());
    }).toList();

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 100),
      children: [
        const KPageHeader(
          eyebrow: 'Marketplace activity',
          title: 'Orders',
          subtitle: 'Inspect recent orders without crowding the operations overview.',
          icon: Icons.receipt_long_rounded,
        ),
        const SizedBox(height: 14),
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'all', label: Text('All')),
            ButtonSegment(value: 'active', label: Text('Active')),
            ButtonSegment(value: 'done', label: Text('Completed')),
          ],
          selected: {filter},
          onSelectionChanged: (v) => setState(() => filter = v.first),
        ),
        const SizedBox(height: 14),
        if (rows.isEmpty)
          const KEmptyState(
            icon: Icons.receipt_long_outlined,
            title: 'No matching orders',
            subtitle: 'Orders matching this filter will appear here.',
          )
        else
          ...rows.map(
            (o) => Padding(
              padding: const EdgeInsets.only(bottom: 9),
              child: _OrderRow(order: o),
            ),
          ),
      ],
    );
  }
}

class _OrderRow extends StatelessWidget {
  final Map<String, dynamic> order;
  const _OrderRow({required this.order});

  @override
  Widget build(BuildContext context) {
    final status = (order['status'] ?? '').toString();
    final active = !['completed', 'delivered', 'cancelled', 'rejected'].contains(status);
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.all(14),
        leading: Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: active ? AppTheme.softRed : AppTheme.softYellow,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Icon(
            active ? Icons.receipt_long_rounded : Icons.check_circle_rounded,
            color: active ? AppTheme.red : AppTheme.deepRed,
          ),
        ),
        title: Text(
          (order['order_no'] ?? 'Order').toString(),
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
        subtitle: Text(
          '${order['stores'] is Map ? order['stores']['name'] : 'Store'} • ${niceStatus(status)}',
        ),
        trailing: Text(
          money(num.tryParse(order['total']?.toString() ?? '0')),
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
      ),
    );
  }
}

class _SystemPage extends StatefulWidget {
  const _SystemPage();

  @override
  State<_SystemPage> createState() => _SystemPageState();
}

class _SystemPageState extends State<_SystemPage> {
  final baseFee = TextEditingController();
  final includedRadius = TextEditingController();
  final stepDistance = TextEditingController();
  final stepFee = TextEditingController();

  bool loadingRates = true;
  bool savingRates = false;
  String? rateError;

  @override
  void initState() {
    super.initState();
    _loadRates();
  }

  @override
  void dispose() {
    baseFee.dispose();
    includedRadius.dispose();
    stepDistance.dispose();
    stepFee.dispose();
    super.dispose();
  }

  Future<void> _loadRates() async {
    if (mounted) {
      setState(() {
        loadingRates = true;
        rateError = null;
      });
    }
    try {
      final rates = await Backend.deliveryRateSettings();

      baseFee.text = _cleanRate(rates['base_fee']);
      includedRadius.text = _cleanRate(rates['included_radius_km']);
      stepDistance.text = _cleanRate(rates['step_distance_km']);
      stepFee.text = _cleanRate(rates['step_fee']);
    } catch (e) {
      rateError = e.toString();
    } finally {
      if (mounted) setState(() => loadingRates = false);
    }
  }

  String _cleanRate(dynamic value) {
    final n = double.tryParse(value?.toString() ?? '') ?? 0;
    return n == n.roundToDouble() ? n.toInt().toString() : n.toStringAsFixed(2);
  }

  Future<void> _saveRates() async {
    final base = double.tryParse(baseFee.text.trim());
    final included = double.tryParse(includedRadius.text.trim());
    final stepKm = double.tryParse(stepDistance.text.trim());
    final step = double.tryParse(stepFee.text.trim());

    if (base == null ||
        included == null ||
        stepKm == null ||
        step == null ||
        base < 0 ||
        included <= 0 ||
        stepKm <= 0 ||
        step < 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter valid delivery rate values.')),
      );
      return;
    }

    setState(() => savingRates = true);
    try {
      await Backend.adminSaveDeliveryRates(
        baseFee: base,
        includedRadiusKm: included,
        stepDistanceKm: stepKm,
        stepFee: step,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Delivery rates updated.')),
      );
      await _loadRates();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not save delivery rates: $e')),
      );
    } finally {
      if (mounted) setState(() => savingRates = false);
    }
  }

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 100),
        children: [
          const KPageHeader(
            eyebrow: 'Integration center',
            title: 'App services & settings',
            subtitle:
                'Manage delivery pricing, account security and production integrations from one place.',
            icon: Icons.hub_rounded,
          ),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.delivery_dining_rounded, color: AppTheme.red),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Delivery rate settings',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Distance basis: actual Store / Pabili pickup GPS pin to customer GPS pin (straight-line estimate). Saved rates apply to new orders, including seller self-delivery.',
                  ),
                  const SizedBox(height: 14),
                  if (loadingRates)
                    const Center(child: CircularProgressIndicator())
                  else if (rateError != null)
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Text(
                          'Could not load rates: $rateError',
                          style: const TextStyle(color: Colors.redAccent),
                        ),
                        const SizedBox(height: 8),
                        OutlinedButton.icon(
                          onPressed: _loadRates,
                          icon: const Icon(Icons.refresh_rounded),
                          label: const Text('Try again'),
                        ),
                      ],
                    )
                  else ...[
                    LayoutBuilder(
                      builder: (context, box) {
                        final wide = box.maxWidth >= 720;
                        final fields = [
                          _RateField(
                            controller: baseFee,
                            label: 'Base fee',
                            helper: 'Fee charged inside the included radius',
                            prefixText: '₱ ',
                          ),
                          _RateField(
                            controller: includedRadius,
                            label: 'Included radius',
                            helper: 'Distance covered by the base fee',
                            suffixText: ' km',
                          ),
                          _RateField(
                            controller: stepDistance,
                            label: 'Extra distance step',
                            helper: 'Each started distance step after the radius',
                            suffixText: ' km',
                          ),
                          _RateField(
                            controller: stepFee,
                            label: 'Fee per extra step',
                            helper: 'Amount added for every started step',
                            prefixText: '₱ ',
                          ),
                        ];
                        if (!wide) {
                          return Column(
                            children: [
                              for (final field in fields) ...[
                                field,
                                const SizedBox(height: 10),
                              ],
                            ],
                          );
                        }
                        return Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            for (var i = 0; i < fields.length; i++) ...[
                              Expanded(child: fields[i]),
                              if (i < fields.length - 1)
                                const SizedBox(width: 10),
                            ],
                          ],
                        );
                      },
                    ),
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.all(13),
                      decoration: BoxDecoration(
                        color: AppTheme.softYellow,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Text(
                        'Current rule: ₱${_cleanRate(baseFee.text)} for the first ${_cleanRate(includedRadius.text)} km from pickup to customer, then +₱${_cleanRate(stepFee.text)} for each started ${_cleanRate(stepDistance.text)} km. Applies to new regular and Pabili orders.',
                        style: const TextStyle(
                          color: AppTheme.deepRed,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    FilledButton.icon(
                      onPressed: savingRates ? null : _saveRates,
                      icon: savingRates
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.save_rounded),
                      label: Text(
                        savingRates ? 'Saving…' : 'Save delivery rates',
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.lock_reset_rounded, color: AppTheme.red),
              title: const Text(
                'Change admin password',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
              subtitle: const Text(
                'Verify your current password and set a new sign-in password',
              ),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => showAccountPasswordDialog(context),
            ),
          ),
          const SizedBox(height: 16),
          ...IntegrationService.capabilities.map((item) {
            final active = item['status'] == 'Active';
            return Padding(
              padding: const EdgeInsets.only(bottom: 9),
              child: Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.all(14),
                  leading: Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      color: (active ? const Color(0xFF2E9D63) : Colors.orange)
                          .withValues(alpha: .10),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Icon(
                      active ? Icons.check_circle_rounded : Icons.key_rounded,
                      color: active ? const Color(0xFF2E9D63) : Colors.orange,
                    ),
                  ),
                  title: Text(
                    item['name'] ?? '',
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  subtitle: Text(item['detail'] ?? ''),
                  trailing: KStatusPill(
                    text: item['status'] ?? '',
                    color: active ? const Color(0xFF2E9D63) : Colors.orange,
                  ),
                ),
              ),
            );
          }),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.softYellow,
              borderRadius: BorderRadius.circular(22),
            ),
            child: const Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.security_rounded, color: AppTheme.deepRed),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'API secrets such as Firebase service credentials or a payment gateway secret must stay server-side. They should never be embedded in the APK.',
                    style: TextStyle(
                      color: AppTheme.deepRed,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      );
}

class _RateField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String helper;
  final String? prefixText;
  final String? suffixText;

  const _RateField({
    required this.controller,
    required this.label,
    required this.helper,
    this.prefixText,
    this.suffixText,
  });

  @override
  Widget build(BuildContext context) => TextField(
        controller: controller,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: InputDecoration(
          labelText: label,
          helperText: helper,
          prefixText: prefixText,
          suffixText: suffixText,
          prefixIcon: Icon(
            prefixText != null ? Icons.payments_outlined : Icons.route_rounded,
          ),
        ),
      );
}

class _ErrorState extends StatelessWidget {
  final String message;
  final Future<void> Function() retry;
  const _ErrorState({required this.message, required this.retry});

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(
                    Icons.error_outline_rounded,
                    size: 46,
                    color: Colors.redAccent,
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Admin dashboard could not load',
                    style: TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(message, textAlign: TextAlign.center),
                  const SizedBox(height: 16),
                  FilledButton.icon(
                    onPressed: retry,
                    icon: const Icon(Icons.refresh_rounded),
                    label: const Text('Try again'),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
}
