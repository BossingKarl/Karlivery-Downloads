import 'package:flutter/material.dart';

import '../../core/modern_ui.dart';
import '../../services/backend.dart';
import '../../theme/app_theme.dart';

class AnnouncementScreen extends StatefulWidget {
  const AnnouncementScreen({super.key});

  @override
  State<AnnouncementScreen> createState() => _AnnouncementScreenState();
}

class _AnnouncementScreenState extends State<AnnouncementScreen> {
  final title = TextEditingController();
  final message = TextEditingController();

  // No audience selected by default. Every send needs explicit role selection.
  final Set<String> selectedRoles = <String>{};
  static const Map<String, String> roleLabels = {
    'customer': 'Customers',
    'store_owner': 'Sellers',
    'rider': 'Riders',
    'admin': 'Admins',
  };
  bool sending = false;
  int? lastRecipients;
  String? lastPushStatus;
  String? lastAudience;

  @override
  void dispose() {
    title.dispose();
    message.dispose();
    super.dispose();
  }

  String get audienceLabel => selectedRoles.isEmpty
      ? 'Choose recipients'
      : roleLabels.entries
          .where((entry) => selectedRoles.contains(entry.key))
          .map((entry) => entry.value)
          .join(', ');

  Future<void> send() async {
    if (sending) return;
    final titleText = title.text.trim();
    final messageText = message.text.trim();
    final roles = roleLabels.keys.where(selectedRoles.contains).toList();

    if (titleText.isEmpty || messageText.isEmpty || roles.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Choose at least one recipient role, and enter a title and message.'),
        ),
      );
      return;
    }

    setState(() => sending = true);
    try {
      // The server, not the mobile UI, counts the selected active roles.
      final preview = await Backend.previewAnnouncementAudience(targetRoles: roles);
      if (!mounted) return;
      final recipients = int.tryParse('${preview['recipients'] ?? 0}') ?? 0;
      final serverRoles = (preview['target_roles'] as List?)
          ?.map((value) => value.toString()).toList() ?? <String>[];
      if (serverRoles.join('|') != roles.join('|')) {
        throw StateError('Recipient audience mismatch. Nothing was sent.');
      }
      final counts = preview['recipients_by_role'];
      final token = preview['preview_token']?.toString() ?? '';
      if (token.isEmpty) {
        throw StateError('Unable to confirm the recipients. Nothing was sent.');
      }
      if (recipients == 0) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No active accounts match the selected roles.')),
        );
        return;
      }

      final confirm = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Confirm announcement audience'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Only the selected active roles will receive this announcement.'),
                const SizedBox(height: 12),
                ...roleLabels.entries.where((entry) => roles.contains(entry.key)).map(
                  (entry) => Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      children: [
                        const Icon(Icons.check_circle_outline_rounded, size: 19),
                        const SizedBox(width: 8),
                        Expanded(child: Text(entry.value)),
                        Text('${counts is Map ? counts[entry.key] ?? 0 : 0}'),
                      ],
                    ),
                  ),
                ),
                const Divider(),
                Text('$recipients matching inbox recipient(s)',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                if (roles.length == 4) ...[
                  const SizedBox(height: 10),
                  const Text('All four roles selected: this will reach everyone who is active.'),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Send to selected roles'),
            ),
          ],
        ),
      );
      if (!mounted || confirm != true) return;

      final result = await Backend.sendAnnouncement(
        title: titleText,
        message: messageText,
        targetRoles: roles,
        previewToken: token,
      );
      if (!mounted) return;

      final confirmedRoles = (result['target_roles'] as List?)
          ?.map((value) => value.toString()).toList() ?? <String>[];
      if (confirmedRoles.join('|') != roles.join('|')) {
        throw StateError('Announcement response audience mismatch. Check inbox before retrying.');
      }
      final savedRecipients = int.tryParse('${result['recipients'] ?? 0}') ?? 0;
      final provider = result['provider'];
      String pushStatus = 'Push delivery requested for subscribed devices.';
      if (provider is Map && provider['skipped'] != null) {
        pushStatus = provider['skipped'].toString();
      } else if (provider is Map && provider['error'] != null) {
        pushStatus = 'Inbox delivery succeeded. Push warning: ${provider['error']}';
      }

      setState(() {
        lastRecipients = savedRecipients;
        lastAudience = roles.map((role) => roleLabels[role]).join(', ');
        lastPushStatus = pushStatus;
        selectedRoles.clear();
      });
      title.clear();
      message.clear();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Saved in $savedRecipients selected-role inbox(es).')),
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Announcement failed: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    final horizontal = width >= 760 ? 26.0 : 16.0;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Announcements'),
      ),
      body: SafeArea(
        top: false,
        child: ListView(
          padding: EdgeInsets.fromLTRB(horizontal, 12, horizontal, 34),
          children: [
            KPageHeader(
              eyebrow: 'ADMIN BROADCAST',
              title: 'Send a Karlivery announcement',
              subtitle:
                  'Every active account in the selected audience gets an inbox message. Push is best-effort for subscribed devices; delivery statistics appear after sending.',
              icon: Icons.campaign_rounded,
              trailing: const KStatusPill(
                text: 'Reliable inbox delivery',
                color: Colors.white,
                icon: Icons.verified_rounded,
              ),
            ),
            const SizedBox(height: 18),
            LayoutBuilder(
              builder: (context, constraints) {
                final twoColumns = constraints.maxWidth >= 900;
                final composer = KPremiumPanel(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const KSectionTitle(
                        title: 'Compose announcement',
                        subtitle: 'Keep it concise, clear and useful.',
                      ),
                      const SizedBox(height: 20),
                      Text(
                        'Select recipients by role',
                        style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: roleLabels.entries.map((entry) => FilterChip(
                          label: Text(entry.value),
                          avatar: Icon(
                            entry.key == 'customer' ? Icons.person_rounded
                                : entry.key == 'store_owner' ? Icons.storefront_rounded
                                : entry.key == 'rider' ? Icons.two_wheeler_rounded
                                : Icons.admin_panel_settings_rounded,
                            size: 18,
                          ),
                          selected: selectedRoles.contains(entry.key),
                          onSelected: sending ? null : (selected) => setState(() {
                            if (selected) {
                              selectedRoles.add(entry.key);
                            } else {
                              selectedRoles.remove(entry.key);
                            }
                          }),
                        )).toList(),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        selectedRoles.isEmpty
                            ? 'No roles selected. Nothing will be sent until you choose.'
                            : 'Selected: $audienceLabel. You will review recipient counts before sending.',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: title,
                        maxLength: 80,
                        textInputAction: TextInputAction.next,
                        decoration: const InputDecoration(
                          labelText: 'Announcement title',
                          hintText: 'Example: Delivery update',
                          prefixIcon: Icon(Icons.title_rounded),
                        ),
                      ),
                      const SizedBox(height: 8),
                      TextField(
                        controller: message,
                        maxLength: 500,
                        minLines: 5,
                        maxLines: 8,
                        decoration: const InputDecoration(
                          labelText: 'Message',
                          hintText: 'Write the update recipients need to know…',
                          alignLabelWithHint: true,
                          prefixIcon: Icon(Icons.message_rounded),
                        ),
                      ),
                      const SizedBox(height: 16),
                      FilledButton.icon(
                        onPressed: sending ? null : send,
                        icon: sending
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2.2,
                                  color: Colors.white,
                                ),
                              )
                            : const Icon(Icons.send_rounded),
                        label: Text(sending ? 'Sending…' : 'Send announcement'),
                      ),
                    ],
                  ),
                );

                final info = Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    KPremiumPanel(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const KSectionTitle(
                            title: 'Delivery behavior',
                            subtitle: 'How Karlivery makes announcements dependable.',
                          ),
                          const SizedBox(height: 18),
                          _DeliveryRow(
                            icon: Icons.inbox_rounded,
                            title: 'Karlivery inbox',
                            text:
                                'Saved directly to every matching active account. This works even when push is unavailable.',
                          ),
                          const SizedBox(height: 12),
                          _DeliveryRow(
                            icon: Icons.notifications_active_rounded,
                            title: 'Phone / web push',
                            text:
                                'Sent through OneSignal to devices that have registered and granted notification permission.',
                          ),
                          const SizedBox(height: 12),
                          _DeliveryRow(
                            icon: Icons.sync_rounded,
                            title: 'Live notification center',
                            text:
                                'With SQL 18 applied, open Karlivery sessions receive new inbox items through Supabase Realtime.',
                          ),
                        ],
                      ),
                    ),
                    if (lastRecipients != null) ...[
                      const SizedBox(height: 14),
                      KPremiumPanel(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const KSectionTitle(
                              title: 'Last send result',
                              subtitle: 'Confirmation from the Karlivery notification service.',
                            ),
                            const SizedBox(height: 18),
                            KMetricGrid(
                              children: [
                                KMetricCard(
                                  label: 'Inbox recipients',
                                  value: '$lastRecipients',
                                  icon: Icons.people_alt_rounded,
                                ),
                                KMetricCard(
                                  label: 'Audience',
                                  value: lastAudience ?? audienceLabel,
                                  icon: Icons.groups_rounded,
                                  accent: AppTheme.deepRed,
                                ),
                              ],
                            ),
                            if (lastPushStatus != null) ...[
                              const SizedBox(height: 14),
                              Text(
                                lastPushStatus!,
                                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                      fontWeight: FontWeight.w700,
                                    ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ],
                  ],
                );

                if (!twoColumns) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [composer, const SizedBox(height: 14), info],
                  );
                }

                return Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(flex: 6, child: composer),
                    const SizedBox(width: 16),
                    Expanded(flex: 5, child: info),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _DeliveryRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;

  const _DeliveryRow({
    required this.icon,
    required this.title,
    required this.text,
  });

  @override
  Widget build(BuildContext context) => Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          KIconTile(icon: icon, size: 42),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                ),
                const SizedBox(height: 3),
                Text(text, style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
        ],
      );
}
