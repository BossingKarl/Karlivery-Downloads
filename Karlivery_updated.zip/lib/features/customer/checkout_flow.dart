import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import '../../core/utils.dart';
import '../../services/backend.dart';
import '../../services/cart.dart';
import '../../theme/app_theme.dart';
import 'address_picker_screen.dart';
import '../../design_system/k_network_image.dart';

// Prevent simultaneous order submissions from multiple checkout surfaces.
bool _checkoutSubmissionInProgress = false;

class CheckoutResult {
  final String orderId;
  final String paymentMethod;
  final bool needsPaymentProof;

  const CheckoutResult({
    required this.orderId,
    required this.paymentMethod,
    this.needsPaymentProof = false,
  });
}

Future<CheckoutResult?> showKarliveryCheckout(
  BuildContext context, {
  required CartService cart,
}) async {
  if (cart.storeId == null || cart.lines.isEmpty || _checkoutSubmissionInProgress) return null;
  final checkoutStoreId = cart.storeId!;
  final checkoutItems = cart.toOrderItems();
  final checkoutSubtotal = cart.subtotal;

  final store = await Backend.storeById(cart.storeId!);
  if (!context.mounted || store == null) return null;

  if (store['is_open'] != true) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          store['schedule_enabled'] == true
              ? 'This store is currently outside its opening hours.'
              : 'This store is currently closed.',
        ),
      ),
    );
    return null;
  }

  final deliveryProvider = await Backend.storeDeliveryProvider(cart.storeId!);
  if (!context.mounted) return null;
  final sellerDelivers = deliveryProvider == 'seller';
  final gcashNumber = (store['gcash_number'] ?? '').toString();
  final gcashQr = (store['gcash_qr_url'] ?? '').toString();
  final gcashReady = gcashNumber.isNotEmpty && gcashQr.isNotEmpty;

  var addresses = await Backend.myAddresses();
  if (!context.mounted) return null;

  var step = 0;
  var fulfillment = 'delivery';
  var paymentMethod = 'cod';
  String? addressId =
      addresses.isEmpty ? null : addresses.first['id'].toString();
  double? fee;
  String? feeError;
  var calculating = false;
  var feeSequence = 0;
  var sheetActive = true;
  double? storeToCustomerKm() {
    if (fulfillment == 'pickup' || addressId == null) return null;
    final chosen = addresses.where((a) => a['id']?.toString() == addressId).toList();
    if (chosen.isEmpty) return null;
    final destination = chosen.first;
    double? asDouble(dynamic v) => v is num ? v.toDouble() : double.tryParse(v?.toString() ?? '');
    final a = asDouble(store['latitude']);
    final b = asDouble(store['longitude']);
    final c = asDouble(destination['latitude']);
    final d = asDouble(destination['longitude']);
    if (a == null || b == null || c == null || d == null ||
        a.abs() > 90 || c.abs() > 90 || b.abs() > 180 || d.abs() > 180) {
      return null;
    }
    return Geolocator.distanceBetween(a, b, c, d) / 1000;
  }
  var utensils = false;
  var placing = false;
  var gcashSentConfirmed = false;

  final notes = TextEditingController();
  final refNo = TextEditingController();
  Uint8List? proofBytes;
  String proofExt = 'jpg';

  Future<void> recalc(void Function(void Function()) setLocal) async {
    final request = ++feeSequence;
    final selectedAddress = addressId;
    if (fulfillment == 'pickup') {
      if (!sheetActive) return;
      setLocal(() {
        fee = 0;
        feeError = null;
        calculating = false;
      });
      return;
    }
    if (selectedAddress == null) {
      setLocal(() {
        fee = null;
        calculating = false;
        feeError = 'Choose a delivery address before continuing.';
      });
      return;
    }

    setLocal(() {
      fee = null;
      feeError = null;
      calculating = true;
    });
    try {
      final value = await Backend.deliveryFee(
        storeId: cart.storeId!,
        addressId: selectedAddress,
      );
      if (!context.mounted || !sheetActive || request != feeSequence) return;
      setLocal(() {
        fee = value;
        calculating = false;
        feeError = null;
      });
    } catch (_) {
      if (!context.mounted || !sheetActive || request != feeSequence) return;
      setLocal(() {
        fee = null;
        calculating = false;
        feeError = 'Could not calculate the delivery fee. Check your GPS address or connection and retry.';
      });
    }
  }

  if (addressId != null) {
    try {
      fee = await Backend.deliveryFee(
        storeId: cart.storeId!,
        addressId: addressId,
      );
    } catch (_) {
      feeError = 'Could not calculate the delivery fee. Please retry.';
    }
  }

  if (!context.mounted) return null;

  final confirmed = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    showDragHandle: true,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setLocal) {
        final validAddress = fulfillment == 'pickup' || addressId != null;
        final validGcash = paymentMethod != 'gcash' ||
            (gcashReady &&
                proofBytes != null &&
                refNo.text.trim().isNotEmpty &&
                gcashSentConfirmed);
        final validFee = fulfillment == 'pickup' ||
            (fee != null && feeError == null && !calculating);
        final canContinue = switch (step) {
          0 => validAddress && validFee,
          1 => validGcash,
          _ => validFee,
        };

        Widget currentStep() {
          if (step == 0) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _StepTitle(
                  icon: Icons.delivery_dining_rounded,
                  title: 'How will you get your order?',
                  subtitle: sellerDelivers
                      ? 'This store uses its own rider. The standard Karlivery fee formula still applies.'
                      : 'Choose delivery or pick-up first. Karlivery will calculate the correct fee before you continue.',
                ),
                const SizedBox(height: 16),
                SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(
                      value: 'delivery',
                      icon: Icon(Icons.delivery_dining_rounded),
                      label: Text('Delivery'),
                    ),
                    ButtonSegment(
                      value: 'pickup',
                      icon: Icon(Icons.storefront_rounded),
                      label: Text('Pick-up'),
                    ),
                  ],
                  selected: {fulfillment},
                  onSelectionChanged: (value) async {
                    setLocal(() => fulfillment = value.first);
                    await recalc(setLocal);
                  },
                ),
                if (fulfillment == 'delivery') ...[
                  const SizedBox(height: 16),
                  if (addresses.isEmpty)
                    _ActionInfoCard(
                      icon: Icons.add_location_alt_rounded,
                      title: 'Add a delivery address',
                      message: 'Use GPS and the map pin so the seller, rider, and delivery-fee calculation use the same location.',
                      actionLabel: 'Add address',
                      onAction: () async {
                        final saved = await Navigator.of(ctx).push<bool>(
                          MaterialPageRoute(
                            builder: (_) => const AddressPickerScreen(),
                          ),
                        );
                        if (saved == true) {
                          addresses = await Backend.myAddresses();
                          if (addresses.isNotEmpty) {
                            addressId = addresses.first['id'].toString();
                            await recalc(setLocal);
                          }
                          setLocal(() {});
                        }
                      },
                    )
                  else ...[
                    DropdownButtonFormField<String>(
                      initialValue: addressId,
                      decoration: const InputDecoration(
                        labelText: 'Delivery address',
                        prefixIcon: Icon(Icons.pin_drop_rounded),
                      ),
                      items: addresses
                          .map(
                            (a) => DropdownMenuItem(
                              value: a['id'].toString(),
                              child: Text(
                                '${a['label'] ?? 'Address'} • ${a['barangay'] ?? ''}',
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          )
                          .toList(),
                      onChanged: (value) async {
                        addressId = value;
                        await recalc(setLocal);
                      },
                    ),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: TextButton.icon(
                        onPressed: () async {
                          final saved = await Navigator.of(ctx).push<bool>(
                            MaterialPageRoute(
                              builder: (_) => const AddressPickerScreen(),
                            ),
                          );
                          if (saved == true) {
                            addresses = await Backend.myAddresses();
                            if (addresses.isNotEmpty) {
                              addressId = addresses.first['id'].toString();
                              await recalc(setLocal);
                            }
                            setLocal(() {});
                          }
                        },
                        icon: const Icon(Icons.add_location_alt_rounded),
                        label: const Text('Add another address'),
                      ),
                    ),
                  ],
                ],
                const SizedBox(height: 14),
                _PriceSummary(
                  subtotal: cart.subtotal,
                  fee: fee,
                  fulfillment: fulfillment,
                  calculating: calculating,
                ),
                if (fulfillment == 'delivery' && feeError != null) ...[
                  const SizedBox(height: 10),
                  _ActionInfoCard(
                    icon: Icons.wifi_off_rounded,
                    title: 'Delivery fee unavailable',
                    message: feeError!,
                    actionLabel: 'Retry calculation',
                    onAction: calculating ? null : () => recalc(setLocal),
                  ),
                ],
              ],
            );
          }

          if (step == 1) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const _StepTitle(
                  icon: Icons.payments_rounded,
                  title: 'Choose your payment',
                  subtitle: 'COD is paid when the order arrives. GCash is manually verified by the restaurant using your reference number and screenshot.',
                ),
                const SizedBox(height: 16),
                SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(
                      value: 'cod',
                      icon: Icon(Icons.payments_outlined),
                      label: Text('COD'),
                    ),
                    ButtonSegment(
                      value: 'gcash',
                      icon: Icon(Icons.qr_code_2_rounded),
                      label: Text('GCash'),
                    ),
                  ],
                  selected: {paymentMethod},
                  onSelectionChanged: (value) => setLocal(() {
                    paymentMethod = value.first;
                    if (paymentMethod != 'gcash') gcashSentConfirmed = false;
                  }),
                ),
                const SizedBox(height: 16),
                if (paymentMethod == 'cod')
                  const _ActionInfoCard(
                    icon: Icons.handshake_rounded,
                    title: 'Cash on Delivery',
                    message: 'Prepare the exact amount when possible. The order total shown on the next step is what you should expect to pay.',
                  )
                else if (!gcashReady)
                  _ActionInfoCard(
                    icon: Icons.info_outline_rounded,
                    title: 'GCash is not available for this store',
                    message: 'This seller has not completed their GCash setup yet. Choose COD to continue.',
                    actionLabel: 'Use COD',
                    onAction: () =>
                        setLocal(() => paymentMethod = 'cod'),
                  )
                else ...[
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          const Text(
                            'Scan or send to this GCash account',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 16,
                            ),
                          ),
                          const SizedBox(height: 8),
                          SelectableText(
                            gcashNumber,
                            style: const TextStyle(
                              fontSize: 19,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 12),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(20),
                            child: KNetImage(
                              gcashQr,
                              height: 210,
                              fit: BoxFit.contain,
                              errorBuilder: (_, _, _) => const SizedBox(
                                height: 130,
                                child: Center(
                                  child: Text('GCash QR could not be loaded.'),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: refNo,
                    onChanged: (_) => setLocal(() => gcashSentConfirmed = false),
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'GCash reference number',
                      helperText: 'Required for seller verification',
                      prefixIcon: Icon(Icons.numbers_rounded),
                    ),
                  ),
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                    onPressed: () async {
                      final picked = await FilePicker.platform.pickFiles(
                        type: FileType.image,
                        withData: true,
                      );
                      if (picked == null || picked.files.isEmpty) return;
                      final file = picked.files.single;
                      if (!ctx.mounted) return;
                      final extension = file.name.contains('.')
                          ? file.name.split('.').last.toLowerCase()
                          : '';
                      const accepted = {'jpg', 'jpeg', 'png', 'webp'};
                      if (!accepted.contains(extension) ||
                          file.bytes == null || file.bytes!.isEmpty ||
                          file.bytes!.lengthInBytes > 8 * 1024 * 1024) {
                        ScaffoldMessenger.of(ctx).showSnackBar(
                          const SnackBar(content: Text(
                            'Choose a JPG, PNG, or WebP screenshot under 8 MB.',
                          )),
                        );
                        return;
                      }
                      setLocal(() {
                        proofBytes = file.bytes;
                        proofExt = extension;
                        gcashSentConfirmed = false;
                      });
                    },
                    icon: Icon(
                      proofBytes == null
                          ? Icons.upload_rounded
                          : Icons.check_circle_rounded,
                    ),
                    label: Text(
                      proofBytes == null
                          ? 'Upload GCash screenshot'
                          : 'Screenshot selected ✓',
                    ),
                  ),
                  const SizedBox(height: 8),
                  CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    value: gcashSentConfirmed,
                    onChanged: proofBytes == null || refNo.text.trim().isEmpty
                        ? null
                        : (value) => setLocal(
                              () => gcashSentConfirmed = value == true,
                            ),
                    controlAffinity: ListTileControlAffinity.leading,
                    title: const Text(
                      'I confirm that I sent this GCash payment',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                    subtitle: const Text(
                      'The seller will separately verify that the payment was received. You can use Order Chat if either side needs clarification.',
                    ),
                  ),
                ],
              ],
            );
          }

          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const _StepTitle(
                icon: Icons.fact_check_rounded,
                title: 'Review before placing',
                subtitle: 'Check the fulfillment method, payment method, total, and optional delivery notes. Nothing is submitted until you tap Place order.',
              ),
              const SizedBox(height: 16),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(17),
                  child: Column(
                    children: [
                      _SummaryLine(
                        label: 'Restaurant',
                        value: cart.storeName ?? 'Karlivery Store',
                      ),
                      const SizedBox(height: 8),
                      _SummaryLine(
                        label: 'Fulfillment',
                        value: fulfillment == 'pickup' ? 'Pick-up' : 'Delivery',
                      ),
                      const SizedBox(height: 8),
                      _SummaryLine(
                        label: 'Payment',
                        value: paymentMethod == 'gcash' ? 'GCash' : 'Cash on Delivery',
                      ),
                      const Divider(height: 24),
                      _SummaryLine(
                        label: 'Food subtotal',
                        value: money(cart.subtotal),
                      ),
                      const SizedBox(height: 8),
                      if (storeToCustomerKm() != null) ...[
                        _SummaryLine(
                          label: 'Store → customer (GPS)',
                          value: '${storeToCustomerKm()!.toStringAsFixed(2)} km',
                        ),
                        const SizedBox(height: 8),
                      ],
                      _SummaryLine(
                        label: fulfillment == 'pickup'
                            ? 'Pick-up fee'
                            : 'Delivery fee',
                        value: fee == null ? 'Unavailable' : money(fee),
                      ),
                      if (fulfillment == 'delivery')
                        const Padding(
                          padding: EdgeInsets.only(top: 5),
                          child: Text('GPS straight-line distance, not driving-route kilometers.',
                            style: TextStyle(fontSize: 12, color: AppTheme.muted)),
                        ),
                      const Divider(height: 24),
                      _SummaryLine(
                        label: 'Total',
                        value: fee == null ? 'Unavailable' : money(cart.subtotal + fee!),
                        strong: true,
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: utensils,
                onChanged: (value) => setLocal(() => utensils = value),
                secondary: const Icon(Icons.flatware_rounded),
                title: const Text(
                  'Include utensils?',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
                subtitle: Text(
                  utensils
                      ? 'Yes, please include utensils.'
                      : 'No utensils needed — less waste.',
                ),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: notes,
                minLines: 2,
                maxLines: 4,
                decoration: const InputDecoration(
                  labelText: 'Optional notes',
                  hintText: 'Less spicy, landmark, call when outside…',
                  prefixIcon: Icon(Icons.notes_rounded),
                ),
              ),
            ],
          );
        }

        return SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(
            18,
            4,
            18,
            MediaQuery.of(ctx).viewInsets.bottom + 26,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text(
                'Secure checkout',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 24,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Step ${step + 1} of 3',
                style: const TextStyle(
                  color: AppTheme.muted,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 13),
              _CheckoutProgress(step: step),
              const SizedBox(height: 22),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 180),
                child: KeyedSubtree(
                  key: ValueKey(step),
                  child: currentStep(),
                ),
              ),
              const SizedBox(height: 22),
              Row(
                children: [
                  if (step > 0) ...[
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: placing
                            ? null
                            : () => setLocal(() => step--),
                        icon: const Icon(Icons.arrow_back_rounded),
                        label: const Text('Back'),
                      ),
                    ),
                    const SizedBox(width: 10),
                  ],
                  Expanded(
                    flex: step > 0 ? 2 : 1,
                    child: FilledButton.icon(
                      onPressed: !canContinue || placing
                          ? null
                          : () {
                              if (step < 2) {
                                setLocal(() => step++);
                              } else {
                                Navigator.pop(ctx, true);
                              }
                            },
                      icon: Icon(
                        step == 2
                            ? Icons.check_circle_rounded
                            : Icons.arrow_forward_rounded,
                      ),
                      label: Text(
                        step == 2 ? 'Place order' : 'Continue',
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 7),
              Text(
                step == 0
                    ? 'You can still go back and change your basket.'
                    : step == 1
                        ? 'Payment details are not submitted until the final step.'
                        : 'By placing the order, it becomes visible to the restaurant immediately.',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: AppTheme.muted,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        );
      },
    ),
  );

  sheetActive = false;
  feeSequence++;
  if (confirmed != true) {
    notes.dispose();
    refNo.dispose();
    return null;
  }

  // A changed basket must never be silently submitted using stale totals.
  if (cart.storeId != checkoutStoreId ||
      cart.subtotal != checkoutSubtotal ||
      cart.toOrderItems().toString() != checkoutItems.toString()) {
    notes.dispose();
    refNo.dispose();
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Your basket changed. Please review checkout again.'),
      ));
    }
    return null;
  }
  if (_checkoutSubmissionInProgress) {
    notes.dispose();
    refNo.dispose();
    return null;
  }
  _checkoutSubmissionInProgress = true;
  try {
    placing = true;
    final order = await Backend.createOrder(
      storeId: checkoutStoreId,
      addressId: fulfillment == 'delivery' ? addressId : null,
      fulfillment: fulfillment,
      paymentMethod: paymentMethod,
      items: checkoutItems,
      notes: notes.text,
      utensils: utensils,
    );

    final orderId = order['order_id'].toString();

    if (paymentMethod == 'gcash') {
      try {
        final proofPath = await Backend.uploadPaymentProof(
          orderId: orderId,
          bytes: proofBytes!,
          extension: proofExt,
        );
        await Backend.submitPaymentProof(
          orderId: orderId,
          proofPath: proofPath,
          referenceNo: refNo.text,
        );
        await Backend.customerConfirmGcashSent(orderId);
      } catch (_) {
        // The order already exists; NEVER invite the customer to place it again.
        // Order details supports uploading/replacing proof and confirming payment.
        return CheckoutResult(
          orderId: orderId,
          paymentMethod: paymentMethod,
          needsPaymentProof: true,
        );
      }
    }

    return CheckoutResult(
      orderId: orderId,
      paymentMethod: paymentMethod,
    );
  } finally {
    _checkoutSubmissionInProgress = false;
    notes.dispose();
    refNo.dispose();
  }
}

class _CheckoutProgress extends StatelessWidget {
  final int step;

  const _CheckoutProgress({required this.step});

  @override
  Widget build(BuildContext context) {
    const items = [
      ('Delivery', Icons.delivery_dining_rounded),
      ('Payment', Icons.payments_rounded),
      ('Review', Icons.fact_check_rounded),
    ];

    return Row(
      children: [
        for (var i = 0; i < items.length; i++) ...[
          Expanded(
            child: Column(
              children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: i <= step ? AppTheme.red : AppTheme.softYellow,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Icon(
                    i < step ? Icons.check_rounded : items[i].$2,
                    color: i <= step ? Colors.white : AppTheme.deepRed,
                    size: 21,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  items[i].$1,
                  style: TextStyle(
                    color: i <= step ? AppTheme.ink : AppTheme.muted,
                    fontWeight: i == step ? FontWeight.w700 : FontWeight.w700,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          if (i < items.length - 1)
            Expanded(
              child: Divider(
                thickness: 2,
                color: i < step ? AppTheme.red : AppTheme.line,
              ),
            ),
        ],
      ],
    );
  }
}

class _StepTitle extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const _StepTitle({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) => Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: AppTheme.softRed,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(icon, color: AppTheme.red),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 18,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: AppTheme.muted,
                    height: 1.35,
                  ),
                ),
              ],
            ),
          ),
        ],
      );
}

class _ActionInfoCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;
  final String? actionLabel;
  final VoidCallback? onAction;

  const _ActionInfoCard({
    required this.icon,
    required this.title,
    required this.message,
    this.actionLabel,
    this.onAction,
  });

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.softYellow,
          borderRadius: BorderRadius.circular(22),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: AppTheme.deepRed, size: 26),
            const SizedBox(width: 11),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 4),
                  Text(message, style: const TextStyle(height: 1.35)),
                  if (actionLabel != null && onAction != null) ...[
                    const SizedBox(height: 8),
                    TextButton(
                      onPressed: onAction,
                      child: Text(actionLabel!),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      );
}

class _PriceSummary extends StatelessWidget {
  final double subtotal;
  final double? fee;
  final String fulfillment;
  final bool calculating;

  const _PriceSummary({
    required this.subtotal,
    required this.fee,
    required this.fulfillment,
    required this.calculating,
  });

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(17),
          child: Column(
            children: [
              _SummaryLine(label: 'Food subtotal', value: money(subtotal)),
              const SizedBox(height: 8),
              _SummaryLine(
                label: fulfillment == 'pickup' ? 'Pick-up fee' : 'Delivery fee',
                value: calculating ? 'Calculating…' : fee == null ? 'Unavailable' : money(fee),
              ),
              const Divider(height: 22),
              _SummaryLine(
                label: 'Estimated total',
                value: calculating || fee == null ? '—' : money(subtotal + fee!),
                strong: true,
              ),
            ],
          ),
        ),
      );
}

class _SummaryLine extends StatelessWidget {
  final String label;
  final String value;
  final bool strong;

  const _SummaryLine({
    required this.label,
    required this.value,
    this.strong = false,
  });

  @override
  Widget build(BuildContext context) => Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontWeight: strong ? FontWeight.w700 : FontWeight.w700,
              ),
            ),
          ),
          Text(
            value,
            textAlign: TextAlign.end,
            style: TextStyle(
              color: strong ? AppTheme.red : null,
              fontWeight: FontWeight.w700,
              fontSize: strong ? 18 : null,
            ),
          ),
        ],
      );
}
