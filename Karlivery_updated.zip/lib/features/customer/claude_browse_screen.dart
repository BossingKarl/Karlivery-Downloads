import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/brand.dart';
import '../../design_system/claude_cards.dart';
import '../../design_system/claude_design.dart';
import '../../services/backend.dart';
import '../../services/cart.dart';

class ClaudeBrowseScreen extends StatefulWidget {
  const ClaudeBrowseScreen({super.key});

  @override
  State<ClaudeBrowseScreen> createState() => _ClaudeBrowseScreenState();
}

class _ClaudeBrowseScreenState extends State<ClaudeBrowseScreen> {
  final TextEditingController _searchController = TextEditingController();
  List<Map<String, dynamic>> stores = [];
  List<Map<String, dynamic>> featured = [];
  bool loading = true;
  String? loadError;
  String query = '';
  String sort = 'popular';
  String? selectedCategory;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      loadError = null;
    });
    try {
      final results = await Future.wait([
        Backend.approvedStores(),
        Backend.featuredProducts(limit: 16),
      ]);
      stores = results[0];
      featured = results[1];
    } catch (error) {
      loadError = 'Unable to load restaurants. Please try again.';
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  List<Map<String, dynamic>> get visibleStores {
    final q = query.trim().toLowerCase();
    var result = stores.where((s) {
      if (q.isEmpty) return true;
      return '${s['name']} ${s['barangay']} ${s['description']}'
          .toLowerCase()
          .contains(q);
    }).toList();

    if (selectedCategory != null) {
      result = result
          .where(
              (s) => s['category']?.toString().contains(selectedCategory!) ?? false)
          .toList();
    }

    double getNum(Map<String, dynamic> m, String key) =>
        double.tryParse(m[key]?.toString() ?? '') ?? 0;

    switch (sort) {
      case 'rating':
        result.sort((a, b) =>
            getNum(b, 'rating_avg').compareTo(getNum(a, 'rating_avg')));
        break;
      case 'fastest':
        result.sort((a, b) =>
            getNum(a, 'eta_min_minutes')
                .compareTo(getNum(b, 'eta_min_minutes')));
        break;
      default:
        result.sort((a, b) =>
            getNum(b, 'completed_orders')
                .compareTo(getNum(a, 'completed_orders')));
    }
    return result;
  }

  @override
  Widget build(BuildContext context) => Theme(
    data: claudeTheme(),
    child: Scaffold(
      backgroundColor: ClaudeColors.surface,
      appBar: AppBar(
        backgroundColor: ClaudeColors.background,
        elevation: 0,
        title: const KarliveryWordmark(compact: true),
        actions: [
          IconButton(
            icon: const Icon(Icons.help_outline_rounded),
            onPressed: () => context.push('/help?role=customer'),
            tooltip: 'Help',
          ),
          AnimatedBuilder(
            animation: CartService.instance,
            builder: (_, __) => IconButton(
              icon: Badge(
                isLabelVisible: CartService.instance.count > 0,
                label: Text('${CartService.instance.count}'),
                child: const Icon(Icons.shopping_bag_outlined),
              ),
              onPressed: () => context.push('/cart'),
              tooltip: 'Basket',
            ),
          ),
          TextButton(
            onPressed: () => Backend.user == null
                ? context.push('/login')
                : context.go('/splash'),
            child: Text(Backend.user == null ? 'Sign in' : 'Account'),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : loadError != null
              ? _buildErrorState()
              : RefreshIndicator(
                  onRefresh: _load,
                  color: ClaudeColors.primary,
                  child: CustomScrollView(
                    slivers: [
                      /// Search bar
                      SliverToBoxAdapter(
                        child: ClaudeSearchBar(
                          controller: _searchController,
                          onChanged: (v) => setState(() => query = v),
                          placeholder: 'Search restaurants or dishes',
                          onFilterTap: _showFilters,
                        ),
                      ),

                      /// Hero section
                      SliverToBoxAdapter(
                        child: _buildHeroSection(),
                      ),

                      /// Category buttons
                      SliverToBoxAdapter(
                        child: _buildCategories(),
                      ),

                      /// Featured section
                      if (featured.isNotEmpty) ...[
                        SliverToBoxAdapter(
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(
                              ClaudeSpacing.lg,
                              ClaudeSpacing.xxl,
                              ClaudeSpacing.lg,
                              ClaudeSpacing.lg,
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Curated for you',
                                  style: ClaudeTypography.headingLarge
                                      .copyWith(color: ClaudeColors.text),
                                ),
                                const SizedBox(height: ClaudeSpacing.md),
                                Text(
                                  'Handpicked dishes from top restaurants',
                                  style: ClaudeTypography.bodySmall.copyWith(
                                    color: ClaudeColors.textSecondary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        SliverToBoxAdapter(
                          child: SizedBox(
                            height: 220,
                            child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              padding: const EdgeInsets.symmetric(
                                horizontal: ClaudeSpacing.lg,
                              ),
                              itemCount: featured.length,
                              itemBuilder: (context, index) {
                                final dish = featured[index];
                                return Padding(
                                  padding:
                                      const EdgeInsets.only(right: ClaudeSpacing.lg),
                                  child: SizedBox(
                                    width: 160,
                                    child: ClaudeDishCard(
                                      name: dish['name'] ?? '',
                                      imageUrl: dish['image_url'],
                                      price: double.tryParse(
                                          dish['price']?.toString() ?? ''),
                                      restaurant: dish['_store_name'],
                                      featured: true,
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        ),
                      ],

                      /// Restaurants section
                      SliverToBoxAdapter(
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(
                            ClaudeSpacing.lg,
                            ClaudeSpacing.xxl,
                            ClaudeSpacing.lg,
                            ClaudeSpacing.lg,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                visibleStores.isEmpty
                                    ? 'No restaurants found'
                                    : 'All restaurants',
                                style: ClaudeTypography.headingLarge
                                    .copyWith(color: ClaudeColors.text),
                              ),
                              if (visibleStores.isNotEmpty) ...[
                                const SizedBox(height: ClaudeSpacing.md),
                                Text(
                                  '${visibleStores.length} places to order from',
                                  style: ClaudeTypography.bodySmall.copyWith(
                                    color: ClaudeColors.textSecondary,
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ),

                      /// Restaurant grid
                      if (visibleStores.isEmpty)
                        SliverToBoxAdapter(
                          child: SizedBox(
                            height: 300,
                            child: Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.restaurant_outlined,
                                    size: 56,
                                    color: ClaudeColors.textTertiary,
                                  ),
                                  const SizedBox(height: ClaudeSpacing.lg),
                                  Text(
                                    'No restaurants match your search',
                                    style: ClaudeTypography.bodyMedium.copyWith(
                                      color: ClaudeColors.textSecondary,
                                    ),
                                  ),
                                  const SizedBox(height: ClaudeSpacing.lg),
                                  TextButton.icon(
                                    onPressed: () {
                                      _searchController.clear();
                                      setState(() => query = '');
                                    },
                                    icon: const Icon(Icons.refresh_outlined),
                                    label: const Text('Clear search'),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        )
                      else
                        SliverPadding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: ClaudeSpacing.lg,
                          ),
                          sliver: SliverGrid(
                            gridDelegate:
                                const SliverGridDelegateWithMaxCrossAxisExtent(
                              maxCrossAxisExtent: 200,
                              childAspectRatio: 0.8,
                              crossAxisSpacing: ClaudeSpacing.lg,
                              mainAxisSpacing: ClaudeSpacing.lg,
                            ),
                            delegate: SliverChildBuilderDelegate(
                              (context, index) {
                                final restaurant = visibleStores[index];
                                return ClaudeRestaurantCard(
                                  id: restaurant['id'] ?? '',
                                  name: restaurant['name'] ?? '',
                                  imageUrl: restaurant['cover_photo_url'],
                                  cuisine: restaurant['category'],
                                  rating: double.tryParse(
                                        restaurant['rating_avg']?.toString() ?? '',
                                      ) ??
                                      4.5,
                                  ratingCount: int.tryParse(
                                        restaurant['rating_count']?.toString() ??
                                            '',
                                      ) ??
                                      0,
                                  deliveryMinutes: int.tryParse(
                                        restaurant['eta_min_minutes']
                                                ?.toString() ??
                                            '',
                                      ) ??
                                      25,
                                  closed: restaurant['status'] == 'closed',
                                  onTap: () => context.push(
                                    '/store/${restaurant['id']}',
                                  ),
                                );
                              },
                              childCount: visibleStores.length,
                            ),
                          ),
                        ),

                      /// Bottom padding
                      const SliverToBoxAdapter(
                        child: SizedBox(height: ClaudeSpacing.massive),
                      ),
                    ],
                  ),
                ),
    ),
  );

  Widget _buildHeroSection() => Container(
    margin: const EdgeInsets.symmetric(
      horizontal: ClaudeSpacing.lg,
      vertical: ClaudeSpacing.xxl,
    ),
    padding: const EdgeInsets.all(ClaudeSpacing.xxl),
    decoration: BoxDecoration(
      color: ClaudeColors.primaryLight,
      borderRadius: BorderRadius.circular(ClaudeRadius.lg),
      border: Border.all(color: ClaudeColors.primary.withValues(alpha: 0.2)),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Discover the finest food',
          style: ClaudeTypography.displayMedium.copyWith(
            color: ClaudeColors.primary,
          ),
        ),
        const SizedBox(height: ClaudeSpacing.lg),
        Text(
          'Explore restaurants curated for quality, taste, and service.',
          style: ClaudeTypography.bodyLarge.copyWith(
            color: ClaudeColors.primary.withValues(alpha: 0.8),
            height: 1.6,
          ),
        ),
        const SizedBox(height: ClaudeSpacing.xxl),
        FilledButton.icon(
          onPressed: () {
            _searchController.clear();
            setState(() => query = '');
          },
          icon: const Icon(Icons.storefront_outlined),
          label: const Text('Browse restaurants'),
        ),
      ],
    ),
  );

  Widget _buildCategories() => Container(
    padding: const EdgeInsets.symmetric(
      horizontal: ClaudeSpacing.lg,
      vertical: ClaudeSpacing.lg,
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Cuisine type',
          style: ClaudeTypography.labelLarge.copyWith(
            color: ClaudeColors.text,
            letterSpacing: 0.3,
          ),
        ),
        const SizedBox(height: ClaudeSpacing.lg),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              ClaudeCategoryButton(
                label: 'All',
                icon: Icons.restaurant_outlined,
                selected: selectedCategory == null,
                onTap: () => setState(() => selectedCategory = null),
              ),
              const SizedBox(width: ClaudeSpacing.md),
              ClaudeCategoryButton(
                label: 'Meals',
                icon: Icons.lunch_dining_outlined,
                selected: selectedCategory == 'Meals',
                onTap: () => setState(() => selectedCategory = 'Meals'),
              ),
              const SizedBox(width: ClaudeSpacing.md),
              ClaudeCategoryButton(
                label: 'Burgers',
                icon: Icons.fastfood_outlined,
                selected: selectedCategory == 'Burgers',
                onTap: () => setState(() => selectedCategory = 'Burgers'),
              ),
              const SizedBox(width: ClaudeSpacing.md),
              ClaudeCategoryButton(
                label: 'Noodles',
                icon: Icons.ramen_dining_outlined,
                selected: selectedCategory == 'Noodles',
                onTap: () => setState(() => selectedCategory = 'Noodles'),
              ),
              const SizedBox(width: ClaudeSpacing.md),
              ClaudeCategoryButton(
                label: 'Drinks',
                icon: Icons.local_cafe_outlined,
                selected: selectedCategory == 'Drinks',
                onTap: () => setState(() => selectedCategory = 'Drinks'),
              ),
              const SizedBox(width: ClaudeSpacing.md),
              ClaudeCategoryButton(
                label: 'Snacks',
                icon: Icons.bakery_dining_outlined,
                selected: selectedCategory == 'Snacks',
                onTap: () => setState(() => selectedCategory = 'Snacks'),
              ),
            ],
          ),
        ),
      ],
    ),
  );

  Widget _buildErrorState() => Center(
    child: Padding(
      padding: const EdgeInsets.all(ClaudeSpacing.xxl),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.error_outline_rounded,
            size: 56,
            color: ClaudeColors.error.withValues(alpha: 0.5),
          ),
          const SizedBox(height: ClaudeSpacing.lg),
          Text(
            loadError ?? 'Something went wrong',
            textAlign: TextAlign.center,
            style: ClaudeTypography.bodyLarge.copyWith(
              color: ClaudeColors.textSecondary,
            ),
          ),
          const SizedBox(height: ClaudeSpacing.xxl),
          FilledButton.icon(
            onPressed: _load,
            icon: const Icon(Icons.refresh_outlined),
            label: const Text('Try again'),
          ),
        ],
      ),
    ),
  );

  void _showFilters() {
    showModalBottomSheet<void>(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(ClaudeRadius.xl),
        ),
      ),
      builder: (context) => Padding(
        padding: const EdgeInsets.all(ClaudeSpacing.xxl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Sort by',
              style: ClaudeTypography.headingSmall
                  .copyWith(color: ClaudeColors.text),
            ),
            const SizedBox(height: ClaudeSpacing.lg),
            ...[
              ('Popular', 'popular'),
              ('Top rated', 'rating'),
              ('Fastest delivery', 'fastest'),
            ].map(
              (option) => Padding(
                padding: const EdgeInsets.only(bottom: ClaudeSpacing.md),
                child: SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () {
                      setState(() => sort = option.$2);
                      Navigator.pop(context);
                    },
                    style: OutlinedButton.styleFrom(
                      backgroundColor: sort == option.$2
                          ? ClaudeColors.primaryLight
                          : Colors.transparent,
                      side: BorderSide(
                        color: sort == option.$2
                            ? ClaudeColors.primary
                            : ClaudeColors.border,
                      ),
                    ),
                    child: Text(option.$1),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
