import 'dart:async';

import 'package:flutter/material.dart';
import '../../design_system/k_tokens.dart';
import '../../design_system/k_network_image.dart';
import 'package:go_router/go_router.dart';
import '../../config/app_config.dart';
import '../../core/brand.dart';
import '../../core/modern_ui.dart';
import '../../core/future_food_ui.dart';
import '../../core/customer_discovery_hero.dart';
import '../../core/utils.dart';
import '../../services/backend.dart';
import '../../services/cart.dart';
import '../../services/theme_controller.dart';
import '../../theme/app_theme.dart';
import 'cart_screen.dart';
import 'address_picker_screen.dart';
import '../shared/notification_center_screen.dart';
import '../shared/rating_sheet.dart';
import '../shared/order_receipt_screen.dart';
import '../shared/change_password_dialog.dart';
import '../pasabuy/pasabuy_chat_threads_section.dart';

class CustomerShell extends StatefulWidget {
  const CustomerShell({super.key});

  @override
  State<CustomerShell> createState() => _CustomerShellState();
}

class _CustomerShellState extends State<CustomerShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final webWide = MediaQuery.sizeOf(context).width >= 980;
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (didPop || !mounted) return;
        if (index != 0) {
          setState(() => index = 0);
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('You are already on Karlivery Home.')),
          );
        }
      },
      child: KDashboardScaffold(
      body: Row(children: [
        if (webWide)
          AnimatedBuilder(
            animation: CartService.instance,
            builder: (context, _) => KarliveryCustomerWebRail(
              selected: index,
              basketCount: CartService.instance.count,
              onTap: (value) => setState(() => index = value),
            ),
          ),
        Expanded(child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1200),
          child: KLazyIndexedStack(
            index: index,
            builders: [
              (_) => const _Home(),
              (_) => const _Orders(),
              (_) => CartScreen(),
              (_) => const _Messages(),
              (_) => const _Settings(),
            ],
          ),
        ),
      )),
      ]),
      bottomNavigationBar: webWide ? null : AnimatedBuilder(
        animation: CartService.instance,
        builder: (context, _) => FutureBottomBar(
          selected: index,
          onTap: (value) => setState(() => index = value),
        ),
      ),
      ),
    );
  }
}

class _Home extends StatefulWidget {
  const _Home();

  @override
  State<_Home> createState() => _HomeState();
}

class _HomeState extends State<_Home> {
  List<Map<String, dynamic>> stores = [];
  List<Map<String, dynamic>> featured = [];
  List<Map<String, dynamic>> menuSearchResults = [];
  List<Map<String, dynamic>> recentStores = [];
  Timer? _searchDebounce;
  int _searchRevision = 0;
  bool loading = true;
  String? loadError;
  String query = '';
  final searchController = TextEditingController();
  String deliveryLabel = 'Choose your delivery address';
  final _storeSectionKey = GlobalKey();
  String sortMode = 'recommended';
  bool openOnly = false;

  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  void dispose() {
    _searchDebounce?.cancel();
    searchController.dispose();
    super.dispose();
  }

  Future<void> load() async {
    if (mounted) {
      setState(() {
        loading = true;
        loadError = null;
      });
    }

    try {
      final startup = await Future.wait([
        Backend.myAddresses(),
        Backend.featuredProducts(limit: 60),
      ]);
      final loadedAddresses = startup[0];
      featured = startup[1];
      String? addressId;

      if (loadedAddresses.isNotEmpty) {
        final a = loadedAddresses.first;
        addressId = a['id']?.toString();

        final parts = [
          a['address_line'],
          a['barangay'],
          a['city'],
        ]
            .where(
              (e) => e != null && e.toString().trim().isNotEmpty,
            )
            .map((e) => e.toString().trim())
            .toList();

        deliveryLabel =
            parts.isEmpty ? 'Saved delivery address' : parts.join(', ');
      }

      stores = await Backend.approvedStores(addressId: addressId);
      try {
        recentStores = _recentStoresFrom(await Backend.myOrders());
      } catch (_) {
        recentStores = [];
      }
    } catch (_) {
      loadError = 'Karlivery could not refresh restaurants right now. Check your connection and try again.';
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  /// Distinct, currently listed stores from the customer's past orders.
  List<Map<String, dynamic>> _recentStoresFrom(List<Map<String, dynamic>> orders) {
    final seen = <String>{};
    final out = <Map<String, dynamic>>[];
    for (final o in orders) {
      final id = '${o['store_id'] ?? ''}';
      if (id.isEmpty || !seen.add(id)) continue;
      final match = stores.where((s) => '${s['id']}' == id);
      if (match.isEmpty) continue;
      out.add(match.first);
      if (out.length >= 8) break;
    }
    return out;
  }

  void updateQuery(String value) {
    _searchDebounce?.cancel();
    final revision = ++_searchRevision;
    setState(() {
      query = value;
      menuSearchResults = [];
    });
    if (value.trim().length < 2) return;
    _searchDebounce = Timer(const Duration(milliseconds: 320), () async {
      final found = await Backend.searchMenuProducts(value.trim());
      if (!mounted || revision != _searchRevision) return;
      setState(() => menuSearchResults = found);
    });
  }

  List<Map<String, dynamic>> get visibleStores {
    final q = query.trim().toLowerCase();

    final result = stores.where((s) {
      if (openOnly && s['is_open'] != true) return false;
      if (q.isEmpty) return true;

      final hay =
          '${s['name']} ${s['barangay']} ${s['description']}'.toLowerCase();
      if (hay.contains(q)) return true;

      final storeId = s['id']?.toString() ?? '';
      return [...featured, ...menuSearchResults].any((p) {
        if ((p['_store_id'] ?? p['store_id'])?.toString() != storeId) {
          return false;
        }
        final productHay =
            '${p['name']} ${p['description']} ${p['category']}'.toLowerCase();
        return productHay.contains(q);
      });
    }).toList();

    double number(Map<String, dynamic> map, String key) =>
        double.tryParse(map[key]?.toString() ?? '') ?? 0;

    switch (sortMode) {
      case 'top_rated':
        result.sort(
          (a, b) =>
              number(b, 'rating_avg').compareTo(number(a, 'rating_avg')),
        );
        break;
      case 'nearest':
        result.sort(
          (a, b) =>
              (double.tryParse(a['distance_km']?.toString() ?? '') ?? double.infinity).compareTo(double.tryParse(b['distance_km']?.toString() ?? '') ?? double.infinity),
        );
        break;
      case 'lowest_fee':
        result.sort(
          (a, b) => (double.tryParse(a['delivery_fee_preview']?.toString() ?? '') ?? double.infinity)
              .compareTo(double.tryParse(b['delivery_fee_preview']?.toString() ?? '') ?? double.infinity),
        );
        break;
      case 'fastest':
        result.sort(
          (a, b) => (double.tryParse(a['eta_min_minutes']?.toString() ?? '') ?? double.infinity)
              .compareTo(double.tryParse(b['eta_min_minutes']?.toString() ?? '') ?? double.infinity),
        );
        break;
      case 'popular':
        result.sort(
          (a, b) => number(b, 'completed_orders')
              .compareTo(number(a, 'completed_orders')),
        );
        break;
      case 'recommended':
      default:
        result.sort((a, b) {
          if ((a['is_open'] == true) != (b['is_open'] == true)) {
            return a['is_open'] == true ? -1 : 1;
          }
          final pop = number(b, 'completed_orders')
              .compareTo(number(a, 'completed_orders'));
          if (pop != 0) return pop;
          return number(b, 'rating_avg')
              .compareTo(number(a, 'rating_avg'));
        });
    }

    return result;
  }

  Future<void> showFilters() async {
    var draftSort = sortMode;
    var draftOpenOnly = openOnly;

    final apply = await showModalBottomSheet<bool>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 4, 18, 22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'Sort restaurants',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 21,
                  ),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  initialValue: draftSort,
                  decoration: const InputDecoration(
                    labelText: 'Sort by',
                    prefixIcon: Icon(Icons.sort_rounded),
                  ),
                  items: const [
                    DropdownMenuItem(
                      value: 'recommended',
                      child: Text('Recommended'),
                    ),
                    DropdownMenuItem(
                      value: 'popular',
                      child: Text('Most ordered'),
                    ),
                    DropdownMenuItem(
                      value: 'top_rated',
                      child: Text('Top rated'),
                    ),
                    DropdownMenuItem(
                      value: 'nearest',
                      child: Text('Nearest'),
                    ),
                    DropdownMenuItem(
                      value: 'lowest_fee',
                      child: Text('Lowest delivery fee'),
                    ),
                    DropdownMenuItem(
                      value: 'fastest',
                      child: Text('Fastest delivery estimate'),
                    ),
                  ],
                  onChanged: (v) =>
                      setLocal(() => draftSort = v ?? 'recommended'),
                ),
                const SizedBox(height: 8),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: draftOpenOnly,
                  onChanged: (v) => setLocal(() => draftOpenOnly = v),
                  title: const Text(
                    'Open restaurants only',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
                const SizedBox(height: 10),
                FilledButton.icon(
                  onPressed: () => Navigator.pop(ctx, true),
                  icon: const Icon(Icons.check_rounded),
                  label: const Text('Apply filters'),
                ),
              ],
            ),
          ),
        ),
      ),
    );

    if (apply == true && mounted) {
      setState(() {
        sortMode = draftSort;
        openOnly = draftOpenOnly;
      });
    }
  }

  List<Map<String, dynamic>> featuredForStore(String storeId) => featured
      .where(
        (p) => p['_store_id']?.toString() == storeId && p['is_featured'] == true,
      )
      .take(3)
      .toList();

  @override
  Widget build(BuildContext context) {
    final storeResults = visibleStores;
    final visibleIds = storeResults.map((store) => '${store['id'] ?? ''}').toSet();
    final seenDishIds = <String>{};
    final matchingFood = [...menuSearchResults, ...featured].where((dish) {
      final dishId = '${dish['id'] ?? ''}';
      if (dishId.isNotEmpty && !seenDishIds.add(dishId)) return false;
      final storeId = '${dish['_store_id'] ?? dish['store_id'] ?? ''}';
      if (!visibleIds.contains(storeId)) return false;
      if (query.trim().isEmpty) return true;
      final haystack = '${dish['name']} ${dish['description']} ${dish['category']}'
          .toLowerCase();
      return haystack.contains(query.toLowerCase()) || storeResults.any(
        (store) => '${store['id']}' == storeId &&
          '${store['name']}'.toLowerCase().contains(query.toLowerCase()));
    }).toList();

    final scale = MediaQuery.textScalerOf(context).scale(1).clamp(1.0, 1.4).toDouble();
    final searching = query.trim().isNotEmpty;
    final showOrderAgain = !searching && !loading && recentStores.isNotEmpty;
    final showHero = !searching && !showOrderAgain;
    final Widget? spotlight = (!loading && matchingFood.isNotEmpty)
        ? FutureFoodSpotlight(
            dishes: matchingFood,
            isSearch: searching,
            onOpenStore: (storeId) => context.push('/store/$storeId'))
        : null;

    return SafeArea(
      child: RefreshIndicator(
        onRefresh: load,
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: [
            // 1. Compact header: brand, help, notifications, delivery address.
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(17, 8, 17, 0),
              sliver: SliverToBoxAdapter(child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(children: [
                    const Expanded(child: KarliveryWordmark(compact: true)),
                    IconButton(
                      tooltip: 'Help and support',
                      onPressed: () => context.push('/help?role=customer'),
                      icon: const Icon(Icons.headset_mic_outlined, size: 22)),
                    const NotificationBell(),
                  ]),
                  if (loadError != null) ...[
                    const SizedBox(height: 8),
                    MaterialBanner(
                      content: Text(loadError!),
                      leading: const Icon(Icons.wifi_off_rounded),
                      actions: [TextButton(onPressed: load,
                        child: const Text('Retry'))],
                    ),
                  ],
                  const SizedBox(height: 6),
                  _HomeAddress(
                    label: deliveryLabel,
                    onTap: () async {
                      final changed = await Navigator.of(context).push<bool>(
                        MaterialPageRoute(builder: (_) => const AddressPickerScreen()));
                      if (changed == true) await load();
                    },
                  ),
                  const SizedBox(height: 10),
                ],
              )),
            ),
            // 2. Search + filters stay pinned while the list scrolls.
            SliverPersistentHeader(
              pinned: true,
              delegate: _HomeStickyHeader(
                extent: 112 * scale,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(17, 4, 17, 6),
                  child: SingleChildScrollView(
                    physics: const NeverScrollableScrollPhysics(),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        TextField(
                          controller: searchController,
                          textInputAction: TextInputAction.search,
                          onChanged: updateQuery,
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Theme.of(context).colorScheme.surface,
                            hintText: 'Search restaurants or dishes',
                            prefixIcon: const Icon(Icons.search_rounded, size: 24),
                            suffixIcon: IconButton(
                              tooltip: 'Sort and filter restaurants',
                              onPressed: showFilters,
                              icon: const Icon(Icons.tune_rounded)),
                          ),
                        ),
                        const SizedBox(height: 8),
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(children: [
                            FilterChip(
                              label: const Text('Open now'),
                              avatar: const Icon(Icons.bolt_rounded, size: 17),
                              selected: openOnly,
                              onSelected: (value) => setState(() => openOnly = value)),
                            const SizedBox(width: 8),
                            ChoiceChip(
                              label: const Text('Top rated'),
                              selected: sortMode == 'top_rated',
                              onSelected: (value) => setState(() =>
                                sortMode = value ? 'top_rated' : 'recommended')),
                            const SizedBox(width: 8),
                            ChoiceChip(
                              label: const Text('Nearest'),
                              selected: sortMode == 'nearest',
                              onSelected: (value) => setState(() =>
                                sortMode = value ? 'nearest' : 'recommended')),
                            if (query.isNotEmpty || openOnly || sortMode != 'recommended') ...[
                              const SizedBox(width: 8),
                              ActionChip(label: const Text('Reset'),
                                onPressed: () {
                                  setState(() {
                                    openOnly = false;
                                    sortMode = 'recommended';
                                  });
                                  searchController.clear();
                                  updateQuery('');
                                }),
                            ],
                          ]),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            // 3. Returning customers get "Order again"; new customers get the
            //    compact brand banner. Then categories and the restaurant list.
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(17, 10, 17, 0),
              sliver: SliverToBoxAdapter(child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  if (showOrderAgain) ...[
                    _OrderAgainStrip(
                      stores: recentStores,
                      onOpen: (id) => context.push('/store/$id')),
                    const SizedBox(height: 18),
                  ] else if (showHero) ...[
                    KarliveryDiscoveryHero(
                      storeCount: stores.length,
                      loading: loading,
                      coverUrl: featured.where((dish) =>
                        '${dish['image_url'] ?? ''}'.trim().isNotEmpty).isEmpty
                            ? null
                            : '${featured.firstWhere((dish) =>
                              '${dish['image_url'] ?? ''}'.trim().isNotEmpty)['image_url']}',
                      onExplore: () {
                        final target = _storeSectionKey.currentContext;
                        if (target != null) {
                          Scrollable.ensureVisible(target,
                            duration: const Duration(milliseconds: 450),
                            curve: Curves.easeOutCubic);
                        }
                      },
                    ),
                    const SizedBox(height: 18),
                  ],
                  if (!searching) ...[
                    Text('What are you craving?', style: Theme.of(context)
                      .textTheme.titleLarge?.copyWith(fontSize: 19)),
                    const SizedBox(height: 10),
                    FutureFoodCategories(query: query, onSelect: (value) {
                      searchController.text = value;
                      updateQuery(value);
                    }),
                    const SizedBox(height: 20),
                  ],
                  if (searching && spotlight != null) ...[
                    spotlight,
                    const SizedBox(height: 20),
                  ],
                  KeyedSubtree(
                    key: _storeSectionKey,
                    child: FutureFoodHeadline(
                      eyebrow: 'RESTAURANTS & LOCAL FAVORITES',
                      title: searching ? 'Search results' : 'Restaurants near you',
                      subtitle: 'Discover your neighborhood favorites.',
                      trailing: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.surface,
                          borderRadius: FutureFoodStyle.corners(12)),
                        child: Text('${storeResults.length} stores',
                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                ],
              )),
            ),
            if (loadError != null && stores.isEmpty)
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 17),
                sliver: SliverToBoxAdapter(
                  child: _HomeLoadError(message: loadError!, retry: load)))
            else if (loading)
              const SliverPadding(
                padding: EdgeInsets.symmetric(horizontal: 17),
                sliver: SliverToBoxAdapter(child: _HomeSkeletonGrid()))
            else if (storeResults.isEmpty)
              const SliverPadding(
                padding: EdgeInsets.symmetric(horizontal: 17),
                sliver: SliverToBoxAdapter(child: _EmptyStoreState()))
            else
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 17),
                sliver: SliverLayoutBuilder(builder: (context, constraints) {
                  final space = constraints.crossAxisExtent;
                  final textScale = MediaQuery.textScalerOf(context).scale(1);
                  final columns = KBreakpoints.storeColumns(space, textScale: textScale);
                  final rows = (storeResults.length / columns).ceil();
                  return SliverList(delegate: SliverChildBuilderDelegate((context, row) {
                    final start = row * columns;
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        for (var col = 0; col < columns; col++) ...[
                          if (col > 0) const SizedBox(width: 10),
                          Expanded(child: start + col < storeResults.length
                            ? FutureFoodStoreCard(
                                store: storeResults[start + col],
                                dishes: featuredForStore('${storeResults[start + col]['id'] ?? ''}'),
                                onTap: () => context.push(
                                  '/store/${storeResults[start + col]['id']}'))
                            : const SizedBox.shrink()),
                        ],
                      ]),
                    );
                  }, childCount: rows));
                }),
              ),
            // 4. Secondary discovery sits after the restaurants.
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(17, 12, 17, 0),
              sliver: SliverToBoxAdapter(child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  if (!searching && spotlight != null) ...[
                    spotlight,
                    const SizedBox(height: 20),
                  ],
                  FutureFoodPabiliEntry(onTap: () => context.push('/pasabuy')),
                ],
              )),
            ),
            const SliverToBoxAdapter(child: SizedBox(height: 95)),
          ],
        ),
      ),
    );
  }

}


/// Pinned header delegate for the Home search + filter row.
class _HomeStickyHeader extends SliverPersistentHeaderDelegate {
  _HomeStickyHeader({required this.extent, required this.child});
  final double extent;
  final Widget child;

  @override
  double get minExtent => extent;
  @override
  double get maxExtent => extent;

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) =>
      Material(
        color: Theme.of(context).scaffoldBackgroundColor,
        elevation: overlapsContent ? 1.5 : 0,
        shadowColor: Colors.black26,
        child: child,
      );

  @override
  bool shouldRebuild(covariant _HomeStickyHeader old) => true;
}

/// Horizontal "Order again" row built from the customer's real past orders.
class _OrderAgainStrip extends StatelessWidget {
  const _OrderAgainStrip({required this.stores, required this.onOpen});
  final List<Map<String, dynamic>> stores;
  final ValueChanged<String> onOpen;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Order again',
        style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 19)),
      const SizedBox(height: 10),
      SizedBox(
        height: 76,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          itemCount: stores.length,
          separatorBuilder: (_, _) => const SizedBox(width: 10),
          itemBuilder: (context, i) {
            final s = stores[i];
            final id = '${s['id'] ?? ''}';
            final logo = '${s['logo_url'] ?? ''}'.trim();
            final open = s['is_open'] == true;
            return Semantics(
              button: true,
              label: 'Order again from ${s['name'] ?? 'this restaurant'}',
              child: Material(
                color: scheme.surface,
                borderRadius: BorderRadius.circular(KRadius.md),
                child: InkWell(
                  borderRadius: BorderRadius.circular(KRadius.md),
                  onTap: id.isEmpty ? null : () => onOpen(id),
                  child: Container(
                    width: 220,
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      border: Border.all(color: scheme.outlineVariant),
                      borderRadius: BorderRadius.circular(KRadius.md)),
                    child: Row(children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(KRadius.sm),
                        child: SizedBox(
                          width: 54, height: 54,
                          child: logo.isEmpty
                              ? ColoredBox(
                                  color: KPalette.blush,
                                  child: const Icon(Icons.storefront_rounded,
                                    color: KPalette.red))
                              : KNetImage(logo,
                                  errorBuilder: (_, _, _) => const ColoredBox(
                                    color: KPalette.blush)),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('${s['name'] ?? 'Restaurant'}',
                            maxLines: 1, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 14, fontWeight: FontWeight.w700)),
                          const SizedBox(height: 3),
                          Text(open ? 'Open · Reorder' : 'Closed now',
                            style: TextStyle(
                              fontSize: 12, fontWeight: FontWeight.w600,
                              color: open ? KPalette.openBadge : scheme.onSurfaceVariant)),
                        ],
                      )),
                    ]),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    ]);
  }
}

/// Skeleton shown in place of the restaurant grid while Home loads.
class _HomeSkeletonGrid extends StatelessWidget {
  const _HomeSkeletonGrid();

  @override
  Widget build(BuildContext context) => Column(children: [
    for (var r = 0; r < 2; r++) ...[
      const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(child: KStoreCardSkeleton()),
        SizedBox(width: 10),
        Expanded(child: KStoreCardSkeleton()),
      ]),
      const SizedBox(height: 16),
    ],
  ]);
}

class _HomeAddress extends StatelessWidget {
  final String label;
  final VoidCallback onTap;

  const _HomeAddress({
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => Material(
    color: Theme.of(context).colorScheme.surface,
    borderRadius: FutureFoodStyle.corners(16),
    child: InkWell(
      onTap: onTap,
      borderRadius: FutureFoodStyle.corners(16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        decoration: BoxDecoration(
          border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
          borderRadius: FutureFoodStyle.corners(16),
        ),
        child: Row(children: [
          const Icon(Icons.near_me_rounded, color: FutureFoodStyle.pop, size: 23),
          const SizedBox(width: 9),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('DELIVERING TO', style: TextStyle(
                color: FutureFoodStyle.pop, fontWeight: FontWeight.w700,
                fontSize: 12, letterSpacing: 1.3)),
              const SizedBox(height: 2),
              Text(label, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
            ],
          )),
          const Icon(Icons.keyboard_arrow_down_rounded, size: 23),
        ]),
      ),
    ),
  );

}

class _Orders extends StatefulWidget {
  const _Orders();

  @override
  State<_Orders> createState() => _OrdersState();
}

class _OrdersState extends State<_Orders> {
  @override
  Widget build(BuildContext context) => SafeArea(
        child: StreamBuilder<List<Map<String, dynamic>>>(
          stream: Backend.watchMyOrders(),
          builder: (context, snap) {
            final orders = snap.data ?? [];

            return ListView(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 110),
              children: [
                const PageTitle(
                  'Track your orders',
                  subtitle:
                      'See every step from order confirmation to delivery.',
                ),
                const SizedBox(height: 16),
                if (snap.connectionState == ConnectionState.waiting &&
                    orders.isEmpty)
                  const KLoadingState(message: 'Loading your orders…')
                else if (orders.isEmpty)
                  const _EmptyCard(
                    icon: Icons.receipt_long_outlined,
                    title: 'No orders yet',
                    subtitle:
                        'Your current and past Karlivery orders will appear here.',
                  )
                else
                  ...orders.map(
                    (o) => Padding(
                      padding: const EdgeInsets.only(bottom: 14),
                      child: _OrderTimelineCard(order: o),
                    ),
                  ),
              ],
            );
          },
        ),
      );
}

class _OrderTimelineCard extends StatelessWidget {
  final Map<String, dynamic> order;

  const _OrderTimelineCard({
    required this.order,
  });

  @override
  Widget build(BuildContext context) {
    final status = (order['status'] ?? '').toString();
    final hasRider = order['rider_id'] != null;
    final canTrack = hasRider &&
        order['fulfillment'] == 'delivery' &&
        ['assigned', 'picked_up', 'delivering'].contains(status);

    final steps = _stepsFor(status);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(17),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    color: AppTheme.softRed,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Icon(
                    Icons.receipt_long_rounded,
                    color: AppTheme.red,
                  ),
                ),
                const SizedBox(width: 11),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        (order['order_no'] ?? 'Order').toString(),
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 17,
                        ),
                      ),
                      Text(
                        '${niceStatus(status)} • ${(order['payment_method'] ?? '').toString().toUpperCase()}',
                      ),
                    ],
                  ),
                ),
                Text(
                  money(
                    num.tryParse(
                      order['total']?.toString() ?? '0',
                    ),
                  ),
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 16,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppTheme.softYellow,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.notifications_active_rounded,
                    color: AppTheme.deepRed,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      _statusMessage(status),
                      style: const TextStyle(
                        color: AppTheme.deepRed,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            ...steps.map(
              (step) => _TimelineStep(
                title: step.$1,
                subtitle: step.$2,
                done: step.$3,
                active: step.$4,
                icon: step.$5,
              ),
            ),
            if (hasRider) ...[
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () =>
                          context.push('/chat/${order['id']}'),
                      icon: const Icon(
                        Icons.chat_bubble_outline_rounded,
                      ),
                      label: const Text('Chat with rider'),
                    ),
                  ),
                  if (canTrack) ...[
                    const SizedBox(width: 10),
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: () =>
                            context.push('/track/${order['id']}'),
                        icon: const Icon(
                          Icons.location_on_rounded,
                        ),
                        label: const Text('Track rider'),
                      ),
                    ),
                  ],
                ],
              ),
            ],
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => context.push('/order/${order['id']}'),
                    icon: const Icon(Icons.receipt_long_rounded),
                    label: const Text('View details'),
                  ),
                ),
                if (['delivered', 'completed'].contains(status)) ...[
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: () => _orderAgain(context),
                      icon: const Icon(Icons.replay_rounded),
                      label: const Text('Order again'),
                    ),
                  ),
                ],
              ],
            ),
            if (['delivered', 'completed'].contains(status)) ...[
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: FilledButton.tonalIcon(
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => OrderReceiptScreen(orderId: order['id'].toString()),
                  )),
                  icon: const Icon(Icons.receipt_long_rounded),
                  label: const Text('View local-store receipt & PDF'),
                ),
              ),
              RateOrderCard(order: order),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _orderAgain(BuildContext context) async {
    try {
      final payload = await Backend.reorderPayload(order['id'].toString());
      if (payload == null) {
        throw Exception('This order is not available for re-order.');
      }

      final items = payload['items'] is List
          ? List<Map<String, dynamic>>.from(payload['items'])
          : <Map<String, dynamic>>[];
      if (items.isEmpty) {
        throw Exception('The items from this order are currently unavailable.');
      }

      if (!context.mounted) return;
      final cart = CartService.instance;
      if (cart.count > 0) {
        final replace = await showDialog<bool>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: const Text('Replace your current basket?'),
            content: const Text(
              'Ordering again will remove the dishes currently in your basket. '
              'You can cancel and keep them instead.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, false),
                child: const Text('Keep basket'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(dialogContext, true),
                child: const Text('Replace basket'),
              ),
            ],
          ),
        );
        if (replace != true || !context.mounted) return;
      }
      cart.clear();
      final storeId = payload['store_id'].toString();
      final storeName = payload['store_name']?.toString() ?? 'Restaurant';

      for (final item in items) {
        final product = item['product'] is Map
            ? Map<String, dynamic>.from(item['product'])
            : <String, dynamic>{};
        final quantity =
            int.tryParse(item['quantity']?.toString() ?? '1') ?? 1;
        if (product.isNotEmpty) {
          cart.add(product, storeId, storeName, quantity: quantity);
        }
      }

      if (!context.mounted) return;
      final original = int.tryParse(
            payload['original_item_count']?.toString() ?? '0',
          ) ??
          0;
      final available = int.tryParse(
            payload['available_item_count']?.toString() ?? '0',
          ) ??
          0;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            available < original
                ? 'Some old items are sold out or unavailable. Available items were added; please reselect add-ons.'
                : 'Items were added again. Please reselect any add-ons before checkout if needed.',
          ),
        ),
      );
      context.push('/cart');
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not order again: $e')),
      );
    }
  }

  List<(String, String, bool, bool, IconData)> _stepsFor(
    String status,
  ) {
    const order = [
      'pending_payment',
      'payment_review',
      'paid',
      'accepted',
      'preparing',
      'ready',
      'assigned',
      'picked_up',
      'delivering',
      'delivered',
      'completed',
    ];

    final current = order.indexOf(status);
    final safeCurrent = current < 0 ? 0 : current;

    bool reached(String key) {
      final i = order.indexOf(key);
      return i <= safeCurrent;
    }

    bool active(String key) => status == key;

    return [
      (
        'Order placed',
        'We received your order.',
        reached('pending_payment'),
        active('pending_payment') || active('payment_review'),
        Icons.check_circle_outline_rounded,
      ),
      (
        'Accepted by store',
        'The store confirmed and is preparing it.',
        reached('accepted'),
        active('accepted') || active('preparing'),
        Icons.storefront_rounded,
      ),
      (
        'Rider assigned',
        'A rider will collect your order.',
        reached('assigned'),
        active('ready') || active('assigned'),
        Icons.delivery_dining_rounded,
      ),
      (
        'On the way',
        'Your order is traveling to you.',
        reached('picked_up'),
        active('picked_up') || active('delivering'),
        Icons.route_rounded,
      ),
      (
        'Delivered',
        'Your Karlivery order has arrived.',
        reached('delivered'),
        active('delivered') || active('completed'),
        Icons.home_rounded,
      ),
    ];
  }

  String _statusMessage(String status) {
    switch (status) {
      case 'pending_payment':
        return 'Complete your GCash payment to continue.';
      case 'payment_review':
        return 'Your GCash proof is being checked.';
      case 'payment_rejected':
        return 'Your GCash proof needs attention.';
      case 'paid':
        return 'Payment is confirmed. Waiting for the store.';
      case 'accepted':
        return 'The store accepted your order.';
      case 'preparing':
        return 'Your food is being prepared.';
      case 'ready':
        return 'Your order is ready and waiting for a rider.';
      case 'assigned':
        return 'A delivery rider accepted your order.';
      case 'picked_up':
        return 'Your order has been handed to the rider.';
      case 'delivering':
        return 'Your rider is on the way.';
      case 'delivered':
        return 'Delivered. Enjoy your order!';
      case 'completed':
        return 'Order completed. Thank you for using Karlivery.';
      case 'cancelled':
        return 'This order was cancelled.';
      case 'rejected':
        return 'The store could not accept this order.';
      default:
        return niceStatus(status);
    }
  }
}

class _TimelineStep extends StatelessWidget {
  final String title;
  final String subtitle;
  final bool done;
  final bool active;
  final IconData icon;

  const _TimelineStep({
    required this.title,
    required this.subtitle,
    required this.done,
    required this.active,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) => IntrinsicHeight(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              width: 38,
              child: Column(
                children: [
                  Container(
                    width: 31,
                    height: 31,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: done
                          ? AppTheme.red
                          : Theme.of(context)
                              .colorScheme
                              .surfaceContainerHighest,
                      border: Border.all(
                        color: active
                            ? AppTheme.yellow
                            : Theme.of(context).dividerColor,
                        width: active ? 3 : 1,
                      ),
                    ),
                    child: Icon(
                      done ? Icons.check_rounded : icon,
                      size: 17,
                      color: done
                          ? Colors.white
                          : AppTheme.muted,
                    ),
                  ),
                  Expanded(
                    child: Container(
                      width: 2,
                      color: done
                          ? AppTheme.red.withValues(alpha: .35)
                          : Theme.of(context).dividerColor,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 9),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(
                  top: 3,
                  bottom: 18,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: active
                            ? AppTheme.red
                            : null,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style:
                          Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
}

class _Messages extends StatefulWidget {
  const _Messages();

  @override
  State<_Messages> createState() => _MessagesState();
}

class _MessagesState extends State<_Messages> {
  late Future<List<Map<String, dynamic>>> future;

  @override
  void initState() {
    super.initState();
    future = Backend.myMessageThreads();
  }

  Future<void> refresh() async {
    setState(() => future = Backend.myMessageThreads());
    await future;
  }

  bool _isCurrent(Map<String, dynamic> item) {
    final status = (item['status'] ?? '').toString();
    return [
      'pending_payment',
      'payment_review',
      'paid',
      'accepted',
      'preparing',
      'ready',
      'ready_for_pickup',
      'assigned',
      'picked_up',
      'delivering',
    ].contains(status);
  }

  @override
  Widget build(BuildContext context) => SafeArea(
        child: FutureBuilder<List<Map<String, dynamic>>>(
          future: future,
          builder: (context, snap) {
            final items = snap.data ?? [];
            final current =
                items.where(_isCurrent).toList();
            final history =
                items.where((item) => !_isCurrent(item)).toList();

            return RefreshIndicator(
              onRefresh: refresh,
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(18, 14, 18, 110),
                children: [
                  const KPageHeader(
                    eyebrow: 'Order conversations',
                    title: 'Messages',
                    subtitle:
                        'Only active order chats stay on top. Past conversations are kept below as history.',
                    icon: Icons.forum_rounded,
                  ),
                  const SizedBox(height: 18),
                  if (snap.connectionState !=
                          ConnectionState.done &&
                      items.isEmpty)
                    const Center(
                      child: Padding(
                        padding: EdgeInsets.all(24),
                        child: CircularProgressIndicator(),
                      ),
                    )
                  else if (items.isEmpty)
                    const KEmptyState(
                      icon: Icons.forum_outlined,
                      title: 'No conversations yet',
                      subtitle:
                          'Your order chat opens as soon as an order exists, so you can talk with the seller and later the assigned rider.',
                    )
                  else ...[
                    if (current.isNotEmpty) ...[
                      const _MessageSectionTitle(
                        title: 'Current order chat',
                        subtitle:
                            'Your active delivery conversation',
                        icon: Icons.delivery_dining_rounded,
                      ),
                      const SizedBox(height: 10),
                      ...current.map(
                        (item) => _ConversationCard(
                          item: item,
                          active: true,
                        ),
                      ),
                    ] else
                      const KEmptyState(
                        icon: Icons.chat_bubble_outline_rounded,
                        title: 'No active order chat',
                        subtitle:
                            'Current seller and rider conversations will appear here.',
                      ),
                    if (history.isNotEmpty) ...[
                      const SizedBox(height: 24),
                      const _MessageSectionTitle(
                        title: 'Past conversations',
                        subtitle:
                            'Delivered and completed order history',
                        icon: Icons.history_rounded,
                      ),
                      const SizedBox(height: 10),
                      ...history.map(
                        (item) => _ConversationCard(
                          item: item,
                          active: false,
                        ),
                      ),
                    ],
                  ],
                  const PasabuyChatThreadsSection(forRider: false),
                ],
              ),
            );
          },
        ),
      );
}

class _MessageSectionTitle extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;

  const _MessageSectionTitle({
    required this.title,
    required this.subtitle,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) => Row(
        children: [
          CircleAvatar(
            radius: 20,
            backgroundColor: AppTheme.softRed,
            child: Icon(icon, color: AppTheme.red, size: 20),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 17,
                  ),
                ),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: AppTheme.muted,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      );
}

class _ConversationCard extends StatelessWidget {
  final Map<String, dynamic> item;
  final bool active;

  const _ConversationCard({
    required this.item,
    required this.active,
  });

  @override
  Widget build(BuildContext context) {
    final store = item['store_name'] ??
        (item['stores'] is Map ? item['stores']['name'] : 'Store');
    final rider = (item['rider_name'] ?? '').toString();
    final seller = (item['seller_name'] ?? store).toString();
    final participants = item['rider_id'] != null
        ? '$seller • $rider'
        : seller;
    final summary = (item['item_summary'] ?? 'Order items').toString();
    final last = (item['last_message'] ?? 'No messages yet').toString();
    final status = (item['status'] ?? '').toString();

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Card(
        child: InkWell(
          borderRadius: BorderRadius.circular(24),
          onTap: () => context.push('/chat/${item['id'] ?? item['order_id']}'),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 54,
                  height: 54,
                  decoration: BoxDecoration(
                    gradient: active
                        ? const LinearGradient(
                            colors: [
                              AppTheme.red,
                              AppTheme.deepRed,
                            ],
                          )
                        : null,
                    color: active ? null : AppTheme.softYellow,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Icon(
                    active
                        ? Icons.delivery_dining_rounded
                        : Icons.history_rounded,
                    color:
                        active ? Colors.white : AppTheme.deepRed,
                    size: 27,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        participants,
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '${item['order_no']} • $store',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        summary,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: AppTheme.muted,
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(height: 7),
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              last,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 12,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          KStatusPill(
                            text: active
                                ? 'CURRENT'
                                : niceStatus(status).toUpperCase(),
                            color: active
                                ? const Color(0xFF2E9D63)
                                : AppTheme.red,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 5),
                const Icon(Icons.chevron_right_rounded),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Settings extends StatefulWidget {
  const _Settings();

  @override
  State<_Settings> createState() => _SettingsState();
}

class _SettingsState extends State<_Settings> {
  Map<String, dynamic>? profile;
  List<Map<String, dynamic>> addresses = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    if (mounted) setState(() => loading = true);
    final result = await Future.wait([
      Backend.myProfile(),
      Backend.myAddresses(),
    ]);
    profile = result[0] as Map<String, dynamic>?;
    addresses = result[1] as List<Map<String, dynamic>>;
    if (mounted) setState(() => loading = false);
  }

  Future<void> editProfile() async {
    final fullName = TextEditingController(
      text: (profile?['full_name'] ?? '').toString(),
    );
    final phone = TextEditingController(
      text: (profile?['phone'] ?? '').toString(),
    );

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Edit profile'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: fullName,
              decoration: const InputDecoration(
                labelText: 'Full name',
                prefixIcon: Icon(Icons.badge_outlined),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: phone,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                labelText: 'Mobile number',
                prefixIcon: Icon(Icons.phone_iphone_rounded),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Save'),
          ),
        ],
      ),
    );

    if (ok != true) return;

    try {
      await Backend.updateMyProfile(
        fullName: fullName.text,
        phone: phone.text,
      );
      await load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Profile updated.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not update profile: $e')),
        );
      }
    }
  }

  Future<void> deleteAccount() async {
    final confirm = TextEditingController();

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        icon: const Icon(Icons.warning_amber_rounded, color: Colors.redAccent),
        title: const Text('Delete account permanently?'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'This permanently deletes your login and customer profile. Historical completed orders may remain as anonymized transaction records.',
            ),
            const SizedBox(height: 14),
            TextField(
              controller: confirm,
              decoration: const InputDecoration(
                labelText: 'Type DELETE',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: Colors.redAccent,
            ),
            onPressed: () {
              if (confirm.text.trim().toUpperCase() == 'DELETE') {
                Navigator.pop(ctx, true);
              }
            },
            child: const Text('Delete forever'),
          ),
        ],
      ),
    );

    if (ok != true) return;

    try {
      await Backend.deleteMyCustomerAccount();
      await Backend.logout();
      if (mounted) context.go('/login');
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Account delete failed: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) => SafeArea(
        child: loading
            ? const KLoadingState(message: 'Loading your account…')
            : RefreshIndicator(
                onRefresh: load,
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(18, 14, 18, 110),
                  children: [
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        gradient: const LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            AppTheme.red,
                            AppTheme.deepRed,
                          ],
                        ),
                      ),
                      child: Row(
                        children: [
                          const CircleAvatar(
                            radius: 34,
                            backgroundColor: Colors.white,
                            child: Icon(
                              Icons.person_rounded,
                              color: AppTheme.red,
                              size: 34,
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment:
                                  CrossAxisAlignment.start,
                              children: [
                                Text(
                                  (profile?['full_name'] ??
                                          'Karlivery Customer')
                                      .toString(),
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 20,
                                  ),
                                ),
                                const SizedBox(height: 3),
                                Text(
                                  (profile?['email'] ??
                                          Backend.user?.email ??
                                          '')
                                      .toString(),
                                  style: const TextStyle(
                                    color: Color(0xFFFFE6E0),
                                  ),
                                ),
                                if ((profile?['phone'] ?? '')
                                    .toString()
                                    .isNotEmpty)
                                  Text(
                                    profile!['phone'].toString(),
                                    style: const TextStyle(
                                      color: Color(0xFFFFE6E0),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                          IconButton.filled(
                            style: IconButton.styleFrom(
                              backgroundColor: Colors.white,
                              foregroundColor: AppTheme.red,
                            ),
                            onPressed: editProfile,
                            icon: const Icon(Icons.edit_rounded),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 18),
                    const Text(
                      'Account & app',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 18,
                      ),
                    ),
                    const SizedBox(height: 9),
                    Card(
                      child: Column(
                        children: [
                          SwitchListTile(
                            value: ThemeController.isDark(context),
                            secondary: const _SettingIcon(
                              icon: Icons.dark_mode_rounded,
                            ),
                            title: const Text(
                              'Dark mode',
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            subtitle: const Text(
                              'Switch between light and dark appearance',
                            ),
                            onChanged: ThemeController.setDark,
                          ),
                          const Divider(height: 1),
                          ListTile(
                            leading: const _SettingIcon(
                              icon: Icons.lock_reset_rounded,
                            ),
                            title: const Text(
                              'Change password',
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            subtitle: const Text(
                              'Update your sign-in password',
                            ),
                            trailing:
                                const Icon(Icons.chevron_right_rounded),
                            onTap: () => showAccountPasswordDialog(context),
                          ),
                          const Divider(height: 1),
                          const ListTile(
                            leading: _SettingIcon(
                              icon: Icons.payments_outlined,
                            ),
                            title: Text(
                              'Payment methods',
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            subtitle: Text(
                              'Cash on Delivery (COD) • GCash',
                            ),
                          ),
                          const Divider(height: 1),
                          ListTile(
                            leading: const _SettingIcon(
                              icon: Icons.help_center_rounded,
                            ),
                            title: const Text(
                              'Help & how Karlivery works',
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            subtitle: const Text(
                              'Quick ordering guide, notifications, tracking and common questions',
                            ),
                            trailing: const Icon(Icons.chevron_right_rounded),
                            onTap: () =>
                                context.push('/help?role=customer'),
                          ),
                          const Divider(height: 1),
                          const ListTile(
                            leading: _SettingIcon(
                              icon: Icons.info_outline_rounded,
                            ),
                            title: Text(
                              'App version',
                              style: TextStyle(fontWeight: FontWeight.w700),
                            ),
                            subtitle: Text('Karlivery V${AppConfig.appVersion}'),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        const Expanded(
                          child: Text(
                            'Saved addresses',
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 18,
                            ),
                          ),
                        ),
                        FilledButton.tonalIcon(
                          onPressed: () async {
                            final saved =
                                await Navigator.of(context).push<bool>(
                              MaterialPageRoute(
                                builder: (_) =>
                                    const AddressPickerScreen(),
                              ),
                            );
                            if (saved == true) await load();
                          },
                          icon: const Icon(
                            Icons.add_location_alt_rounded,
                          ),
                          label: const Text('Add'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 9),
                    if (addresses.isEmpty)
                      const Card(
                        child: Padding(
                          padding: EdgeInsets.all(20),
                          child: Text(
                            'No saved addresses yet. Add one using GPS and the map pin.',
                          ),
                        ),
                      )
                    else
                      ...addresses.map(
                        (a) => Padding(
                          padding:
                              const EdgeInsets.only(bottom: 9),
                          child: Card(
                            child: ListTile(
                              leading: const _SettingIcon(
                                icon: Icons.location_on_rounded,
                              ),
                              title: Text(
                                (a['label'] ?? 'Address').toString(),
                                style: const TextStyle(
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              subtitle: Text(
                                '${a['address_line'] ?? ''}, ${a['barangay'] ?? ''}, ${a['city'] ?? ''}',
                              ),
                              trailing: IconButton(
                                tooltip: 'Delete address',
                                onPressed: () async {
                                  final ok = await showDialog<bool>(
                                    context: context,
                                    builder: (ctx) => AlertDialog(
                                      icon: const Icon(
                                        Icons.location_off_rounded,
                                        color: Colors.redAccent,
                                      ),
                                      title: const Text('Remove saved address?'),
                                      content: Text(
                                        'Remove ${a['label'] ?? 'this address'} from your Karlivery account?',
                                      ),
                                      actions: [
                                        TextButton(
                                          onPressed: () =>
                                              Navigator.pop(ctx, false),
                                          child: const Text('Keep address'),
                                        ),
                                        FilledButton(
                                          style: FilledButton.styleFrom(
                                            backgroundColor: Colors.redAccent,
                                          ),
                                          onPressed: () =>
                                              Navigator.pop(ctx, true),
                                          child: const Text('Remove'),
                                        ),
                                      ],
                                    ),
                                  );
                                  if (ok != true) return;
                                  await Backend.deleteAddress(
                                    a['id'].toString(),
                                  );
                                  await load();
                                },
                                icon: const Icon(
                                  Icons.delete_outline_rounded,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    const SizedBox(height: 10),
                    FilledButton.tonalIcon(
                      onPressed: () async {
                        await Backend.logout();
                        if (context.mounted) {
                          context.go('/login');
                        }
                      },
                      icon: const Icon(Icons.logout_rounded),
                      label: const Text('Sign out'),
                    ),
                    const SizedBox(height: 12),
                    OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.redAccent,
                      ),
                      onPressed: deleteAccount,
                      icon: const Icon(
                        Icons.delete_forever_rounded,
                      ),
                      label: const Text('Delete my account'),
                    ),
                  ],
                ),
              ),
      );
}

class _SettingIcon extends StatelessWidget {
  final IconData icon;
  const _SettingIcon({required this.icon});

  @override
  Widget build(BuildContext context) => Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          color: AppTheme.softYellow,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Icon(
          icon,
          color: AppTheme.deepRed,
          size: 21,
        ),
      );
}

class _HomeLoadError extends StatelessWidget {
  final String message;
  final Future<void> Function() retry;

  const _HomeLoadError({
    required this.message,
    required this.retry,
  });

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const Icon(
                Icons.wifi_off_rounded,
                color: AppTheme.red,
                size: 42,
              ),
              const SizedBox(height: 10),
              const Text(
                'Could not load restaurants',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 17,
                ),
              ),
              const SizedBox(height: 5),
              Text(message, textAlign: TextAlign.center),
              const SizedBox(height: 14),
              FilledButton.tonalIcon(
                onPressed: retry,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Try again'),
              ),
            ],
          ),
        ),
      );
}

class _EmptyStoreState extends StatelessWidget {
  const _EmptyStoreState();

  @override
  Widget build(BuildContext context) => const _EmptyCard(
        icon: Icons.search_off_rounded,
        title: 'No stores found',
        subtitle: 'Try another search or pull down to refresh.',
      );
}

class _EmptyCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const _EmptyCard({required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            children: [
              Icon(icon, size: 46, color: Theme.of(context).colorScheme.primary),
              const SizedBox(height: 12),
              Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
              const SizedBox(height: 4),
              Text(subtitle, textAlign: TextAlign.center),
            ],
          ),
        ),
      );
}
