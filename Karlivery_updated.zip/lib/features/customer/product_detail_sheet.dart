import 'package:flutter/material.dart';

import '../../core/utils.dart';
import '../../services/cart.dart';
import '../../theme/app_theme.dart';
import '../../design_system/k_network_image.dart';

Future<bool> showKarliveryProductSheet(
  BuildContext context, {
  required Map<String, dynamic> product,
  required String storeId,
  required String storeName,
  required bool storeOpen,
}) async {
  final available = product['is_available'] != false;
  final enabled = storeOpen && available;
  final image = (product['image_url'] ?? '').toString();

  final addons = product['product_addons'] is List
      ? List<Map<String, dynamic>>.from(product['product_addons'])
          .where((a) => a['is_available'] != false)
          .toList()
      : <Map<String, dynamic>>[];

  final selected = <String>{};
  var quantity = 1;

  final ok = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    showDragHandle: true,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setLocal) {
        final base =
            double.tryParse(product['price']?.toString() ?? '0') ?? 0;

        var addonsTotal = 0.0;
        for (final addon in addons) {
          if (selected.contains(addon['id'].toString())) {
            addonsTotal +=
                double.tryParse(addon['price']?.toString() ?? '0') ?? 0;
          }
        }

        final unit = base + addonsTotal;
        final total = unit * quantity;

        return SizedBox(
          height: (MediaQuery.sizeOf(ctx).height -
                  MediaQuery.of(ctx).viewInsets.bottom) * .82,
          child: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(18, 4, 18, 18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
              if (image.isNotEmpty)
                ClipRRect(
                  borderRadius: BorderRadius.circular(26),
                  child: AspectRatio(
                    aspectRatio: 16 / 10,
                    child: KNetImage(
                      image,
                      fit: BoxFit.cover,
                      errorBuilder: (_, _, _) => Container(
                        color: AppTheme.softYellow,
                        child: const Icon(
                          Icons.fastfood_rounded,
                          color: AppTheme.red,
                          size: 64,
                        ),
                      ),
                    ),
                  ),
                ),
              if (image.isNotEmpty) const SizedBox(height: 18),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Text(
                      product['name']?.toString() ?? 'Menu item',
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 24,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    money(base),
                    style: const TextStyle(
                      color: AppTheme.red,
                      fontWeight: FontWeight.w700,
                      fontSize: 20,
                    ),
                  ),
                ],
              ),
              if ((product['description'] ?? '')
                  .toString()
                  .trim()
                  .isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(
                  product['description'].toString(),
                  style: const TextStyle(
                    color: AppTheme.muted,
                    height: 1.4,
                  ),
                ),
              ],
              const SizedBox(height: 13),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _AvailabilityChip(
                    available: available,
                    storeOpen: storeOpen,
                  ),
                  Chip(
                    avatar: const Icon(
                      Icons.schedule_rounded,
                      color: AppTheme.deepRed,
                      size: 18,
                    ),
                    label: Text('Prep ${prepTimeLabel(product)}'),
                  ),
                  if (product['is_featured'] == true)
                    const Chip(
                      avatar: Icon(
                        Icons.local_fire_department_rounded,
                        color: AppTheme.red,
                        size: 18,
                      ),
                      label: Text('Featured'),
                    ),
                ],
              ),
              if (addons.isNotEmpty) ...[
                const SizedBox(height: 18),
                const Text(
                  'Choose add-ons',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 17,
                  ),
                ),
                const SizedBox(height: 5),
                ...addons.map(
                  (addon) => CheckboxListTile(
                    value: selected.contains(addon['id'].toString()),
                    contentPadding: EdgeInsets.zero,
                    controlAffinity: ListTileControlAffinity.trailing,
                    title: Text(
                      addon['name']?.toString() ?? 'Add-on',
                      style: const TextStyle(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    subtitle: Text(
                      '+${money(num.tryParse(addon['price']?.toString() ?? '0'))}',
                    ),
                    onChanged: !enabled
                        ? null
                        : (value) => setLocal(() {
                              final id = addon['id'].toString();
                              if (value == true) {
                                selected.add(id);
                              } else {
                                selected.remove(id);
                              }
                            }),
                  ),
                ),
              ],
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(13),
                decoration: BoxDecoration(
                  color: AppTheme.softYellow,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    const Expanded(
                      child: Text(
                        'Quantity',
                        style: TextStyle(fontWeight: FontWeight.w700),
                      ),
                    ),
                    IconButton.filledTonal(
                      onPressed: quantity <= 1
                          ? null
                          : () => setLocal(() => quantity--),
                      icon: const Icon(Icons.remove_rounded),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Text(
                        '$quantity',
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 17,
                        ),
                      ),
                    ),
                    IconButton.filled(
                      onPressed: !enabled || quantity >= 20
                          ? null
                          : () => setLocal(() => quantity++),
                      icon: const Icon(Icons.add_rounded),
                    ),
                  ],
                ),
              ),
                    ],
                  ),
                ),
              ),
              Container(
                width: double.infinity,
                padding: EdgeInsets.fromLTRB(
                  18, 12, 18, 16 + MediaQuery.paddingOf(ctx).bottom,
                ),
                decoration: BoxDecoration(
                  color: Theme.of(ctx).colorScheme.surface,
                  border: Border(
                    top: BorderSide(color: Theme.of(ctx).dividerColor),
                  ),
                ),
                child: FilledButton.icon(
                  onPressed: !enabled ? null : () => Navigator.pop(ctx, true),
                  icon: const Icon(Icons.add_shopping_cart_rounded),
                  label: Text(
                    enabled
                        ? 'Add $quantity to basket • ${money(total)}'
                        : available ? 'Store is closed' : 'Sold out',
                  ),
                ),
              ),
            ],
          ),
        );
      },
    ),
  );

  if (ok != true) return false;

  final chosen = addons
      .where((a) => selected.contains(a['id'].toString()))
      .toList();

  final cart = CartService.instance;
  if (cart.count > 0 && cart.storeId != storeId) {
    if (!context.mounted) return false;
    final replace = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        icon: const Icon(Icons.shopping_bag_outlined),
        title: const Text('Start a new restaurant basket?'),
        content: Text(
          'Your current basket is from ${cart.storeName ?? 'another restaurant'}. '
          'Adding this dish from $storeName will replace those items.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Keep current basket'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Replace basket'),
          ),
        ],
      ),
    );
    if (replace != true) return false;
    cart.clear();
  }

  cart.add(
    product,
    storeId,
    storeName,
    addons: chosen,
    quantity: quantity,
  );

  return true;
}

class _AvailabilityChip extends StatelessWidget {
  final bool available;
  final bool storeOpen;

  const _AvailabilityChip({
    required this.available,
    required this.storeOpen,
  });

  @override
  Widget build(BuildContext context) {
    final text = !available
        ? 'Sold out'
        : storeOpen
            ? 'Available'
            : 'Store closed';
    final color = !available
        ? AppTheme.muted
        : storeOpen
            ? const Color(0xFF198754)
            : AppTheme.deepRed;

    return Chip(
      avatar: Icon(
        available && storeOpen
            ? Icons.check_circle_rounded
            : Icons.schedule_rounded,
        size: 18,
        color: color,
      ),
      label: Text(text),
      labelStyle: TextStyle(
        color: color,
        fontWeight: FontWeight.w700,
      ),
    );
  }
}
