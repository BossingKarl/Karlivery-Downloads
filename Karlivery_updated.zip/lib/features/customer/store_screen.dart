// NOVA / 10: store experience inherits shared premium theme and safer navigation.
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';

import '../../core/modern_ui.dart';
import '../../core/smart_back.dart';
import '../../core/utils.dart';
import '../../services/backend.dart';
import '../../services/cart.dart';
import '../../theme/app_theme.dart';
import 'product_detail_sheet.dart';
import '../../design_system/k_network_image.dart';

void _showKarliveryPhoto(
  BuildContext context,
  String url,
  String title,
) {
  if (url.trim().isEmpty) return;

  showDialog<void>(
    context: context,
    barrierColor: Colors.black.withValues(alpha: .92),
    builder: (ctx) => Dialog.fullscreen(
      backgroundColor: Colors.black,
      child: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(
              child: InteractiveViewer(
                minScale: .8,
                maxScale: 4,
                child: Center(
                  child: KNetImage(
                    url,
                    fit: BoxFit.contain,
                    errorBuilder: (_, _, _) => const Icon(
                      Icons.broken_image_outlined,
                      color: Colors.white,
                      size: 64,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              top: 10,
              left: 10,
              child: IconButton.filled(
                style: IconButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.black,
                ),
                onPressed: () => Navigator.pop(ctx),
                icon: const Icon(Icons.close_rounded),
              ),
            ),
            Positioned(
              left: 20,
              right: 20,
              bottom: 24,
              child: Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 18,
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

class StoreScreen extends StatefulWidget {
  final String storeId;

  const StoreScreen({
    super.key,
    required this.storeId,
  });

  @override
  State<StoreScreen> createState() => _StoreScreenState();
}

class _StoreScreenState extends State<StoreScreen> {
  Map<String, dynamic>? store;
  List<Map<String, dynamic>> products = [];
  List<Map<String, dynamic>> gallery = [];

  bool loading = true;
  String? loadError;
  String query = '';
  String category = 'All';

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    if (mounted) {
      setState(() {
      loading = true;
      loadError = null;
      });
    }

    try {
      final result = await Future.wait([
        Backend.storeById(widget.storeId),
        Backend.productsForStore(widget.storeId),
        Backend.storeGallery(widget.storeId),
      ]);

      store = result[0] as Map<String, dynamic>?;
      products = result[1] as List<Map<String, dynamic>>;
      gallery = result[2] as List<Map<String, dynamic>>;
      if (store == null) { loadError = 'This restaurant is not available right now.'; }
    } catch (_) {
      loadError = 'Could not load this restaurant. Check your internet connection and try again.';
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  List<String> get categories {
    final values = <String>{'All'};
    for (final p in products) {
      final c = (p['category'] ?? '').toString().trim();
      if (c.isNotEmpty) values.add(c);
    }
    return values.toList();
  }

  List<Map<String, dynamic>> get featured => products
      .where(
        (p) =>
            p['is_featured'] == true &&
            p['is_available'] != false,
      )
      .toList();

  List<Map<String, dynamic>> get visibleProducts {
    final q = query.trim().toLowerCase();

    return products.where((p) {
      final hay =
          '${p['name']} ${p['description']} ${p['category']}'.toLowerCase();
      final matchesQuery = q.isEmpty || hay.contains(q);
      final matchesCategory =
          category == 'All' || p['category']?.toString() == category;

      return matchesQuery && matchesCategory;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final open = store?['is_open'] == true;
    final visible = visibleProducts;

    return Scaffold(
      bottomNavigationBar: AnimatedBuilder(
        animation: CartService.instance,
        builder: (context, _) {
          final cart = CartService.instance;
          if (cart.count == 0 || cart.storeId != widget.storeId) {
            return const SizedBox.shrink();
          }
          return SafeArea(
            top: false,
            child: Container(
              margin: const EdgeInsets.fromLTRB(14, 0, 14, 10),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppTheme.deepRed,
                borderRadius: BorderRadius.circular(22),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: .14),
                    blurRadius: 22,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: .14),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Center(
                      child: Text(
                        '${cart.count}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'View basket',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Text(
                          money(cart.subtotal),
                          style: const TextStyle(
                            color: AppTheme.warmYellow,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                  FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: AppTheme.yellow,
                      foregroundColor: AppTheme.ink,
                    ),
                    onPressed: () => context.push('/cart'),
                    child: const Text('Checkout'),
                  ),
                ],
              ),
            ),
          );
        },
      ),
      body: loading
          ? const KLoadingState(message: 'Loading store menu…')
          : loadError != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.wifi_off_rounded, size: 48),
                        const SizedBox(height: 12),
                        Text(loadError!, textAlign: TextAlign.center),
                        const SizedBox(height: 16),
                        FilledButton.icon(
                          onPressed: load,
                          icon: const Icon(Icons.refresh_rounded),
                          label: const Text('Try again'),
                        ),
                      ],
                    ),
                  ),
                )
              : RefreshIndicator(
              onRefresh: load,
              child: CustomScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                slivers: [
                  SliverToBoxAdapter(
                    child: _StoreHeader(
                      store: store,
                      gallery: gallery,
                      open: open,
                      onBack: () => KarliveryBack.navigate(context, '/customer'),
                    ),
                  ),
                  if ((int.tryParse(
                            store?['rating_count']?.toString() ?? '0',
                          ) ??
                          0) >
                      0)
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(18, 4, 18, 0),
                      sliver: SliverToBoxAdapter(
                        child: OutlinedButton.icon(
                          onPressed: () => context.push(
                            '/store/${widget.storeId}/reviews',
                          ),
                          icon: const Icon(Icons.reviews_rounded),
                          label: Text(
                            'See ${store?['rating_count']} verified reviews',
                          ),
                        ),
                      ),
                    ),
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(18, 16, 18, 0),
                    sliver: SliverToBoxAdapter(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          if (gallery.length > 1)
                            _GalleryStrip(gallery: gallery.skip(1).toList()),
                          if (gallery.length > 1)
                            const SizedBox(height: 18),
                          TextField(
                            onChanged: (value) =>
                                setState(() => query = value),
                            decoration: const InputDecoration(
                              hintText: 'Search this menu…',
                              prefixIcon:
                                  Icon(Icons.search_rounded, size: 28),
                              suffixIcon: Icon(Icons.tune_rounded),
                            ),
                          ),
                          const SizedBox(height: 12),
                          SizedBox(
                            height: 45,
                            child: ListView.separated(
                              scrollDirection: Axis.horizontal,
                              itemCount: categories.length,
                              separatorBuilder: (_, _) =>
                                  const SizedBox(width: 8),
                              itemBuilder: (_, i) {
                                final c = categories[i];
                                return FilterChip(
                                  selected: category == c,
                                  showCheckmark: false,
                                  label: Text(c),
                                  onSelected: (_) =>
                                      setState(() => category = c),
                                );
                              },
                            ),
                          ),
                          if (featured.isNotEmpty) ...[
                            const SizedBox(height: 22),
                            _SectionTitle(
                              icon: Icons.local_fire_department_rounded,
                              title: 'Featured Items',
                              subtitle:
                                  'Highlighted dishes from this store',
                              count: '${featured.length} picks',
                            ),
                            const SizedBox(height: 11),
                          ],
                        ],
                      ),
                    ),
                  ),
                  if (featured.isNotEmpty)
                    SliverToBoxAdapter(
                      child: SizedBox(
                        height: 237,
                        child: ListView.separated(
                          padding:
                              const EdgeInsets.symmetric(horizontal: 18),
                          scrollDirection: Axis.horizontal,
                          itemCount: featured.length,
                          separatorBuilder: (_, _) =>
                              const SizedBox(width: 12),
                          itemBuilder: (_, i) => _FeaturedDish(
                            product: featured[i],
                            enabled: open,
                            onTap: () => _customizeAndAdd(featured[i]),
                          ),
                        ),
                      ),
                    ),
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(18, 24, 18, 10),
                    sliver: SliverToBoxAdapter(
                      child: _SectionTitle(
                        icon: Icons.restaurant_menu_rounded,
                        title: 'Full Menu',
                        subtitle: open
                            ? 'Choose your favorites'
                            : 'This store is currently closed',
                        count: '${visible.length} items',
                      ),
                    ),
                  ),
                  if (!open)
                    const SliverPadding(
                      padding: EdgeInsets.fromLTRB(18, 0, 18, 12),
                      sliver: SliverToBoxAdapter(
                        child: _ClosedNotice(),
                      ),
                    ),
                  if (visible.isEmpty)
                    const SliverPadding(
                      padding: EdgeInsets.fromLTRB(18, 8, 18, 110),
                      sliver: SliverToBoxAdapter(
                        child: _MenuEmpty(),
                      ),
                    )
                  else
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(18, 0, 18, 110),
                      sliver: SliverList.separated(
                        itemCount: visible.length,
                        separatorBuilder: (_, _) =>
                            const SizedBox(height: 10),
                        itemBuilder: (_, i) => _MenuDish(
                          product: visible[i],
                          enabled:
                              open && visible[i]['is_available'] != false,
                          onTap: () => _customizeAndAdd(visible[i]),
                        ),
                      ),
                    ),
                ],
              ),
            ),
    );
  }

  Future<void> _customizeAndAdd(
    Map<String, dynamic> product,
  ) async {
    final added = await showKarliveryProductSheet(
      context,
      product: product,
      storeId: widget.storeId,
      storeName: store?['name']?.toString() ?? 'Store',
      storeOpen: store?['is_open'] == true,
    );

    if (added && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            '${product['name'] ?? 'Item'} added to basket',
          ),
        ),
      );
    }
  }

}

class _StoreHeader extends StatelessWidget {
  final Map<String, dynamic>? store;
  final List<Map<String, dynamic>> gallery;
  final bool open;
  final VoidCallback onBack;

  const _StoreHeader({
    required this.store,
    required this.gallery,
    required this.open,
    required this.onBack,
  });

  @override
  Widget build(BuildContext context) {
    final logo = (store?['logo_url'] ?? '').toString();
    final gcash =
        (store?['gcash_number'] ?? '').toString().trim().isNotEmpty;
    final hero = gallery.isNotEmpty
        ? (gallery.first['image_url'] ?? '').toString()
        : '';

    return Column(
      children: [
        SizedBox(
          height: 225,
          child: Stack(
            fit: StackFit.expand,
            children: [
              if (hero.isNotEmpty)
                KNetImage(
                  hero,
                  fit: BoxFit.cover,
                  errorBuilder: (_, _, _) =>
                      const _StoreHeroFallback(),
                )
              else
                const _StoreHeroFallback(),
              const DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color(0x55000000),
                      Colors.transparent,
                      Color(0xAA000000),
                    ],
                  ),
                ),
              ),
              Positioned(
                top: MediaQuery.of(context).padding.top + 10,
                left: 16,
                child: _OverlayButton(
                  icon: Icons.arrow_back_rounded,
                  onTap: onBack,
                ),
              ),
              Positioned(
                top: MediaQuery.of(context).padding.top + 10,
                right: 16,
                child: Row(
                  children: [
                    _OverlayButton(
                      icon: Icons.share_outlined,
                      onTap: () async {
                        final id = store?['id']?.toString();
                        if (id == null || id.isEmpty) return;
                        final url = 'https://karlivery.pages.dev/#/store/${Uri.encodeComponent(id)}';
                        await Clipboard.setData(ClipboardData(text: url));
                        if (!context.mounted) return;
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Restaurant link copied.')),
                        );
                      },
                    ),
                  ],
                ),
              ),
              Positioned(
                left: 20,
                right: 20,
                bottom: 18,
                child: Text(
                  store?['name']?.toString() ?? 'Your local favorite',
                  maxLines: 2, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 27,
                    height: 1.06,
                    letterSpacing: -.8,
                  ),
                ),
              ),
            ],
          ),
        ),
        Transform.translate(
          offset: const Offset(0, -2),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
            decoration: BoxDecoration(
              color: Theme.of(context).scaffoldBackgroundColor,
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(30),
              ),
            ),
            child: Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 72,
                      height: 72,
                      padding: const EdgeInsets.all(5),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(21),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: .08),
                            blurRadius: 18,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: logo.isNotEmpty
                            ? KNetImage(
                                logo,
                                fit: BoxFit.cover,
                                errorBuilder: (_, _, _) =>
                                    const _LogoFallback(),
                              )
                            : const _LogoFallback(),
                      ),
                    ),
                    const SizedBox(width: 13),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(top: 5),
                        child: Column(
                          crossAxisAlignment:
                              CrossAxisAlignment.start,
                          children: [
                            Text(
                              store?['name']?.toString() ?? 'Store',
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 21,
                                letterSpacing: -.55,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Row(
                              children: [
                                const Icon(
                                  Icons.location_on_rounded,
                                  color: AppTheme.red,
                                  size: 18,
                                ),
                                const SizedBox(width: 4),
                                Expanded(
                                  child: Text(
                                    (store?['barangay'] ??
                                            'Local restaurant')
                                        .toString(),
                                    style: const TextStyle(
                                      color: AppTheme.muted,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            if ((store?['description'] ?? '')
                                .toString()
                                .trim()
                                .isNotEmpty) ...[
                              const SizedBox(height: 7),
                              Text(
                                store!['description'].toString(),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 13),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Wrap(
                    spacing: 7,
                    runSpacing: 7,
                    children: [
                      _StoreBadge(
                        icon: open
                            ? Icons.bolt_rounded
                            : Icons.schedule_rounded,
                        text: open ? 'Open now' : 'Closed',
                        color: open
                            ? const Color(0xFF209E63)
                            : AppTheme.muted,
                      ),
                      if (store?['schedule_enabled'] == true)
                        _StoreBadge(
                          icon: Icons.access_time_rounded,
                          text: (store?['schedule_label'] ?? 'Scheduled hours')
                              .toString(),
                          color: AppTheme.deepRed,
                        ),
                      _StoreBadge(
                        icon: Icons.star_rounded,
                        text: (() {
                          final count = int.tryParse(
                                store?['rating_count']?.toString() ?? '0',
                              ) ??
                              0;
                          final avg = double.tryParse(
                            store?['rating_avg']?.toString() ?? '',
                          );
                          if (count == 0 || avg == null) return 'New';
                          return '${avg.toStringAsFixed(1)} ($count)';
                        })(),
                        color: const Color(0xFFE5A000),
                      ),
                      const _StoreBadge(
                        icon: Icons.payments_outlined,
                        text: 'COD',
                        color: AppTheme.deepRed,
                      ),
                      if (gcash)
                        const _StoreBadge(
                          icon: Icons.qr_code_2_rounded,
                          text: 'GCash',
                          color: Color(0xFF1377E8),
                        ),
                      const _StoreBadge(
                        icon: Icons.shopping_bag_rounded,
                        text: 'Pick-up',
                        color: Color(0xFFE9A000),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _StoreHeroFallback extends StatelessWidget {
  const _StoreHeroFallback();

  @override
  Widget build(BuildContext context) => const DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              AppTheme.deepRed,
              AppTheme.red,
              Color(0xFFFFB61F),
            ],
          ),
        ),
        child: Center(
          child: Icon(
            Icons.restaurant_rounded,
            color: Colors.white,
            size: 92,
          ),
        ),
      );
}

class _OverlayButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _OverlayButton({
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => Material(
        color: Colors.white.withValues(alpha: .94),
        shape: const CircleBorder(),
        child: InkWell(
          onTap: onTap,
          customBorder: const CircleBorder(),
          child: SizedBox(
            width: 46,
            height: 46,
            child: Icon(icon, color: AppTheme.ink),
          ),
        ),
      );
}

class _LogoFallback extends StatelessWidget {
  const _LogoFallback();

  @override
  Widget build(BuildContext context) => Container(
        color: AppTheme.softYellow,
        child: const Icon(
          Icons.storefront_rounded,
          color: AppTheme.red,
          size: 44,
        ),
      );
}

class _StoreBadge extends StatelessWidget {
  final IconData icon;
  final String text;
  final Color color;

  const _StoreBadge({
    required this.icon,
    required this.text,
    required this.color,
  });

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(
          horizontal: 11,
          vertical: 8,
        ),
        decoration: BoxDecoration(
          color: color.withValues(alpha: .10),
          borderRadius: BorderRadius.circular(999),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 16, color: color),
            const SizedBox(width: 5),
            Text(
              text,
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.w700,
                fontSize: 12,
              ),
            ),
          ],
        ),
      );
}

class _GalleryStrip extends StatelessWidget {
  final List<Map<String, dynamic>> gallery;

  const _GalleryStrip({
    required this.gallery,
  });

  @override
  Widget build(BuildContext context) => SizedBox(
        height: 138,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          itemCount: gallery.length,
          separatorBuilder: (_, _) => const SizedBox(width: 9),
          itemBuilder: (_, i) {
            final url = gallery[i]['image_url'].toString();
            return GestureDetector(
              onTap: () => _showKarliveryPhoto(
                context,
                url,
                'Store photo',
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(22),
                child: KNetImage(
                  url,
                  width: i == 0 ? 250 : 150,
                  height: 138,
                  fit: BoxFit.cover,
                  errorBuilder: (_, _, _) => Container(
                    width: 150,
                    color: AppTheme.softYellow,
                    child: const Icon(
                      Icons.image_not_supported_outlined,
                      color: AppTheme.red,
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      );
}

class _SectionTitle extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final String count;

  const _SectionTitle({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.count,
  });

  @override
  Widget build(BuildContext context) => Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Icon(icon, color: AppTheme.red, size: 25),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
          Text(
            count,
            style: const TextStyle(
              color: AppTheme.muted,
              fontWeight: FontWeight.w600,
              fontSize: 12,
            ),
          ),
        ],
      );
}

class _FeaturedDish extends StatelessWidget {
  final Map<String, dynamic> product;
  final bool enabled;
  final VoidCallback onTap;

  const _FeaturedDish({
    required this.product,
    required this.enabled,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final image = (product['image_url'] ?? '').toString();

    return SizedBox(
      width: 198,
      child: Card(
        child: InkWell(
          onTap: enabled ? onTap : null,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    GestureDetector(
                      onTap: image.isEmpty
                          ? null
                          : () => _showKarliveryPhoto(
                                context,
                                image,
                                product['name']?.toString() ?? 'Menu item',
                              ),
                      child: image.isEmpty
                          ? const _DishFallback()
                          : KNetImage(
                              image,
                              fit: BoxFit.cover,
                              errorBuilder: (_, _, _) =>
                                  const _DishFallback(),
                            ),
                    ),
                    Positioned(
                      left: 9,
                      top: 9,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 9,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: AppTheme.red,
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: const Text(
                          'Featured',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [
                          Text(
                            product['name']?.toString() ?? 'Dish',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 15,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            money(
                              num.tryParse(
                                product['price']?.toString() ?? '0',
                              ),
                            ),
                            style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 16,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              const Icon(
                                Icons.schedule_rounded,
                                size: 13,
                                color: AppTheme.muted,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                'Prep ${prepTimeLabel(product)}',
                                style: const TextStyle(
                                  color: AppTheme.muted,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    _AddButton(
                      enabled: enabled,
                      onTap: onTap,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MenuDish extends StatelessWidget {
  final Map<String, dynamic> product;
  final bool enabled;
  final VoidCallback onTap;

  const _MenuDish({
    required this.product,
    required this.enabled,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final image = (product['image_url'] ?? '').toString();

    return Card(
      child: InkWell(
        onTap: enabled ? onTap : null,
        child: Padding(
          padding: const EdgeInsets.all(11),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: SizedBox(
                  width: 96,
                  height: 96,
                  child: GestureDetector(
                    onTap: image.isEmpty
                        ? null
                        : () => _showKarliveryPhoto(
                              context,
                              image,
                              product['name']?.toString() ?? 'Menu item',
                            ),
                    child: image.isEmpty
                        ? const _DishFallback()
                        : KNetImage(
                            image,
                            fit: BoxFit.cover,
                            errorBuilder: (_, _, _) =>
                                const _DishFallback(),
                          ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            product['name']?.toString() ?? 'Dish',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 16,
                            ),
                          ),
                        ),
                        if (product['is_featured'] == true)
                          const Icon(
                            Icons.local_fire_department_rounded,
                            color: AppTheme.red,
                            size: 18,
                          ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      (product['description'] ?? '').toString(),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppTheme.muted,
                        fontSize: 12,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Text(
                          money(
                            num.tryParse(
                              product['price']?.toString() ?? '0',
                            ),
                          ),
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 16.5,
                          ),
                        ),
                        const SizedBox(width: 10),
                        const Icon(
                          Icons.schedule_rounded,
                          size: 14,
                          color: AppTheme.muted,
                        ),
                        const SizedBox(width: 4),
                        Flexible(
                          child: Text(
                            prepTimeLabel(product),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: AppTheme.muted,
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              _AddButton(
                enabled: enabled,
                onTap: onTap,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AddButton extends StatelessWidget {
  final bool enabled;
  final VoidCallback onTap;

  const _AddButton({
    required this.enabled,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => Material(
        color: enabled
            ? AppTheme.red
            : Theme.of(context).disabledColor,
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: enabled ? onTap : null,
          child: const SizedBox(
            width: 44,
            height: 44,
            child: Icon(
              Icons.add_rounded,
              color: Colors.white,
              size: 28,
            ),
          ),
        ),
      );
}

class _DishFallback extends StatelessWidget {
  const _DishFallback();

  @override
  Widget build(BuildContext context) => Container(
        color: AppTheme.softYellow,
        child: const Center(
          child: Icon(
            Icons.fastfood_rounded,
            color: AppTheme.red,
            size: 40,
          ),
        ),
      );
}

class _ClosedNotice extends StatelessWidget {
  const _ClosedNotice();

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppTheme.softYellow,
          borderRadius: BorderRadius.circular(20),
        ),
        child: const Row(
          children: [
            Icon(
              Icons.schedule_rounded,
              color: AppTheme.deepRed,
            ),
            SizedBox(width: 10),
            Expanded(
              child: Text(
                'This store is closed right now. You can still browse its menu.',
                style: TextStyle(
                  color: AppTheme.deepRed,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      );
}

class _MenuEmpty extends StatelessWidget {
  const _MenuEmpty();

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const Icon(
                Icons.search_off_rounded,
                color: AppTheme.red,
                size: 42,
              ),
              const SizedBox(height: 10),
              Text(
                'No matching menu items',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 4),
              const Text(
                'Try a different search or category.',
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      );
}
