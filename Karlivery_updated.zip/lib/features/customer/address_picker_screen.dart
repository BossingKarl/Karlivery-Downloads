import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../../core/brand.dart';
import '../../core/camiling_barangays.dart';
import '../../services/backend.dart';
import '../../services/location_service.dart';
import '../../theme/app_theme.dart';

class AddressPickerScreen extends StatefulWidget {
  const AddressPickerScreen({super.key});

  @override
  State<AddressPickerScreen> createState() => _AddressPickerScreenState();
}

class _AddressPickerScreenState extends State<AddressPickerScreen> {
  final map = MapController();
  final recipient = TextEditingController();
  final phone = TextEditingController();
  final address = TextEditingController();
  String? selectedBarangay;
  final city = TextEditingController(text: 'Camiling');
  final province = TextEditingController(text: 'Tarlac');
  final landmark = TextEditingController();
  final label = TextEditingController(text: 'Home');

  LatLng pin = const LatLng(15.6866, 120.4125);
  bool locating = false;
  bool saving = false;

  @override
  void dispose() {
    recipient.dispose();
    phone.dispose();
    address.dispose();
    city.dispose();
    province.dispose();
    landmark.dispose();
    label.dispose();
    super.dispose();
  }

  Future<void> locateMe() async {
    setState(() => locating = true);
    try {
      final result = await LocationService.currentWithAddress();
      if (!mounted) return;
      if (result == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Location is unavailable. Turn on location or choose a pin manually.'),
          ),
        );
        return;
      }
      await applyLocation(result);
      map.move(pin, 17);
    } finally {
      if (mounted) setState(() => locating = false);
    }
  }

  Future<void> choosePin(LatLng value) async {
    setState(() => pin = value);
    final result = await LocationService.reverse(value.latitude, value.longitude);
    if (!mounted) return;
    await applyLocation(result, move: false);
  }

  Future<void> applyLocation(LocationResult result, {bool move = true}) async {
    setState(() {
      pin = LatLng(result.latitude, result.longitude);
      if (result.addressLine.isNotEmpty) address.text = result.addressLine;
      final matched = CamilingBarangays.match(result.barangay);
      if (matched != null) selectedBarangay = matched;
      if (result.city.isNotEmpty) city.text = result.city;
      if (result.province.isNotEmpty) province.text = result.province;
    });
    if (move) map.move(pin, 17);
  }

  Future<void> save() async {
    if (recipient.text.trim().isEmpty ||
        phone.text.trim().isEmpty ||
        address.text.trim().isEmpty ||
        selectedBarangay == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Complete recipient, phone, street/address and barangay.')),
      );
      return;
    }

    setState(() => saving = true);
    try {
      await Backend.addAddress(
        label: label.text.trim().isEmpty ? 'Home' : label.text.trim(),
        recipientName: recipient.text,
        phone: phone.text,
        addressLine: address.text,
        barangay: selectedBarangay!,
        city: city.text,
        province: province.text,
        landmark: landmark.text,
        latitude: pin.latitude,
        longitude: pin.longitude,
      );
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not save address: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Pin delivery address', style: TextStyle(fontWeight: FontWeight.w700)),
        ),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 120),
          children: [
            const PageTitle(
              'Where should we deliver?',
              subtitle: 'Use your current location or tap the map. We will fill what we can, and you can correct every field before saving.',
            ),
            const SizedBox(height: 16),
            Card(
              clipBehavior: Clip.antiAlias,
              child: SizedBox(
                height: 320,
                child: Stack(
                  children: [
                    FlutterMap(
                      mapController: map,
                      options: MapOptions(
                        initialCenter: pin,
                        initialZoom: 15.5,
                        onTap: (_, point) => choosePin(point),
                      ),
                      children: [
                        TileLayer(
                          urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                          userAgentPackageName: 'com.karlivery.karl_delivery',
                        ),
                        MarkerLayer(
                          markers: [
                            Marker(
                              point: pin,
                              width: 58,
                              height: 58,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Theme.of(context).colorScheme.primary,
                                  shape: BoxShape.circle,
                                  border: Border.all(color: Colors.white, width: 4),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withValues(alpha: .18),
                                      blurRadius: 18,
                                      offset: const Offset(0, 8),
                                    ),
                                  ],
                                ),
                                child: const Icon(Icons.home_rounded, color: Colors.white),
                              ),
                            ),
                          ],
                        ),
                        const RichAttributionWidget(
                          attributions: [TextSourceAttribution('OpenStreetMap contributors')],
                        ),
                      ],
                    ),
                    Positioned(
                      right: 12,
                      top: 12,
                      child: FloatingActionButton.small(
                        heroTag: 'locate-address',
                        onPressed: locating ? null : locateMe,
                        child: locating
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.my_location_rounded),
                      ),
                    ),
                    Positioned(
                      left: 12,
                      bottom: 12,
                      right: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.surface.withValues(alpha: .92),
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: const Row(
                          children: [
                            Icon(Icons.touch_app_rounded, size: 18, color: AppTheme.red),
                            SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                'Tap the map to move your delivery pin',
                                style: TextStyle(fontWeight: FontWeight.w700),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            FilledButton.tonalIcon(
              onPressed: locating ? null : locateMe,
              icon: const Icon(Icons.near_me_rounded),
              label: const Text('Use my current location'),
            ),
            const SizedBox(height: 18),
            _field(label, 'Address label', Icons.bookmark_outline_rounded, hint: 'Home, Work, Dorm...'),
            const SizedBox(height: 10),
            _field(recipient, 'Recipient name', Icons.person_outline_rounded),
            const SizedBox(height: 10),
            _field(phone, 'Mobile number', Icons.phone_iphone_rounded, keyboard: TextInputType.phone),
            const SizedBox(height: 10),
            _field(address, 'Street / house / building', Icons.home_work_outlined),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              initialValue: selectedBarangay,
              isExpanded: true,
              decoration: const InputDecoration(
                labelText: 'Barangay',
                prefixIcon: Icon(Icons.location_city_rounded),
                helperText: 'Auto-selected from GPS when recognized. You can change it anytime.',
              ),
              hint: const Text('Choose barangay'),
              items: CamilingBarangays.values
                  .map(
                    (barangay) => DropdownMenuItem(
                      value: barangay,
                      child: Text(barangay),
                    ),
                  )
                  .toList(),
              onChanged: (value) => setState(() => selectedBarangay = value),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(child: _field(city, 'City / Municipality', Icons.map_outlined)),
                const SizedBox(width: 10),
                Expanded(child: _field(province, 'Province', Icons.public_rounded)),
              ],
            ),
            const SizedBox(height: 10),
            _field(landmark, 'Nearby landmark (optional)', Icons.flag_outlined),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: .55),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                children: [
                  Icon(Icons.pin_drop_rounded, color: Theme.of(context).colorScheme.primary),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      '${pin.latitude.toStringAsFixed(6)}, ${pin.longitude.toStringAsFixed(6)}',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: saving ? null : save,
              icon: saving
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.check_rounded),
              label: Text(saving ? 'Saving address...' : 'Save delivery address'),
            ),
          ],
        ),
      );

  Widget _field(
    TextEditingController controller,
    String label,
    IconData icon, {
    String? hint,
    TextInputType? keyboard,
  }) => TextField(
        controller: controller,
        keyboardType: keyboard,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          prefixIcon: Icon(icon),
        ),
      );
}
