import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/brand.dart';
import '../../core/modern_ui.dart';
import '../../core/utils.dart';
import '../../services/backend.dart';
import '../../services/cart.dart';
import '../../theme/app_theme.dart';
import '../../design_system/k_network_image.dart';

class GuestBrowseScreen extends StatefulWidget {
  const GuestBrowseScreen({super.key});

  @override
  State<GuestBrowseScreen> createState() => _GuestBrowseScreenState();
}

class _GuestBrowseScreenState extends State<GuestBrowseScreen> {
  List<Map<String, dynamic>> stores = [];
  List<Map<String, dynamic>> featured = [];
  bool loading = true;
  String? loadError;
  String query = '';
  String sort = 'popular';

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() {
      loading = true;
      loadError = null;
    });
    try {
      final results = await Future.wait([
        Backend.approvedStores(),
        Backend.featuredProducts(limit: 16),
      ]);
      stores = results[0];
      featured = results[1];
    } catch (_) {
      loadError = 'We could not load the restaurant list. Check your internet connection and try again.';
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  List<Map<String, dynamic>> get visibleStores {
    final q = query.trim().toLowerCase();
    final result = stores.where((s) {
      if (q.isEmpty) return true;
      return '${s['name']} ${s['barangay']} ${s['description']}'
          .toLowerCase()
          .contains(q);
    }).toList();

    double n(Map<String, dynamic> m, String key) =>
        double.tryParse(m[key]?.toString() ?? '') ?? 0;

    switch (sort) {
      case 'rating':
        result.sort(
          (a, b) => n(b, 'rating_avg').compareTo(n(a, 'rating_avg')),
        );
        break;
      case 'fastest':
        result.sort(
          (a, b) =>
              n(a, 'eta_min_minutes').compareTo(n(b, 'eta_min_minutes')),
        );
        break;
      case 'popular':
      default:
        result.sort(
          (a, b) =>
              n(b, 'completed_orders').compareTo(n(a, 'completed_orders')),
        );
    }
    return result;
  }

  List<Map<String, dynamic>> get visibleFeatured {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return featured;
    return featured.where((p) {
      return '${p['name']} ${p['description']} ${p['_store_name']}'
          .toLowerCase()
          .contains(q);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final storeResults = visibleStores;
    final dishResults = visibleFeatured;

    return KDashboardScaffold(
      appBar: AppBar(
        title: const KarliveryWordmark(compact: true),
        actions: [
          IconButton(
            tooltip: 'How Karlivery works',
            onPressed: () => context.push('/help?role=customer'),
            icon: const Icon(Icons.help_outline_rounded),
          ),
          AnimatedBuilder(
            animation: CartService.instance,
            builder: (_, _) => IconButton(
              tooltip: 'Basket',
              onPressed: () => context.push('/cart'),
              icon: Badge(
                isLabelVisible: CartService.instance.count > 0,
                label: Text('${CartService.instance.count}'),
                child: const Icon(Icons.shopping_bag_outlined),
              ),
            ),
          ),
          TextButton(
            onPressed: () => Backend.user == null
                ? context.push('/login')
                : context.go('/splash'),
            child: Text(Backend.user == null ? 'Sign in' : 'My account'),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: load,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(18, 10, 18, 30),
          children: [
            const KPageHeader(
              eyebrow: 'Browse before you sign in',
              title: 'Find your next meal.',
              subtitle:
                  'Explore restaurants, preparation time and featured dishes. Karlivery asks you to sign in only when you are ready to check out.',
              icon: Icons.restaurant_rounded,
            ),
            const SizedBox(height: 14),
            TextField(
              onChanged: (v) => setState(() => query = v),
              decoration: InputDecoration(
                hintText: 'Search restaurants or food…',
                prefixIcon: const Icon(Icons.search_rounded),
                suffixIcon: PopupMenuButton<String>(
                  tooltip: 'Sort restaurants',
                  initialValue: sort,
                  onSelected: (v) => setState(() => sort = v),
                  icon: const Icon(Icons.tune_rounded),
                  itemBuilder: (_) => const [
                    PopupMenuItem(
                      value: 'popular',
                      child: Text('Most ordered'),
                    ),
                    PopupMenuItem(
                      value: 'rating',
                      child: Text('Top rated'),
                    ),
                    PopupMenuItem(
                      value: 'fastest',
                      child: Text('Fastest prep'),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: Text(
                    query.isEmpty ? 'Restaurants' : 'Matching restaurants',
                    style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 20,
                    ),
                  ),
                ),
                Text(
                  '${storeResults.length} stores',
                  style: const TextStyle(
                    color: AppTheme.muted,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            if (loading)
              const KLoadingState(message: 'Finding local restaurants…')
            else if (loadError != null && stores.isEmpty)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      const Icon(Icons.wifi_off_rounded, size: 40, color: AppTheme.red),
                      const SizedBox(height: 8),
                      Text(loadError!, textAlign: TextAlign.center),
                      const SizedBox(height: 12),
                      FilledButton.tonalIcon(
                        onPressed: load,
                        icon: const Icon(Icons.refresh_rounded),
                        label: const Text('Try again'),
                      ),
                    ],
                  ),
                ),
              )
            else if (storeResults.isEmpty)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(22),
                  child: Text(
                    'No matching restaurants yet.',
                    textAlign: TextAlign.center,
                  ),
                ),
              )
            else
              ...storeResults.map(
                (store) => _GuestRestaurantCard(store: store),
              ),
            const SizedBox(height: 22),
            Text(
              query.isEmpty ? 'Featured dishes' : 'Matching dishes',
              style: const TextStyle(
                fontWeight: FontWeight.w700,
                fontSize: 20,
              ),
            ),
            const SizedBox(height: 10),
            if (!loading && dishResults.isEmpty)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Text('Featured dishes will appear here.'),
                ),
              )
            else
              SizedBox(
                height: 220,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: dishResults.length,
                  separatorBuilder: (_, _) => const SizedBox(width: 10),
                  itemBuilder: (_, i) =>
                      _GuestDishCard(product: dishResults[i]),
                ),
              ),
            const SizedBox(height: 24),
            if (Backend.user == null)
              OutlinedButton.icon(
                onPressed: () => context.push('/register'),
                icon: const Icon(Icons.person_add_alt_1_rounded),
                label: const Text('Create customer account'),
              ),
          ],
        ),
      ),
    );
  }
}

class _GuestRestaurantCard extends StatelessWidget {
  final Map<String, dynamic> store;

  const _GuestRestaurantCard({required this.store});

  @override
  Widget build(BuildContext context) {
    final logo = (store['logo_url'] ?? '').toString();
    final rating = double.tryParse(store['rating_avg']?.toString() ?? '');
    final count = int.tryParse(store['rating_count']?.toString() ?? '0') ?? 0;
    final orders =
        int.tryParse(store['completed_orders']?.toString() ?? '0') ?? 0;
    final etaMin =
        int.tryParse(store['eta_min_minutes']?.toString() ?? '15') ?? 15;
    final etaMax =
        int.tryParse(store['eta_max_minutes']?.toString() ?? '30') ?? 30;
    final open = store['is_open'] == true;

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: () => context.push('/store/${store['id']}'),
        child: Padding(
          padding: const EdgeInsets.all(13),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(19),
                child: SizedBox(
                  width: 82,
                  height: 82,
                  child: logo.isEmpty
                      ? Container(
                          color: AppTheme.softYellow,
                          child: const Icon(
                            Icons.storefront_rounded,
                            color: AppTheme.red,
                            size: 38,
                          ),
                        )
                      : KNetImage(
                          logo,
                          fit: BoxFit.cover,
                          errorBuilder: (_, _, _) => Container(
                            color: AppTheme.softYellow,
                            child: const Icon(
                              Icons.storefront_rounded,
                              color: AppTheme.red,
                            ),
                          ),
                        ),
                ),
              ),
              const SizedBox(width: 13),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            store['name']?.toString() ?? 'Restaurant',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 16,
                            ),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 5,
                          ),
                          decoration: BoxDecoration(
                            color: open
                                ? const Color(0xFFE9F8EF)
                                : Theme.of(context)
                                    .colorScheme
                                    .surfaceContainerHighest,
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            open ? 'OPEN' : 'CLOSED',
                            style: TextStyle(
                              color: open
                                  ? const Color(0xFF198754)
                                  : AppTheme.muted,
                              fontWeight: FontWeight.w700,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      (store['barangay'] ?? 'Camiling').toString(),
                      style: const TextStyle(color: AppTheme.muted),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 10,
                      runSpacing: 5,
                      children: [
                        Text(
                          count == 0 || rating == null
                              ? '★ New'
                              : '★ ${rating.toStringAsFixed(1)} ($count)',
                          style: const TextStyle(
                            color: Color(0xFFE5A000),
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Text(
                          '$etaMin–$etaMax min',
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                        if (orders > 0)
                          Text(
                            '$orders orders',
                            style: const TextStyle(
                              color: AppTheme.muted,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded),
            ],
          ),
        ),
      ),
    );
  }
}

class _GuestDishCard extends StatelessWidget {
  final Map<String, dynamic> product;

  const _GuestDishCard({required this.product});

  @override
  Widget build(BuildContext context) {
    final image = (product['image_url'] ?? '').toString();

    return SizedBox(
      width: 175,
      child: Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => context.push('/store/${product['_store_id']}'),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(
                child: image.isEmpty
                    ? Container(
                        color: AppTheme.softYellow,
                        child: const Icon(
                          Icons.fastfood_rounded,
                          color: AppTheme.red,
                          size: 42,
                        ),
                      )
                    : KNetImage(
                        image,
                        fit: BoxFit.cover,
                        errorBuilder: (_, _, _) => Container(
                          color: AppTheme.softYellow,
                          child: const Icon(
                            Icons.fastfood_rounded,
                            color: AppTheme.red,
                          ),
                        ),
                      ),
              ),
              Padding(
                padding: const EdgeInsets.all(11),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      product['name']?.toString() ?? 'Dish',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                    Text(
                      product['_store_name']?.toString() ?? 'Karlivery',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppTheme.muted,
                        fontSize: 12,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      money(num.tryParse(product['price']?.toString() ?? '0')),
                      style: const TextStyle(
                        color: AppTheme.red,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
