import '../../core/smart_back.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/utils.dart';
import '../../services/backend.dart';
import '../../theme/app_theme.dart';
import '../shared/rating_sheet.dart';
import '../shared/order_receipt_screen.dart';

class CustomerOrderDetailScreen extends StatelessWidget {
  final String orderId;

  const CustomerOrderDetailScreen({super.key, required this.orderId});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          leading: const KarliveryBackButton(fallback: '/customer'),
          title: const Text(
            'Order details',
            style: TextStyle(fontWeight: FontWeight.w700),
          ),
        ),
        body: FutureBuilder<Map<String, dynamic>?>(
          future: Backend.orderDetails(orderId),
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }

            final order = snapshot.data;
            if (order == null) {
              return const Center(
                child: Padding(
                  padding: EdgeInsets.all(28),
                  child: Text(
                    'This order is unavailable.',
                    textAlign: TextAlign.center,
                  ),
                ),
              );
            }

            final status = (order['status'] ?? '').toString();
            final sellerDelivers = order['delivery_provider'] == 'seller';
            final hasRider = order['rider_id'] != null;
            final canTrack = !sellerDelivers && hasRider &&
                order['fulfillment'] == 'delivery' &&
                ['assigned', 'picked_up', 'delivering'].contains(status);
            final store = order['stores'];
            final storeName =
                store is Map ? store['name']?.toString() : 'Restaurant';

            return ListView(
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 30),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          order['order_no']?.toString() ?? 'Order',
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 22,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          storeName ?? 'Restaurant',
                          style: const TextStyle(
                            color: AppTheme.muted,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 14),
                        Row(
                          children: [
                            Expanded(
                              child: _Info(
                                label: 'Status',
                                value: niceStatus(status),
                              ),
                            ),
                            Expanded(
                              child: _Info(
                                label: 'Total',
                                value: money(
                                  num.tryParse(
                                    order['total']?.toString() ?? '0',
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                if (sellerDelivers && order['fulfillment'] == 'delivery')
                  Card(
                    child: ListTile(
                      leading: const Icon(Icons.local_shipping_rounded, color: AppTheme.red),
                      title: const Text('Delivered by the restaurant',
                        style: TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: const Text(
                        'This store uses its own delivery rider. The same distance-based delivery rate applies. Contact the store through the order chat for updates.'),
                    ),
                  ),
                if ((order['payment_method'] ?? '').toString().toLowerCase() == 'gcash') ...[
                  const SizedBox(height: 14),
                  _GcashPaymentStatus(order: order),
                ],
                const SizedBox(height: 14),
                _SimpleTimeline(status: status),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => context.push('/chat/$orderId'),
                        icon: const Icon(Icons.forum_rounded),
                        label: const Text('Order chat'),
                      ),
                    ),
                    if (canTrack) ...[
                      const SizedBox(width: 10),
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: () => context.push('/track/$orderId'),
                          icon: const Icon(Icons.location_on_rounded),
                          label: const Text('Live tracking'),
                        ),
                      ),
                    ],
                  ],
                ),
                if (['delivered', 'completed'].contains(status)) ...[
                  const SizedBox(height: 14),
                  FilledButton.icon(
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => OrderReceiptScreen(orderId: orderId),
                    )),
                    icon: const Icon(Icons.receipt_long_rounded),
                    label: const Text('View completed-order receipt'),
                  ),
                  RateOrderCard(order: order),
                ],
              ],
            );
          },
        ),
      );
}

class _GcashPaymentStatus extends StatefulWidget {
  final Map<String, dynamic> order;
  const _GcashPaymentStatus({required this.order});

  @override
  State<_GcashPaymentStatus> createState() => _GcashPaymentStatusState();
}

class _GcashPaymentStatusState extends State<_GcashPaymentStatus> {
  bool busy = false;
  late bool sent;
  late bool received;
  late bool rejected;
  late String reason;
  late String reference;
  late String proofPath;

  @override
  void initState() {
    super.initState();
    _sync(widget.order);
  }

  void _sync(Map<String, dynamic> order) {
    sent = order['customer_gcash_sent_at'] != null;
    received = order['seller_gcash_received_at'] != null;
    rejected = order['gcash_rejected_at'] != null;
    reason = (order['gcash_rejection_reason'] ?? '').toString();
    reference = (order['payment_reference_no'] ?? '').toString();
    proofPath = (order['payment_proof_path'] ?? '').toString();
  }

  Future<void> _confirmSent() async {
    if (busy) return;
    if (reference.trim().isEmpty || proofPath.trim().isEmpty) {
      await _updateProof();
      return;
    }

    setState(() => busy = true);
    try {
      await Backend.customerConfirmGcashSent(widget.order['id'].toString());
      if (!mounted) return;
      setState(() {
        sent = true;
        rejected = false;
        reason = '';
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Payment marked as sent. The seller was notified.'),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not confirm payment: $e')),
      );
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _updateProof() async {
    if (busy || received) return;

    final ref = TextEditingController(text: reference);
    final picked = await FilePicker.platform.pickFiles(
      type: FileType.image,
      withData: true,
    );
    if (picked == null || picked.files.isEmpty || picked.files.single.bytes == null) {
      ref.dispose();
      return;
    }

    if (!mounted) {
      ref.dispose();
      return;
    }

    final proceed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Update GCash proof'),
        content: TextField(
          controller: ref,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            labelText: 'GCash reference number',
            helperText: 'Check the number carefully before submitting.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Submit proof'),
          ),
        ],
      ),
    );

    if (proceed != true || ref.text.trim().isEmpty) {
      ref.dispose();
      return;
    }

    final file = picked.files.single;
    final extension = file.name.contains('.')
        ? file.name.split('.').last.toLowerCase()
        : 'jpg';

    setState(() => busy = true);
    try {
      final uploaded = await Backend.uploadPaymentProof(
        orderId: widget.order['id'].toString(),
        bytes: file.bytes!,
        extension: extension,
      );
      await Backend.submitPaymentProof(
        orderId: widget.order['id'].toString(),
        proofPath: uploaded,
        referenceNo: ref.text.trim(),
      );
      await Backend.customerConfirmGcashSent(widget.order['id'].toString());

      if (!mounted) return;
      setState(() {
        proofPath = uploaded;
        reference = ref.text.trim();
        sent = true;
        received = false;
        rejected = false;
        reason = '';
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('GCash proof updated and seller notified.'),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not update payment proof: $e')),
      );
    } finally {
      ref.dispose();
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.qr_code_2_rounded, color: AppTheme.red),
                SizedBox(width: 8),
                Text(
                  'GCash payment',
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
                ),
              ],
            ),
            const SizedBox(height: 12),
            _PaymentStep(
              done: sent,
              title: sent
                  ? 'You confirmed that payment was sent'
                  : 'Confirm after sending your GCash payment',
              subtitle: 'Reference: ${reference.isEmpty ? '-' : reference}',
            ),
            const SizedBox(height: 9),
            _PaymentStep(
              done: received,
              title: received
                  ? 'Seller confirmed payment received'
                  : rejected
                      ? 'Seller needs you to check the payment'
                      : 'Seller is verifying your payment',
              subtitle: rejected && reason.isNotEmpty
                  ? reason
                  : 'Use Order Chat if either side needs clarification.',
              warning: rejected,
            ),
            if (!received) ...[
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  if (!sent)
                    FilledButton.icon(
                      onPressed: busy ? null : _confirmSent,
                      icon: const Icon(Icons.check_circle_rounded),
                      label: const Text('I sent the payment'),
                    ),
                  if (rejected || proofPath.isEmpty)
                    OutlinedButton.icon(
                      onPressed: busy ? null : _updateProof,
                      icon: const Icon(Icons.upload_file_rounded),
                      label: Text(rejected ? 'Replace proof' : 'Upload proof'),
                    ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _PaymentStep extends StatelessWidget {
  final bool done;
  final bool warning;
  final String title;
  final String subtitle;
  const _PaymentStep({
    required this.done,
    required this.title,
    required this.subtitle,
    this.warning = false,
  });

  @override
  Widget build(BuildContext context) {
    final color = warning
        ? Colors.orange
        : done
            ? const Color(0xFF198754)
            : AppTheme.muted;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(
          warning
              ? Icons.warning_amber_rounded
              : done
                  ? Icons.check_circle_rounded
                  : Icons.schedule_rounded,
          color: color,
        ),
        const SizedBox(width: 9),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 2),
              Text(subtitle, style: const TextStyle(color: AppTheme.muted)),
            ],
          ),
        ),
      ],
    );
  }
}

class _Info extends StatelessWidget {
  final String label;
  final String value;

  const _Info({required this.label, required this.value});

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: AppTheme.muted,
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            value,
            style: const TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 16,
            ),
          ),
        ],
      );
}

class _SimpleTimeline extends StatelessWidget {
  final String status;

  const _SimpleTimeline({required this.status});

  @override
  Widget build(BuildContext context) {
    const steps = [
      ('accepted', 'Order accepted', Icons.storefront_rounded),
      ('preparing', 'Preparing', Icons.restaurant_rounded),
      ('assigned', 'Rider assigned', Icons.delivery_dining_rounded),
      ('delivering', 'On the way', Icons.route_rounded),
      ('delivered', 'Delivered', Icons.home_rounded),
    ];
    const order = [
      'pending_payment',
      'payment_review',
      'paid',
      'accepted',
      'preparing',
      'ready',
      'assigned',
      'picked_up',
      'delivering',
      'delivered',
      'completed',
    ];
    var current = order.indexOf(status);
    if (current < 0) current = 0;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(17),
        child: Column(
          children: List.generate(steps.length, (i) {
            final stepIndex = order.indexOf(steps[i].$1);
            final done = current >= stepIndex;
            return Padding(
              padding: EdgeInsets.only(bottom: i == steps.length - 1 ? 0 : 12),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 17,
                    backgroundColor: done ? AppTheme.red : AppTheme.softYellow,
                    child: Icon(
                      done ? Icons.check_rounded : steps[i].$3,
                      size: 18,
                      color: done ? Colors.white : AppTheme.muted,
                    ),
                  ),
                  const SizedBox(width: 11),
                  Expanded(
                    child: Text(
                      steps[i].$2,
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: done ? null : AppTheme.muted,
                      ),
                    ),
                  ),
                  if (done)
                    const Icon(
                      Icons.check_circle_rounded,
                      color: Color(0xFF198754),
                    ),
                ],
              ),
            );
          }),
        ),
      ),
    );
  }
}
