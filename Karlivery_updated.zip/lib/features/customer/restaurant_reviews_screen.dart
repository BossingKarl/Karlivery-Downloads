import '../../core/smart_back.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../services/backend.dart';
import '../../theme/app_theme.dart';

class RestaurantReviewsScreen extends StatelessWidget {
  final String storeId;

  const RestaurantReviewsScreen({super.key, required this.storeId});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          leading: const KarliveryBackButton(fallback: '/customer'),
          title: const Text(
            'Restaurant Reviews',
            style: TextStyle(fontWeight: FontWeight.w700),
          ),
        ),
        body: FutureBuilder<List<dynamic>>(
          future: Future.wait([
            Backend.storeById(storeId),
            Backend.storeReviews(storeId),
          ]),
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }

            final data = snapshot.data;
            final store =
                data == null ? null : data[0] as Map<String, dynamic>?;
            final reviews = data == null
                ? <Map<String, dynamic>>[]
                : List<Map<String, dynamic>>.from(data[1] as List);

            final avg =
                double.tryParse(store?['rating_avg']?.toString() ?? '') ??
                    (reviews.isEmpty
                        ? 0
                        : reviews.fold<double>(
                              0,
                              (sum, r) =>
                                  sum +
                                  (int.tryParse(
                                        r['rating']?.toString() ?? '0',
                                      ) ??
                                      0),
                            ) /
                            reviews.length);

            return ListView(
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 28),
              children: [
                Text(
                  store?['name']?.toString() ?? 'Restaurant',
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 24,
                  ),
                ),
                const SizedBox(height: 14),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Row(
                      children: [
                        Column(
                          children: [
                            Text(
                              avg == 0 ? 'New' : avg.toStringAsFixed(1),
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 38,
                              ),
                            ),
                            const Row(
                              children: [
                                Icon(
                                  Icons.star_rounded,
                                  color: Color(0xFFFFB300),
                                ),
                                SizedBox(width: 3),
                                Text(
                                  'Restaurant rating',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 4),
                            Text('${reviews.length} verified orders'),
                          ],
                        ),
                        const SizedBox(width: 22),
                        Expanded(
                          child: Column(
                            children: [
                              for (var star = 5; star >= 1; star--)
                                _RatingBar(
                                  star: star,
                                  count: reviews
                                      .where(
                                        (r) =>
                                            int.tryParse(
                                              r['rating']?.toString() ?? '',
                                            ) ==
                                            star,
                                      )
                                      .length,
                                  total: reviews.length,
                                ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                const Text(
                  'Recent verified reviews',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 18,
                  ),
                ),
                const SizedBox(height: 10),
                if (reviews.isEmpty)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(22),
                      child: Text(
                        'No restaurant ratings yet. Ratings appear only after a real delivered/completed Karlivery order.',
                        textAlign: TextAlign.center,
                      ),
                    ),
                  )
                else
                  ...reviews.map((review) => _ReviewCard(review: review)),
              ],
            );
          },
        ),
      );
}

class _RatingBar extends StatelessWidget {
  final int star;
  final int count;
  final int total;

  const _RatingBar({
    required this.star,
    required this.count,
    required this.total,
  });

  @override
  Widget build(BuildContext context) {
    final value = total == 0 ? 0.0 : count / total;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          SizedBox(
            width: 24,
            child: Text(
              '$star',
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
          const Icon(Icons.star_rounded, size: 14, color: Color(0xFFFFB300)),
          const SizedBox(width: 6),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(999),
              child: LinearProgressIndicator(
                value: value,
                minHeight: 7,
                backgroundColor:
                    Theme.of(context).colorScheme.surfaceContainerHighest,
                valueColor:
                    const AlwaysStoppedAnimation(Color(0xFFFFB300)),
              ),
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 24,
            child: Text(
              '$count',
              textAlign: TextAlign.end,
              style: const TextStyle(color: AppTheme.muted, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }
}

class _ReviewCard extends StatelessWidget {
  final Map<String, dynamic> review;

  const _ReviewCard({required this.review});

  @override
  Widget build(BuildContext context) {
    final rating = int.tryParse(review['rating']?.toString() ?? '0') ?? 0;
    final dt = DateTime.tryParse(review['created_at']?.toString() ?? '')
        ?.toLocal();
    final date = dt == null ? '' : DateFormat('MMM d, yyyy').format(dt);
    final comment = (review['comment'] ?? '').toString().trim();

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const CircleAvatar(
                  backgroundColor: AppTheme.softRed,
                  child: Icon(Icons.person_rounded, color: AppTheme.red),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        review['customer_name']?.toString() ??
                            'Karlivery customer',
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      Text(
                        date,
                        style: const TextStyle(
                          color: AppTheme.muted,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppTheme.softYellow,
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.star_rounded,
                        color: Color(0xFFFFB300),
                        size: 17,
                      ),
                      const SizedBox(width: 3),
                      Text(
                        '$rating',
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            const Row(
              children: [
                Icon(Icons.verified_rounded,
                    size: 17, color: Color(0xFF198754)),
                SizedBox(width: 5),
                Text(
                  'Verified Karlivery order',
                  style: TextStyle(
                    color: Color(0xFF198754),
                    fontWeight: FontWeight.w700,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
            if (comment.isNotEmpty) ...[
              const SizedBox(height: 9),
              Text(comment, style: const TextStyle(height: 1.4)),
            ],
          ],
        ),
      ),
    );
  }
}
