import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/brand.dart';
import '../../design_system/modern_cards.dart';
import '../../design_system/modern_palette.dart';
import '../../services/backend.dart';
import '../../services/cart.dart';

class ModernBrowseScreen extends StatefulWidget {
  const ModernBrowseScreen({super.key});

  @override
  State<ModernBrowseScreen> createState() => _ModernBrowseScreenState();
}

class _ModernBrowseScreenState extends State<ModernBrowseScreen> {
  final TextEditingController _searchController = TextEditingController();
  List<Map<String, dynamic>> stores = [];
  List<Map<String, dynamic>> featured = [];
  bool loading = true;
  String? loadError;
  String query = '';
  String sort = 'popular';
  String? selectedCategory;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      loadError = null;
    });
    try {
      final results = await Future.wait([
        Backend.approvedStores(),
        Backend.featuredProducts(limit: 16),
      ]);
      stores = results[0];
      featured = results[1];
    } catch (_) {
      loadError = 'Could not load restaurants. Check your connection.';
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  List<Map<String, dynamic>> get _visibleStores {
    final q = query.trim().toLowerCase();
    var result = stores.where((s) {
      if (q.isEmpty) return true;
      return '${s['name']} ${s['barangay']} ${s['description']}'
          .toLowerCase()
          .contains(q);
    }).toList();

    // Apply category filter
    if (selectedCategory != null) {
      result = result
          .where((s) =>
              s['category']?.toString().contains(selectedCategory!) ?? false)
          .toList();
    }

    // Sort
    double getNum(Map<String, dynamic> m, String key) =>
        double.tryParse(m[key]?.toString() ?? '') ?? 0;

    switch (sort) {
      case 'rating':
        result.sort((a, b) =>
            getNum(b, 'rating_avg').compareTo(getNum(a, 'rating_avg')));
        break;
      case 'fastest':
        result.sort((a, b) => getNum(a, 'eta_min_minutes')
            .compareTo(getNum(b, 'eta_min_minutes')));
        break;
      case 'popular':
      default:
        result.sort((a, b) => getNum(b, 'completed_orders')
            .compareTo(getNum(a, 'completed_orders')));
    }
    return result;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ModernPalette.surface,
    appBar: AppBar(
      backgroundColor: ModernPalette.surface,
      elevation: 0,
      toolbarHeight: 56,
      title: const KarliveryWordmark(compact: true),
      actions: [
        IconButton(
          tooltip: 'Help',
          onPressed: () => context.push('/help?role=customer'),
          icon: const Icon(Icons.help_outline_rounded),
        ),
        AnimatedBuilder(
          animation: CartService.instance,
          builder: (_, __) => IconButton(
            tooltip: 'Your basket',
            onPressed: () => context.push('/cart'),
            icon: Badge(
              isLabelVisible: CartService.instance.count > 0,
              label: Text('${CartService.instance.count}'),
              child: const Icon(Icons.shopping_bag_outlined),
            ),
          ),
        ),
        TextButton(
          onPressed: () => Backend.user == null
              ? context.push('/login')
              : context.go('/splash'),
          child: Text(Backend.user == null ? 'Sign in' : 'Account'),
        ),
        const SizedBox(width: 8),
      ],
    ),
    body: loading
        ? const Center(child: CircularProgressIndicator())
        : loadError != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.signal_cellular_null,
                        size: 56,
                        color: ModernPalette.onSurfaceLight,
                      ),
                      const SizedBox(height: 16),
                      Text(
                        loadError!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 16,
                          color: ModernPalette.onSurfaceVariant,
                        ),
                      ),
                      const SizedBox(height: 24),
                      FilledButton(
                        onPressed: _load,
                        child: const Text('Try again'),
                      ),
                    ],
                  ),
                ),
              )
            : RefreshIndicator(
                onRefresh: _load,
                color: ModernPalette.primary,
                child: CustomScrollView(
                  slivers: [
                    /// Search bar
                    SliverToBoxAdapter(
                      child: ModernSearchBar(
                        controller: _searchController,
                        onChanged: (v) =>
                            setState(() => query = v),
                        hintText: 'Search restaurants or food...',
                        onFilterTap: _showFilters,
                      ),
                    ),



                    /// Hero section with categories
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            /// Hero banner
                            Container(
                              height: 140,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(ModernRadius.lg),
                                gradient: LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [
                                    ModernPalette.primary.withValues(alpha: 0.8),
                                    ModernPalette.primary.withValues(alpha: 0.6),
                                  ],
                                ),
                                boxShadow: ModernShadow.md,
                              ),
                              child: Stack(
                                children: [
                                  /// Decorative circles background
                                  Positioned(
                                    right: -40,
                                    top: -40,
                                    child: Container(
                                      width: 200,
                                      height: 200,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Colors.white.withValues(alpha: 0.08),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    left: -60,
                                    bottom: -60,
                                    child: Container(
                                      width: 180,
                                      height: 180,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Colors.white.withValues(alpha: 0.06),
                                      ),
                                    ),
                                  ),
                                  /// Content
                                  Padding(
                                    padding: const EdgeInsets.all(ModernSpacing.lg),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            const Text(
                                              'GOOD FOOD. BRIGHTER DAYS.',
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 11,
                                                fontWeight: FontWeight.w700,
                                                letterSpacing: 1.2,
                                              ),
                                            ),
                                            const SizedBox(height: 4),
                                            const Text(
                                              'Your cravings, delivered.',
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 22,
                                                fontWeight: FontWeight.w700,
                                                height: 1.2,
                                              ),
                                            ),
                                          ],
                                        ),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              '${_visibleStores.length} restaurants nearby',
                                              style: const TextStyle(
                                                color: Colors.white,
                                                fontSize: 13,
                                                fontWeight: FontWeight.w500,
                                              ),
                                            ),
                                            FilledButton(
                                              style: FilledButton.styleFrom(
                                                backgroundColor: Colors.white,
                                                foregroundColor: ModernPalette.primary,
                                                padding: const EdgeInsets.symmetric(
                                                  horizontal: 16,
                                                  vertical: 8,
                                                ),
                                              ),
                                              onPressed: () {
                                                _searchController.clear();
                                                setState(() => query = '');
                                              },
                                              child: const Text(
                                                'Order now',
                                                style: TextStyle(
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 13,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    /// Category chips
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'What are you craving?',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                                color: ModernPalette.onSurface,
                              ),
                            ),
                            const SizedBox(height: 12),
                            SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: Row(
                                children: [
                                  ModernCategoryChip(
                                    label: 'All',
                                    icon: Icons.restaurant_rounded,
                                    selected: selectedCategory == null,
                                    selectedColor: ModernPalette.primary,
                                    onTap: () => setState(() => selectedCategory = null),
                                  ),
                                  const SizedBox(width: 8),
                                  ModernCategoryChip(
                                    label: 'Meals',
                                    icon: Icons.lunch_dining_rounded,
                                    selected: selectedCategory == 'Meals',
                                    selectedColor: ModernPalette.primary,
                                    onTap: () => setState(() => selectedCategory = 'Meals'),
                                  ),
                                  const SizedBox(width: 8),
                                  ModernCategoryChip(
                                    label: 'Burgers',
                                    icon: Icons.fastfood_rounded,
                                    selected: selectedCategory == 'Burgers',
                                    selectedColor: ModernPalette.primary,
                                    onTap: () => setState(() => selectedCategory = 'Burgers'),
                                  ),
                                  const SizedBox(width: 8),
                                  ModernCategoryChip(
                                    label: 'Noodles',
                                    icon: Icons.ramen_dining_rounded,
                                    selected: selectedCategory == 'Noodles',
                                    selectedColor: ModernPalette.primary,
                                    onTap: () => setState(() => selectedCategory = 'Noodles'),
                                  ),
                                  const SizedBox(width: 8),
                                  ModernCategoryChip(
                                    label: 'Drinks',
                                    icon: Icons.local_cafe_rounded,
                                    selected: selectedCategory == 'Drinks',
                                    selectedColor: ModernPalette.primary,
                                    onTap: () => setState(() => selectedCategory = 'Drinks'),
                                  ),
                                  const SizedBox(width: 8),
                                  ModernCategoryChip(
                                    label: 'Snacks',
                                    icon: Icons.bakery_dining_rounded,
                                    selected: selectedCategory == 'Snacks',
                                    selectedColor: ModernPalette.primary,
                                    onTap: () => setState(() => selectedCategory = 'Snacks'),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    /// Sort chips
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                        child: SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            children: [
                              _SortChip(
                                label: 'Popular',
                                value: 'popular',
                                isSelected: sort == 'popular',
                                onTap: () => setState(() => sort = 'popular'),
                              ),
                              const SizedBox(width: 8),
                              _SortChip(
                                label: 'Fastest',
                                value: 'fastest',
                                isSelected: sort == 'fastest',
                                onTap: () => setState(() => sort = 'fastest'),
                              ),
                              const SizedBox(width: 8),
                              _SortChip(
                                label: 'Top rated',
                                value: 'rating',
                                isSelected: sort == 'rating',
                                onTap: () => setState(() => sort = 'rating'),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    /// Featured section
                    if (featured.isNotEmpty) ...[
                      SliverToBoxAdapter(
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(16, 24, 16, 12),
                          child: Text(
                            'Featured now',
                            style: ModernTypography.headlineLarge.copyWith(
                              color: ModernPalette.onSurface,
                            ),
                          ),
                        ),
                      ),
                      SliverToBoxAdapter(
                        child: SizedBox(
                          height: 220,
                          child: ListView.builder(
                            scrollDirection: Axis.horizontal,
                            padding:
                                const EdgeInsets.symmetric(horizontal: 16),
                            itemCount: featured.length,
                            itemBuilder: (context, index) {
                              final item = featured[index];
                              return Padding(
                                padding: const EdgeInsets.only(right: 12),
                                child: SizedBox(
                                  width: 160,
                                  child: ModernProductCard(
                                    name: item['name'] ?? '',
                                    imageUrl: item['image_url'],
                                    price: double.tryParse(
                                        item['price']?.toString() ?? ''),
                                    category: item['_store_name'],
                                    featured: true,
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                    ],

                    /// Restaurants section
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(16, 24, 16, 12),
                        child: Text(
                          'Restaurants nearby',
                          style: ModernTypography.headlineLarge.copyWith(
                            color: ModernPalette.onSurface,
                          ),
                        ),
                      ),
                    ),

                    if (_visibleStores.isEmpty)
                      SliverToBoxAdapter(
                        child: Padding(
                          padding: const EdgeInsets.all(32),
                          child: Column(
                            children: [
                              Icon(
                                Icons.restaurant_outlined,
                                size: 56,
                                color: ModernPalette.onSurfaceLight,
                              ),
                              const SizedBox(height: 16),
                              Text(
                                'No restaurants found',
                                style: ModernTypography.titleLarge.copyWith(
                                  color: ModernPalette.onSurfaceVariant,
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                    else
                      SliverPadding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        sliver: SliverGrid(
                          gridDelegate:
                              SliverGridDelegateWithMaxCrossAxisExtent(
                            maxCrossAxisExtent: 200,
                            childAspectRatio: 0.75,
                            crossAxisSpacing: 12,
                            mainAxisSpacing: 12,
                          ),
                          delegate: SliverChildBuilderDelegate(
                            (context, i) {
                              final store = _visibleStores[i];
                              return ModernStoreCard(
                                id: store['id'] ?? '',
                                name: store['name'] ?? '',
                                imageUrl: store['cover_photo_url'],
                                category: store['category'],
                                rating: double.tryParse(
                                      store['rating_avg']?.toString() ?? '',
                                    ) ??
                                    4.5,
                                ratingCount: int.tryParse(
                                      store['rating_count']?.toString() ?? '',
                                    ) ??
                                    0,
                                eta: double.tryParse(
                                      store['eta_min_minutes']?.toString() ??
                                          '',
                                    ) ??
                                    25,
                                closed: store['status'] == 'closed',
                                onTap: () => context.push(
                                  '/store/${store['id']}',
                                ),
                              );
                            },
                            childCount: _visibleStores.length,
                          ),
                        ),
                      ),

                    /// Bottom padding
                    const SliverToBoxAdapter(
                      child: SizedBox(height: 32),
                    ),
                  ],
                ),
              ),
  );

  void _showFilters() {
    showModalBottomSheet<void>(
      context: context,
      builder: (_) => Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Sort & Filter',
              style: ModernTypography.headlineMedium.copyWith(
                color: ModernPalette.onSurface,
              ),
            ),
            const SizedBox(height: 16),
            // Add more filter options here as needed
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Close'),
            ),
          ],
        ),
      ),
    );
  }
}

class _SortChip extends StatelessWidget {
  final String label;
  final String value;
  final bool isSelected;
  final VoidCallback onTap;

  const _SortChip({
    required this.label,
    required this.value,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => FilterChip(
    label: Text(label),
    selected: isSelected,
    onSelected: (_) => onTap(),
    backgroundColor: ModernPalette.surfaceVariant,
    selectedColor: ModernPalette.primary,
    labelStyle: TextStyle(
      color: isSelected ? Colors.white : ModernPalette.onSurfaceVariant,
      fontWeight: FontWeight.w600,
      fontSize: 13,
    ),
    side: BorderSide(
      color: isSelected ? Colors.transparent : ModernPalette.outline,
    ),
  );
}

// Import ModernTypography
extension ModernTypography on Object {
  static const displayMedium = ModernPaletteTypography.displayMedium;
  static const bodyLarge = ModernPaletteTypography.bodyLarge;
  static const headlineLarge = ModernPaletteTypography.headlineLarge;
  static const headlineMedium = ModernPaletteTypography.headlineMedium;
  static const titleLarge = ModernPaletteTypography.titleLarge;
  static const bodySmall = ModernPaletteTypography.bodySmall;
}

abstract final class ModernPaletteTypography {
  static const displayMedium = TextStyle(
    fontSize: 28,
    fontWeight: FontWeight.w700,
    height: 1.2,
    letterSpacing: -0.3,
  );

  static const bodyLarge = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w400,
    height: 1.5,
  );

  static const headlineLarge = TextStyle(
    fontSize: 24,
    fontWeight: FontWeight.w700,
    height: 1.3,
  );

  static const headlineMedium = TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.w600,
    height: 1.3,
  );

  static const titleLarge = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w600,
    height: 1.4,
  );

  static const bodySmall = TextStyle(
    fontSize: 12,
    fontWeight: FontWeight.w400,
    height: 1.5,
  );
}
