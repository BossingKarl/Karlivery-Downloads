import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/brand.dart';
import '../../core/utils.dart';
import '../../services/backend.dart';
import '../../services/cart.dart';
import 'checkout_flow.dart';
import '../../design_system/k_tokens.dart';
import '../../design_system/k_network_image.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final cart = CartService.instance;

  @override
  void initState() {
    super.initState();
    cart.addListener(_changed);
  }

  @override
  void dispose() {
    cart.removeListener(_changed);
    super.dispose();
  }

  void _changed() { if (mounted) setState(() {}); }

  Future<void> _confirmClear() async {
    if (cart.lines.isEmpty) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Empty your basket?'),
        content: const Text('All selected dishes and add-ons will be removed. This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Keep items')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Empty basket')),
        ],
      ),
    );
    if (confirmed == true && mounted) cart.clear();
  }


  @override
  Widget build(BuildContext context) => SafeArea(
        child: cart.lines.isEmpty
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(28),
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 460),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 84,
                          height: 84,
                          decoration: BoxDecoration(
                            color: const Color(0xFFFFF3C2),
                            borderRadius: BorderRadius.circular(28),
                          ),
                          child: const Icon(
                            Icons.shopping_bag_outlined,
                            size: 42,
                          ),
                        ),
                        const SizedBox(height: 16),
                        const Text(
                          'Your basket is empty',
                          style: TextStyle(
                            fontSize: 21,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 6),
                        const Text(
                          'Browse a restaurant, open a dish, choose the quantity and add-ons, then it will appear here.',
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 18),
                        FilledButton.icon(
                          onPressed: () => context.go('/browse'),
                          icon: const Icon(Icons.restaurant_menu_rounded),
                          label: const Text('Browse food'),
                        ),
                      ],
                    ),
                  ),
                ),
              )
            : Column(children: [
              Expanded(child: ListView(
                padding: const EdgeInsets.fromLTRB(18, 18, 18, 18),
                children: [
                  PageTitle(
                    'Your basket',
                    subtitle: cart.storeName ?? 'Karlivery',
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Text('${cart.count} ${cart.count == 1 ? 'item' : 'items'}',
                        style: Theme.of(context).textTheme.bodyMedium),
                      const Spacer(),
                      TextButton.icon(
                        onPressed: _confirmClear,
                        icon: const Icon(Icons.delete_outline_rounded, size: 18),
                        label: const Text('Empty basket'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  ...cart.lines.map(
                    (l) => Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Card(
                        child: Padding(
                          padding: const EdgeInsets.all(14),
                          child: Row(
                            children: [
                              if ('${l.product['image_url'] ?? ''}'.trim().isNotEmpty) ...[
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(KRadius.sm),
                                  child: SizedBox(
                                    width: 60, height: 60,
                                    child: KNetImage('${l.product['image_url']}'.trim()),
                                  ),
                                ),
                                const SizedBox(width: 12),
                              ],
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      l.product['name'] ?? '',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    if (l.addons.isNotEmpty) ...[
                                      const SizedBox(height: 3),
                                      Text(
                                        l.addons
                                            .map((a) => a['name'])
                                            .join(', '),
                                        style: Theme.of(context).textTheme.bodySmall,
                                      ),
                                    ],
                                    const SizedBox(height: 6),
                                    Text(
                                      '${money(l.unitPrice)} each · ${money(l.subtotal)} total',
                                      style: const TextStyle(fontWeight: FontWeight.w700),
                                    ),
                                    TextButton.icon(
                                      onPressed: () => cart.change(l.key, -l.quantity),
                                      icon: const Icon(Icons.close_rounded, size: 15),
                                      label: const Text('Remove'),
                                    ),
                                  ],
                                ),
                              ),
                              IconButton.filledTonal(
                                onPressed: () => cart.change(l.key, -1),
                                icon: const Icon(Icons.remove_rounded),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 10),
                                child: Text(
                                  '${l.quantity}',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                              IconButton.filled(
                                onPressed: () => cart.change(l.key, 1),
                                icon: const Icon(Icons.add_rounded),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Text('Delivery fees and any applicable charges are confirmed at checkout.',
                    style: Theme.of(context).textTheme.bodySmall),
                ],
              )),
              // Sticky total + checkout: always reachable without scrolling.
              Container(
                padding: const EdgeInsets.fromLTRB(18, 12, 18, 14),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surface,
                  border: Border(top: BorderSide(color: Theme.of(context).dividerColor)),
                ),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  _row(
                    'Food subtotal · ${cart.count} ${cart.count == 1 ? 'item' : 'items'}',
                    money(cart.subtotal),
                    bold: true,
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: FilledButton.icon(
                      onPressed: checkout,
                      icon: const Icon(Icons.lock_rounded),
                      label: const Text('Secure checkout'),
                    ),
                  ),
                ]),
              ),
            ]),
      );

  Widget _row(String a, String b, {bool bold = false}) => Row(
        children: [
          Expanded(
            child: Text(
              a,
              style: TextStyle(
                fontWeight: bold ? FontWeight.w700 : FontWeight.w600,
              ),
            ),
          ),
          Text(
            b,
            style: TextStyle(
              fontWeight: bold ? FontWeight.w700 : FontWeight.w700,
            ),
          ),
        ],
      );

  Future<void> checkout() async {
    if (cart.storeId == null) return;

    if (Backend.user == null) {
      final signIn = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          icon: const Icon(Icons.lock_rounded),
          title: const Text('Sign in to check out'),
          content: const Text(
            'Your basket will stay here while you sign in. You can continue the same checkout after login.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Keep browsing'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Sign in'),
            ),
          ],
        ),
      );
      if (signIn == true && mounted) context.push('/login');
      return;
    }

    try {
      final result = await showKarliveryCheckout(
        context,
        cart: cart,
      );
      if (!mounted || result == null) return;

      cart.clear();

      final action = await showDialog<String>(
        context: context,
        builder: (ctx) => AlertDialog(
          icon: Icon(
            result.needsPaymentProof ? Icons.info_outline_rounded : Icons.check_circle_rounded,
            color: result.needsPaymentProof ? Colors.orange : const Color(0xFF198754),
            size: 48,
          ),
          title: Text(result.needsPaymentProof ? 'Order saved — finish payment' : 'Order placed!'),
          content: Text(
            result.needsPaymentProof
                ? 'Your order was created, but the GCash proof could not be submitted. '
                    'Open order details now to upload proof and confirm payment. '
                    'Do not place this order a second time.'
                : result.paymentMethod == 'gcash'
                ? 'Your GCash proof is ready for seller verification. You can follow every update from your order details.'
                : 'The restaurant received your order. Karlivery will keep the status, rider messages and delivery progress in one place.',
          ),
          actions: [
            if (!result.needsPaymentProof)
              TextButton(
                onPressed: () => Navigator.pop(ctx, 'browse'),
                child: const Text('Browse more'),
              ),
            FilledButton.icon(
              onPressed: () => Navigator.pop(ctx, 'order'),
              icon: const Icon(Icons.receipt_long_rounded),
              label: Text(result.needsPaymentProof ? 'Upload proof' : 'View order'),
            ),
          ],
        ),
      );

      if (!mounted) return;
      if (action == 'order') {
        context.push('/order/${result.orderId}');
      } else if (action == 'browse') {
        context.go('/browse');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not place order: $e')),
        );
      }
    }
  }

}
