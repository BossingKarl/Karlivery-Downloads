import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../../services/backend.dart';
import '../../services/pasabuy_service.dart';
import '../../theme/app_theme.dart';

/// Displays saved order details rather than an editable cart or a price guess.
/// Pabili values remain labelled as estimates until a verified final-price
/// workflow is implemented. PDF generation works on Android and Flutter web.
class OrderReceiptScreen extends StatefulWidget {
  final String orderId;
  final bool isPabili;

  const OrderReceiptScreen({super.key, required this.orderId, this.isPabili = false});

  @override
  State<OrderReceiptScreen> createState() => _OrderReceiptScreenState();
}

class _OrderReceiptScreenState extends State<OrderReceiptScreen> {
  late Future<_ReceiptViewData> _future;
  bool _printing = false;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<_ReceiptViewData> _load() async {
    if (widget.isPabili) {
      final order = await PasabuyService.orderById(widget.orderId);
      if (order == null) throw StateError('Pabili order unavailable.');
      final status = (order['status'] ?? '').toString().toLowerCase();
      if (status != 'delivered') {
        throw StateError('Your Pabili receipt appears after delivery is completed.');
      }
      final items = await PasabuyService.orderItems(widget.orderId);
      // The order-detail RPC is access-controlled; address read additionally
      // respects the customer's RLS policy.
      if (order['address_id'] != null) {
        try {
          final address = await Backend.db.from('addresses')
              .select('address_line,barangay,city,province')
              .eq('id', order['address_id']).maybeSingle();
          if (address != null) order['addresses'] = address;
        } catch (_) {
          // Do not invent an address if it is unavailable to the session.
        }
      }
      return _ReceiptViewData.fromOrder(order, items, pabili: true);
    }
    final order = await Backend.orderDetails(widget.orderId);
    if (order == null) throw StateError('Order unavailable.');
    final status = (order['status'] ?? '').toString().toLowerCase();
    if (status != 'delivered' && status != 'completed') {
      throw StateError('Your receipt appears after the order is completed.');
    }
    final raw = await Backend.db.from('order_items').select('*').eq('order_id', widget.orderId);
    return _ReceiptViewData.fromOrder(
      order,
      List<Map<String, dynamic>>.from(raw),
      pabili: false,
    );
  }


  Future<void> _print(_ReceiptViewData receipt) async {
    if (_printing) return;
    setState(() => _printing = true);
    try {
      final bytes = await _makePdf(receipt);
      await Printing.layoutPdf(
        name: 'Karlivery_${receipt.reference.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_')}.pdf',
        onLayout: (_) async => bytes,
      );
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not open PDF: $error')),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _printing = false);
      }
    }
  }

  Future<Uint8List> _makePdf(_ReceiptViewData r) async {
    final doc = pw.Document();
    final logo = pw.MemoryImage(
      (await rootBundle.load('assets/branding/karlivery_logo.png')).buffer.asUint8List(),
    );
    pw.Widget pdfRow(String label, String value, {bool bold = false}) => pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 4),
      child: pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
        pw.Expanded(child: pw.Text(label, style: pw.TextStyle(fontWeight: bold ? pw.FontWeight.bold : null))),
        pw.Text(value, style: pw.TextStyle(fontWeight: bold ? pw.FontWeight.bold : null)),
      ]),
    );
    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(34),
      build: (_) => [
        pw.Container(
          padding: const pw.EdgeInsets.all(14),
          decoration: const pw.BoxDecoration(color: PdfColor.fromInt(0xFFE51C23)),
          child: pw.Row(children: [
            pw.Image(logo, width: 44, height: 44),
            pw.SizedBox(width: 12),
            pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.Text('KARLIVERY', style: pw.TextStyle(color: PdfColors.white, fontSize: 22, fontWeight: pw.FontWeight.bold)),
              pw.Text(r.pabili ? 'Pabili delivery summary' : 'Completed order receipt', style: const pw.TextStyle(color: PdfColors.white)),
            ]),
          ]),
        ),
        pw.SizedBox(height: 20),
        pw.Text(r.store, style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
        pw.Text('Order: ${r.reference}'),
        if (r.completedAt.isNotEmpty) pw.Text('Completed: ${r.completedAt}'),
        pw.Text('Payment: ${r.payment}'),
        pw.Text('Delivery by: ${r.provider}'),
        if (r.destination.isNotEmpty) pw.Text('Delivery to: ${r.destination}'),
        pw.SizedBox(height: 16),
        pw.Text('Order details', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
        pw.Divider(),
        for (final item in r.items) pdfRow('${item.qty} x ${item.name}', _pdfMoney(item.total)),
        if (r.customRequest.isNotEmpty) ...[
          pw.Text('Special request: ${r.customRequest}'),
          if (r.customRequestAmount > 0)
            pdfRow('Custom request item estimate (included in subtotal)', _pdfMoney(r.customRequestAmount)),
        ],
        pw.Divider(),
        pdfRow('Items ${r.pabili ? '(estimated)' : ''}', _pdfMoney(r.subtotal)),
        if (r.handlingFee > 0) pdfRow('Pabili handling', _pdfMoney(r.handlingFee)),
        if (r.distanceKm != null) pdfRow('Store to customer GPS distance', '${r.distanceKm!.toStringAsFixed(2)} km'),
        if (r.rateBreakdown != null) pw.Text('Rate at order time: ${r.rateBreakdown}',
          style: const pw.TextStyle(fontSize: 12)),
        if (r.isDelivery) pdfRow('Delivery fee', _pdfMoney(r.deliveryFee)),
        pw.Divider(),
        pdfRow(r.pabili ? 'Estimated total' : 'Order total', _pdfMoney(r.total), bold: true),
        pw.SizedBox(height: 14),
        pw.Text(r.pabili
          ? 'Pabili item costs are estimates unless confirmed by the rider. This summary is not proof of payment.'
          : 'This order receipt lists the recorded charges. Payment verification is separate from delivery status.',
          style: const pw.TextStyle(fontSize: 12, color: PdfColors.grey700)),
        pw.Text('Distance is a GPS straight-line estimate, not an actual road route or travel distance.',
          style: const pw.TextStyle(fontSize: 12, color: PdfColors.grey700)),
        pw.SizedBox(height: 20),
        pw.Text('Thank you for choosing Karlivery!', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
      ],
    ));
    return doc.save();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Your Karlivery receipt')),
    body: FutureBuilder<_ReceiptViewData>(
      future: _future,
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          if (snapshot.hasError) {
            return Center(child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.receipt_long_rounded, size: 56, color: Color(0xFFE51C23)),
                const SizedBox(height: 12),
                const Text('Receipt is temporarily unavailable',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                const Text('We could not load your order items. Please try again.',
                  textAlign: TextAlign.center),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: () => setState(() => _future = _load()),
                  icon: const Icon(Icons.refresh_rounded),
                  label: const Text('Retry receipt'),
                ),
                const SizedBox(height: 12),
                Text('${snapshot.error}',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 12)),
              ]),
            ));
          }
          return const Center(child: CircularProgressIndicator());
        }
        final r = snapshot.data!;
        return ListView(padding: const EdgeInsets.fromLTRB(16, 14, 16, 32), children: [
          Center(child: Image.asset('assets/branding/karlivery_logo.png', height: 72)),
          const SizedBox(height: 12),
          const Icon(Icons.check_circle_rounded, color: Color(0xFF17A45B), size: 56),
          const SizedBox(height: 8),
          Text('Order completed!', textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Text(r.pabili ? 'Pabili delivery summary' : 'Thanks for ordering with Karlivery',
            textAlign: TextAlign.center),
          const SizedBox(height: 15),
          Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(r.store, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              Text('Order ${r.reference}', style: const TextStyle(color: AppTheme.muted)),
              if (r.completedAt.isNotEmpty) Text('Completed ${r.completedAt}'),
              const SizedBox(height: 8),
              Text('Payment: ${r.payment}  •  Delivered by ${r.provider}'),
              if (r.destination.isNotEmpty) ...[
                const SizedBox(height: 6),
                Text('Deliver to: ${r.destination}'),
              ],
              const Divider(height: 28),
              const Text('Order items', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              for (final item in r.items)
                _ReceiptMoneyRow('${item.qty}× ${item.name}', item.total),
              if (r.customRequest.isNotEmpty) ...[
                const SizedBox(height: 6),
                Text('Special request: ${r.customRequest}'),
                if (r.customRequestAmount > 0)
                  _ReceiptMoneyRow('Custom request estimate (included in items subtotal)', r.customRequestAmount),
              ],
              const Divider(height: 25),
              _ReceiptMoneyRow(r.pabili ? 'Items (estimated)' : 'Items', r.subtotal),
              if (r.handlingFee > 0) _ReceiptMoneyRow('Pabili handling fee', r.handlingFee),
              if (r.distanceKm != null)
                Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Row(children: [
                  const Expanded(child: Text('Store → customer distance')),
                  Text('${r.distanceKm!.toStringAsFixed(2)} km', style: const TextStyle(fontWeight: FontWeight.w700)),
                ])),
              if (r.rateBreakdown != null)
                Padding(
                  padding: const EdgeInsets.only(top: 6, bottom: 6),
                  child: Text('Rate at order time: ${r.rateBreakdown}',
                    style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
                ),
              if (r.isDelivery) _ReceiptMoneyRow('Delivery fee', r.deliveryFee),
              const Divider(height: 25),
              _ReceiptMoneyRow(r.pabili ? 'Estimated total' : 'Order total', r.total, strong: true),
              const SizedBox(height: 12),
              Text(r.pabili
                ? 'Pabili prices are estimated until confirmed. This receipt does not prove payment.'
                : 'Payment confirmation is separate from delivery completion.',
                style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
              const Text('Distance uses straight-line GPS between the saved store and customer pins—not road kilometers.',
                style: TextStyle(color: AppTheme.muted, fontSize: 12)),
            ],
          ))),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: _printing ? null : () => _print(r),
            icon: const Icon(Icons.picture_as_pdf_rounded),
            label: Text(_printing ? 'Opening PDF...' : 'Save or print PDF receipt')),
          const SizedBox(height: 10),
          // KARLIVERY_NO_EMAIL_RECEIPTS_2026: In-app and PDF only.
          const Text('Keep a copy of this order by saving or printing the PDF above.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12, color: AppTheme.muted)),
        ]);
      },
    ),
  );
}

String _pdfMoney(double value) => 'PHP ${value.toStringAsFixed(2)}';

class _ReceiptMoneyRow extends StatelessWidget {
  const _ReceiptMoneyRow(this.label, this.amount, {this.strong = false});
  final String label;
  final double amount;
  final bool strong;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 6),
    child: Row(children: [
      Expanded(child: Text(label, style: TextStyle(fontWeight: strong ? FontWeight.w700 : FontWeight.normal))),
      Text(NumberFormat.currency(locale: 'en_PH', symbol: '₱').format(amount),
        style: TextStyle(fontSize: strong ? 19 : 14,
          color: strong ? AppTheme.red : null,
          fontWeight: strong ? FontWeight.w700 : FontWeight.w600)),
    ]),
  );
}

class _ReceiptItem {
  const _ReceiptItem(this.qty, this.name, this.total);
  final int qty;
  final String name;
  final double total;
}

class _ReceiptViewData {
  _ReceiptViewData({
    required this.pabili, required this.reference, required this.store,
    required this.payment, required this.provider, required this.destination,
    required this.completedAt, required this.items, required this.customRequest,
    required this.subtotal, required this.handlingFee, required this.deliveryFee,
    required this.customRequestAmount, required this.total, required this.distanceKm,
    required this.isDelivery, this.rateBreakdown,
  });

  final bool pabili;
  final String reference, store, payment, provider, destination, completedAt, customRequest;
  final List<_ReceiptItem> items;
  final double subtotal, handlingFee, deliveryFee, customRequestAmount, total;
  final double? distanceKm;
  final bool isDelivery;
  final String? rateBreakdown;

  static double _num(dynamic value) => double.tryParse(value?.toString() ?? '') ?? 0;
  static double? _nullableNum(dynamic value) => value == null ? null : double.tryParse(value.toString());

  static _ReceiptViewData fromOrder(Map<String, dynamic> order, List<Map<String, dynamic>> rows,
      {required bool pabili}) {
    final store = order[pabili ? 'pasabuy_shops' : 'stores'];
    final address = order['addresses'];
    final lines = rows.map((line) {
      final qty = int.tryParse(line['quantity']?.toString() ?? '') ?? 1;
      final price = _num(line['item_price'] ?? line['unit_price'] ?? line['price']);
      return _ReceiptItem(qty,
        (line['item_name'] ?? line['product_name'] ?? line['name'] ?? 'Item').toString(),
        _num(line['line_total'] ?? line['total_price'] ?? (price * qty)));
    }).toList();
    final total = _num(order[pabili ? 'total_amount' : 'total']);
    final delivery = _num(order['delivery_fee']);
    final handling = pabili ? _num(order['handling_fee']) : 0.0;
    String? rateBreakdown;
    final rate = order['delivery_rate_snapshot'];
    // Display a recorded fee rule only when it matches the charged amount.
    if (rate is Map) {
      final calculated = _nullableNum(rate['delivery_fee']);
      if (calculated != null && (calculated - delivery).abs() < 0.01) {
        final base = _num(rate['base_fee']);
        final included = _num(rate['included_radius_km']);
        final step = _num(rate['step_distance_km']);
        final increment = _num(rate['step_fee']);
        final steps = _num(rate['extra_steps']).toInt();
        rateBreakdown = 'PHP ${base.toStringAsFixed(2)} for first '
          '${included.toStringAsFixed(2)} km + PHP ${increment.toStringAsFixed(2)} '
          'per started ${step.toStringAsFixed(2)} km ($steps extra steps)';
      }
    }
    final subtotal = _nullableNum(order['subtotal']) ??
        (total - delivery - handling).clamp(0.0, double.infinity).toDouble();
    final addressText = address is Map
      ? [address['address_line'], address['barangay'], address['city'], address['province']]
          .where((v) => (v?.toString() ?? '').trim().isNotEmpty).join(', ')
      : '';
    final stamp = order['delivered_at'] ?? order['updated_at'] ?? order['created_at'];
    String completedAt = '';
    final parsed = DateTime.tryParse(stamp?.toString() ?? '');
    if (parsed != null) completedAt = DateFormat('MMM d, yyyy • h:mm a').format(parsed.toLocal());
    return _ReceiptViewData(
      pabili: pabili,
      reference: (order[pabili ? 'id' : 'order_no'] ?? order['id']).toString(),
      store: store is Map ? (store['name'] ?? 'Karlivery store').toString() : 'Karlivery store',
      payment: (order['payment_method'] ?? 'Not specified').toString().toUpperCase(),
      provider: pabili ? 'Karlivery rider' : order['delivery_provider'] == 'seller' ? 'store rider' : 'Karlivery rider',
      destination: addressText,
      completedAt: completedAt,
      items: lines,
      customRequest: pabili ? (order['custom_request'] ?? '').toString() : '',
      subtotal: subtotal,
      handlingFee: handling,
      deliveryFee: delivery,
      customRequestAmount: pabili ? _num(order['custom_request_amount']) : 0,
      total: total,
      distanceKm: _nullableNum(order['delivery_distance_km']),
      isDelivery: pabili || order['fulfillment'] == 'delivery',
      rateBreakdown: rateBreakdown,
    );
  }
}
