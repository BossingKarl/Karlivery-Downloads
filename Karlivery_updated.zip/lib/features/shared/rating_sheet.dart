import 'package:flutter/material.dart';

import '../../services/backend.dart';
import '../../theme/app_theme.dart';

class RateOrderCard extends StatefulWidget {
  final Map<String, dynamic> order;

  const RateOrderCard({
    super.key,
    required this.order,
  });

  @override
  State<RateOrderCard> createState() => _RateOrderCardState();
}

class _RateOrderCardState extends State<RateOrderCard> {
  Map<String, dynamic>? rating;
  bool loading = true;

  String get orderId => widget.order['id'].toString();

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      rating = await Backend.myOrderRating(orderId);
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> rate() async {
    final result = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => _RatingSheet(order: widget.order),
    );

    if (result == true) {
      setState(() => loading = true);
      await load();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const SizedBox.shrink();
    }

    if (rating != null) {
      final store = rating!['store_rating'] ?? 0;
      final rider = rating!['rider_rating'];

      return Container(
        margin: const EdgeInsets.only(top: 12),
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(
          color: AppTheme.softYellow,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Row(
          children: [
            const Icon(
              Icons.star_rounded,
              color: Color(0xFFFFB300),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                rider == null
                    ? 'Restaurant rated $store/5 • Thank you!'
                    : 'Restaurant $store/5 • Rider $rider/5',
                style: const TextStyle(
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            TextButton(
              onPressed: rate,
              child: const Text('Edit'),
            ),
          ],
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: FilledButton.icon(
        onPressed: rate,
        icon: const Icon(Icons.star_outline_rounded),
        label: Text(
          widget.order['rider_id'] == null
              ? 'Rate restaurant'
              : 'Rate restaurant & rider',
        ),
      ),
    );
  }
}

class _RatingSheet extends StatefulWidget {
  final Map<String, dynamic> order;

  const _RatingSheet({
    required this.order,
  });

  @override
  State<_RatingSheet> createState() => _RatingSheetState();
}

class _RatingSheetState extends State<_RatingSheet> {
  int restaurant = 5;
  int rider = 5;
  bool submitting = false;

  final comment = TextEditingController();

  bool get hasRider => widget.order['rider_id'] != null;

  @override
  void dispose() {
    comment.dispose();
    super.dispose();
  }

  Future<void> submit() async {
    setState(() => submitting = true);

    try {
      await Backend.submitOrderRating(
        orderId: widget.order['id'].toString(),
        storeRating: restaurant,
        riderRating: hasRider ? rider : null,
        comment: comment.text,
      );

      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Rating failed: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) => SafeArea(
        child: Padding(
          padding: EdgeInsets.fromLTRB(
            20,
            4,
            20,
            20 + MediaQuery.of(context).viewInsets.bottom,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'How was your order?',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 5),
              const Text(
                'Your ratings help Karlivery highlight trusted restaurants and riders.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              const Text(
                'Rate the restaurant',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 8),
              _Stars(
                value: restaurant,
                onChanged: (v) =>
                    setState(() => restaurant = v),
              ),
              if (hasRider) ...[
                const SizedBox(height: 18),
                const Text(
                  'Rate your rider',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 8),
                _Stars(
                  value: rider,
                  onChanged: (v) => setState(() => rider = v),
                ),
              ],
              const SizedBox(height: 18),
              TextField(
                controller: comment,
                minLines: 2,
                maxLines: 4,
                maxLength: 500,
                decoration: const InputDecoration(
                  labelText: 'Optional feedback',
                  alignLabelWithHint: true,
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: submitting ? null : submit,
                  icon: submitting
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2.2,
                            color: Colors.white,
                          ),
                        )
                      : const Icon(Icons.star_rounded),
                  label: const Text('Submit rating'),
                ),
              ),
            ],
          ),
        ),
      );
}

class _Stars extends StatelessWidget {
  final int value;
  final ValueChanged<int> onChanged;

  const _Stars({
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) => Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(
          5,
          (i) {
            final star = i + 1;
            return IconButton(
              onPressed: () => onChanged(star),
              iconSize: 38,
              icon: Icon(
                star <= value
                    ? Icons.star_rounded
                    : Icons.star_border_rounded,
                color: const Color(0xFFFFB300),
              ),
            );
          },
        ),
      );
}
