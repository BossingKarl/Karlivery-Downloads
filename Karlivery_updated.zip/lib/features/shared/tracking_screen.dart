import '../../core/smart_back.dart';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:go_router/go_router.dart';
import 'package:latlong2/latlong.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/utils.dart';
import '../../services/backend.dart';
import '../../theme/app_theme.dart';

class TrackingScreen extends StatelessWidget {
  final String orderId;

  const TrackingScreen({super.key, required this.orderId});

  double _distanceKm(LatLng a, LatLng b) {
    const earth = 6371.0;
    final dLat = (b.latitude - a.latitude) * math.pi / 180;
    final dLng = (b.longitude - a.longitude) * math.pi / 180;
    final lat1 = a.latitude * math.pi / 180;
    final lat2 = b.latitude * math.pi / 180;
    final h = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(lat1) *
            math.cos(lat2) *
            math.sin(dLng / 2) *
            math.sin(dLng / 2);
    return earth * 2 * math.asin(math.sqrt(h));
  }

  int _etaMinutes({
    required double distanceKm,
    double? speedMetersPerSecond,
  }) {
    final reportedKmh =
        speedMetersPerSecond == null ? 0 : speedMetersPerSecond * 3.6;
    final effectiveKmh =
        reportedKmh >= 8 ? reportedKmh.clamp(8, 45).toDouble() : 20.0;
    return math.max(1, (distanceKm / effectiveKmh * 60).ceil());
  }

  String _lastUpdated(dynamic raw) {
    final dt = DateTime.tryParse(raw?.toString() ?? '')?.toLocal();
    if (dt == null) return 'Live GPS';
    final seconds = DateTime.now().difference(dt).inSeconds;
    if (seconds < 15) return 'Updated just now';
    if (seconds < 60) return 'Updated ${seconds}s ago';
    final minutes = seconds ~/ 60;
    return 'Updated ${minutes}m ago';
  }

  bool _stale(dynamic raw) {
    final dt = DateTime.tryParse(raw?.toString() ?? '')?.toLocal();
    if (dt == null) return false;
    return DateTime.now().difference(dt).inMinutes >= 2;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          leading: const KarliveryBackButton(fallback: '/customer'),
          title: const Text(
            'Live delivery',
            style: TextStyle(fontWeight: FontWeight.w700),
          ),
        ),
        body: FutureBuilder<Map<String, dynamic>?>(
          future: Backend.orderDetails(orderId),
          builder: (context, orderSnap) {
            if (orderSnap.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }

            final order = orderSnap.data;
            if (order == null) {
              return const Center(child: Text('This order is unavailable.'));
            }

            final address = order['addresses'];
            final store = order['stores'];
            final status = (order['status'] ?? '').toString();
            final orderNo = (order['order_no'] ?? 'Order').toString();
            final storeName = store is Map
                ? (store['name'] ?? 'Restaurant').toString()
                : 'Restaurant';

            final destLat = address is Map && address['latitude'] != null
                ? (address['latitude'] as num).toDouble()
                : null;
            final destLng = address is Map && address['longitude'] != null
                ? (address['longitude'] as num).toDouble()
                : null;
            final storeLat = store is Map && store['latitude'] != null
                ? (store['latitude'] as num).toDouble()
                : null;
            final storeLng = store is Map && store['longitude'] != null
                ? (store['longitude'] as num).toDouble()
                : null;

            return StreamBuilder<Map<String, dynamic>?>(
              stream: Backend.watchOrderTracking(orderId),
              builder: (context, snap) {
                final data = snap.data;

                if (snap.connectionState == ConnectionState.waiting &&
                    data == null) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (data == null) {
                  return _WaitingForLocation(
                    orderNo: orderNo,
                    status: status,
                    onChat: order['rider_id'] == null
                        ? null
                        : () => context.push('/chat/$orderId'),
                  );
                }

                final lat = (data['latitude'] as num).toDouble();
                final lng = (data['longitude'] as num).toDouble();
                final rider = LatLng(lat, lng);
                final destination = destLat != null && destLng != null
                    ? LatLng(destLat, destLng)
                    : null;
                final storePoint = storeLat != null && storeLng != null
                    ? LatLng(storeLat, storeLng)
                    : null;

                final remainingKm = destination == null
                    ? null
                    : _distanceKm(rider, destination);
                final eta = remainingKm == null
                    ? null
                    : _etaMinutes(
                        distanceKm: remainingKm,
                        speedMetersPerSecond:
                            (data['speed'] as num?)?.toDouble(),
                      );
                final stale = _stale(data['updated_at']);

                final center = destination == null
                    ? rider
                    : LatLng(
                        (rider.latitude + destination.latitude) / 2,
                        (rider.longitude + destination.longitude) / 2,
                      );

                return Column(
                  children: [
                    Expanded(
                      child: Stack(
                        children: [
                          FlutterMap(
                            options: MapOptions(
                              initialCenter: center,
                              initialZoom: remainingKm != null && remainingKm > 5
                                  ? 12.5
                                  : remainingKm != null && remainingKm > 2
                                      ? 13.5
                                      : 15.2,
                            ),
                            children: [
                              TileLayer(
                                urlTemplate:
                                    'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                                userAgentPackageName: 'com.karl.karl_delivery',
                              ),
                              if (destination != null)
                                PolylineLayer(
                                  polylines: [
                                    Polyline(
                                      points: [rider, destination],
                                      strokeWidth: 5,
                                      color: AppTheme.red,
                                    ),
                                  ],
                                ),
                              MarkerLayer(
                                markers: [
                                  if (storePoint != null)
                                    Marker(
                                      point: storePoint,
                                      width: 52,
                                      height: 52,
                                      child: const _MapMarker(
                                        icon: Icons.storefront_rounded,
                                        color: Color(0xFFE5A000),
                                      ),
                                    ),
                                  Marker(
                                    point: rider,
                                    width: 62,
                                    height: 62,
                                    child: const _MapMarker(
                                      icon: Icons.delivery_dining_rounded,
                                      color: AppTheme.red,
                                      emphasized: true,
                                    ),
                                  ),
                                  if (destination != null)
                                    Marker(
                                      point: destination,
                                      width: 54,
                                      height: 54,
                                      child: const _MapMarker(
                                        icon: Icons.home_rounded,
                                        color: AppTheme.deepRed,
                                      ),
                                    ),
                                ],
                              ),
                              const RichAttributionWidget(
                                attributions: [
                                  TextSourceAttribution(
                                    'OpenStreetMap contributors',
                                  ),
                                ],
                              ),
                            ],
                          ),
                          Positioned(
                            left: 12,
                            top: 12,
                            right: 12,
                            child: Wrap(
                              spacing: 7,
                              runSpacing: 7,
                              children: [
                                _MapLegend(
                                  icon: Icons.storefront_rounded,
                                  text: storeName,
                                  color: const Color(0xFFE5A000),
                                ),
                                const _MapLegend(
                                  icon: Icons.delivery_dining_rounded,
                                  text: 'Rider',
                                  color: AppTheme.red,
                                ),
                                const _MapLegend(
                                  icon: Icons.home_rounded,
                                  text: 'You',
                                  color: AppTheme.deepRed,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.fromLTRB(18, 14, 18, 20),
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.surface,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: .07),
                            blurRadius: 20,
                            offset: const Offset(0, -4),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      niceStatus(status),
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontSize: 18,
                                      ),
                                    ),
                                    Text(
                                      '$orderNo • ${_lastUpdated(data['updated_at'])}',
                                      style: TextStyle(
                                        color: stale ? Colors.orange : AppTheme.muted,
                                        fontSize: 12,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 7,
                                ),
                                decoration: BoxDecoration(
                                  color: stale
                                      ? Colors.orange.withValues(alpha: .12)
                                      : const Color(0xFF2E9D63)
                                          .withValues(alpha: .12),
                                  borderRadius: BorderRadius.circular(999),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(
                                      stale
                                          ? Icons.sync_problem_rounded
                                          : Icons.radar_rounded,
                                      size: 16,
                                      color: stale
                                          ? Colors.orange
                                          : const Color(0xFF2E9D63),
                                    ),
                                    const SizedBox(width: 5),
                                    Text(
                                      stale ? 'GPS delayed' : 'Live GPS',
                                      style: TextStyle(
                                        color: stale
                                            ? Colors.orange
                                            : const Color(0xFF2E9D63),
                                        fontWeight: FontWeight.w700,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          if (remainingKm != null && eta != null) ...[
                            const SizedBox(height: 12),
                            Row(
                              children: [
                                Expanded(
                                  child: _TrackingMetric(
                                    icon: Icons.route_rounded,
                                    label: 'Remaining',
                                    value: '${remainingKm.toStringAsFixed(1)} km',
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: _TrackingMetric(
                                    icon: Icons.schedule_rounded,
                                    label: 'Estimated arrival',
                                    value: 'About $eta min',
                                  ),
                                ),
                              ],
                            ),
                          ],
                          const SizedBox(height: 9),
                          const Text(
                            'ETA uses the rider’s latest GPS point and speed. Actual travel time may change with traffic, stops and road conditions.',
                            style: TextStyle(
                              color: AppTheme.muted,
                              fontSize: 12,
                              height: 1.35,
                            ),
                          ),
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              Expanded(
                                child: OutlinedButton.icon(
                                  onPressed: () => context.push('/chat/$orderId'),
                                  icon: const Icon(Icons.chat_bubble_rounded),
                                  label: const Text('Order chat'),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: FilledButton.icon(
                                  onPressed: () async {
                                    final uri = Uri.parse(
                                      'https://www.google.com/maps/search/?api=1&query=$lat,$lng',
                                    );
                                    await launchUrl(
                                      uri,
                                      mode: LaunchMode.externalApplication,
                                    );
                                  },
                                  icon: const Icon(Icons.map_rounded),
                                  label: const Text('Open Maps'),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                );
              },
            );
          },
        ),
      );
}

class _MapMarker extends StatelessWidget {
  final IconData icon;
  final Color color;
  final bool emphasized;

  const _MapMarker({
    required this.icon,
    required this.color,
    this.emphasized = false,
  });

  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white, width: 3),
          boxShadow: [
            BoxShadow(
              blurRadius: emphasized ? 18 : 10,
              color: Colors.black26,
            ),
          ],
        ),
        child: Icon(icon, color: Colors.white, size: emphasized ? 31 : 26),
      );
}

class _MapLegend extends StatelessWidget {
  final IconData icon;
  final String text;
  final Color color;

  const _MapLegend({
    required this.icon,
    required this.text,
    required this.color,
  });

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface.withValues(alpha: .94),
          borderRadius: BorderRadius.circular(999),
          boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 8)],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 16),
            const SizedBox(width: 5),
            ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 125),
              child: Text(
                text,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
              ),
            ),
          ],
        ),
      );
}

class _TrackingMetric extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _TrackingMetric({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppTheme.softYellow,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Row(
          children: [
            Icon(icon, color: AppTheme.deepRed, size: 21),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: const TextStyle(color: AppTheme.muted, fontSize: 12),
                  ),
                  Text(
                    value,
                    style: const TextStyle(
                      color: AppTheme.deepRed,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
}

class _WaitingForLocation extends StatelessWidget {
  final String orderNo;
  final String status;
  final VoidCallback? onChat;

  const _WaitingForLocation({
    required this.orderNo,
    required this.status,
    required this.onChat,
  });

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(30),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 430),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.radar_rounded, size: 64, color: AppTheme.red),
                    const SizedBox(height: 14),
                    const Text(
                      'Waiting for rider location',
                      style: TextStyle(fontWeight: FontWeight.w700, fontSize: 19),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '$orderNo • ${niceStatus(status)}',
                      style: const TextStyle(color: AppTheme.muted),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'The map will appear automatically once the assigned rider starts sharing live GPS.',
                      textAlign: TextAlign.center,
                    ),
                    if (onChat != null) ...[
                      const SizedBox(height: 16),
                      OutlinedButton.icon(
                        onPressed: onChat,
                        icon: const Icon(Icons.chat_bubble_rounded),
                        label: const Text('Open order chat'),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      );
}
