import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../config/app_config.dart';
import '../../core/brand.dart';
import '../../services/backend.dart';
import '../../services/onboarding_service.dart';
import '../../theme/app_theme.dart';

class HelpCenterScreen extends StatelessWidget {
  final String role;

  const HelpCenterScreen({
    super.key,
    this.role = 'customer',
  });

  String get roleLabel => switch (role) {
        'store_owner' => 'Seller',
        'rider' => 'Rider',
        'admin' => 'Administrator',
        _ => 'Customer',
      };

  List<(IconData, String, String)> get steps => switch (role) {
        'store_owner' => const [
            (Icons.storefront_rounded, 'Complete your store', 'Add a logo, delivery pin, menu items and optional GCash details.'),
            (Icons.toggle_on_rounded, 'Open only when ready', 'Customers can place new orders only while your store is marked Open.'),
            (Icons.receipt_long_rounded, 'Work from Orders', 'Review payment proofs, accept orders, prepare food and mark orders ready.'),
            (Icons.history_rounded, 'Use History & reports', 'Review completed orders and export seller reports when needed.'),
          ],
        'rider' => const [
            (Icons.power_settings_new_rounded, 'Go online', 'Turn on availability only when you are ready to accept a delivery.'),
            (Icons.inventory_2_rounded, 'Claim a ready order', 'Available orders appear after a seller marks them ready for a rider.'),
            (Icons.location_on_rounded, 'Share live location', 'Karlivery shares location only for the active delivery you are tracking.'),
            (Icons.check_circle_rounded, 'Update each delivery step', 'Picked up → Start delivery → Delivered keeps the customer informed.'),
          ],
        'admin' => const [
            (Icons.manage_accounts_rounded, 'Create staff accounts', 'Public signup is customer-only. Create seller and rider accounts from Users.'),
            (Icons.storefront_rounded, 'Review stores', 'Check store setup, availability and operational details.'),
            (Icons.campaign_rounded, 'Send announcements', 'Target customers, sellers, riders, or everyone from the announcement tool.'),
            (Icons.hub_rounded, 'Check system services', 'Use System to review enabled integrations and server-side requirements.'),
          ],
        _ => const [
            (Icons.restaurant_menu_rounded, 'Browse first', 'Search restaurants and food before signing in.'),
            (Icons.shopping_bag_rounded, 'Build your basket', 'Open a dish, choose add-ons and quantity, then review your basket.'),
            (Icons.lock_rounded, 'Follow guided checkout', 'Choose fulfillment, address, payment and review your total before placing the order.'),
            (Icons.route_rounded, 'Track after ordering', 'Use Orders, Messages and notifications to follow delivery progress.'),
          ],
      };

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const KarliveryWordmark(compact: true),
        ),
        body: SafeArea(
          top: false,
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 820),
              child: ListView(
                padding: const EdgeInsets.fromLTRB(18, 14, 18, 32),
                children: [
                  Container(
                    padding: const EdgeInsets.all(22),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [AppTheme.red, AppTheme.deepRed],
                      ),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: Row(
                      children: [
                        const CircleAvatar(
                          radius: 30,
                          backgroundColor: Colors.white,
                          child: Icon(
                            Icons.help_center_rounded,
                            color: AppTheme.red,
                            size: 32,
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '$roleLabel guide',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 24,
                                ),
                              ),
                              const SizedBox(height: 4),
                              const Text(
                                'Short steps, plain language, and the most important actions first.',
                                style: TextStyle(
                                  color: Color(0xFFFFEDE4),
                                  height: 1.35,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'Quick start',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 10),
                  ...steps.indexed.map(
                    (entry) {
                      final i = entry.$1;
                      final s = entry.$2;
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 9),
                        child: Card(
                          child: ListTile(
                            contentPadding: const EdgeInsets.all(14),
                            leading: CircleAvatar(
                              backgroundColor: AppTheme.softRed,
                              child: Text(
                                '${i + 1}',
                                style: const TextStyle(
                                  color: AppTheme.red,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                            title: Text(
                              s.$2,
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            subtitle: Text(s.$3),
                            trailing: Icon(s.$1, color: AppTheme.red),
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Common questions',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 8),
                  const _Faq(
                    q: 'Why is a button disabled?',
                    a: 'Karlivery disables actions until required information is complete. Look for the nearby hint or missing step before continuing.',
                  ),
                  const _Faq(
                    q: 'Where do notifications go?',
                    a: 'Tap the bell icon. Orders, messages and announcements are kept in the notification center, and supported devices can also receive push alerts.',
                  ),
                  const _Faq(
                    q: 'What if the app cannot load something?',
                    a: 'Check your internet connection, then pull down to refresh or use the Retry button. Your account data stays in Supabase.',
                  ),
                  const _Faq(
                    q: 'Can I use Karlivery on iPhone?',
                    a: 'Yes. Open karlivery.pages.dev in Safari and choose Add to Home Screen for the PWA experience.',
                  ),
                  const SizedBox(height: 18),
                  if (Backend.user != null)
                    FilledButton.tonalIcon(
                      onPressed: () => context.push('/notifications'),
                      icon: const Icon(Icons.notifications_rounded),
                      label: const Text('Open notification center'),
                    ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: () async {
                      await OnboardingService.replayWelcome();
                      if (context.mounted) context.go('/welcome');
                    },
                    icon: const Icon(Icons.replay_rounded),
                    label: const Text('Replay welcome guide'),
                  ),
                  const SizedBox(height: 18),
                  Text(
                    'Karlivery V${AppConfig.appVersion}',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: AppTheme.muted,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
}

class _Faq extends StatelessWidget {
  final String q;
  final String a;

  const _Faq({required this.q, required this.a});

  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 8),
        child: ExpansionTile(
          leading: const Icon(Icons.question_answer_rounded),
          title: Text(
            q,
            style: const TextStyle(fontWeight: FontWeight.w700),
          ),
          childrenPadding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: Text(a, style: const TextStyle(height: 1.45)),
            ),
          ],
        ),
      );
}
