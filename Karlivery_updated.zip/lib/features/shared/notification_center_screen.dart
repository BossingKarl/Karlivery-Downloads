import '../../core/smart_back.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../services/backend.dart';
import '../../services/notification_service.dart';
import '../../theme/app_theme.dart';

class NotificationBell extends StatelessWidget {
  const NotificationBell({super.key});

  @override
  Widget build(BuildContext context) {
    if (Backend.user == null) {
      return IconButton(
        tooltip: 'Notifications',
        onPressed: () => context.push('/notifications'),
        icon: const Icon(Icons.notifications_none_rounded),
      );
    }

    return StreamBuilder<List<Map<String, dynamic>>>(
      stream: Backend.watchMyNotifications(),
      builder: (context, snapshot) {
        final unread = (snapshot.data ?? const [])
            .where((n) =>
                n['is_read'] != true &&
                (n['read_at'] == null ||
                    n['read_at'].toString().trim().isEmpty))
            .length;

        return IconButton(
          tooltip: 'Notifications',
          onPressed: () => context.push('/notifications'),
          icon: Badge(
            isLabelVisible: unread > 0,
            label: Text(unread > 99 ? '99+' : '$unread'),
            child: Icon(
              unread > 0
                  ? Icons.notifications_rounded
                  : Icons.notifications_none_rounded,
            ),
          ),
        );
      },
    );
  }
}

class NotificationCenterScreen extends StatefulWidget {
  const NotificationCenterScreen({super.key});

  @override
  State<NotificationCenterScreen> createState() =>
      _NotificationCenterScreenState();
}

class _NotificationCenterScreenState extends State<NotificationCenterScreen> {
  String filter = 'important';

  @override
  void initState() {
    super.initState();
    Future<void>.delayed(const Duration(milliseconds: 300), () async {
      try {
        await NotificationService.init();
        if (!kIsWeb) {
          await NotificationService.requestPermission();
        }
        await NotificationService.startForCurrentUser();
      } catch (e) {
        debugPrint('Notification center startup error: $e');
      }
      if (mounted) setState(() {});
    });
  }

  String _time(dynamic raw) {
    final dt = DateTime.tryParse(raw?.toString() ?? '')?.toLocal();
    if (dt == null) return '';
    return DateFormat('MMM d • h:mm a').format(dt);
  }

  IconData _icon(String kind) {
    switch (kind) {
      case 'announcement':
        return Icons.campaign_rounded;
      case 'chat':
      case 'pasabuy_chat':
        return Icons.chat_bubble_rounded;
      case 'pasabuy':
        return Icons.shopping_bag_rounded;
      case 'login':
        return Icons.login_rounded;
      case 'order':
        return Icons.receipt_long_rounded;
      default:
        return Icons.notifications_active_rounded;
    }
  }

  // Every notification opens its complete content, including announcements.
  // Related order navigation is an optional action, never a silent redirect.
  Future<void> _openNotification(Map<String, dynamic> notification) async {
    final id = notification['id']?.toString();
    if (id != null && id.isNotEmpty) {
      try {
        await Backend.markNotificationRead(id);
      } catch (e) {
        debugPrint('Could not mark notification as read: $e');
      }
    }
    if (!mounted) return;
    final kind = (notification['kind'] ?? 'general').toString();
    final title = (notification['title'] ?? 'Karlivery').toString();
    final message = (notification['message'] ?? '').toString();
    final data = notification['data'] is Map
        ? Map<String, dynamic>.from(notification['data'] as Map)
        : <String, dynamic>{};
    final orderId = (data['order_id'] ?? notification['order_id'])?.toString();
    final screen = data['screen']?.toString() ?? '';
    final pabiliId = data['pasabuy_order_id']?.toString() ??
        (data['order_type'] == 'pabili' ? orderId : null);
    String? orderPath;
    if (pabiliId != null && pabiliId.isNotEmpty) {
      final safe = Uri.encodeComponent(pabiliId);
      orderPath = screen == 'pabili_chat' || screen == 'chat'
          ? '/pasabuy/chat/$safe'
          : screen == 'pabili_tracking' || screen == 'tracking'
              ? '/pasabuy/track/$safe'
              : '/pasabuy/order/$safe';
    } else if (orderId != null && orderId.isNotEmpty) {
      final safeOrderId = Uri.encodeComponent(orderId);
      if (screen == 'chat') {
        orderPath = '/chat/$safeOrderId';
      } else if (screen == 'tracking') {
        orderPath = '/track/$safeOrderId';
      } else if (screen == 'order') {
        orderPath = '/order/$safeOrderId';
      }
    }
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (sheetContext) => Padding(
        padding: const EdgeInsets.fromLTRB(22, 4, 22, 30),
        child: Center(
          heightFactor: 1,
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxWidth: 560,
              maxHeight: MediaQuery.sizeOf(sheetContext).height * .78,
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppTheme.softRed,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Icon(_icon(kind), color: AppTheme.red, size: 26),
                    ),
                    const SizedBox(width: 12),
                    Expanded(child: Text(
                      kind == 'announcement' ? 'Announcement' : 'Notification details',
                      style: const TextStyle(color: AppTheme.muted, fontWeight: FontWeight.w700),
                    )),
                    IconButton(
                      tooltip: 'Close',
                      onPressed: () => Navigator.pop(sheetContext),
                      icon: const Icon(Icons.close_rounded),
                    ),
                  ]),
                  const SizedBox(height: 20),
                  Text(title, style: Theme.of(sheetContext).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  Text(_time(notification['created_at']), style: const TextStyle(color: AppTheme.muted)),
                  const SizedBox(height: 18),
                  SelectableText(message.isEmpty ? 'No message provided.' : message,
                    style: const TextStyle(fontSize: 16, height: 1.6)),
                  const SizedBox(height: 24),
                  Wrap(spacing: 10, runSpacing: 8, children: [
                    OutlinedButton.icon(
                      onPressed: () async {
                        await Clipboard.setData(ClipboardData(text: '$title\n\n$message'));
                        if (sheetContext.mounted) {
                          ScaffoldMessenger.of(sheetContext).showSnackBar(
                            const SnackBar(content: Text('Notification copied.')),
                          );
                        }
                      },
                      icon: const Icon(Icons.copy_rounded),
                      label: const Text('Copy message'),
                    ),
                    if (orderPath != null) FilledButton.icon(
                      onPressed: () {
                        Navigator.pop(sheetContext);
                        if (mounted) context.push(orderPath!);
                      },
                      icon: const Icon(Icons.open_in_new_rounded),
                      label: const Text('View related order'),
                    ),
                  ]),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          leading: const KarliveryBackButton(fallback: '/customer'),
          title: const Text(
            'Notifications',
            style: TextStyle(fontWeight: FontWeight.w700),
          ),
          actions: [
            TextButton(
              onPressed: Backend.markAllNotificationsRead,
              child: const Text('Mark all read'),
            ),
            const SizedBox(width: 6),
          ],
        ),
        body: SafeArea(
          top: false,
          child: StreamBuilder<List<Map<String, dynamic>>>(
            stream: Backend.watchMyNotifications(),
            builder: (context, snapshot) {
              final allItems = snapshot.data ?? const [];
              final items = allItems.where((n) {
                final kind = (n['kind'] ?? 'general').toString();
                return switch (filter) {
                  'orders' => kind == 'order' || kind == 'pasabuy',
                  'messages' => kind == 'chat' || kind == 'pasabuy_chat',
                  'announcements' => kind == 'announcement',
                  'all' => true,
                  _ => kind != 'login',
                };
              }).toList();

              return ListView(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: NotificationService.truePushEnabled
                          ? const Color(0xFFE9F8EF)
                          : AppTheme.softYellow,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          NotificationService.truePushEnabled
                              ? Icons.notifications_active_rounded
                              : Icons.info_outline_rounded,
                          color: NotificationService.truePushEnabled
                              ? const Color(0xFF198754)
                              : AppTheme.deepRed,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            NotificationService.truePushEnabled
                                ? 'Push is connected. Karlivery can alert this device for orders, chat and announcements.'
                                : kIsWeb
                                    ? 'Karlivery notification history is ready. Enable web push below for background alerts.'
                                    : 'Push setup is unavailable on this device. In-app notification history is still available.',
                            style: const TextStyle(
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (kIsWeb) ...[
                    const SizedBox(height: 12),
                    FilledButton.icon(
                      onPressed: NotificationService.truePushEnabled
                          ? null
                          : () async {
                              try {
                                await NotificationService.requestPermission();
                                await NotificationService.startForCurrentUser();

                                if (!context.mounted) return;
                                setState(() {});

                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      NotificationService.truePushEnabled
                                          ? 'Karlivery notifications are enabled on this device.'
                                          : 'Notifications were not enabled. On iPhone, add Karlivery to the Home Screen first, then try again.',
                                    ),
                                  ),
                                );
                              } catch (e) {
                                if (!context.mounted) return;
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      'Could not enable web notifications: $e',
                                    ),
                                  ),
                                );
                              }
                            },
                      icon: Icon(
                        NotificationService.truePushEnabled
                            ? Icons.notifications_active_rounded
                            : Icons.notifications_none_rounded,
                      ),
                      label: Text(
                        NotificationService.truePushEnabled
                            ? 'Notifications enabled'
                            : 'Enable notifications',
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      NotificationService.webAppInstalled
                          ? 'Karlivery is running as an installed Home Screen app.'
                          : 'iPhone/iPad: Safari → Share → Add to Home Screen. Open Karlivery from the new Home Screen icon, then tap Enable notifications.',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: AppTheme.muted,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        height: 1.35,
                      ),
                    ),
                  ],
                  const SizedBox(height: 16),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        for (final item in const [
                          ('important', 'Important', Icons.inbox_rounded),
                          ('orders', 'Orders', Icons.receipt_long_rounded),
                          ('messages', 'Messages', Icons.chat_bubble_rounded),
                          ('announcements', 'Announcements', Icons.campaign_rounded),
                          ('all', 'All', Icons.all_inbox_rounded),
                        ]) ...[
                          ChoiceChip(
                            selected: filter == item.$1,
                            avatar: Icon(item.$3, size: 17),
                            label: Text(item.$2),
                            onSelected: (_) => setState(() => filter = item.$1),
                          ),
                          const SizedBox(width: 7),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  if (snapshot.connectionState ==
                          ConnectionState.waiting &&
                      items.isEmpty)
                    const Center(
                      child: Padding(
                        padding: EdgeInsets.all(28),
                        child: CircularProgressIndicator(),
                      ),
                    )
                  else if (items.isEmpty)
                    _EmptyNotifications(
                      title: filter == 'important'
                          ? 'You are all caught up'
                          : 'Nothing in this category',
                      subtitle: filter == 'important'
                          ? 'Important order, message and announcement updates will appear here.'
                          : 'Try another notification filter or check back later.',
                    )
                  else
                    ...items.map((n) {
                      final unread = n['is_read'] != true &&
                          (n['read_at'] == null ||
                              n['read_at'].toString().trim().isEmpty);
                      final kind = (n['kind'] ?? 'general').toString();

                      return Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Card(
                          child: InkWell(
                            borderRadius: BorderRadius.circular(24),
                            onTap: () => _openNotification(n),
                            child: Padding(
                              padding: const EdgeInsets.all(14),
                              child: Row(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    width: 48,
                                    height: 48,
                                    decoration: BoxDecoration(
                                      color: unread
                                          ? AppTheme.softRed
                                          : AppTheme.softYellow,
                                      borderRadius:
                                          BorderRadius.circular(16),
                                    ),
                                    child: Icon(
                                      _icon(kind),
                                      color: AppTheme.red,
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          children: [
                                            Expanded(
                                              child: Text(
                                                (n['title'] ??
                                                        'Karlivery')
                                                    .toString(),
                                                style: TextStyle(
                                                  fontWeight: unread
                                                      ? FontWeight.w700
                                                      : FontWeight.w700,
                                                  fontSize: 15.5,
                                                ),
                                              ),
                                            ),
                                            if (unread)
                                              const CircleAvatar(
                                                radius: 4,
                                                backgroundColor:
                                                    AppTheme.red,
                                              ),
                                          ],
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          (n['message'] ?? '').toString(),
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(height: 1.35),
                                        ),
                                        const SizedBox(height: 4),
                                        const Text('Tap to read the complete message',
                                          style: TextStyle(fontSize: 12, color: AppTheme.red, fontWeight: FontWeight.w700)),
                                        const SizedBox(height: 7),
                                        Text(
                                          _time(n['created_at']),
                                          style: const TextStyle(
                                            color: AppTheme.muted,
                                            fontWeight: FontWeight.w700,
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    }),
                ],
              );
            },
          ),
        ),
      );
}

class _EmptyNotifications extends StatelessWidget {
  final String title;
  final String subtitle;

  const _EmptyNotifications({
    this.title = 'No notifications yet',
    this.subtitle = 'Order updates, messages and Karlivery announcements will appear here.',
  });

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 70),
        child: Column(
          children: [
            Container(
              width: 82,
              height: 82,
              decoration: BoxDecoration(
                color: AppTheme.softRed,
                borderRadius: BorderRadius.circular(28),
              ),
              child: const Icon(
                Icons.notifications_none_rounded,
                color: AppTheme.red,
                size: 40,
              ),
            ),
            const SizedBox(height: 15),
            Text(
              title,
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 6),
            Text(
              subtitle,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
}
