import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../services/backend.dart';

Future<void> showAccountPasswordDialog(BuildContext context) async {
  final current = TextEditingController();
  final next = TextEditingController();
  final confirm = TextEditingController();
  var hideCurrent = true;
  var hideNext = true;
  var hideConfirm = true;
  var busy = false;
  String? error;

  try {
    await showDialog<void>(
      context: context,
      barrierDismissible: !busy,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setLocal) {
          final valid = current.text.isNotEmpty &&
              next.text.length >= 8 &&
              confirm.text == next.text &&
              !busy;

          Future<void> submit() async {
            if (!valid) return;
            setLocal(() {
              busy = true;
              error = null;
            });

            try {
              await Backend.changeMyPassword(
                currentPassword: current.text,
                newPassword: next.text,
              );
              if (dialogContext.mounted) {
                Navigator.pop(dialogContext);
              }
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Password changed successfully.'),
                  ),
                );
              }
            } catch (e) {
              var message = e.toString();
              if (e is AuthException) message = e.message;
              message = message.replaceFirst('Exception: ', '');
              if (dialogContext.mounted) {
                setLocal(() {
                  busy = false;
                  error = message;
                });
              }
            }
          }

          return AlertDialog(
            title: const Text('Change password'),
            content: SingleChildScrollView(
              child: SizedBox(
                width: 420,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text(
                      'For your security, enter your current password before choosing a new one.',
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: current,
                      obscureText: hideCurrent,
                      enabled: !busy,
                      autofillHints: const [AutofillHints.password],
                      onChanged: (_) => setLocal(() => error = null),
                      decoration: InputDecoration(
                        labelText: 'Current password',
                        prefixIcon: const Icon(Icons.lock_outline_rounded),
                        suffixIcon: IconButton(
                          onPressed: busy
                              ? null
                              : () => setLocal(
                                    () => hideCurrent = !hideCurrent,
                                  ),
                          icon: Icon(
                            hideCurrent
                                ? Icons.visibility_outlined
                                : Icons.visibility_off_outlined,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: next,
                      obscureText: hideNext,
                      enabled: !busy,
                      autofillHints: const [AutofillHints.newPassword],
                      onChanged: (_) => setLocal(() => error = null),
                      decoration: InputDecoration(
                        labelText: 'New password',
                        helperText: 'Use at least 8 characters',
                        prefixIcon: const Icon(Icons.password_rounded),
                        suffixIcon: IconButton(
                          onPressed: busy
                              ? null
                              : () => setLocal(() => hideNext = !hideNext),
                          icon: Icon(
                            hideNext
                                ? Icons.visibility_outlined
                                : Icons.visibility_off_outlined,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: confirm,
                      obscureText: hideConfirm,
                      enabled: !busy,
                      onSubmitted: (_) => submit(),
                      onChanged: (_) => setLocal(() => error = null),
                      decoration: InputDecoration(
                        labelText: 'Confirm new password',
                        prefixIcon: const Icon(Icons.verified_user_outlined),
                        errorText: confirm.text.isNotEmpty &&
                                confirm.text != next.text
                            ? 'Passwords do not match.'
                            : null,
                        suffixIcon: IconButton(
                          onPressed: busy
                              ? null
                              : () => setLocal(
                                    () => hideConfirm = !hideConfirm,
                                  ),
                          icon: Icon(
                            hideConfirm
                                ? Icons.visibility_outlined
                                : Icons.visibility_off_outlined,
                          ),
                        ),
                      ),
                    ),
                    if (error != null) ...[
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Theme.of(context)
                              .colorScheme
                              .errorContainer,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Text(
                          error!,
                          style: TextStyle(
                            color: Theme.of(context)
                                .colorScheme
                                .onErrorContainer,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed:
                    busy ? null : () => Navigator.pop(dialogContext),
                child: const Text('Cancel'),
              ),
              FilledButton.icon(
                onPressed: valid ? submit : null,
                icon: busy
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.lock_reset_rounded),
                label: Text(busy ? 'Updating…' : 'Change password'),
              ),
            ],
          );
        },
      ),
    );
  } finally {
    current.dispose();
    next.dispose();
    confirm.dispose();
  }
}
