import '../../core/smart_back.dart';
import 'package:flutter/material.dart';

import '../../core/chat_timeline.dart';
import '../../services/backend.dart';
import '../../theme/app_theme.dart';

class OrderChatScreen extends StatefulWidget {
  final String orderId;

  const OrderChatScreen({
    super.key,
    required this.orderId,
  });

  @override
  State<OrderChatScreen> createState() => _OrderChatScreenState();
}

class _OrderChatScreenState extends State<OrderChatScreen> {
  final controller = TextEditingController();
  final scroll = ScrollController();

  bool sending = false;
  int lastMessageCount = 0;
  Map<String, dynamic>? contextInfo;

  static const quickReplies = [
    ('Payment sent. Please verify.', Icons.payments_rounded),
    ('Payment received. Thank you.', Icons.verified_rounded),
    ('I am at the pinned location.', Icons.location_on_rounded),
    ('Please message me here.', Icons.chat_bubble_outline_rounded),
  ];

  @override
  void initState() {
    super.initState();
    loadContext();
  }

  Future<void> loadContext() async {
    try {
      final data = await Backend.orderChatContext(widget.orderId);
      if (mounted) setState(() => contextInfo = data);
    } catch (_) {}
  }

  @override
  void dispose() {
    controller.dispose();
    scroll.dispose();
    super.dispose();
  }

  Future<void> send([String? quickText]) async {
    final text = (quickText ?? controller.text).trim();
    if (text.isEmpty || sending) return;

    setState(() => sending = true);

    try {
      await Backend.sendChatMessage(widget.orderId, text);
      if (quickText == null) controller.clear();
      _scrollToBottom(animated: true);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Message failed: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  void _scrollToBottom({bool animated = false}) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!scroll.hasClients) return;

      final target = scroll.position.minScrollExtent;

      if (animated) {
        scroll.animateTo(
          target,
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOut,
        );
      } else {
        scroll.jumpTo(target);
      }
    });
  }

  String _time(dynamic raw) {
    final dt = DateTime.tryParse(raw?.toString() ?? '')?.toLocal();
    if (dt == null) return '';

    final hour = dt.hour % 12 == 0 ? 12 : dt.hour % 12;
    final minute = dt.minute.toString().padLeft(2, '0');
    final suffix = dt.hour >= 12 ? 'PM' : 'AM';

    return '$hour:$minute $suffix';
  }

  DateTime _date(dynamic raw) =>
      DateTime.tryParse(raw?.toString() ?? '')?.toLocal() ??
      DateTime.fromMillisecondsSinceEpoch(0);

  String get sellerName =>
      (contextInfo?['seller_name'] ?? contextInfo?['store_name'] ?? 'Seller')
          .toString();

  String get participantSummary {
    final rider = (contextInfo?['rider_name'] ?? '').toString();
    if (contextInfo?['rider_id'] != null && rider.isNotEmpty) {
      return 'Seller • Customer • Rider';
    }
    return 'Seller • Customer';
  }


  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          leading: const KarliveryBackButton(fallback: '/customer'),
          titleSpacing: 8,
          title: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [
                      AppTheme.red,
                      AppTheme.deepRed,
                    ],
                  ),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: const Icon(
                  Icons.delivery_dining_rounded,
                  color: Colors.white,
                  size: 25,
                ),
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Order chat',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 18,
                      ),
                    ),
                    Text(
                      contextInfo == null
                          ? 'Order chat'
                          : '${contextInfo!['order_no']} • ${contextInfo!['store_name']} • $participantSummary',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.muted,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        body: SafeArea(
          top: false,
          child: Column(
            children: [
              if (contextInfo != null)
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.fromLTRB(14, 8, 14, 5),
                  padding: const EdgeInsets.all(13),
                  decoration: BoxDecoration(
                    color: AppTheme.softRed,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.shopping_bag_rounded,
                        color: AppTheme.red,
                      ),
                      const SizedBox(width: 9),
                      Expanded(
                        child: Text(
                          contextInfo!['item_summary']?.toString() ??
                              'Order items',
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              Container(
                margin: const EdgeInsets.fromLTRB(14, 5, 14, 6),
                padding: const EdgeInsets.all(13),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [
                      AppTheme.softYellow,
                      Color(0xFFFFF8DC),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Row(
                  children: [
                    Icon(
                      Icons.shield_outlined,
                      color: AppTheme.deepRed,
                      size: 22,
                    ),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Keep messages focused on delivery details, landmarks and arrival coordination.',
                        style: TextStyle(
                          color: AppTheme.deepRed,
                          fontWeight: FontWeight.w700,
                          fontSize: 12.2,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 58,
                child: ListView.separated(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 7,
                  ),
                  scrollDirection: Axis.horizontal,
                  itemCount: quickReplies.length,
                  separatorBuilder: (_, _) =>
                      const SizedBox(width: 7),
                  itemBuilder: (_, i) {
                    final item = quickReplies[i];

                    return ActionChip(
                      avatar: Icon(
                        item.$2,
                        color: AppTheme.red,
                        size: 17,
                      ),
                      label: Text(item.$1),
                      onPressed:
                          sending ? null : () => send(item.$1),
                    );
                  },
                ),
              ),
              const _TodayDivider(),
              Expanded(
                child: StreamBuilder<List<Map<String, dynamic>>>(
                  stream: Backend.watchChat(widget.orderId),
                  builder: (context, snap) {
                    final items =
                        List<Map<String, dynamic>>.from(
                      snap.data ?? const [],
                    );

                    // Oldest at top, new messages append downward.
                    items.sort(
                      (a, b) => _date(a['created_at']).compareTo(
                        _date(b['created_at']),
                      ),
                    );

                    if (snap.connectionState ==
                            ConnectionState.waiting &&
                        items.isEmpty) {
                      return const Center(
                        child: CircularProgressIndicator(),
                      );
                    }

                    if (items.isEmpty) {
                      return const _ChatEmptyState();
                    }

                    if (items.length != lastMessageCount) {
                      lastMessageCount = items.length;
                      _scrollToBottom(
                        animated: lastMessageCount > 1,
                      );
                    }

                    final latestFirst = newestFirstChatMessages(items);
                    return ListView.builder(
                      reverse: true,
                      controller: scroll,
                      keyboardDismissBehavior:
                          ScrollViewKeyboardDismissBehavior.onDrag,
                      padding:
                          const EdgeInsets.fromLTRB(14, 10, 14, 20),
                      itemCount: items.length,
                      itemBuilder: (_, i) {
                        final message = latestFirst[i];
                        final system =
                            message['message_type'] == 'system' ||
                                message['sender_id'] == null;
                        final mine =
                            message['sender_id'] == Backend.user?.id;

                        if (system) {
                          return _SystemMessage(
                            text:
                                message['message']?.toString() ?? '',
                            time: _time(message['created_at']),
                          );
                        }

                        return _ChatBubble(
                          mine: mine,
                          text:
                              message['message']?.toString() ?? '',
                          time: _time(message['created_at']),
                        );
                      },
                    );
                  },
                ),
              ),
              Container(
                padding: const EdgeInsets.fromLTRB(12, 9, 12, 12),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surface,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: .05),
                      blurRadius: 20,
                      offset: const Offset(0, -5),
                    ),
                  ],
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Expanded(
                      child: TextField(
                        controller: controller,
                        minLines: 1,
                        maxLines: 4,
                        textCapitalization:
                            TextCapitalization.sentences,
                        onSubmitted: (_) => send(),
                        decoration: InputDecoration(
                          hintText:
                              'Message order chat…',
                          prefixIcon: const Icon(
                            Icons.chat_bubble_outline_rounded,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    SizedBox(
                      width: 57,
                      height: 57,
                      child: IconButton.filled(
                        tooltip: 'Send',
                        onPressed: sending ? null : send,
                        icon: sending
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child:
                                    CircularProgressIndicator(
                                  strokeWidth: 2.2,
                                  color: Colors.white,
                                ),
                              )
                            : const Icon(
                                Icons.send_rounded,
                                size: 26,
                              ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
}

class _TodayDivider extends StatelessWidget {
  const _TodayDivider();

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 4, 18, 6),
        child: Row(
          children: [
            Expanded(child: Divider(color: Theme.of(context).dividerColor)),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 10),
              padding: const EdgeInsets.symmetric(
                horizontal: 14,
                vertical: 5,
              ),
              decoration: BoxDecoration(
                color: Theme.of(context)
                    .colorScheme
                    .surfaceContainerHighest,
                borderRadius: BorderRadius.circular(999),
              ),
              child: const Text(
                'Today',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                ),
              ),
            ),
            Expanded(child: Divider(color: Theme.of(context).dividerColor)),
          ],
        ),
      );
}

class _ChatBubble extends StatelessWidget {
  final bool mine;
  final String text;
  final String time;

  const _ChatBubble({
    required this.mine,
    required this.text,
    required this.time,
  });

  @override
  Widget build(BuildContext context) => Align(
        alignment:
            mine ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          constraints: const BoxConstraints(maxWidth: 330),
          margin: EdgeInsets.only(
            bottom: 9,
            left: mine ? 55 : 0,
            right: mine ? 0 : 55,
          ),
          padding: const EdgeInsets.fromLTRB(15, 11, 15, 8),
          decoration: BoxDecoration(
            gradient: mine
                ? const LinearGradient(
                    colors: [
                      AppTheme.red,
                      AppTheme.deepRed,
                    ],
                  )
                : null,
            color: mine
                ? null
                : Theme.of(context)
                    .colorScheme
                    .surfaceContainerHighest,
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(22),
              topRight: const Radius.circular(22),
              bottomLeft: Radius.circular(mine ? 22 : 7),
              bottomRight: Radius.circular(mine ? 7 : 22),
            ),
          ),
          child: Column(
            crossAxisAlignment:
                mine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
            children: [
              Text(
                text,
                style: TextStyle(
                  color: mine
                      ? Colors.white
                      : Theme.of(context).colorScheme.onSurface,
                  height: 1.34,
                  fontWeight: FontWeight.w600,
                ),
              ),
              if (time.isNotEmpty) ...[
                const SizedBox(height: 5),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      time,
                      style: TextStyle(
                        color: mine
                            ? Colors.white70
                            : AppTheme.muted,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    if (mine) ...[
                      const SizedBox(width: 5),
                      const Icon(
                        Icons.done_all_rounded,
                        color: Colors.white,
                        size: 14,
                      ),
                    ],
                  ],
                ),
              ],
            ],
          ),
        ),
      );
}

class _SystemMessage extends StatelessWidget {
  final String text;
  final String time;

  const _SystemMessage({
    required this.text,
    required this.time,
  });

  IconData get icon {
    final lower = text.toLowerCase();

    if (lower.contains('near')) {
      return Icons.location_on_rounded;
    }
    if (lower.contains('rider')) {
      return Icons.delivery_dining_rounded;
    }
    if (lower.contains('arrived') ||
        lower.contains('delivered')) {
      return Icons.celebration_rounded;
    }
    return Icons.notifications_active_rounded;
  }

  @override
  Widget build(BuildContext context) => Align(
        alignment: Alignment.centerLeft,
        child: Container(
          constraints: const BoxConstraints(maxWidth: 390),
          margin: const EdgeInsets.only(bottom: 11, right: 38),
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [
                AppTheme.softYellow,
                Color(0xFFFFF8DC),
              ],
            ),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                radius: 20,
                backgroundColor:
                    AppTheme.red.withValues(alpha: .09),
                child: Icon(
                  icon,
                  color: AppTheme.red,
                  size: 20,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      text,
                      style: const TextStyle(
                        color: AppTheme.deepRed,
                        fontWeight: FontWeight.w700,
                        fontSize: 12.7,
                        height: 1.3,
                      ),
                    ),
                    if (time.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(
                        time,
                        style: const TextStyle(
                          color: AppTheme.muted,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      );
}

class _ChatEmptyState extends StatelessWidget {
  const _ChatEmptyState();

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 78,
                height: 78,
                decoration: BoxDecoration(
                  color: AppTheme.softRed,
                  borderRadius: BorderRadius.circular(26),
                ),
                child: const Icon(
                  Icons.forum_outlined,
                  size: 38,
                  color: AppTheme.red,
                ),
              ),
              const SizedBox(height: 14),
              Text(
                'Start the delivery conversation',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 6),
              const Text(
                'Messages for this order will appear here.',
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      );
}
