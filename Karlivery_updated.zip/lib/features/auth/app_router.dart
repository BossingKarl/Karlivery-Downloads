import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/navigation_loader.dart';
import '../../core/smart_back.dart';
import '../../core/modern_ui.dart';
import 'login_screen.dart';
import 'register_screen.dart';
import 'email_verification_screen.dart';
import 'forgot_password_screen.dart';
import 'splash_screen.dart';
import 'welcome_screen.dart';
import '../customer/customer_shell.dart';
import '../customer/store_screen.dart';
import '../customer/guest_browse_screen.dart';
import '../customer/cart_screen.dart';
import '../customer/order_detail_screen.dart';
import '../customer/restaurant_reviews_screen.dart';
import '../store/store_dashboard.dart';
import '../rider/rider_dashboard.dart';
import '../admin/admin_dashboard.dart';
import '../shared/chat_screen.dart';
import '../shared/tracking_screen.dart';
import '../shared/notification_center_screen.dart';
import '../shared/help_center_screen.dart';
import '../admin/announcement_screen.dart';
import '../pasabuy/pasabuy_home_screen.dart';
import '../pasabuy/pasabuy_shop_screen.dart';
import '../pasabuy/pasabuy_checkout_screen.dart';
import '../pasabuy/admin_pasabuy_studio_screen.dart';
import '../pasabuy/pasabuy_tracking_screen.dart';
import '../pasabuy/pasabuy_chat_screen.dart';
import '../pasabuy/pasabuy_order_detail_screen.dart';

final GoRouter router = GoRouter(
  initialLocation: '/splash',
  observers: [karliveryNavigatorObserver],
  errorBuilder: (_, state) => _KarliveryRouteError(error: state.error),
  routes: [
    GoRoute(path: '/', redirect: (_, _) => '/splash'),
    GoRoute(path: '/splash', builder: (_, _) => const SplashScreen()),
    GoRoute(path: '/welcome', builder: (_, _) => const WelcomeScreen()),
    GoRoute(path: '/login-callback', builder: (_, _) => const SplashScreen()),
    GoRoute(path: '/login', builder: (_, _) => const LoginScreen()),
    GoRoute(path: '/signin', redirect: (_, _) => '/login'),
    GoRoute(path: '/sign-in', redirect: (_, _) => '/login'),
    GoRoute(path: '/browse', builder: (_, _) => const KarliveryBackScope(fallback: '/welcome', child: GuestBrowseScreen())),
    GoRoute(path: '/cart', builder: (_, _) => KarliveryBackScope(
      fallback: '/customer',
      child: Scaffold(
        appBar: AppBar(title: Text('Your basket'), leading: KarliveryBackButton(fallback: '/customer')),
        body: CartScreen(),
      ),
    )),
    GoRoute(
      path: '/order/:orderId',
      builder: (_, s) => KarliveryBackScope(
        fallback: '/customer', child: CustomerOrderDetailScreen(
        orderId: s.pathParameters['orderId']!,
      )),
    ),
    GoRoute(
      path: '/store/:id/reviews',
      builder: (_, s) => KarliveryBackScope(
        fallback: '/store/${s.pathParameters['id']}', child: RestaurantReviewsScreen(
        storeId: s.pathParameters['id']!,
      )),
    ),
    GoRoute(path: '/register', builder: (_, _) => const RegisterScreen()),
    GoRoute(path: '/signup', redirect: (_, _) => '/register'),
    GoRoute(path: '/sign-up', redirect: (_, _) => '/register'),
    GoRoute(
      path: '/verify-email',
      builder: (_, s) => EmailVerificationScreen(
        email: s.uri.queryParameters['email'] ?? '',
      ),
    ),
    GoRoute(
      path: '/forgot-password',
      builder: (_, _) => const ForgotPasswordScreen(),
    ),
    GoRoute(path: '/pasabuy', builder: (_, _) => const KarliveryBackScope(fallback: '/customer', child: PasabuyHomeScreen())),
    GoRoute(
      path: '/pasabuy/shop/:id',
      builder: (_, s) => KarliveryBackScope(fallback: '/pasabuy', child: PasabuyShopScreen(shopId: s.pathParameters['id']!)),
    ),
    GoRoute(path: '/pasabuy/checkout', builder: (_, _) => const KarliveryBackScope(fallback: '/pasabuy', child: PasabuyCheckoutScreen())),
    GoRoute(
      path: '/pasabuy/order/:id',
      builder: (_, s) => KarliveryBackScope(fallback: '/pasabuy', child: PasabuyOrderDetailScreen(orderId: s.pathParameters['id']!)),
    ),
    GoRoute(
      path: '/pasabuy/chat/:id',
      builder: (_, s) => KarliveryBackScope(fallback: '/pasabuy/order/${s.pathParameters['id']}', child: PasabuyChatScreen(orderId: s.pathParameters['id']!)),
    ),
    GoRoute(
      path: '/pasabuy/track/:id',
      builder: (_, s) => KarliveryBackScope(fallback: '/pasabuy/order/${s.pathParameters['id']}', child: PasabuyTrackingScreen(orderId: s.pathParameters['id']!)),
    ),
    GoRoute(path: '/customer', builder: (_, _) => const CustomerShell()),
    GoRoute(
      path: '/store/:id',
      builder: (_, s) => KarliveryBackScope(fallback: '/customer', child: StoreScreen(storeId: s.pathParameters['id']!)),
    ),
    GoRoute(path: '/store-owner', builder: (_, _) => const KarliveryRootGuard(child: StoreDashboard())),
    GoRoute(path: '/rider', builder: (_, _) => const KarliveryRootGuard(child: RiderDashboard())),
    GoRoute(path: '/admin', builder: (_, _) => const KarliveryRootGuard(child: AdminDashboard())),
    GoRoute(
      path: '/chat/:orderId',
      builder: (_, s) => KarliveryBackScope(fallback: '/order/${s.pathParameters['orderId']}', child: OrderChatScreen(orderId: s.pathParameters['orderId']!)),
    ),
    GoRoute(
      path: '/track/:orderId',
      builder: (_, s) => KarliveryBackScope(fallback: '/order/${s.pathParameters['orderId']}', child: TrackingScreen(orderId: s.pathParameters['orderId']!)),
    ),
    GoRoute(
      path: '/notifications',
      builder: (_, _) => const KarliveryBackScope(fallback: '/customer', child: NotificationCenterScreen()),
    ),
    GoRoute(
      path: '/help',
      builder: (_, s) => HelpCenterScreen(
        role: s.uri.queryParameters['role'] ?? 'customer',
      ),
    ),
    GoRoute(
      path: '/admin/announcement',
      builder: (_, _) => const KarliveryBackScope(fallback: '/admin', child: AnnouncementScreen()),
    ),
    GoRoute(
      path: '/admin/pasabuy',
      builder: (_, _) => const KarliveryBackScope(fallback: '/admin', child: AdminPasabuyStudioScreen()),
    ),
  ],
);


class _KarliveryRouteError extends StatelessWidget {
  final Object? error;

  const _KarliveryRouteError({this.error});

  @override
  Widget build(BuildContext context) => Scaffold(
        body: KAuthBackdrop(
          child: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(22),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 520),
                  child: KPremiumPanel(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const KIconTile(
                          icon: Icons.route_rounded,
                          size: 70,
                        ),
                        const SizedBox(height: 18),
                        Text(
                          'We could not open this page',
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                                fontWeight: FontWeight.w700,
                              ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Karlivery recovered from a navigation error. Return to sign in and try again.',
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                        if (error != null) ...[
                          const SizedBox(height: 10),
                          Text(
                            error.toString(),
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.center,
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ],
                        const SizedBox(height: 20),
                        SizedBox(
                          width: double.infinity,
                          child: FilledButton.icon(
                            onPressed: () => context.go('/login'),
                            icon: const Icon(Icons.login_rounded),
                            label: const Text('Go to sign in'),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      );
}
