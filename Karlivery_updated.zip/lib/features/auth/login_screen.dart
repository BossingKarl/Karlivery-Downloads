// NOVA / 10: authentication uses the shared design system.
import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import 'auth_studio.dart';
import '../../services/backend.dart';
import '../../services/notification_service.dart';
import '../../theme/app_theme.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final login = TextEditingController();
  final password = TextEditingController();
  bool loading = false;
  bool obscure = true;

  @override
  void dispose() {
    login.dispose();
    password.dispose();
    super.dispose();
  }

  void message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> signIn() async {
    if (login.text.trim().isEmpty || password.text.isEmpty) {
      message('Enter your email (or admin username) and password.');
      return;
    }

    setState(() => loading = true);
    try {
      await Backend.login(login.text, password.text);
      final access = await Backend.access();
      if (!mounted) return;

      if (access == null) {
        await Backend.logout();
        message('Account profile is missing.');
        return;
      }

      final role = access['role'].toString();
      final displayName = (access['full_name'] ?? '').toString();
      final destination = switch (role) {
        'admin' => '/admin',
        'rider' => '/rider',
        'store_owner' => '/store-owner',
        _ => '/customer',
      };
      context.go(destination);

      unawaited(
        Future<void>.delayed(const Duration(milliseconds: 220), () async {
          try {
            await NotificationService.init();
            if (!kIsWeb) {
              await NotificationService.requestPermission();
            }
            await NotificationService.startForCurrentUser();
          } catch (e) {
            debugPrint('Post-login notification setup failed: $e');
          }

          try {
            await NotificationService.showLoginNotification(
              role: role,
              displayName: displayName,
            );
          } catch (e) {
            debugPrint('Login phone notification failed: $e');
          }
        }),
      );
    } catch (e) {
      final raw = e.toString();
      if (raw.contains('Invalid login credentials')) {
        message('Wrong email/admin username or password.');
      } else if (raw.contains('Email not confirmed')) {
        message('Your email still needs verification. Enter the code from Karlivery.');
        final typed = login.text.trim();
        if (typed.contains('@') && mounted) {
          final route = Uri(path: '/verify-email', queryParameters: {'email': typed}).toString();
          context.push(route);
        }
      } else {
        message('Sign in failed. Please check your connection and try again.');
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => AuthStudio(
    isRegister: false,
    child: _LoginForm(login: login, password: password, loading: loading,
      obscure: obscure, onToggle: () => setState(() => obscure = !obscure),
      onSignIn: signIn),
  );

}

class _LoginForm extends StatelessWidget {
  final TextEditingController login;
  final TextEditingController password;
  final bool loading;
  final bool obscure;
  final VoidCallback onToggle;
  final Future<void> Function() onSignIn;

  const _LoginForm({
    required this.login,
    required this.password,
    required this.loading,
    required this.obscure,
    required this.onToggle,
    required this.onSignIn,
  });

  @override
  Widget build(BuildContext context) => StudioFormCard(
        child: AutofillGroup(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('WELCOME BACK', style: TextStyle(
                color: Color(0xFFE21A38), fontSize: 12,
                fontWeight: FontWeight.w700, letterSpacing: 1.4)),
              const SizedBox(height: 9),
              Text('Everything you crave,\ncloser than ever.', style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.w700, color: const Color(0xFF241F1A),
                letterSpacing: -1.1)),
              const SizedBox(height: 7),
              const Text('Sign in to your Karlivery account and pick up where you left off.',
                style: TextStyle(fontSize: 13, color: Color(0xFF756F69))),
              const SizedBox(height: 32),
              TextField(
                controller: login,
                keyboardType: TextInputType.emailAddress,
                textInputAction: TextInputAction.next,
                autofillHints: const [AutofillHints.username, AutofillHints.email],
                decoration: const InputDecoration(
                  labelText: 'Email address or username',
                  hintText: 'Enter your account',
                  prefixIcon: Icon(Icons.alternate_email_rounded),
                ),
              ),
              const SizedBox(height: 13),
              TextField(
                controller: password,
                obscureText: obscure,
                autofillHints: const [AutofillHints.password],
                onSubmitted: (_) => onSignIn(),
                decoration: InputDecoration(
                  labelText: 'Password',
                  hintText: 'Enter your password',
                  prefixIcon: const Icon(Icons.key_rounded),
                  suffixIcon: IconButton(
                    tooltip: obscure ? 'Show password' : 'Hide password',
                    onPressed: onToggle,
                    icon: Icon(obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                  ),
                ),
              ),
              const SizedBox(height: 3),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  onPressed: loading ? null : () => context.push('/forgot-password'),
                  icon: const Icon(Icons.lock_reset_rounded, size: 19),
                  label: const Text('Forgot password?'),
                ),
              ),
              const SizedBox(height: 8),
              FilledButton.icon(
                onPressed: loading ? null : onSignIn,
                icon: loading
                    ? const SizedBox(
                        width: 19,
                        height: 19,
                        child: CircularProgressIndicator(strokeWidth: 2.3, color: Colors.white),
                      )
                    : const Icon(Icons.arrow_forward_rounded),
                label: Text(loading ? 'Signing in…' : 'Continue'),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  const Expanded(child: Divider()),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Text(
                      'NEW HERE?',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1.0,
                          ),
                    ),
                  ),
                  const Expanded(child: Divider()),
                ],
              ),
              const SizedBox(height: 16),
              OutlinedButton.icon(
                onPressed: loading ? null : () => context.go('/register'),
                icon: const Icon(Icons.person_add_alt_1_rounded),
                label: const Text('Create an account'),
              ),
              const SizedBox(height: 8),
              TextButton.icon(
                onPressed: loading
                    ? null
                    : () {
                        final typed = login.text.trim();
                        final route = Uri(
                          path: '/verify-email',
                          queryParameters: typed.contains('@') ? {'email': typed} : null,
                        ).toString();
                        context.push(route);
                      },
                icon: const Icon(Icons.password_rounded),
                label: const Text('I already have a verification code'),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: TextButton.icon(
                      onPressed: loading ? null : () => context.go('/browse'),
                      icon: const Icon(Icons.restaurant_menu_rounded),
                      label: const Text('Browse first'),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: TextButton.icon(
                      onPressed: loading ? null : () => context.push('/help?role=customer'),
                      icon: const Icon(Icons.help_outline_rounded),
                      label: const Text('Get help'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(13),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: .58),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.verified_user_outlined, color: AppTheme.deepRed, size: 20),
                    SizedBox(width: 9),
                    Expanded(
                      child: Text(
                        'Seller and rider accounts are managed by Karlivery for safer marketplace access.',
                        style: TextStyle(fontSize: 12.1, fontWeight: FontWeight.w700, height: 1.4),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
}
