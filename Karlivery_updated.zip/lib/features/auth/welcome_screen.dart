import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/brand.dart';
import '../../core/modern_ui.dart';
import '../../services/backend.dart';
import '../../services/onboarding_service.dart';
import '../../theme/app_theme.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  final page = PageController();
  int index = 0;

  static const slides = [
    (
      Icons.restaurant_rounded,
      'Find local food faster',
      'Browse nearby restaurants, featured dishes and preparation time before you decide what to order.',
      'DISCOVER'
    ),
    (
      Icons.route_rounded,
      'Know what happens next',
      'Follow clear order steps, get notifications, message your rider and see delivery progress in one place.',
      'TRACK'
    ),
    (
      Icons.verified_user_rounded,
      'Checkout with confidence',
      'Choose Delivery or Pick-up, pay with COD or a store’s GCash, review the total and place your order.',
      'ORDER'
    ),
  ];

  Future<void> finish(String route) async {
    await OnboardingService.markWelcomeSeen();
    if (!mounted) return;
    if (Backend.user != null) {
      context.go('/splash');
    } else {
      context.go(route);
    }
  }

  @override
  void dispose() {
    page.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final compact = MediaQuery.sizeOf(context).width < 600;
    return Scaffold(
      body: KAuthBackdrop(
        child: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 760),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(18, 16, 18, 22),
                child: Column(
                  children: [
                    Row(
                      children: [
                        const Expanded(child: KarliveryWordmark()),
                        TextButton(
                          onPressed: () => finish('/browse'),
                          child: const Text('Skip'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Expanded(
                      child: PageView.builder(
                        controller: page,
                        itemCount: slides.length,
                        onPageChanged: (v) => setState(() => index = v),
                        itemBuilder: (_, i) {
                          final slide = slides[i];
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            child: Container(
                              clipBehavior: Clip.antiAlias,
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [AppTheme.red, AppTheme.deepRed, AppTheme.crimson],
                                ),
                                borderRadius: BorderRadius.circular(compact ? 32 : 42),
                                boxShadow: [
                                  BoxShadow(
                                    color: AppTheme.red.withValues(alpha: .18),
                                    blurRadius: 38,
                                    offset: const Offset(0, 18),
                                  ),
                                ],
                              ),
                              child: Stack(
                                children: [
                                  Positioned(
                                    top: -80,
                                    right: -60,
                                    child: Container(
                                      width: compact ? 210 : 290,
                                      height: compact ? 210 : 290,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: AppTheme.yellow.withValues(alpha: .18),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    bottom: -60,
                                    left: -45,
                                    child: Container(
                                      width: 180,
                                      height: 180,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        border: Border.all(
                                          color: Colors.white.withValues(alpha: .08),
                                          width: 26,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned.fill(
                                    child: Padding(
                                      padding: EdgeInsets.all(compact ? 26 : 42),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Container(
                                            width: compact ? 112 : 144,
                                            height: compact ? 112 : 144,
                                            decoration: BoxDecoration(
                                              color: Colors.white.withValues(alpha: .12),
                                              borderRadius: BorderRadius.circular(compact ? 34 : 42),
                                              border: Border.all(
                                                color: Colors.white.withValues(alpha: .16),
                                              ),
                                            ),
                                            child: Icon(
                                              slide.$1,
                                              color: AppTheme.yellow,
                                              size: compact ? 56 : 72,
                                            ),
                                          ),
                                          const SizedBox(height: 28),
                                          Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                                            decoration: BoxDecoration(
                                              color: AppTheme.yellow,
                                              borderRadius: BorderRadius.circular(999),
                                            ),
                                            child: Text(
                                              slide.$4,
                                              style: const TextStyle(
                                                color: AppTheme.crimson,
                                                fontWeight: FontWeight.w700,
                                                fontSize: 12,
                                                letterSpacing: 1.4,
                                              ),
                                            ),
                                          ),
                                          const SizedBox(height: 18),
                                          Text(
                                            slide.$2,
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: compact ? 30 : 40,
                                              fontWeight: FontWeight.w700,
                                              height: 1.04,
                                              letterSpacing: -1.2,
                                            ),
                                          ),
                                          const SizedBox(height: 13),
                                          ConstrainedBox(
                                            constraints: const BoxConstraints(maxWidth: 520),
                                            child: Text(
                                              slide.$3,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                color: const Color(0xFFFFE7E4),
                                                fontSize: compact ? 14.5 : 16,
                                                height: 1.5,
                                                fontWeight: FontWeight.w500,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 18),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(
                        slides.length,
                        (i) => AnimatedContainer(
                          duration: const Duration(milliseconds: 220),
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          width: i == index ? 28 : 8,
                          height: 8,
                          decoration: BoxDecoration(
                            color: i == index ? AppTheme.red : Theme.of(context).dividerColor,
                            borderRadius: BorderRadius.circular(99),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    Row(
                      children: [
                        if (index > 0)
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: () => page.previousPage(
                                duration: const Duration(milliseconds: 300),
                                curve: Curves.easeOutCubic,
                              ),
                              icon: const Icon(Icons.arrow_back_rounded),
                              label: const Text('Back'),
                            ),
                          ),
                        if (index > 0) const SizedBox(width: 10),
                        Expanded(
                          flex: 2,
                          child: FilledButton.icon(
                            onPressed: () {
                              if (index < slides.length - 1) {
                                page.nextPage(
                                  duration: const Duration(milliseconds: 300),
                                  curve: Curves.easeOutCubic,
                                );
                              } else {
                                finish('/browse');
                              }
                            },
                            icon: Icon(
                              index == slides.length - 1
                                  ? Icons.restaurant_menu_rounded
                                  : Icons.arrow_forward_rounded,
                            ),
                            label: Text(
                              index == slides.length - 1 ? 'Explore Karlivery' : 'Continue',
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    TextButton(
                      onPressed: () => finish('/login'),
                      child: const Text('Already have an account? Sign in'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
