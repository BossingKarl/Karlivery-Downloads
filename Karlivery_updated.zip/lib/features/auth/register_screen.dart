// NOVA / 10: sign-up inherits premium textfields and brand palette.
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import 'auth_studio.dart';
import '../../services/backend.dart';
import '../../theme/app_theme.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final name = TextEditingController();
  final phone = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  final confirmPassword = TextEditingController();

  bool loading = false;
  bool obscure = true;
  bool obscureConfirm = true;
  String? nameError;
  String? phoneError;
  String? emailError;
  String? passwordError;
  String? confirmPasswordError;

  @override
  void dispose() {
    name.dispose();
    phone.dispose();
    email.dispose();
    password.dispose();
    confirmPassword.dispose();
    super.dispose();
  }

  int get passwordScore {
    final p = password.text;
    var score = 0;
    if (p.length >= 8) score++;
    if (RegExp(r'[A-Z]').hasMatch(p) && RegExp(r'[a-z]').hasMatch(p)) score++;
    if (RegExp(r'[0-9]').hasMatch(p)) score++;
    if (RegExp(r'[^A-Za-z0-9]').hasMatch(p) || p.length >= 12) score++;
    return score;
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> submit() async {
    final cleanName = name.text.trim();
    final cleanPhone = phone.text.trim();
    final cleanEmail = email.text.trim();

    final nextNameError = cleanName.isEmpty ? 'Enter your full name.' : null;
    final nextPhoneError = cleanPhone.isNotEmpty &&
            !RegExp(r'^[0-9+() -]{7,20}$').hasMatch(cleanPhone)
        ? 'Enter a valid mobile number.'
        : null;
    final nextEmailError = !RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$').hasMatch(cleanEmail)
        ? 'Enter a valid email address.'
        : null;
    final nextPasswordError = password.text.length < 8
        ? 'Use at least 8 characters.'
        : null;
    final nextConfirmError = confirmPassword.text != password.text
        ? 'Passwords do not match.'
        : null;

    setState(() {
      nameError = nextNameError;
      phoneError = nextPhoneError;
      emailError = nextEmailError;
      passwordError = nextPasswordError;
      confirmPasswordError = nextConfirmError;
    });

    if ([
      nextNameError,
      nextPhoneError,
      nextEmailError,
      nextPasswordError,
      nextConfirmError,
    ].any((e) => e != null)) {
      _message('Please check the highlighted fields.');
      return;
    }

    setState(() => loading = true);
    try {
      final result = await Backend.register(
        fullName: cleanName,
        phone: cleanPhone,
        email: cleanEmail,
        password: password.text,
      );
      if (!mounted) return;

      if (result.session == null) {
        final location = Uri(
          path: '/verify-email',
          queryParameters: {'email': cleanEmail},
        ).toString();
        context.go(location);
      } else {
        context.go('/splash');
      }
    } catch (e) {
      final raw = e.toString();
      final text = raw.contains('User already registered')
          ? 'An account already exists for this email. Try signing in instead.'
          : raw.toLowerCase().contains('password')
              ? 'The password was rejected. Use at least 8 characters and try again.'
              : raw.toLowerCase().contains('rate')
                  ? 'Too many attempts. Please wait a moment before trying again.'
                  : 'Registration failed. Please check your internet connection and try again.';
      _message(text);
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => AuthStudio(
    isRegister: true,
    child: _form(context),
  );

  Widget _form(BuildContext context) => StudioFormCard(
        child: AutofillGroup(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('JOIN KARLIVERY', style: TextStyle(
                color: Color(0xFFE21A38), fontSize: 12,
                fontWeight: FontWeight.w700, letterSpacing: 1.4)),
              const SizedBox(height: 9),
              Text('Create your account', style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.w700, color: const Color(0xFF241F1A),
                letterSpacing: -1.1)),
              const SizedBox(height: 7),
              const Text('Order from local favorites and track every delivery.',
                style: TextStyle(fontSize: 13, color: Color(0xFF756F69))),
              const SizedBox(height: 28),
              TextField(
                controller: name,
                textInputAction: TextInputAction.next,
                textCapitalization: TextCapitalization.words,
                autofillHints: const [AutofillHints.name],
                decoration: InputDecoration(
                  labelText: 'Full name',
                  errorText: nameError,
                  prefixIcon: const Icon(Icons.person_outline_rounded),
                ),
              ),
              const SizedBox(height: 13),
              TextField(
                controller: phone,
                keyboardType: TextInputType.phone,
                textInputAction: TextInputAction.next,
                autofillHints: const [AutofillHints.telephoneNumber],
                decoration: InputDecoration(
                  labelText: 'Mobile number (optional)',
                  errorText: phoneError,
                  prefixIcon: const Icon(Icons.phone_outlined),
                ),
              ),
              const SizedBox(height: 13),
              TextField(
                controller: email,
                keyboardType: TextInputType.emailAddress,
                textInputAction: TextInputAction.next,
                autofillHints: const [AutofillHints.email],
                decoration: InputDecoration(
                  labelText: 'Email address',
                  errorText: emailError,
                  prefixIcon: const Icon(Icons.alternate_email_rounded),
                ),
              ),
              const SizedBox(height: 13),
              TextField(
                controller: password,
                obscureText: obscure,
                textInputAction: TextInputAction.next,
                autofillHints: const [AutofillHints.newPassword],
                onChanged: (_) => setState(() {}),
                decoration: InputDecoration(
                  labelText: 'Password',
                  errorText: passwordError,
                  prefixIcon: const Icon(Icons.key_rounded),
                  suffixIcon: IconButton(
                    tooltip: obscure ? 'Show password' : 'Hide password',
                    onPressed: () => setState(() => obscure = !obscure),
                    icon: Icon(obscure
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              _PasswordStrength(score: passwordScore),
              const SizedBox(height: 13),
              TextField(
                controller: confirmPassword,
                obscureText: obscureConfirm,
                autofillHints: const [AutofillHints.newPassword],
                onSubmitted: (_) => loading ? null : submit(),
                decoration: InputDecoration(
                  labelText: 'Confirm password',
                  errorText: confirmPasswordError,
                  prefixIcon: const Icon(Icons.lock_outline_rounded),
                  suffixIcon: IconButton(
                    tooltip: obscureConfirm ? 'Show password' : 'Hide password',
                    onPressed: () =>
                        setState(() => obscureConfirm = !obscureConfirm),
                    icon: Icon(obscureConfirm
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined),
                  ),
                ),
              ),
              const SizedBox(height: 22),
              FilledButton.icon(
                onPressed: loading ? null : submit,
                icon: loading
                    ? const SizedBox(
                        width: 19,
                        height: 19,
                        child: CircularProgressIndicator(
                            strokeWidth: 2.3, color: Colors.white),
                      )
                    : const Icon(Icons.arrow_forward_rounded),
                label: Text(loading ? 'Creating account…' : 'Create account'),
              ),
              const SizedBox(height: 16),
              OutlinedButton.icon(
                onPressed: loading ? null : () => context.go('/login'),
                icon: const Icon(Icons.login_rounded),
                label: const Text('I already have an account'),
              ),
              const SizedBox(height: 8),
              TextButton.icon(
                onPressed: loading ? null : () => context.go('/browse'),
                icon: const Icon(Icons.restaurant_menu_rounded),
                label: const Text('Browse first'),
              ),
            ],
          ),
        ),
      );
}

class _PasswordStrength extends StatelessWidget {
  final int score;

  const _PasswordStrength({required this.score});

  @override
  Widget build(BuildContext context) {
    final labels = ['Add a stronger password', 'Basic', 'Good', 'Strong', 'Excellent'];
    final safeScore = score.clamp(0, 4).toInt();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: List.generate(
            4,
            (i) => Expanded(
              child: Container(
                height: 5,
                margin: EdgeInsets.only(right: i == 3 ? 0 : 6),
                decoration: BoxDecoration(
                  color: i < safeScore
                      ? (safeScore >= 3 ? AppTheme.red : AppTheme.yellow)
                      : Theme.of(context).dividerColor,
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          labels[safeScore],
          style: Theme.of(context).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w700),
        ),
      ],
    );
  }
}
