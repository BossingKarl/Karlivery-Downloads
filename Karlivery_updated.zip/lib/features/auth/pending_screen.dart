import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/brand.dart';
import '../../core/modern_ui.dart';
import '../../services/backend.dart';
import '../../theme/app_theme.dart';

class PendingScreen extends StatelessWidget {
  final String role;
  final String status;

  const PendingScreen({
    super.key,
    required this.role,
    required this.status,
  });

  @override
  Widget build(BuildContext context) {
    final roleName = role == 'store_owner' ? 'Store Owner' : 'Rider';
    return Scaffold(
      body: KAuthBackdrop(
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(22),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 560),
                child: Column(
                  children: [
                    const KarliveryWordmark(),
                    const SizedBox(height: 24),
                    KPremiumPanel(
                      padding: const EdgeInsets.all(30),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const KIconTile(
                            icon: Icons.hourglass_top_rounded,
                            color: AppTheme.red,
                            size: 78,
                          ),
                          const SizedBox(height: 20),
                          Text(
                            status == 'pending'
                                ? '$roleName approval pending'
                                : 'Account ${status.replaceAll('_', ' ')}',
                            textAlign: TextAlign.center,
                            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                                  fontWeight: FontWeight.w700,
                                ),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            'An administrator must approve your account before access is enabled. You can check again anytime.',
                            textAlign: TextAlign.center,
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                          const SizedBox(height: 22),
                          SizedBox(
                            width: double.infinity,
                            child: FilledButton.icon(
                              onPressed: () => context.go('/splash'),
                              icon: const Icon(Icons.refresh_rounded),
                              label: const Text('Check approval status'),
                            ),
                          ),
                          const SizedBox(height: 9),
                          SizedBox(
                            width: double.infinity,
                            child: OutlinedButton.icon(
                              onPressed: () async {
                                await Backend.logout();
                                if (context.mounted) context.go('/login');
                              },
                              icon: const Icon(Icons.logout_rounded),
                              label: const Text('Sign out'),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
