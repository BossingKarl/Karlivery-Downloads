import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';

import '../../core/modern_ui.dart';
import '../../services/backend.dart';
import '../../theme/app_theme.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final email = TextEditingController();
  final code = TextEditingController();
  final newPassword = TextEditingController();
  final confirmPassword = TextEditingController();

  int step = 0;
  bool loading = false;
  bool obscure = true;
  bool obscureConfirm = true;
  int cooldown = 0;
  Timer? _timer;

  @override
  void dispose() {
    _timer?.cancel();
    email.dispose();
    code.dispose();
    newPassword.dispose();
    confirmPassword.dispose();
    super.dispose();
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _startCooldown() {
    _timer?.cancel();
    setState(() => cooldown = 45);
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return;
      if (cooldown <= 1) {
        timer.cancel();
        setState(() => cooldown = 0);
      } else {
        setState(() => cooldown--);
      }
    });
  }

  Future<void> _sendCode({bool resend = false}) async {
    final cleanEmail = email.text.trim();
    if (!RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$').hasMatch(cleanEmail)) {
      _message('Enter the email address connected to your Karlivery account.');
      return;
    }
    if (resend && cooldown > 0) return;

    setState(() => loading = true);
    try {
      await Backend.requestPasswordResetCode(cleanEmail);
      if (!mounted) return;
      code.clear();
      setState(() => step = 1);
      _startCooldown();
      _message(
        resend
            ? 'A fresh Karlivery reset code was sent.'
            : 'Check your email for your Karlivery reset code.',
      );
    } catch (_) {
      // Privacy-safe copy: never reveal whether an account exists.
      if (!mounted) return;
      code.clear();
      setState(() => step = 1);
      _startCooldown();
      _message('If that email belongs to a Karlivery account, a reset code is on the way.');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _verifyCode() async {
    final cleanCode = code.text.trim();
    if (cleanCode.length < 6) {
      _message('Enter the complete reset code from your Karlivery email.');
      return;
    }

    setState(() => loading = true);
    try {
      await Backend.verifyPasswordResetCode(
        email: email.text.trim(),
        code: cleanCode,
      );
      if (!mounted) return;
      setState(() => step = 2);
    } catch (_) {
      _message('That reset code is invalid or expired. Request a fresh code and try again.');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _savePassword() async {
    if (newPassword.text.length < 8) {
      _message('Use at least 8 characters for your new password.');
      return;
    }
    if (newPassword.text != confirmPassword.text) {
      _message('The new passwords do not match.');
      return;
    }

    setState(() => loading = true);
    try {
      await Backend.finishPasswordReset(newPassword.text);
      await Backend.logout();
      if (!mounted) return;
      setState(() => step = 3);
    } catch (_) {
      _message('Could not update your password. Please request a new reset code and try again.');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  int get _passwordScore {
    final value = newPassword.text;
    var score = 0;
    if (value.length >= 8) score++;
    if (value.length >= 12) score++;
    if (RegExp(r'[A-Z]').hasMatch(value) && RegExp(r'[a-z]').hasMatch(value)) score++;
    if (RegExp(r'\d').hasMatch(value)) score++;
    if (RegExp(r'[^A-Za-z0-9]').hasMatch(value)) score++;
    return score > 5 ? 5 : score;
  }

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.sizeOf(context).width >= 900;
    final panel = KPremiumPanel(
      padding: EdgeInsets.all(wide ? 30 : 22),
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 230),
        switchInCurve: Curves.easeOutCubic,
        switchOutCurve: Curves.easeInCubic,
        child: KeyedSubtree(
          key: ValueKey(step),
          child: _buildStep(context),
        ),
      ),
    );

    return Scaffold(
      body: KAuthBackdrop(
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(wide ? 30 : 18, 20, wide ? 30 : 18, 34),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1120),
                child: wide
                    ? Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const Expanded(
                            child: KAuthHero(
                              eyebrow: 'Secure account recovery',
                              title: 'A safer reset.\nA smoother return.',
                              description:
                                  'Karlivery keeps password recovery inside the app with a one-time email code, clear security cues, and no confusing redirect flow.',
                              features: [
                                (Icons.mark_email_read_rounded, 'Branded reset email', 'Easy-to-spot one-time code'),
                                (Icons.password_rounded, 'Code verification', 'Secure identity check'),
                                (Icons.lock_reset_rounded, 'New password', 'Finish inside Karlivery'),
                              ],
                            ),
                          ),
                          const SizedBox(width: 32),
                          Expanded(child: panel),
                        ],
                      )
                    : Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Row(
                            children: [
                              IconButton(
                                tooltip: 'Back to sign in',
                                onPressed: loading ? null : () => context.go('/login'),
                                icon: const Icon(Icons.arrow_back_rounded),
                              ),
                              const Spacer(),
                              const KStatusPill(
                                text: 'Secure recovery',
                                color: AppTheme.red,
                                icon: Icons.shield_outlined,
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          panel,
                        ],
                      ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStep(BuildContext context) {
    switch (step) {
      case 0:
        return _emailStep(context);
      case 1:
        return _codeStep(context);
      case 2:
        return _passwordStep(context);
      default:
        return _successStep(context);
    }
  }

  Widget _stepHeader(
    BuildContext context, {
    required IconData icon,
    required String eyebrow,
    required String title,
    required String subtitle,
    required int activeStep,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            KIconTile(icon: icon, size: 58),
            const Spacer(),
            if (activeStep < 4)
              Text(
                '${activeStep + 1} of 3',
                style: Theme.of(context).textTheme.labelMedium?.copyWith(
                      color: AppTheme.muted,
                      fontWeight: FontWeight.w700,
                    ),
              ),
          ],
        ),
        const SizedBox(height: 18),
        Text(
          eyebrow.toUpperCase(),
          style: Theme.of(context).textTheme.labelSmall?.copyWith(
                color: AppTheme.deepRed,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.1,
              ),
        ),
        const SizedBox(height: 7),
        Text(
          title,
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w700,
                letterSpacing: -.4,
              ),
        ),
        const SizedBox(height: 7),
        Text(subtitle, style: Theme.of(context).textTheme.bodyMedium),
        if (activeStep < 3) ...[
          const SizedBox(height: 18),
          _RecoveryProgress(activeStep: activeStep),
        ],
      ],
    );
  }

  Widget _emailStep(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _stepHeader(
          context,
          icon: Icons.lock_reset_rounded,
          eyebrow: 'Password recovery',
          title: 'Let’s get you back in.',
          subtitle:
              'Enter the email connected to your Karlivery account. We’ll send a secure one-time reset code.',
          activeStep: 0,
        ),
        const SizedBox(height: 24),
        TextField(
          controller: email,
          enabled: !loading,
          keyboardType: TextInputType.emailAddress,
          textInputAction: TextInputAction.done,
          autofillHints: const [AutofillHints.email],
          onSubmitted: (_) => _sendCode(),
          decoration: const InputDecoration(
            labelText: 'Email address',
            hintText: 'you@example.com',
            helperText: 'Use the same email you use to sign in to Karlivery.',
            prefixIcon: Icon(Icons.alternate_email_rounded),
          ),
        ),
        const SizedBox(height: 16),
        _SecurityNote(
          icon: Icons.privacy_tip_outlined,
          title: 'Private by design',
          text: 'For your security, Karlivery will not reveal whether an email is registered.',
        ),
        const SizedBox(height: 18),
        FilledButton.icon(
          onPressed: loading ? null : _sendCode,
          icon: loading
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2.2, color: Colors.white),
                )
              : const Icon(Icons.mark_email_unread_rounded),
          label: Text(loading ? 'Sending secure code…' : 'Send reset code'),
        ),
        const SizedBox(height: 9),
        TextButton.icon(
          onPressed: loading ? null : () => context.go('/login'),
          icon: const Icon(Icons.arrow_back_rounded),
          label: const Text('Back to sign in'),
        ),
      ],
    );
  }

  Widget _codeStep(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _stepHeader(
          context,
          icon: Icons.mark_email_read_rounded,
          eyebrow: 'Check your inbox',
          title: 'Enter your reset code.',
          subtitle:
              'We sent a one-time code to your email. Copy it from the Karlivery password-reset message and enter it below.',
          activeStep: 1,
        ),
        const SizedBox(height: 22),
        _EmailDestination(
          email: email.text.trim(),
          onChange: loading ? null : () => setState(() => step = 0),
        ),
        const SizedBox(height: 20),
        _RecoveryCodeEntry(
          controller: code,
          enabled: !loading,
          onComplete: _verifyCode,
        ),
        const SizedBox(height: 15),
        _SecurityNote(
          icon: Icons.shield_outlined,
          title: 'Keep this code private',
          text: 'Karlivery support will never ask for your password or one-time reset code.',
        ),
        const SizedBox(height: 18),
        FilledButton.icon(
          onPressed: loading ? null : _verifyCode,
          icon: loading
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2.2, color: Colors.white),
                )
              : const Icon(Icons.verified_user_rounded),
          label: Text(loading ? 'Verifying securely…' : 'Verify reset code'),
        ),
        const SizedBox(height: 7),
        TextButton.icon(
          onPressed: loading || cooldown > 0 ? null : () => _sendCode(resend: true),
          icon: const Icon(Icons.refresh_rounded),
          label: Text(
            cooldown > 0 ? 'Resend available in ${cooldown}s' : 'Send a new reset code',
          ),
        ),
        TextButton.icon(
          onPressed: loading ? null : () => context.go('/login'),
          icon: const Icon(Icons.arrow_back_rounded),
          label: const Text('Back to sign in'),
        ),
      ],
    );
  }

  Widget _passwordStep(BuildContext context) {
    final score = _passwordScore;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _stepHeader(
          context,
          icon: Icons.shield_rounded,
          eyebrow: 'Identity verified',
          title: 'Create a new password.',
          subtitle:
              'Your reset code is verified. Choose a strong password that is difficult to guess and unique to Karlivery.',
          activeStep: 2,
        ),
        const SizedBox(height: 24),
        TextField(
          controller: newPassword,
          enabled: !loading,
          obscureText: obscure,
          textInputAction: TextInputAction.next,
          autofillHints: const [AutofillHints.newPassword],
          onChanged: (_) => setState(() {}),
          decoration: InputDecoration(
            labelText: 'New password',
            hintText: 'At least 8 characters',
            prefixIcon: const Icon(Icons.key_rounded),
            suffixIcon: IconButton(
              tooltip: obscure ? 'Show password' : 'Hide password',
              onPressed: () => setState(() => obscure = !obscure),
              icon: Icon(obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined),
            ),
          ),
        ),
        const SizedBox(height: 12),
        _PasswordStrengthMeter(score: score),
        const SizedBox(height: 14),
        TextField(
          controller: confirmPassword,
          enabled: !loading,
          obscureText: obscureConfirm,
          textInputAction: TextInputAction.done,
          autofillHints: const [AutofillHints.newPassword],
          onSubmitted: (_) => _savePassword(),
          decoration: InputDecoration(
            labelText: 'Confirm new password',
            prefixIcon: const Icon(Icons.lock_outline_rounded),
            suffixIcon: IconButton(
              tooltip: obscureConfirm ? 'Show password' : 'Hide password',
              onPressed: () => setState(() => obscureConfirm = !obscureConfirm),
              icon: Icon(
                obscureConfirm ? Icons.visibility_outlined : Icons.visibility_off_outlined,
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
        _SecurityNote(
          icon: Icons.tips_and_updates_outlined,
          title: 'Better password tip',
          text: 'Use a mix of words, numbers, and symbols. Avoid reusing a password from another app.',
        ),
        const SizedBox(height: 18),
        FilledButton.icon(
          onPressed: loading ? null : _savePassword,
          icon: loading
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2.2, color: Colors.white),
                )
              : const Icon(Icons.check_circle_rounded),
          label: Text(loading ? 'Securing your account…' : 'Save new password'),
        ),
      ],
    );
  }

  Widget _successStep(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
          width: 82,
          height: 82,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: AppTheme.softYellow,
            borderRadius: BorderRadius.circular(27),
            border: Border.all(color: AppTheme.yellow.withValues(alpha: .6)),
          ),
          child: const Icon(Icons.verified_rounded, color: AppTheme.deepRed, size: 42),
        ),
        const SizedBox(height: 22),
        Text(
          'Password updated successfully.',
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w700,
                letterSpacing: -.4,
              ),
        ),
        const SizedBox(height: 8),
        Text(
          'Your Karlivery account is secured with your new password. Sign in again to continue.',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        const SizedBox(height: 22),
        _SecurityNote(
          icon: Icons.logout_rounded,
          title: 'Fresh sign-in required',
          text: 'We signed out the recovery session so your next login starts clean and secure.',
        ),
        const SizedBox(height: 22),
        FilledButton.icon(
          onPressed: () => context.go('/login'),
          icon: const Icon(Icons.login_rounded),
          label: const Text('Sign in with new password'),
        ),
      ],
    );
  }
}

class _RecoveryProgress extends StatelessWidget {
  final int activeStep;

  const _RecoveryProgress({required this.activeStep});

  @override
  Widget build(BuildContext context) {
    const labels = ['Email', 'Code', 'Password'];
    return Row(
      children: List.generate(labels.length * 2 - 1, (index) {
        if (index.isOdd) {
          final completed = activeStep > index ~/ 2;
          return Expanded(
            child: Container(
              height: 3,
              margin: const EdgeInsets.symmetric(horizontal: 7),
              decoration: BoxDecoration(
                color: completed ? AppTheme.red : AppTheme.line,
                borderRadius: BorderRadius.circular(999),
              ),
            ),
          );
        }
        final stepIndex = index ~/ 2;
        final completed = stepIndex < activeStep;
        final active = stepIndex == activeStep;
        return Column(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              width: 31,
              height: 31,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: completed || active ? AppTheme.red : Colors.transparent,
                border: Border.all(
                  color: completed || active ? AppTheme.red : AppTheme.line,
                  width: 1.5,
                ),
              ),
              child: completed
                  ? const Icon(Icons.check_rounded, size: 17, color: Colors.white)
                  : Text(
                      '${stepIndex + 1}',
                      style: TextStyle(
                        color: active ? Colors.white : AppTheme.muted,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
            ),
            const SizedBox(height: 4),
            Text(
              labels[stepIndex],
              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: active || completed ? AppTheme.deepRed : AppTheme.muted,
                    fontWeight: FontWeight.w700,
                  ),
            ),
          ],
        );
      }),
    );
  }
}

class _EmailDestination extends StatelessWidget {
  final String email;
  final VoidCallback? onChange;

  const _EmailDestination({required this.email, this.onChange});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(15, 13, 10, 13),
      decoration: BoxDecoration(
        color: AppTheme.softYellow.withValues(alpha: .55),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppTheme.yellow.withValues(alpha: .35)),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: .85),
              borderRadius: BorderRadius.circular(13),
            ),
            child: const Icon(Icons.mail_outline_rounded, color: AppTheme.deepRed, size: 21),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Code sent to',
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: AppTheme.muted,
                        fontWeight: FontWeight.w700,
                      ),
                ),
                const SizedBox(height: 2),
                Text(
                  email,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ),
          TextButton(onPressed: onChange, child: const Text('Change')),
        ],
      ),
    );
  }
}

class _RecoveryCodeEntry extends StatefulWidget {
  final TextEditingController controller;
  final bool enabled;
  final Future<void> Function() onComplete;

  const _RecoveryCodeEntry({
    required this.controller,
    required this.enabled,
    required this.onComplete,
  });

  @override
  State<_RecoveryCodeEntry> createState() => _RecoveryCodeEntryState();
}

class _RecoveryCodeEntryState extends State<_RecoveryCodeEntry> {
  final FocusNode _focusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_rebuild);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && widget.enabled) _focusNode.requestFocus();
    });
  }

  @override
  void didUpdateWidget(covariant _RecoveryCodeEntry oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.controller != widget.controller) {
      oldWidget.controller.removeListener(_rebuild);
      widget.controller.addListener(_rebuild);
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_rebuild);
    _focusNode.dispose();
    super.dispose();
  }

  void _rebuild() {
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final value = widget.controller.text;
    const slots = 6;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          '6-digit reset code',
          style: Theme.of(context).textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 10),
        GestureDetector(
          onTap: widget.enabled ? _focusNode.requestFocus : null,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Opacity(
                opacity: .01,
                child: TextField(
                  controller: widget.controller,
                  focusNode: _focusNode,
                  enabled: widget.enabled,
                  autofocus: true,
                  keyboardType: TextInputType.number,
                  textInputAction: TextInputAction.done,
                  autofillHints: const [AutofillHints.oneTimeCode],
                  inputFormatters: [
                    FilteringTextInputFormatter.digitsOnly,
                    LengthLimitingTextInputFormatter(slots),
                  ],
                  onChanged: (text) {
                    if (text.length == slots) unawaited(widget.onComplete());
                  },
                  onSubmitted: (_) => widget.onComplete(),
                  decoration: const InputDecoration(border: InputBorder.none),
                ),
              ),
              IgnorePointer(
                child: Row(
                  children: List.generate(slots, (index) {
                    final filled = index < value.length;
                    final active = index == value.length && value.length < slots;
                    return Expanded(
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 160),
                        height: 58,
                        margin: EdgeInsets.only(right: index == slots - 1 ? 0 : 7),
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: filled
                              ? AppTheme.softYellow.withValues(alpha: .7)
                              : Theme.of(context).colorScheme.surface,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: active
                                ? AppTheme.red
                                : filled
                                    ? AppTheme.yellow
                                    : AppTheme.line,
                            width: active ? 2 : 1.2,
                          ),
                          boxShadow: active
                              ? [
                                  BoxShadow(
                                    color: AppTheme.red.withValues(alpha: .08),
                                    blurRadius: 14,
                                    offset: const Offset(0, 4),
                                  ),
                                ]
                              : null,
                        ),
                        child: Text(
                          filled ? value[index] : '',
                          style: const TextStyle(
                            color: AppTheme.crimson,
                            fontSize: 23,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    );
                  }),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 9),
        Row(
          children: [
            const Icon(Icons.copy_all_rounded, size: 16, color: AppTheme.muted),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                'Tip: you can copy the code from your email and paste it here.',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _SecurityNote extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;

  const _SecurityNote({required this.icon, required this.title, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.softRed.withValues(alpha: .48),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: AppTheme.red.withValues(alpha: .10)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: AppTheme.deepRed, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 3),
                Text(text, style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PasswordStrengthMeter extends StatelessWidget {
  final int score;

  const _PasswordStrengthMeter({required this.score});

  @override
  Widget build(BuildContext context) {
    final label = switch (score) {
      <= 1 => 'Needs work',
      2 => 'Fair',
      3 => 'Good',
      4 => 'Strong',
      _ => 'Excellent',
    };
    final color = switch (score) {
      <= 1 => AppTheme.red,
      2 => const Color(0xFFF08A24),
      3 => const Color(0xFFD5A100),
      _ => const Color(0xFF238B57),
    };

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            Text('Password strength', style: Theme.of(context).textTheme.bodySmall),
            const Spacer(),
            Text(
              label,
              style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w700),
            ),
          ],
        ),
        const SizedBox(height: 7),
        Row(
          children: List.generate(5, (index) {
            return Expanded(
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 170),
                height: 5,
                margin: EdgeInsets.only(right: index == 4 ? 0 : 5),
                decoration: BoxDecoration(
                  color: index < score ? color : AppTheme.line,
                  borderRadius: BorderRadius.circular(999),
                ),
              ),
            );
          }),
        ),
      ],
    );
  }
}
