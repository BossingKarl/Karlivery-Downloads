import 'dart:async';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/modern_ui.dart';
import '../../services/backend.dart';
import '../../services/onboarding_service.dart';
import '../../theme/app_theme.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _route();
  }

  Timer? _fallbackTimer;

  @override
  void dispose() {
    _fallbackTimer?.cancel();
    super.dispose();
  }

  Future<void> _route() async {
    // A failed remote access lookup must not trap a signed-in user forever.
    _fallbackTimer = Timer(const Duration(seconds: 15), () {
      if (mounted) context.go('/login');
    });
    await Future<void>.delayed(const Duration(milliseconds: 30));
    if (!mounted) return;

    if (Backend.user == null) {
      final seenWelcome = await OnboardingService.hasSeenWelcome()
          .timeout(const Duration(seconds: 5), onTimeout: () => true);
      if (!mounted) return;
      context.go(seenWelcome ? '/browse' : '/welcome');
      return;
    }

    try {
      final a = await Backend.access().timeout(const Duration(seconds: 10));
      if (!mounted) return;
      if (a == null) {
        await Backend.logout();
        if (mounted) context.go('/login');
        return;
      }

      final role = a['role'].toString();
      switch (role) {
        case 'admin':
          context.go('/admin');
          break;
        case 'rider':
          context.go('/rider');
          break;
        case 'store_owner':
          context.go('/store-owner');
          break;
        default:
          context.go('/customer');
      }
    } catch (error) {
      debugPrint('Karlivery access lookup failed: $error');
      // Do not sign the user out for a temporary connection/RPC timeout.
      if (mounted) context.go('/login');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: KAuthBackdrop(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const KarliveryLoader(size: 92),
                  const SizedBox(height: 24),
                  Text(
                    'Karlivery',
                    style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                          fontWeight: FontWeight.w700,
                          letterSpacing: -1.2,
                        ),
                  ),
                  const SizedBox(height: 7),
                  const Text(
                    'FOOD  •  PICK-UP  •  DELIVERY',
                    style: TextStyle(
                      color: AppTheme.deepRed,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.6,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'Preparing your local food experience…',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.w700,
                        ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
}
