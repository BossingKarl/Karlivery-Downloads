import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';

import '../../core/modern_ui.dart';
import '../../services/backend.dart';
import '../../theme/app_theme.dart';

class EmailVerificationScreen extends StatefulWidget {
  final String email;

  const EmailVerificationScreen({
    super.key,
    this.email = '',
  });

  @override
  State<EmailVerificationScreen> createState() => _EmailVerificationScreenState();
}

class _EmailVerificationScreenState extends State<EmailVerificationScreen> {
  late final TextEditingController email;
  final code = TextEditingController();
  bool verifying = false;
  bool resending = false;
  int cooldown = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    email = TextEditingController(text: widget.email.trim());
    if (widget.email.trim().isNotEmpty) _startCooldown();
  }

  @override
  void dispose() {
    _timer?.cancel();
    email.dispose();
    code.dispose();
    super.dispose();
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  void _startCooldown() {
    _timer?.cancel();
    setState(() => cooldown = 45);
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return;
      if (cooldown <= 1) {
        timer.cancel();
        setState(() => cooldown = 0);
      } else {
        setState(() => cooldown--);
      }
    });
  }

  Future<void> _verify() async {
    final cleanEmail = email.text.trim();
    final cleanCode = code.text.trim();
    if (!RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$').hasMatch(cleanEmail)) {
      _message('Enter the email address you registered with.');
      return;
    }
    if (cleanCode.length < 6) {
      _message('Enter the verification code from your Karlivery email.');
      return;
    }

    setState(() => verifying = true);
    try {
      await Backend.verifySignupCode(email: cleanEmail, code: cleanCode);
      if (!mounted) return;
      _message('Email verified. Welcome to Karlivery!');
      context.go('/splash');
    } catch (e) {
      final raw = e.toString().toLowerCase();
      _message(
        raw.contains('expired') || raw.contains('invalid')
            ? 'That code is invalid or expired. Request a fresh code and try again.'
            : 'Could not verify the code. Please check it and try again.',
      );
    } finally {
      if (mounted) setState(() => verifying = false);
    }
  }

  Future<void> _resend() async {
    if (cooldown > 0 || resending) return;
    final cleanEmail = email.text.trim();
    if (!RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$').hasMatch(cleanEmail)) {
      _message('Enter a valid email address first.');
      return;
    }

    setState(() => resending = true);
    try {
      await Backend.resendSignupCode(cleanEmail);
      if (!mounted) return;
      _startCooldown();
      _message('A new Karlivery verification code was sent.');
    } catch (_) {
      _message('Could not resend the code yet. Please wait a moment and try again.');
    } finally {
      if (mounted) setState(() => resending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.sizeOf(context).width >= 900;
    const features = <(IconData, String, String)>[
      (Icons.password_rounded, 'Code verification', 'No confirmation-link redirect'),
      (Icons.shield_outlined, 'Secure', 'One-time email verification'),
      (Icons.restaurant_rounded, 'Ready after verify', 'Start browsing immediately'),
    ];

    final panel = KPremiumPanel(
      padding: EdgeInsets.all(wide ? 30 : 22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const KIconTile(icon: Icons.mark_email_read_rounded, size: 56),
          const SizedBox(height: 18),
          Text(
            'Verify your email',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
          ),
          const SizedBox(height: 7),
          Text(
            'Enter the one-time code we sent to your email. You no longer need to leave Karlivery and follow a confirmation link.',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 24),
          TextField(
            controller: email,
            keyboardType: TextInputType.emailAddress,
            textInputAction: TextInputAction.next,
            autofillHints: const [AutofillHints.email],
            decoration: const InputDecoration(
              labelText: 'Email address',
              prefixIcon: Icon(Icons.alternate_email_rounded),
            ),
          ),
          const SizedBox(height: 13),
          TextField(
            controller: code,
            autofocus: widget.email.trim().isNotEmpty,
            keyboardType: TextInputType.number,
            textInputAction: TextInputAction.done,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
              LengthLimitingTextInputFormatter(8),
            ],
            onSubmitted: (_) => _verify(),
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w700,
              letterSpacing: 5,
            ),
            decoration: const InputDecoration(
              labelText: 'Verification code',
              hintText: 'Enter code',
              helperText: 'Use the code shown in the Karlivery verification email.',
              prefixIcon: Icon(Icons.pin_outlined),
            ),
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: verifying ? null : _verify,
            icon: verifying
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2.2, color: Colors.white),
                  )
                : const Icon(Icons.verified_rounded),
            label: Text(verifying ? 'Verifying…' : 'Verify and continue'),
          ),
          const SizedBox(height: 8),
          TextButton.icon(
            onPressed: cooldown > 0 || resending ? null : _resend,
            icon: const Icon(Icons.refresh_rounded),
            label: Text(
              resending
                  ? 'Sending…'
                  : cooldown > 0
                      ? 'Resend code in ${cooldown}s'
                      : 'Resend verification code',
            ),
          ),
          const Divider(height: 28),
          TextButton.icon(
            onPressed: verifying ? null : () => context.go('/login'),
            icon: const Icon(Icons.arrow_back_rounded),
            label: const Text('Back to sign in'),
          ),
        ],
      ),
    );

    return Scaffold(
      body: KAuthBackdrop(
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(wide ? 30 : 18, 20, wide ? 30 : 18, 34),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1120),
                child: wide
                    ? Row(
                        children: [
                          const Expanded(
                            child: KAuthHero(
                              eyebrow: 'Secure verification',
                              title: 'One code.\nNo redirect hassle.',
                              description:
                                  'Karlivery keeps account verification inside the app so new customers can confirm their email and continue naturally.',
                              features: features,
                            ),
                          ),
                          const SizedBox(width: 32),
                          Expanded(child: panel),
                        ],
                      )
                    : Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Row(
                            children: [
                              IconButton(
                                tooltip: 'Back',
                                onPressed: () => context.go('/login'),
                                icon: const Icon(Icons.arrow_back_rounded),
                              ),
                              const Spacer(),
                              const KStatusPill(
                                text: 'Email security',
                                color: AppTheme.red,
                                icon: Icons.shield_outlined,
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          panel,
                        ],
                      ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
