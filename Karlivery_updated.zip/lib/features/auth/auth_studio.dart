import 'package:flutter/material.dart';

/// Mobile-first Karlivery authentication layout. Authentication logic lives in each screen.
class AuthStudio extends StatelessWidget {
  const AuthStudio({super.key, required this.child, required this.isRegister});
  final Widget child;
  final bool isRegister;
  @override
  Widget build(BuildContext context) {
    const bg = Color(0xFFFCFAF7);
    final width = MediaQuery.sizeOf(context).width;
    final wide = width >= 850;
    final form = SingleChildScrollView(
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      padding: EdgeInsets.fromLTRB(wide ? 46 : 25, wide ? 52 : 16, wide ? 46 : 25, 30),
      child: Center(child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 410),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const _KarliveryBrand(),
          SizedBox(height: wide ? 88 : 36),
          child,
          const SizedBox(height: 42),
          const Text('MADE FOR THE WAY YOU EAT.', textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12, color: Color(0xFFAAA5A0), fontWeight: FontWeight.w600, letterSpacing: 1.2)),
        ]),
      )),
    );
    return Scaffold(backgroundColor: bg, resizeToAvoidBottomInset: true,
      body: SafeArea(child: wide ? Row(children: [
        Expanded(child: form),
        Expanded(child: _FoodPanel(isRegister: isRegister)),
      ]) : form),
    );
  }
}

class _KarliveryBrand extends StatelessWidget {
  const _KarliveryBrand();
  @override
  Widget build(BuildContext context) => Row(children: [
    ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.asset(
      'assets/branding/karlivery_logo.png', width: 48, height: 48, fit: BoxFit.cover,
    )),
    const SizedBox(width: 11),
    const Text('Karlivery', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700,
      letterSpacing: -1.15, color: Color(0xFF211B1A))),
  ]);
}

class _FoodPanel extends StatelessWidget {
  const _FoodPanel({required this.isRegister});
  final bool isRegister;
  @override
  Widget build(BuildContext context) => Stack(fit: StackFit.expand, children: [
    Image.asset('assets/pasabuy/original/gallery_01.png', fit: BoxFit.cover,
      errorBuilder: (context, error, stack) => const ColoredBox(color: Color(0xFF442A21))),
    const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(
      begin: Alignment.topCenter, end: Alignment.bottomCenter,
      colors: [Color(0x44000000), Color(0x11000000), Color(0xCC000000)],
    ))),
    Padding(padding: const EdgeInsets.all(48), child: Column(
      crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('LOCAL FOOD, BETTER TOGETHER', style: TextStyle(
          color: Colors.white, fontSize: 12, letterSpacing: 1.4, fontWeight: FontWeight.w700)),
        const Spacer(),
        Text(isRegister ? 'Your favorites.\nOne place.' : 'Good food.\nGreat days.',
          style: const TextStyle(color: Colors.white, fontSize: 54, fontWeight: FontWeight.w700,
            height: 1.08, letterSpacing: -2)),
        const SizedBox(height: 15),
        const Text('Made for the cravings and communities around you.',
          style: TextStyle(color: Color(0xFFF7F3ED), fontSize: 15)),
      ],
    )),
  ]);
}

class StudioFormCard extends StatelessWidget {
  const StudioFormCard({super.key, required this.child});
  final Widget child;
  @override
  Widget build(BuildContext context) {
    const red = Color(0xFFE21A38);
    const border = Color(0xFFE8E2DC);
    return Theme(data: Theme.of(context).copyWith(
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 17, vertical: 17),
        labelStyle: const TextStyle(color: Color(0xFF6B625E), fontSize: 13),
        hintStyle: const TextStyle(color: Color(0xFFA6A09C), fontSize: 14),
        prefixIconColor: const Color(0xFF9C9591),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: const BorderSide(color: border)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: const BorderSide(color: border)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: const BorderSide(color: red, width: 1.5)),
      ),
      filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(
        backgroundColor: red, foregroundColor: Colors.white,
        minimumSize: const Size.fromHeight(56),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
        textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
      )),
      outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(
        minimumSize: const Size.fromHeight(54),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
        side: const BorderSide(color: border), foregroundColor: const Color(0xFF2C2523),
      )),
      textButtonTheme: TextButtonThemeData(style: TextButton.styleFrom(foregroundColor: red)),
    ), child: child);
  }
}
