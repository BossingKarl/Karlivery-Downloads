import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/brand.dart';
import '../../core/camiling_barangays.dart';
import '../../core/modern_ui.dart';
import '../../core/role_panels.dart';
import '../../core/nova_headline.dart';
import '../../core/utils.dart';
import '../../services/backend.dart';
import '../../services/location_service.dart';
import '../../services/store_schedule.dart';
import '../../services/seller_report_service.dart';
import '../../services/theme_controller.dart';
import '../../theme/app_theme.dart';
import '../shared/notification_center_screen.dart';
import '../shared/change_password_dialog.dart';
import 'store_location_screen.dart';
import 'product_editor_dialog.dart';
import '../../design_system/k_network_image.dart';

class StoreDashboard extends StatefulWidget {
  const StoreDashboard({super.key});

  @override
  State<StoreDashboard> createState() => _StoreDashboardState();
}

class _StoreDashboardState extends State<StoreDashboard> {
  Map<String, dynamic>? store;
  List<Map<String, dynamic>> products = [];
  List<Map<String, dynamic>> payments = [];
  List<Map<String, dynamic>> orders = [];
  List<Map<String, dynamic>> history = [];
  List<Map<String, dynamic>> gallery = [];

  bool loading = true;
  String? loadError;
  int tab = 0;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    if (mounted) {
      setState(() {
        loading = true;
        loadError = null;
      });
    }

    try {
      store = await Backend.myStore();

      if (store != null) {
        final id = store!['id'].toString();
        final result = await Future.wait([
          Backend.ownerProducts(id),
          Backend.paymentReviews(id),
          Backend.storeOrders(id),
          Backend.storeOrderHistory(id),
          Backend.storeGallery(id),
        ]);
        products = result[0];
        payments = result[1];
        orders = result[2];
        history = result[3];
        gallery = result[4];
      }
    } catch (_) {
      loadError = 'Your seller workspace could not refresh. Check the connection and try again.';
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  bool get gcashReady =>
      (store?['gcash_number'] ?? '').toString().isNotEmpty &&
      (store?['gcash_qr_url'] ?? '').toString().isNotEmpty;

  @override
  Widget build(BuildContext context) {
    final pages = [
      _Overview(
        store: store,
        orders: orders,
        payments: payments,
        products: products,
        history: history,
        onOpenTab: (value) => setState(() => tab = value),
        onDeliveryProvider: (provider) async {
          if (store == null) return;
          await Backend.sellerSetDeliveryProvider(
            storeId: store!['id'].toString(), provider: provider,
          );
          await load();
        },
        onToggle: (v) async {
          if (store == null) return;
          await Backend.toggleStore(store!['id'].toString(), v);
          await load();
        },
      ),
      _Orders(
        orders: orders,
        payments: payments,
        onRefresh: load,
      ),
      _Products(
        products: products,
        onAdd: addProduct,
        onEdit: editProduct,
        onAddAddon: addAddon,
        onFeature: setFeatured,
        onAvailability: setAvailability,
        onDelete: deleteProduct,
      ),
      _History(
        storeName: (store?['name'] ?? 'Karlivery Store').toString(),
        orders: history,
      ),
      _StoreProfile(
        store: store,
        gallery: gallery,
        gcashReady: gcashReady,
        onLogo: uploadLogo,
        onGcash: configureGcash,
        onGallery: addGallery,
        onLocation: saveCurrentStoreLocation,
        onHours: configureOpeningHours,
        onRename: renameStore,
        onDeliveryProvider: (provider) async {
          if (store == null) return;
          await Backend.sellerSetDeliveryProvider(
            storeId: store!['id'].toString(), provider: provider,
          );
          await load();
        },
      ),
    ];

    return KDashboardScaffold(
      appBar: AppBar(
        toolbarHeight: 68,
        titleSpacing: 10,
        title: MediaQuery.sizeOf(context).width < 560
            ? const KarliveryMark(size: 40)
            : const KarliveryWordmark(compact: true),
        actions: MediaQuery.sizeOf(context).width < 560
            ? [
                const NotificationBell(),
                PopupMenuButton<String>(
                  tooltip: 'More',
                  onSelected: (value) async {
                    if (value == 'help') {
                      if (context.mounted) {
                        context.push('/help?role=store_owner');
                      }
                    } else if (value == 'theme') {
                      ThemeController.toggle(context);
                    } else if (value == 'refresh') {
                      await load();
                    } else if (value == 'logout') {
                      await Backend.logout();
                      if (context.mounted) context.go('/login');
                    }
                  },
                  itemBuilder: (_) => [
                    const PopupMenuItem(
                      value: 'help',
                      child: ListTile(
                        leading: Icon(Icons.help_outline_rounded),
                        title: Text('Help'),
                        contentPadding: EdgeInsets.zero,
                      ),
                    ),
                    PopupMenuItem(
                      value: 'theme',
                      child: ListTile(
                        leading: Icon(
                          ThemeController.isDark(context)
                              ? Icons.light_mode_rounded
                              : Icons.dark_mode_rounded,
                        ),
                        title: Text(
                          ThemeController.isDark(context)
                              ? 'Light mode'
                              : 'Dark mode',
                        ),
                        contentPadding: EdgeInsets.zero,
                      ),
                    ),
                    const PopupMenuItem(
                      value: 'refresh',
                      child: ListTile(
                        leading: Icon(Icons.refresh_rounded),
                        title: Text('Refresh'),
                        contentPadding: EdgeInsets.zero,
                      ),
                    ),
                    const PopupMenuDivider(),
                    const PopupMenuItem(
                      value: 'logout',
                      child: ListTile(
                        leading: Icon(Icons.logout_rounded),
                        title: Text('Sign out'),
                        contentPadding: EdgeInsets.zero,
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: 4),
              ]
            : [
                IconButton(
                  tooltip: 'Help',
                  onPressed: () => context.push('/help?role=store_owner'),
                  icon: const Icon(Icons.help_outline_rounded),
                ),
                const NotificationBell(),
                IconButton(
                  tooltip: 'Theme',
                  onPressed: () => ThemeController.toggle(context),
                  icon: Icon(
                    ThemeController.isDark(context)
                        ? Icons.light_mode_rounded
                        : Icons.dark_mode_rounded,
                  ),
                ),
                IconButton(
                  tooltip: 'Refresh',
                  onPressed: load,
                  icon: const Icon(Icons.refresh_rounded),
                ),
                IconButton(
                  tooltip: 'Sign out',
                  onPressed: () async {
                    await Backend.logout();
                    if (context.mounted) context.go('/login');
                  },
                  icon: const Icon(Icons.logout_rounded),
                ),
              ],
      ),
      body: loading
          ? const KLoadingState(message: 'Loading seller workspace…')
          : loadError != null && store == null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 520),
                      child: Card(
                        child: Padding(
                          padding: const EdgeInsets.all(22),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.wifi_off_rounded, size: 44, color: AppTheme.red),
                              const SizedBox(height: 10),
                              const Text('Seller dashboard could not load', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18)),
                              const SizedBox(height: 6),
                              Text(loadError!, textAlign: TextAlign.center),
                              const SizedBox(height: 14),
                              FilledButton.icon(
                                onPressed: load,
                                icon: const Icon(Icons.refresh_rounded),
                                label: const Text('Try again'),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                )
              : Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1200),
                child: store == null
                    ? _CreateStore(onDone: load)
                     : Column(children: [
                        if (loadError != null)
                          MaterialBanner(content: Text(loadError!), actions: [TextButton(onPressed: load, child: const Text('Retry'))]),
                        if (tab == 0)
                          const Padding(
                            padding: EdgeInsets.fromLTRB(16, 12, 16, 4),
                            child: NovaHeadline(
                              eyebrow: 'YOUR STORE DASHBOARD',
                              icon: Icons.storefront_rounded,
                              title: 'Your shop, beautifully organized.',
                              subtitle: 'Orders, your menu and delivery tools in one place.',
                            ),
                          ),
                        Expanded(child: IndexedStack(index: tab, children: pages)),
                      ]),
              ),
            ),
      bottomNavigationBar: store == null
          ? null
          : NavigationBar(
              selectedIndex: tab,
              onDestinationSelected: (v) => setState(() => tab = v),
              destinations: const [
                NavigationDestination(
                  icon: Icon(Icons.dashboard_outlined),
                  selectedIcon: Icon(Icons.dashboard_rounded),
                  label: 'Overview',
                ),
                NavigationDestination(
                  icon: Icon(Icons.receipt_long_outlined),
                  selectedIcon: Icon(Icons.receipt_long_rounded),
                  label: 'Orders',
                ),
                NavigationDestination(
                  icon: Icon(Icons.fastfood_outlined),
                  selectedIcon: Icon(Icons.fastfood_rounded),
                  label: 'Menu',
                ),
                NavigationDestination(
                  icon: Icon(Icons.history_rounded),
                  selectedIcon: Icon(Icons.history_rounded),
                  label: 'History',
                ),
                NavigationDestination(
                  icon: Icon(Icons.storefront_outlined),
                  selectedIcon: Icon(Icons.storefront_rounded),
                  label: 'Store',
                ),
              ],
            ),
    );
  }

  Future<void> uploadLogo() async {
    if (store == null) return;

    final picked = await FilePicker.platform.pickFiles(
      type: FileType.image,
      withData: true,
    );
    if (picked == null || picked.files.isEmpty) return;

    final f = picked.files.single;
    if (f.bytes == null) return;

    final ext =
        f.name.contains('.') ? f.name.split('.').last.toLowerCase() : 'png';

    try {
      final url = await Backend.uploadStoreLogo(
        storeId: store!['id'].toString(),
        bytes: f.bytes!,
        extension: ext,
      );
      await Backend.saveStoreLogo(
        storeId: store!['id'].toString(),
        logoUrl: url,
      );
      await load();
      _message('Store logo updated.');
    } catch (e) {
      _message('Logo upload failed: $e');
    }
  }

  Future<void> renameStore() async {
    if (store == null) return;

    final name = TextEditingController(
      text: (store!['name'] ?? '').toString(),
    );

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: const Text('Change store name'),
          content: TextField(
            controller: name,
            autofocus: true,
            textCapitalization: TextCapitalization.words,
            maxLength: 80,
            onChanged: (_) => setLocal(() {}),
            decoration: const InputDecoration(
              labelText: 'Store name',
              helperText: 'This name is shown to customers across Karlivery.',
              prefixIcon: Icon(Icons.storefront_rounded),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: name.text.trim().length >= 2
                  ? () => Navigator.pop(ctx, true)
                  : null,
              child: const Text('Save name'),
            ),
          ],
        ),
      ),
    );

    if (ok != true) return;

    try {
      await Backend.renameStore(
        storeId: store!['id'].toString(),
        name: name.text,
      );
      await load();
      _message('Store name updated.');
    } catch (e) {
      _message('Could not update store name: $e');
    }
  }

  Future<void> configureGcash() async {
    if (store == null) return;

    final number = TextEditingController(
      text: (store!['gcash_number'] ?? '').toString(),
    );
    Uint8List? bytes;
    String ext = 'png';
    final oldQr = (store!['gcash_qr_url'] ?? '').toString();

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: const Text('GCash settings'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: number,
                  keyboardType: TextInputType.phone,
                  onChanged: (_) => setLocal(() {}),
                  decoration: const InputDecoration(
                    labelText: 'GCash mobile number',
                    prefixIcon: Icon(Icons.phone_iphone_rounded),
                  ),
                ),
                const SizedBox(height: 12),
                if (oldQr.isNotEmpty && bytes == null)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: KNetImage(
                      oldQr,
                      height: 180,
                      fit: BoxFit.contain,
                    ),
                  ),
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed: () async {
                    final picked = await FilePicker.platform.pickFiles(
                      type: FileType.image,
                      withData: true,
                    );
                    if (picked == null || picked.files.isEmpty) return;
                    final f = picked.files.single;
                    bytes = f.bytes;
                    ext = f.name.contains('.')
                        ? f.name.split('.').last.toLowerCase()
                        : 'png';
                    setLocal(() {});
                  },
                  icon: const Icon(Icons.qr_code_2_rounded),
                  label: Text(
                    bytes != null
                        ? 'New QR selected ✓'
                        : oldQr.isNotEmpty
                            ? 'Replace QR'
                            : 'Upload QR',
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: number.text.trim().isEmpty ||
                      (bytes == null && oldQr.isEmpty)
                  ? null
                  : () => Navigator.pop(ctx, true),
              child: const Text('Save GCash'),
            ),
          ],
        ),
      ),
    );

    if (ok != true) return;

    try {
      var qrUrl = oldQr;

      if (bytes != null) {
        qrUrl = await Backend.uploadStoreQr(
          storeId: store!['id'].toString(),
          bytes: bytes!,
          extension: ext,
        );
      }

      await Backend.saveGcash(
        storeId: store!['id'].toString(),
        number: number.text,
        qrUrl: qrUrl,
      );

      await load();
      _message('GCash number and QR saved.');
    } catch (e) {
      _message('GCash save failed: $e');
    }
  }

  Future<void> configureOpeningHours() async {
    if (store == null) return;

    bool enabled = store!['schedule_enabled'] == true;
    List<int> days = store!['opening_days'] is List
        ? List<int>.from(
            (store!['opening_days'] as List)
                .map((e) => int.tryParse(e.toString()) ?? 0)
                .where((e) => e >= 1 && e <= 7),
          )
        : <int>[1, 2, 3, 4, 5, 6, 7];

    TimeOfDay parseTime(dynamic raw, TimeOfDay fallback) {
      final value = (raw ?? '').toString().split('.').first;
      final parts = value.split(':');
      if (parts.length < 2) return fallback;
      final h = int.tryParse(parts[0]);
      final m = int.tryParse(parts[1]);
      if (h == null || m == null) return fallback;
      return TimeOfDay(hour: h, minute: m);
    }

    var opening = parseTime(
      store!['opening_time'],
      const TimeOfDay(hour: 8, minute: 0),
    );
    var closing = parseTime(
      store!['closing_time'],
      const TimeOfDay(hour: 20, minute: 0),
    );

    const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: const Text('Store opening hours'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: enabled,
                  onChanged: (v) => setLocal(() => enabled = v),
                  title: const Text(
                    'Use automatic opening hours',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                  subtitle: const Text(
                    'Karlivery will automatically follow your selected schedule. Enabling this also turns Open Store on; you can still use the manual switch for a temporary close.',
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Open days',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: List.generate(7, (index) {
                    final day = index + 1;
                    return FilterChip(
                      label: Text(labels[index]),
                      selected: days.contains(day),
                      onSelected: (selected) {
                        setLocal(() {
                          if (selected) {
                            if (!days.contains(day)) days.add(day);
                          } else if (days.length > 1) {
                            days.remove(day);
                          }
                          days.sort();
                        });
                      },
                    );
                  }),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          final picked = await showTimePicker(
                            context: ctx,
                            initialTime: opening,
                          );
                          if (picked != null) setLocal(() => opening = picked);
                        },
                        icon: const Icon(Icons.wb_sunny_outlined),
                        label: Text('Opens ${opening.format(ctx)}'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          final picked = await showTimePicker(
                            context: ctx,
                            initialTime: closing,
                          );
                          if (picked != null) setLocal(() => closing = picked);
                        },
                        icon: const Icon(Icons.nightlight_outlined),
                        label: Text('Closes ${closing.format(ctx)}'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Save hours'),
            ),
          ],
        ),
      ),
    );

    if (ok != true) return;

    String sqlTime(TimeOfDay time) =>
        '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}:00';

    try {
      await Backend.saveStoreOpeningHours(
        storeId: store!['id'].toString(),
        enabled: enabled,
        openingTime: sqlTime(opening),
        closingTime: sqlTime(closing),
        days: days,
      );
      await load();
      _message('Opening hours saved.');
    } catch (e) {
      _message('Could not save opening hours: $e');
    }
  }

  Future<void> addGallery() async {
    if (store == null) return;

    final picked = await FilePicker.platform.pickFiles(
      type: FileType.image,
      withData: true,
    );
    if (picked == null || picked.files.isEmpty) return;

    final f = picked.files.single;
    if (f.bytes == null) return;

    final ext =
        f.name.contains('.') ? f.name.split('.').last.toLowerCase() : 'jpg';

    try {
      final url = await Backend.uploadStoreGalleryImage(
        storeId: store!['id'].toString(),
        bytes: f.bytes!,
        extension: ext,
      );
      await Backend.addStoreGalleryImage(
        storeId: store!['id'].toString(),
        imageUrl: url,
      );
      await load();
      _message('Gallery photo uploaded.');
    } catch (e) {
      _message('Gallery upload failed: $e');
    }
  }

  Future<void> saveCurrentStoreLocation() async {
    if (store == null) return;
    final saved = await Navigator.of(context).push<bool>(MaterialPageRoute(
      builder: (_) => StoreLocationScreen(store: Map<String, dynamic>.from(store!)),
    ));
    if (saved == true && mounted) {
      await load();
      if (mounted) _message('Store address and pickup pin updated.');
    }
  }

  Future<void> addProduct() async {
    if (store == null) return;

    final draft = await showProductEditorDialog(context);
    if (draft == null) return;

    try {
      String? imageUrl;
      if (draft.imageBytes != null) {
        imageUrl = await Backend.uploadProductImage(
          storeId: store!['id'].toString(),
          bytes: draft.imageBytes!,
          extension: draft.imageExtension,
        );
      }

      await Backend.addProduct(
        storeId: store!['id'].toString(),
        name: draft.name,
        description: draft.description,
        category: draft.category,
        price: draft.price,
        imageUrl: imageUrl,
        isFeatured: draft.isFeatured,
        isAvailable: draft.isAvailable,
        prepTimeMin: draft.prepTimeMin,
        prepTimeMax: draft.prepTimeMax,
      );

      await load();
      _message('Menu item added with ${prepTimeLabelFromValues(draft.prepTimeMin, draft.prepTimeMax)} preparation time.');
    } catch (e) {
      _message('Could not add product: $e');
    }
  }

  Future<void> editProduct(Map<String, dynamic> product) async {
    if (store == null) return;

    final draft = await showProductEditorDialog(
      context,
      product: product,
    );
    if (draft == null) return;

    try {
      String? replacementImageUrl;
      if (draft.imageBytes != null) {
        replacementImageUrl = await Backend.uploadProductImage(
          storeId: store!['id'].toString(),
          bytes: draft.imageBytes!,
          extension: draft.imageExtension,
        );
      }

      await Backend.updateProduct(
        productId: product['id'].toString(),
        name: draft.name,
        description: draft.description,
        category: draft.category,
        price: draft.price,
        imageUrl: replacementImageUrl,
        isFeatured: draft.isFeatured,
        isAvailable: draft.isAvailable,
        prepTimeMin: draft.prepTimeMin,
        prepTimeMax: draft.prepTimeMax,
      );

      await load();
      _message('Menu item updated.');
    } catch (e) {
      _message('Could not update product: $e');
    }
  }

  Future<void> setAvailability(
    Map<String, dynamic> product,
    bool value,
  ) async {
    try {
      await Backend.setProductAvailability(product['id'].toString(), value);
      await load();
      _message(value ? 'Dish is available again.' : 'Dish marked unavailable.');
    } catch (e) {
      _message('Could not update availability: $e');
    }
  }

  Future<void> addAddon(Map<String, dynamic> product) async {
    final name = TextEditingController();
    final price = TextEditingController();

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Add-on for ${product['name']}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: name,
              decoration: const InputDecoration(
                labelText: 'Add-on name',
                hintText: 'Extra cheese, egg, sauce...',
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: price,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Additional price',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Save add-on'),
          ),
        ],
      ),
    );

    if (ok == true &&
        name.text.trim().isNotEmpty &&
        double.tryParse(price.text) != null) {
      await Backend.addProductAddon(
        productId: product['id'].toString(),
        name: name.text,
        price: double.parse(price.text),
      );
      await load();
      _message('Add-on saved.');
    }
  }

  Future<void> setFeatured(
    Map<String, dynamic> product,
    bool value,
  ) async {
    try {
      await Backend.setProductFeatured(product['id'].toString(), value);
      await load();
    } catch (e) {
      _message('Could not update featured item: $e');
    }
  }

  Future<void> deleteProduct(Map<String, dynamic> product) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete menu item?'),
        content: Text(
          'Delete ${product['name']} from your current menu? '
          'Historical order item names remain in completed orders.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: Colors.redAccent,
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (ok != true) return;

    try {
      await Backend.deleteProduct(product['id'].toString());
      await load();
      _message('Menu item deleted.');
    } catch (e) {
      _message('Delete failed: $e');
    }
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text)),
    );
  }
}

class _Overview extends StatelessWidget {
  final Map<String, dynamic>? store;
  final List<Map<String, dynamic>> orders;
  final List<Map<String, dynamic>> payments;
  final List<Map<String, dynamic>> products;
  final List<Map<String, dynamic>> history;
  final ValueChanged<bool> onToggle;
  final ValueChanged<int> onOpenTab;
  final Future<void> Function(String) onDeliveryProvider;

  const _Overview({
    required this.store,
    required this.orders,
    required this.payments,
    required this.products,
    required this.history,
    required this.onToggle,
    required this.onOpenTab,
    required this.onDeliveryProvider,
  });

  @override
  Widget build(BuildContext context) {
    final completed = history.where(
      (o) => ['completed', 'delivered'].contains(o['status']?.toString()),
    );
    final sales = completed.fold<double>(
      0,
      (sum, o) =>
          sum + (double.tryParse(o['total']?.toString() ?? '') ?? 0),
    );
    final logo = (store?['logo_url'] ?? '').toString();
    final open = StoreSchedule.isOpenNow(store ?? const {});
    final acceptingOrders = store?['is_open'] == true;

    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 110),
      children: [
        KPageHeader(
          eyebrow: 'KARLIVERY / SELLER',
          title: (store?['name'] ?? 'Your store').toString(),
          subtitle: open
              ? 'Every order, menu item and delivery—beautifully in sync.'
              : 'Your store is currently closed. Open it when you are ready to accept orders.',
          icon: Icons.storefront_rounded,
          trailing: ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: Container(
              width: 58,
              height: 58,
              color: Colors.white,
              child: logo.isEmpty
                  ? const Icon(
                      Icons.storefront_rounded,
                      color: AppTheme.red,
                    )
                  : KNetImage(
                      logo,
                      fit: BoxFit.cover,
                      errorBuilder: (_, _, _) => const Icon(
                        Icons.storefront_rounded,
                        color: AppTheme.red,
                      ),
                    ),
            ),
          ),
        ),
        const SizedBox(height: 14),
        KarliveryStoreStatusCard(
          acceptingOrders: acceptingOrders,
          withinHours: open,
          onChanged: onToggle,
        ),
        const SizedBox(height: 14),
        _DeliveryChoiceCard(
          provider: (store?['delivery_provider'] ?? 'karlivery').toString(),
          onChanged: onDeliveryProvider,
        ),
        const SizedBox(height: 14),
        _SellerNextAction(
          store: store,
          products: products,
          payments: payments,
          orders: orders,
          onOpenTab: onOpenTab,
        ),
        const SizedBox(height: 14),
        KMetricGrid(children: [
          KMetricCard(label: 'Active orders', value: '${orders.length}', icon: Icons.receipt_long_outlined),
          KMetricCard(label: 'GCash reviews', value: '${payments.length}', icon: Icons.qr_code_2_rounded, accent: const Color(0xFF1677FF)),
          KMetricCard(label: 'Menu items', value: '${products.length}', icon: Icons.restaurant_menu_rounded),
          KMetricCard(label: 'Completed value', value: money(sales), icon: Icons.payments_outlined, accent: const Color(0xFF087E93)),
        ]),
        const SizedBox(height: 22),
        const KSectionTitle(
          title: 'Storefront checklist',
          subtitle: 'These details make your restaurant look complete on the customer app.',
        ),
        const SizedBox(height: 10),
        Card(
          child: Column(
            children: [
              _ChecklistRow(
                icon: Icons.image_rounded,
                title: 'Store logo',
                ready: logo.isNotEmpty,
                hint: 'Upload a square logo in the Store tab.',
              ),
              const Divider(height: 1),
              _ChecklistRow(
                icon: Icons.fastfood_rounded,
                title: 'Menu items',
                ready: products.isNotEmpty,
                hint: 'Add product photos, prices and featured items.',
              ),
              const Divider(height: 1),
              _ChecklistRow(
                icon: Icons.qr_code_2_rounded,
                title: 'GCash setup',
                ready: (store?['gcash_number'] ?? '').toString().isNotEmpty,
                hint: 'COD stays available even without GCash.',
              ),
              const Divider(height: 1),
              _ChecklistRow(
                icon: Icons.location_on_rounded,
                title: 'Delivery pin',
                ready: store?['latitude'] != null && store?['longitude'] != null,
                hint: 'Help riders find your pickup entrance.',
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _SellerNextAction extends StatelessWidget {
  final Map<String, dynamic>? store;
  final List<Map<String, dynamic>> products;
  final List<Map<String, dynamic>> payments;
  final List<Map<String, dynamic>> orders;
  final ValueChanged<int> onOpenTab;

  const _SellerNextAction({
    required this.store,
    required this.products,
    required this.payments,
    required this.orders,
    required this.onOpenTab,
  });

  @override
  Widget build(BuildContext context) {
    late final IconData icon;
    late final String title;
    late final String message;
    late final String action;
    late final int tab;

    if (payments.isNotEmpty) {
      icon = Icons.qr_code_2_rounded;
      title = '${payments.length} GCash payment${payments.length == 1 ? '' : 's'} waiting';
      message = 'Review payment proof first so valid orders can move forward without delay.';
      action = 'Review payments';
      tab = 1;
    } else if (orders.isNotEmpty) {
      icon = Icons.receipt_long_rounded;
      title = '${orders.length} active order${orders.length == 1 ? '' : 's'} need attention';
      message = 'Keep order statuses updated so customers and riders always know what happens next.';
      action = 'Open orders';
      tab = 1;
    } else if (products.isEmpty) {
      icon = Icons.add_circle_rounded;
      title = 'Add your first menu item';
      message = 'Customers need at least one available product before they can build an order.';
      action = 'Set up menu';
      tab = 2;
    } else if (store?['latitude'] == null || store?['longitude'] == null) {
      icon = Icons.location_on_rounded;
      title = 'Set your pickup location';
      message = 'Add a street address and a precise map pin so riders can find your store.';
      action = 'Store setup';
      tab = 4;
    } else {
      icon = Icons.check_circle_rounded;
      title = 'Your storefront is ready';
      message = 'Keep the menu accurate and open the store only when your team can accept new orders.';
      action = 'Review store';
      tab = 4;
    }

    return KarliveryNextStepPanel(
      icon: icon,
      eyebrow: 'NEXT BEST ACTION',
      title: title,
      message: message,
      action: action,
      onPressed: () => onOpenTab(tab),
    );
  }
}

class _ChecklistRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final bool ready;
  final String hint;
  const _ChecklistRow({
    required this.icon,
    required this.title,
    required this.ready,
    required this.hint,
  });

  @override
  Widget build(BuildContext context) => ListTile(
        leading: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: (ready ? const Color(0xFF2E9D63) : AppTheme.red)
                .withValues(alpha: .10),
            borderRadius: BorderRadius.circular(15),
          ),
          child: Icon(
            ready ? Icons.check_rounded : icon,
            color: ready ? const Color(0xFF2E9D63) : AppTheme.red,
          ),
        ),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
        subtitle: Text(hint),
        trailing: KStatusPill(
          text: ready ? 'READY' : 'SET UP',
          color: ready ? const Color(0xFF2E9D63) : Colors.orange,
        ),
      );
}

class _GcashPaymentReviewCard extends StatefulWidget {
  final Map<String, dynamic> order;
  final Future<void> Function() onRefresh;

  const _GcashPaymentReviewCard({
    required this.order,
    required this.onRefresh,
  });

  @override
  State<_GcashPaymentReviewCard> createState() =>
      _GcashPaymentReviewCardState();
}

class _GcashPaymentReviewCardState extends State<_GcashPaymentReviewCard> {
  bool busy = false;

  Future<void> showProof() async {
    final path = (widget.order['payment_proof_path'] ?? '').toString();
    if (path.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No payment screenshot was uploaded.')),
      );
      return;
    }

    try {
      final url = await Backend.signedPaymentProof(path);
      if (!mounted || url == null) return;
      await showDialog<void>(
        context: context,
        builder: (ctx) => Dialog(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 620, maxHeight: 720),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'GCash payment proof',
                          style: TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ),
                      IconButton(
                        onPressed: () => Navigator.pop(ctx),
                        icon: const Icon(Icons.close_rounded),
                      ),
                    ],
                  ),
                  Flexible(
                    child: InteractiveViewer(
                      child: KNetImage(
                        url,
                        fit: BoxFit.contain,
                        errorBuilder: (_, _, _) => const Padding(
                          padding: EdgeInsets.all(24),
                          child: Text('Could not load the payment proof.'),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not open payment proof: $e')),
      );
    }
  }

  Future<void> confirmReceived() async {
    if (busy) return;
    setState(() => busy = true);
    try {
      await Backend.sellerConfirmGcashReceived(widget.order['id'].toString());
      await widget.onRefresh();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('GCash payment marked as received.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not confirm payment: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> rejectPayment() async {
    final reason = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Payment needs attention'),
        content: TextField(
          controller: reason,
          maxLines: 3,
          decoration: const InputDecoration(
            labelText: 'Message to customer',
            hintText: 'Example: Reference number does not match.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Send back'),
          ),
        ],
      ),
    );
    if (ok != true) return;

    setState(() => busy = true);
    try {
      await Backend.sellerRejectGcashPayment(
        widget.order['id'].toString(),
        reason: reason.text.trim().isEmpty
            ? 'Please check the payment reference or proof and try again.'
            : reason.text.trim(),
      );
      await widget.onRefresh();
    } finally {
      reason.dispose();
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final o = widget.order;
    final customerSent = o['customer_gcash_sent_at'] != null;
    final sellerReceived = o['seller_gcash_received_at'] != null;

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    (o['order_no'] ?? 'Order').toString(),
                    style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 16,
                    ),
                  ),
                ),
                Text(
                  money(num.tryParse(o['total']?.toString() ?? '0')),
                  style: const TextStyle(
                    color: AppTheme.red,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text('GCash ref: ${o['payment_reference_no'] ?? '-'}'),
            const SizedBox(height: 10),
            Wrap(
              spacing: 7,
              runSpacing: 7,
              children: [
                KStatusPill(
                  text: customerSent ? 'CUSTOMER SENT' : 'WAITING FOR SENT CONFIRMATION',
                  color: customerSent ? const Color(0xFF2E9D63) : Colors.orange,
                  icon: customerSent
                      ? Icons.check_circle_rounded
                      : Icons.schedule_rounded,
                ),
                KStatusPill(
                  text: sellerReceived ? 'RECEIVED' : 'SELLER TO VERIFY',
                  color: sellerReceived ? const Color(0xFF2E9D63) : AppTheme.red,
                  icon: sellerReceived
                      ? Icons.verified_rounded
                      : Icons.fact_check_rounded,
                ),
              ],
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                OutlinedButton.icon(
                  onPressed: showProof,
                  icon: const Icon(Icons.image_rounded),
                  label: const Text('View proof'),
                ),
                OutlinedButton.icon(
                  onPressed: () => context.push('/chat/${o['id']}'),
                  icon: const Icon(Icons.chat_bubble_rounded),
                  label: const Text('Chat customer'),
                ),
                FilledButton.icon(
                  onPressed: busy || !customerSent ? null : confirmReceived,
                  icon: const Icon(Icons.verified_rounded),
                  label: const Text('Payment received'),
                ),
                TextButton(
                  onPressed: busy || !customerSent ? null : rejectPayment,
                  child: const Text('Needs attention'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _StoreActiveOrderCard extends StatefulWidget {
  final Map<String, dynamic> order;
  final Future<void> Function() onRefresh;
  final List<PopupMenuEntry<String>> statusActions;

  const _StoreActiveOrderCard({
    required this.order,
    required this.onRefresh,
    required this.statusActions,
  });

  @override
  State<_StoreActiveOrderCard> createState() => _StoreActiveOrderCardState();
}

class _StoreActiveOrderCardState extends State<_StoreActiveOrderCard> {
  bool busy = false;

  bool get _needsRiderFeeSettlement {
    final o = widget.order;
    return o['delivery_provider'] != 'seller' &&
        (o['payment_method'] ?? '').toString().toLowerCase() == 'gcash' &&
        (o['fulfillment'] ?? '').toString().toLowerCase() == 'delivery' &&
        (double.tryParse(o['delivery_fee']?.toString() ?? '') ?? 0) > 0;
  }

  Future<void> _markSent() async {
    final reference = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Release rider delivery fee'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'The delivery fee belongs to the assigned rider. Mark this only after you actually sent ₱${(double.tryParse(widget.order['delivery_fee']?.toString() ?? '') ?? 0).toStringAsFixed(0)} to the rider.',
            ),
            const SizedBox(height: 12),
            TextField(
              controller: reference,
              decoration: const InputDecoration(
                labelText: 'GCash/reference number (optional)',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('I sent the rider fee')),
        ],
      ),
    );
    if (ok != true) {
      reference.dispose();
      return;
    }
    setState(() => busy = true);
    try {
      await Backend.sellerMarkRiderFeeSent(
        widget.order['id'].toString(),
        reference: reference.text,
      );
      await widget.onRefresh();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Rider delivery fee marked as sent. Rider must still confirm receipt.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not mark rider fee sent: $e')),
        );
      }
    } finally {
      reference.dispose();
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final o = widget.order;
    final settlement = (o['rider_fee_settlement_status'] ?? 'not_applicable').toString();
    final fee = double.tryParse(o['delivery_fee']?.toString() ?? '') ?? 0;
    final riderAssigned = o['rider_id'] != null;

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Column(
        children: [
          ListTile(
            title: Text(
              (o['order_no'] ?? '').toString(),
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
            subtitle: Text(
              '${niceStatus(o['status'].toString())} • ${money(num.tryParse(o['total']?.toString() ?? '0'))}\n'
              '${o['utensils'] == true ? 'With utensils' : 'No utensils'}',
            ),
            isThreeLine: true,
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  tooltip: 'Order chat',
                  onPressed: () => context.push('/chat/${o['id']}'),
                  icon: const Icon(Icons.chat_bubble_outline_rounded),
                ),
                PopupMenuButton<String>(
                  onSelected: (status) async {
                    await Backend.storeStatus(o['id'].toString(), status);
                    await widget.onRefresh();
                  },
                  itemBuilder: (_) => widget.statusActions,
                ),
              ],
            ),
          ),
          if (o['delivery_provider'] == 'seller' &&
              o['fulfillment'] == 'delivery')
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
              child: Row(children: [
                const Icon(Icons.local_shipping_rounded, color: AppTheme.red, size: 19),
                const SizedBox(width: 8),
                const Expanded(child: Text(
                  'Your own rider handles this delivery. The customer pays the standard Karlivery distance-based delivery rate.',
                  style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700),
                )),
              ]),
            ),
          if (_needsRiderFeeSettlement)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: settlement == 'received'
                    ? const Color(0xFFE8F7EF)
                    : AppTheme.softYellow,
                borderRadius: BorderRadius.circular(18),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(
                        settlement == 'received' ? Icons.verified_rounded : Icons.delivery_dining_rounded,
                        color: settlement == 'received' ? const Color(0xFF2E9D63) : AppTheme.deepRed,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          settlement == 'received'
                              ? 'Rider confirmed ₱${fee.toStringAsFixed(0)} delivery fee received'
                              : settlement == 'sent'
                                  ? '₱${fee.toStringAsFixed(0)} marked sent — waiting for rider confirmation'
                                  : riderAssigned
                                      ? '₱${fee.toStringAsFixed(0)} delivery fee is due to the assigned rider'
                                      : 'Reserve ₱${fee.toStringAsFixed(0)} delivery fee for the rider',
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ),
                    ],
                  ),
                  if (settlement != 'received') ...[
                    const SizedBox(height: 6),
                    const Text(
                      'For GCash delivery orders, the store receives the customer payment but the delivery fee belongs to the rider. Karlivery records both seller SENT and rider RECEIVED confirmations.',
                      style: TextStyle(fontSize: 12.5),
                    ),
                    if (riderAssigned && settlement != 'sent') ...[
                      const SizedBox(height: 10),
                      FilledButton.tonalIcon(
                        onPressed: busy ? null : _markSent,
                        icon: const Icon(Icons.payments_outlined),
                        label: const Text('Mark rider fee sent'),
                      ),
                    ],
                  ],
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _Orders extends StatelessWidget {
  final List<Map<String, dynamic>> orders;
  final List<Map<String, dynamic>> payments;
  final Future<void> Function() onRefresh;

  const _Orders({
    required this.orders,
    required this.payments,
    required this.onRefresh,
  });

  @override
  Widget build(BuildContext context) => RefreshIndicator(
        onRefresh: onRefresh,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 110),
          children: [
            const PageTitle(
              'Active orders',
              subtitle:
                  'GCash verification and orders that still need store action.',
            ),
            const SizedBox(height: 16),
            if (payments.isNotEmpty) ...[
              const Text(
                'GCash verification',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 17,
                ),
              ),
              const SizedBox(height: 8),
              ...payments.map(
                (o) => _GcashPaymentReviewCard(
                  order: o,
                  onRefresh: onRefresh,
                ),
              ),
              const SizedBox(height: 18),
            ],
            const Text(
              'Store workflow',
              style: TextStyle(
                fontWeight: FontWeight.w700,
                fontSize: 17,
              ),
            ),
            const SizedBox(height: 8),
            if (orders.isEmpty)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(24),
                  child: Text('No active orders.'),
                ),
              )
            else
              ...orders.map(
                (o) => _StoreActiveOrderCard(
                  order: o,
                  onRefresh: onRefresh,
                  statusActions: _statusActions(o),
                ),
              ),
          ],
        ),
      );

  List<PopupMenuEntry<String>> _statusActions(Map<String, dynamic> o) {
    final status = o['status'].toString();

    if (status == 'paid') {
      return const [
        PopupMenuItem(
          value: 'accepted',
          child: Text('Accept order'),
        ),
        PopupMenuItem(
          value: 'rejected',
          child: Text('Reject order'),
        ),
      ];
    }

    if (status == 'accepted') {
      return const [
        PopupMenuItem(
          value: 'preparing',
          child: Text('Start preparing'),
        ),
      ];
    }

    if (status == 'preparing' && o['fulfillment'] == 'delivery') {
      return [
        PopupMenuItem(
          value: 'ready',
          child: Text(o['delivery_provider'] == 'seller'
              ? 'Ready for your rider' : 'Ready for Karlivery rider'),
        ),
      ];
    }

    if (o['delivery_provider'] == 'seller' && o['fulfillment'] == 'delivery') {
      if (status == 'ready') {
        return const [PopupMenuItem(
          value: 'delivering', child: Text('Own rider is on the way'),
        )];
      }
      if (status == 'delivering') {
        return const [PopupMenuItem(
          value: 'delivered', child: Text('Confirm delivered'),
        )];
      }
    }

    if (status == 'preparing' && o['fulfillment'] == 'pickup') {
      return const [
        PopupMenuItem(
          value: 'ready_for_pickup',
          child: Text('Ready for pickup'),
        ),
      ];
    }

    if (status == 'ready_for_pickup') {
      return const [
        PopupMenuItem(
          value: 'completed',
          child: Text('Customer picked up'),
        ),
      ];
    }

    return const [];
  }
}

class _Products extends StatelessWidget {
  final List<Map<String, dynamic>> products;
  final Future<void> Function() onAdd;
  final Future<void> Function(Map<String, dynamic>) onEdit;
  final Future<void> Function(Map<String, dynamic>) onAddAddon;
  final Future<void> Function(Map<String, dynamic>, bool) onFeature;
  final Future<void> Function(Map<String, dynamic>, bool) onAvailability;
  final Future<void> Function(Map<String, dynamic>) onDelete;

  const _Products({
    required this.products,
    required this.onAdd,
    required this.onEdit,
    required this.onAddAddon,
    required this.onFeature,
    required this.onAvailability,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final available = products.where((p) => p['is_available'] != false).length;
    final featured = products.where((p) => p['is_featured'] == true).length;
    final categories = products
        .map((p) => (p['category'] ?? 'Food').toString().trim())
        .where((value) => value.isNotEmpty)
        .toSet()
        .length;

    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 110),
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Expanded(
              child: PageTitle(
                'Menu manager',
                subtitle:
                    'Build your catalog, set dish preparation time and control availability.',
              ),
            ),
            const SizedBox(width: 10),
            FilledButton.icon(
              onPressed: onAdd,
              icon: const Icon(Icons.add_rounded),
              label: const Text('New item'),
            ),
          ],
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: AppTheme.softYellow,
            borderRadius: BorderRadius.circular(22),
          ),
          child: const Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(Icons.lightbulb_rounded, color: AppTheme.deepRed),
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Tip: set a realistic preparation range for every dish. Customers see it before ordering, while you can quickly mark an item unavailable when it sells out.',
                  style: TextStyle(
                    color: AppTheme.deepRed,
                    fontWeight: FontWeight.w600,
                    height: 1.35,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            _MenuMetric(
              icon: Icons.restaurant_menu_rounded,
              value: '${products.length}',
              label: 'Menu items',
            ),
            _MenuMetric(
              icon: Icons.check_circle_outline_rounded,
              value: '$available',
              label: 'Available',
            ),
            _MenuMetric(
              icon: Icons.local_fire_department_outlined,
              value: '$featured',
              label: 'Featured',
            ),
            _MenuMetric(
              icon: Icons.category_outlined,
              value: '$categories',
              label: 'Categories',
            ),
          ],
        ),
        const SizedBox(height: 18),
        if (products.isEmpty)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(26),
              child: Column(
                children: [
                  const Icon(
                    Icons.restaurant_menu_rounded,
                    size: 46,
                    color: AppTheme.red,
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'Your menu is empty',
                    style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18),
                  ),
                  const SizedBox(height: 5),
                  const Text(
                    'Create your first dish with a photo, price, category and preparation time.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppTheme.muted),
                  ),
                  const SizedBox(height: 14),
                  FilledButton.icon(
                    onPressed: onAdd,
                    icon: const Icon(Icons.add_rounded),
                    label: const Text('Create first item'),
                  ),
                ],
              ),
            ),
          )
        else
          ...products.map(
            (p) => Padding(
              padding: const EdgeInsets.only(bottom: 11),
              child: _SellerMenuItemCard(
                product: p,
                onEdit: () => onEdit(p),
                onAddAddon: () => onAddAddon(p),
                onFeature: () => onFeature(p, p['is_featured'] != true),
                onAvailability: () =>
                    onAvailability(p, p['is_available'] == false),
                onDelete: () => onDelete(p),
              ),
            ),
          ),
      ],
    );
  }
}

class _MenuMetric extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;

  const _MenuMetric({
    required this.icon,
    required this.value,
    required this.label,
  });

  @override
  Widget build(BuildContext context) => Container(
        constraints: const BoxConstraints(minWidth: 138),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: AppTheme.red, size: 20),
            const SizedBox(width: 9),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 17,
                  ),
                ),
                Text(
                  label,
                  style: const TextStyle(
                    color: AppTheme.muted,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ],
        ),
      );
}

class _SellerMenuItemCard extends StatelessWidget {
  final Map<String, dynamic> product;
  final VoidCallback onEdit;
  final VoidCallback onAddAddon;
  final VoidCallback onFeature;
  final VoidCallback onAvailability;
  final VoidCallback onDelete;

  const _SellerMenuItemCard({
    required this.product,
    required this.onEdit,
    required this.onAddAddon,
    required this.onFeature,
    required this.onAvailability,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final image = (product['image_url'] ?? '').toString();
    final available = product['is_available'] != false;
    final addons = product['product_addons'] is List
        ? (product['product_addons'] as List).length
        : 0;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: SizedBox(
                width: 82,
                height: 82,
                child: image.isEmpty
                    ? ColoredBox(
                        color: AppTheme.softYellow,
                        child: const Icon(
                          Icons.fastfood_rounded,
                          color: AppTheme.red,
                        ),
                      )
                    : KNetImage(
                        image,
                        fit: BoxFit.cover,
                        errorBuilder: (_, _, _) => ColoredBox(
                          color: AppTheme.softYellow,
                          child: const Icon(
                            Icons.fastfood_rounded,
                            color: AppTheme.red,
                          ),
                        ),
                      ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          (product['name'] ?? 'Menu item').toString(),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 15.5,
                          ),
                        ),
                      ),
                      if (product['is_featured'] == true)
                        const Padding(
                          padding: EdgeInsets.only(left: 6),
                          child: Icon(
                            Icons.local_fire_department_rounded,
                            color: AppTheme.red,
                            size: 19,
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 3),
                  Text(
                    '${product['category'] ?? 'Food'} • ${money(num.tryParse(product['price']?.toString() ?? '0'))}',
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  if ((product['description'] ?? '').toString().trim().isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Text(
                      product['description'].toString(),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppTheme.muted,
                        fontSize: 12,
                      ),
                    ),
                  ],
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      _MenuInfoPill(
                        icon: Icons.schedule_rounded,
                        text: prepTimeLabel(product),
                      ),
                      _MenuInfoPill(
                        icon: Icons.tune_rounded,
                        text: '$addons add-on${addons == 1 ? '' : 's'}',
                      ),
                      _MenuInfoPill(
                        icon: available
                            ? Icons.check_circle_rounded
                            : Icons.pause_circle_outline_rounded,
                        text: available ? 'Available' : 'Sold out',
                        emphasized: !available,
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 4),
            PopupMenuButton<String>(
              tooltip: 'Menu item actions',
              onSelected: (value) {
                if (value == 'edit') onEdit();
                if (value == 'addon') onAddAddon();
                if (value == 'availability') onAvailability();
                if (value == 'feature') onFeature();
                if (value == 'delete') onDelete();
              },
              itemBuilder: (_) => [
                const PopupMenuItem(
                  value: 'edit',
                  child: ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(Icons.edit_outlined),
                    title: Text('Edit item'),
                  ),
                ),
                const PopupMenuItem(
                  value: 'addon',
                  child: ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(Icons.add_circle_outline_rounded),
                    title: Text('Add add-on'),
                  ),
                ),
                PopupMenuItem(
                  value: 'availability',
                  child: ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(
                      available
                          ? Icons.pause_circle_outline_rounded
                          : Icons.check_circle_outline_rounded,
                    ),
                    title: Text(
                      available ? 'Mark sold out' : 'Mark available',
                    ),
                  ),
                ),
                PopupMenuItem(
                  value: 'feature',
                  child: ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.local_fire_department_outlined),
                    title: Text(
                      product['is_featured'] == true
                          ? 'Remove highlight'
                          : 'Highlight item',
                    ),
                  ),
                ),
                const PopupMenuDivider(),
                const PopupMenuItem(
                  value: 'delete',
                  child: ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(Icons.delete_outline_rounded, color: Colors.redAccent),
                    title: Text(
                      'Delete product',
                      style: TextStyle(color: Colors.redAccent),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _MenuInfoPill extends StatelessWidget {
  final IconData icon;
  final String text;
  final bool emphasized;

  const _MenuInfoPill({
    required this.icon,
    required this.text,
    this.emphasized = false,
  });

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
        decoration: BoxDecoration(
          color: emphasized
              ? Colors.orange.withValues(alpha: .10)
              : Theme.of(context).colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(999),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 13,
              color: emphasized ? Colors.orange.shade800 : AppTheme.muted,
            ),
            const SizedBox(width: 4),
            Text(
              text,
              style: TextStyle(
                color: emphasized ? Colors.orange.shade900 : AppTheme.muted,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      );
}

class _History extends StatefulWidget {
  final String storeName;
  final List<Map<String, dynamic>> orders;

  const _History({
    required this.storeName,
    required this.orders,
  });

  @override
  State<_History> createState() => _HistoryState();
}

class _HistoryState extends State<_History> {
  String status = 'all';
  String payment = 'all';
  DateTimeRange? range;
  bool exporting = false;

  List<Map<String, dynamic>> get filtered {
    return widget.orders.where((o) {
      if (status != 'all' && o['status']?.toString() != status) {
        return false;
      }

      if (payment != 'all' &&
          o['payment_method']?.toString().toLowerCase() != payment) {
        return false;
      }

      if (range != null) {
        final created = DateTime.tryParse(o['created_at']?.toString() ?? '');
        if (created == null) return false;
        final local = created.toLocal();
        final start = DateTime(
          range!.start.year,
          range!.start.month,
          range!.start.day,
        );
        final end = DateTime(
          range!.end.year,
          range!.end.month,
          range!.end.day,
          23,
          59,
          59,
        );
        if (local.isBefore(start) || local.isAfter(end)) return false;
      }

      return true;
    }).toList();
  }

  Future<void> chooseDate() async {
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2024),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      initialDateRange: range,
    );
    if (picked != null) setState(() => range = picked);
  }

  Future<void> export(String type) async {
    final rows = filtered;
    if (rows.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No filtered rows to export.')),
      );
      return;
    }

    setState(() => exporting = true);

    try {
      bool saved = false;

      if (type == 'csv') {
        saved = await SellerReportService.saveCsv(
          storeName: widget.storeName,
          orders: rows,
        );
      } else if (type == 'excel') {
        saved = await SellerReportService.saveExcel(
          storeName: widget.storeName,
          orders: rows,
        );
      } else {
        saved = await SellerReportService.savePdf(
          storeName: widget.storeName,
          orders: rows,
        );
      }

      if (mounted && saved) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${type.toUpperCase()} report saved.'),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Export failed: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => exporting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final rows = filtered;
    final gross = rows.fold<double>(
      0,
      (sum, o) =>
          sum + (double.tryParse(o['total']?.toString() ?? '') ?? 0),
    );

    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 110),
      children: [
        const PageTitle(
          'Order history',
          subtitle:
              'Filter seller transactions and export CSV, Excel or PDF reports.',
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              children: [
                DropdownButtonFormField<String>(
                  initialValue: status,
                  decoration: const InputDecoration(
                    labelText: 'Order status',
                  ),
                  items: const [
                    DropdownMenuItem(value: 'all', child: Text('All statuses')),
                    DropdownMenuItem(value: 'pending_payment', child: Text('Pending payment')),
                    DropdownMenuItem(value: 'payment_review', child: Text('Payment review')),
                    DropdownMenuItem(value: 'payment_rejected', child: Text('Payment rejected')),
                    DropdownMenuItem(value: 'paid', child: Text('Paid / received')),
                    DropdownMenuItem(value: 'accepted', child: Text('Accepted')),
                    DropdownMenuItem(value: 'preparing', child: Text('Preparing')),
                    DropdownMenuItem(value: 'ready', child: Text('Ready for rider')),
                    DropdownMenuItem(value: 'ready_for_pickup', child: Text('Ready for pickup')),
                    DropdownMenuItem(value: 'assigned', child: Text('Rider assigned')),
                    DropdownMenuItem(value: 'picked_up', child: Text('Picked up')),
                    DropdownMenuItem(value: 'delivering', child: Text('Delivering')),
                    DropdownMenuItem(value: 'delivered', child: Text('Delivered')),
                    DropdownMenuItem(value: 'completed', child: Text('Completed')),
                    DropdownMenuItem(value: 'cancelled', child: Text('Cancelled')),
                    DropdownMenuItem(value: 'rejected', child: Text('Rejected')),
                  ],
                  onChanged: (v) =>
                      setState(() => status = v ?? 'all'),
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  initialValue: payment,
                  decoration: const InputDecoration(
                    labelText: 'Payment method',
                  ),
                  items: const [
                    DropdownMenuItem(value: 'all', child: Text('All payments')),
                    DropdownMenuItem(value: 'cod', child: Text('COD')),
                    DropdownMenuItem(value: 'gcash', child: Text('GCash')),
                  ],
                  onChanged: (v) =>
                      setState(() => payment = v ?? 'all'),
                ),
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed: chooseDate,
                  icon: const Icon(Icons.date_range_rounded),
                  label: Text(
                    range == null
                        ? 'Choose date range'
                        : '${range!.start.month}/${range!.start.day}/${range!.start.year}'
                          ' - '
                          '${range!.end.month}/${range!.end.day}/${range!.end.year}',
                  ),
                ),
                if (range != null)
                  TextButton(
                    onPressed: () => setState(() => range = null),
                    child: const Text('Clear date filter'),
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _HistorySummary(
                label: 'Filtered orders',
                value: '${rows.length}',
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _HistorySummary(
                label: 'Gross value',
                value: money(gross),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            FilledButton.tonalIcon(
              onPressed: exporting ? null : () => export('csv'),
              icon: const Icon(Icons.table_rows_rounded),
              label: const Text('CSV'),
            ),
            FilledButton.tonalIcon(
              onPressed: exporting ? null : () => export('excel'),
              icon: const Icon(Icons.grid_on_rounded),
              label: const Text('Excel'),
            ),
            FilledButton.tonalIcon(
              onPressed: exporting ? null : () => export('pdf'),
              icon: const Icon(Icons.picture_as_pdf_rounded),
              label: const Text('PDF'),
            ),
          ],
        ),
        const SizedBox(height: 16),
        if (rows.isEmpty)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Text('No orders match these filters.'),
            ),
          )
        else
          ...rows.map(
            (o) => Padding(
              padding: const EdgeInsets.only(bottom: 9),
              child: Card(
                child: ListTile(
                  title: Text(
                    o['order_no'] ?? '',
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  subtitle: Text(
                    '${niceStatus((o['status'] ?? '').toString())} • '
                    '${(o['payment_method'] ?? '').toString().toUpperCase()} • '
                    '${niceStatus((o['fulfillment'] ?? '').toString())}',
                  ),
                  trailing: Text(
                    money(num.tryParse(o['total']?.toString() ?? '0')),
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class _HistorySummary extends StatelessWidget {
  final String label;
  final String value;

  const _HistorySummary({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Text(
                value,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Text(label, textAlign: TextAlign.center),
            ],
          ),
        ),
      );
}

/// A dedicated and reversible seller preference. Affects future orders only.
class _DeliveryChoiceCard extends StatefulWidget {
  final String provider;
  final Future<void> Function(String) onChanged;
  const _DeliveryChoiceCard({required this.provider, required this.onChanged});

  @override
  State<_DeliveryChoiceCard> createState() => _DeliveryChoiceCardState();
}

class _DeliveryChoiceCardState extends State<_DeliveryChoiceCard> {
  bool saving = false;

  Future<void> choose(String provider) async {
    if (provider == widget.provider || saving) return;
    setState(() => saving = true);
    try {
      await widget.onChanged(provider);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Delivery preference saved for new orders.')),
        );
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not save delivery preference: $error')),
        );
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final own = widget.provider == 'seller';
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Row(children: [
            Icon(Icons.local_shipping_rounded, color: AppTheme.red),
            SizedBox(width: 10),
            Expanded(child: Text('Who delivers your orders?',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700))),
          ]),
          const SizedBox(height: 7),
          Text(own
            ? 'Your own rider handles new delivery orders.'
            : 'Karlivery riders can accept your new delivery orders.'),
          const SizedBox(height: 14),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'karlivery', icon: Icon(Icons.delivery_dining_rounded), label: Text('Karlivery')),
              ButtonSegment(value: 'seller', icon: Icon(Icons.storefront_rounded), label: Text('Own rider')),
            ],
            selected: {widget.provider == 'seller' ? 'seller' : 'karlivery'},
            onSelectionChanged: saving ? null : (choice) => choose(choice.first),
          ),
          if (saving) const Padding(
            padding: EdgeInsets.only(top: 12),
            child: LinearProgressIndicator(minHeight: 3),
          ),
          const SizedBox(height: 10),
          const Text(
            'Same delivery fee: ₱50 for the first 3 km, +₱15 per started 2 km. '
            'Your choice applies only to future orders; existing rider assignments stay unchanged. '
            'Fee rates follow current admin settings.',
            style: TextStyle(fontSize: 12, height: 1.4),
          ),
        ]),
      ),
    );
  }
}

class _StoreProfile extends StatelessWidget {
  final Map<String, dynamic>? store;
  final List<Map<String, dynamic>> gallery;
  final bool gcashReady;
  final Future<void> Function() onLogo;
  final Future<void> Function() onGcash;
  final Future<void> Function() onGallery;
  final Future<void> Function() onLocation;
  final Future<void> Function() onHours;
  final Future<void> Function() onRename;
  final Future<void> Function(String) onDeliveryProvider;

  const _StoreProfile({
    required this.store,
    required this.gallery,
    required this.gcashReady,
    required this.onLogo,
    required this.onGcash,
    required this.onGallery,
    required this.onLocation,
    required this.onHours,
    required this.onRename,
    required this.onDeliveryProvider,
  });

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 110),
        children: [
          const KPageHeader(
            eyebrow: 'Brand & payments',
            title: 'Store profile',
            subtitle: 'Your store details, pickup location, hours and payment options—all in one place.',
            icon: Icons.storefront_rounded,
          ),
          const SizedBox(height: 16),
          _DeliveryChoiceCard(
            provider: (store?['delivery_provider'] ?? 'karlivery').toString(),
            onChanged: onDeliveryProvider,
          ),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(22),
                    child: SizedBox(
                      width: 86,
                      height: 86,
                      child: (store?['logo_url'] ?? '').toString().isEmpty
                          ? ColoredBox(
                              color: Theme.of(context)
                                  .colorScheme
                                  .primaryContainer,
                              child: const Icon(
                                Icons.storefront_rounded,
                                size: 38,
                              ),
                            )
                          : KNetImage(
                              store!['logo_url'].toString(),
                              fit: BoxFit.cover,
                            ),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          (store?['name'] ?? 'Store').toString(),
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 18,
                          ),
                        ),
                        const SizedBox(height: 4),
                        const Text(
                          'Your logo is shown on customer store cards and inside your shop.',
                        ),
                        const SizedBox(height: 9),
                        FilledButton.tonalIcon(
                          onPressed: onLogo,
                          icon: const Icon(Icons.add_photo_alternate_rounded),
                          label: Text(
                            (store?['logo_url'] ?? '').toString().isEmpty
                                ? 'Upload logo'
                                : 'Change logo',
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.edit_rounded),
              title: const Text(
                'Store name',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
              subtitle: Text((store?['name'] ?? 'Store').toString()),
              trailing: FilledButton.tonal(
                onPressed: onRename,
                child: const Text('Edit'),
              ),
              onTap: onRename,
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.qr_code_rounded),
                  title: const Text(
                    'GCash',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                  subtitle: Text(
                    gcashReady
                        ? '${store?['gcash_number']} • QR saved'
                        : 'Add your GCash number and QR',
                  ),
                  trailing: FilledButton.tonal(
                    onPressed: onGcash,
                    child: Text(gcashReady ? 'Edit' : 'Setup'),
                  ),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.location_on_rounded),
                  title: const Text(
                    'Store location',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                  subtitle: Text(
                    store?['latitude'] == null
                        ? 'Add an address and pickup pin'
                        : '${store?["address_text"] ?? "Saved address"} • ${store?["barangay"] ?? "Camiling"}',
                  ),
                  trailing: FilledButton.tonal(
                    onPressed: onLocation,
                    child: const Text('Edit'),
                  ),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.schedule_rounded),
                  title: const Text(
                    'Opening hours',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                  subtitle: Text(StoreSchedule.scheduleLabel(store ?? const {})),
                  trailing: FilledButton.tonal(
                    onPressed: onHours,
                    child: const Text('Set hours'),
                  ),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.lock_reset_rounded),
                  title: const Text(
                    'Change password',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                  subtitle: const Text(
                    'Verify your current password and set a new one',
                  ),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () => showAccountPasswordDialog(context),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Store gallery',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 18,
                  ),
                ),
              ),
              FilledButton.tonalIcon(
                onPressed: onGallery,
                icon: const Icon(Icons.add_photo_alternate_rounded),
                label: const Text('Upload'),
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (gallery.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(22),
                child: Text(
                  'Upload storefront, food, ambience or promo photos. Customers will see these inside your shop.',
                ),
              ),
            )
          else
            SizedBox(
              height: 145,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: gallery.length,
                separatorBuilder: (_, _) => const SizedBox(width: 10),
                itemBuilder: (_, i) => ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: KNetImage(
                    gallery[i]['image_url'].toString(),
                    width: 220,
                    height: 145,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
        ],
      );
}

class _CreateStore extends StatefulWidget {
  final Future<void> Function() onDone;

  const _CreateStore({required this.onDone});

  @override
  State<_CreateStore> createState() => _CreateStoreState();
}

class _CreateStoreState extends State<_CreateStore> {
  final name = TextEditingController();
  final desc = TextEditingController();
  String? selectedBarangay;
  bool locatingBarangay = false;
  final address = TextEditingController();
  final phone = TextEditingController();

  bool busy = false;

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const PageTitle(
            'Create your store',
            subtitle:
                'Set the basics first, then upload your logo, gallery, GCash QR and menu.',
          ),
          const SizedBox(height: 16),
          TextField(
            controller: name,
            decoration: const InputDecoration(labelText: 'Store name'),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: desc,
            decoration: const InputDecoration(labelText: 'Description'),
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            initialValue: selectedBarangay,
            isExpanded: true,
            decoration: InputDecoration(
              labelText: 'Barangay',
              helperText: 'Choose a Camiling barangay or auto-detect from GPS.',
              suffixIcon: IconButton(
                tooltip: 'Auto-detect barangay',
                onPressed: locatingBarangay
                    ? null
                    : () async {
                        setState(() => locatingBarangay = true);
                        try {
                          final result = await LocationService.currentWithAddress();
                          if (!context.mounted || result == null) return;
                          final matched = CamilingBarangays.match(result.barangay);
                          if (matched != null) {
                            setState(() => selectedBarangay = matched);
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                  result.barangay.isEmpty
                                      ? 'Could not detect the barangay. Please choose it manually.'
                                      : 'Detected ${result.barangay}, but it did not match the Camiling list. Please choose manually.',
                                ),
                              ),
                            );
                          }
                        } finally {
                          if (mounted) setState(() => locatingBarangay = false);
                        }
                      },
                icon: locatingBarangay
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.my_location_rounded),
              ),
            ),
            hint: const Text('Choose barangay'),
            items: CamilingBarangays.values
                .map(
                  (barangay) => DropdownMenuItem(
                    value: barangay,
                    child: Text(barangay),
                  ),
                )
                .toList(),
            onChanged: (value) => setState(() => selectedBarangay = value),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: address,
            decoration: const InputDecoration(labelText: 'Store address'),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: phone,
            decoration: const InputDecoration(labelText: 'Phone'),
          ),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: busy
                ? null
                : () async {
                    if (name.text.trim().isEmpty ||
                        selectedBarangay == null ||
                        address.text.trim().isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text(
                            'Store name, barangay and address are required.',
                          ),
                        ),
                      );
                      return;
                    }

                    setState(() => busy = true);

                    try {
                      await Backend.createStore(
                        name: name.text,
                        description: desc.text,
                        barangay: selectedBarangay!,
                        address: address.text,
                        phone: phone.text,
                      );
                      await widget.onDone();
                    } finally {
                      if (mounted) setState(() => busy = false);
                    }
                  },
            child: Text(busy ? 'Creating...' : 'Create store'),
          ),
        ],
      );
}
