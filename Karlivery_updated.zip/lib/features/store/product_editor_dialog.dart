import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../../core/utils.dart';
import '../../theme/app_theme.dart';
import '../../design_system/k_network_image.dart';

class ProductEditorResult {
  final String name;
  final String description;
  final String category;
  final double price;
  final int prepTimeMin;
  final int prepTimeMax;
  final bool isAvailable;
  final bool isFeatured;
  final Uint8List? imageBytes;
  final String imageExtension;

  const ProductEditorResult({
    required this.name,
    required this.description,
    required this.category,
    required this.price,
    required this.prepTimeMin,
    required this.prepTimeMax,
    required this.isAvailable,
    required this.isFeatured,
    required this.imageBytes,
    required this.imageExtension,
  });
}

Future<ProductEditorResult?> showProductEditorDialog(
  BuildContext context, {
  Map<String, dynamic>? product,
}) async {
  final editing = product != null;
  final name = TextEditingController(text: (product?['name'] ?? '').toString());
  final description = TextEditingController(
    text: (product?['description'] ?? '').toString(),
  );
  final price = TextEditingController(
    text: product == null ? '' : (product['price'] ?? '').toString(),
  );
  final prepMin = TextEditingController(
    text: (product?['prep_time_min'] ?? 10).toString(),
  );
  final prepMax = TextEditingController(
    text: (product?['prep_time_max'] ?? 20).toString(),
  );
  final customCategory = TextEditingController();

  const commonCategories = <String>[
    'Food',
    'Rice Meals',
    'Noodles',
    'Snacks',
    'Drinks',
    'Desserts',
    'Combo Meals',
    'Others',
  ];
  var category = (product?['category'] ?? 'Food').toString().trim();
  if (category.isEmpty) category = 'Food';
  if (category == 'Others') customCategory.text = 'Others';
  final categories = [...commonCategories];
  if (!categories.contains(category)) categories.insert(0, category);

  var isAvailable = product?['is_available'] != false;
  var isFeatured = product?['is_featured'] == true;
  Uint8List? imageBytes;
  var imageExtension = 'jpg';
  final existingImage = (product?['image_url'] ?? '').toString();

  String? validationMessage;

  final result = await showDialog<ProductEditorResult>(
    context: context,
    barrierDismissible: false,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setLocal) {
        void validateAndSave() {
          final parsedPrice = double.tryParse(price.text.trim());
          final min = int.tryParse(prepMin.text.trim());
          final max = int.tryParse(prepMax.text.trim());
          final effectiveCategory = category == 'Others'
              ? customCategory.text.trim()
              : category.trim();

          String? error;
          if (name.text.trim().length < 2) {
            error = 'Enter a menu item name.';
          } else if (effectiveCategory.length < 2) {
            error = 'Enter a category for this dish.';
          } else if (parsedPrice == null || parsedPrice <= 0) {
            error = 'Enter a valid price greater than zero.';
          } else if (min == null || max == null) {
            error = 'Enter a valid preparation time.';
          } else if (min < 1 || min > 240 || max < 1 || max > 360) {
            error = 'Preparation time must be between 1 and 360 minutes.';
          } else if (max < min) {
            error = 'Maximum preparation time cannot be lower than minimum.';
          }

          if (error != null) {
            setLocal(() => validationMessage = error);
            return;
          }

          Navigator.pop(
            ctx,
            ProductEditorResult(
              name: name.text.trim(),
              description: description.text.trim(),
              category: effectiveCategory,
              price: parsedPrice!,
              prepTimeMin: min!,
              prepTimeMax: max!,
              isAvailable: isAvailable,
              isFeatured: isFeatured,
              imageBytes: imageBytes,
              imageExtension: imageExtension,
            ),
          );
        }

        return AlertDialog(
          insetPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 20),
          titlePadding: EdgeInsets.zero,
          contentPadding: const EdgeInsets.fromLTRB(20, 18, 20, 4),
          actionsPadding: const EdgeInsets.fromLTRB(20, 8, 20, 18),
          title: Container(
            padding: const EdgeInsets.fromLTRB(20, 18, 16, 16),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [AppTheme.red, AppTheme.deepRed],
              ),
              borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
            ),
            child: Row(
              children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: .16),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: const Icon(Icons.restaurant_menu_rounded, color: Colors.white),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        editing ? 'Edit menu item' : 'Create menu item',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 20,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        editing
                            ? 'Update the details customers see.'
                            : 'Add complete dish details before publishing.',
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: .82),
                          fontSize: 12.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          content: SizedBox(
            width: 620,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _EditorSectionTitle(
                    icon: Icons.edit_note_rounded,
                    title: 'Dish details',
                    subtitle: 'Use clear names and descriptions customers can understand fast.',
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: name,
                    textCapitalization: TextCapitalization.words,
                    maxLength: 80,
                    decoration: const InputDecoration(
                      labelText: 'Dish name',
                      hintText: 'Example: Chicken Biryani',
                      prefixIcon: Icon(Icons.fastfood_rounded),
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: description,
                    textCapitalization: TextCapitalization.sentences,
                    minLines: 2,
                    maxLines: 4,
                    maxLength: 280,
                    decoration: const InputDecoration(
                      labelText: 'Description',
                      hintText: 'Ingredients, serving notes, flavor or what makes it special.',
                      alignLabelWithHint: true,
                      prefixIcon: Icon(Icons.notes_rounded),
                    ),
                  ),
                  const SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    initialValue: category,
                    items: categories
                        .map((value) => DropdownMenuItem(value: value, child: Text(value)))
                        .toList(),
                    onChanged: (value) => setLocal(() => category = value ?? category),
                    decoration: const InputDecoration(
                      labelText: 'Category',
                      prefixIcon: Icon(Icons.category_outlined),
                    ),
                  ),
                  if (category == 'Others') ...[
                    const SizedBox(height: 10),
                    TextField(
                      controller: customCategory,
                      textCapitalization: TextCapitalization.words,
                      maxLength: 60,
                      decoration: const InputDecoration(
                        labelText: 'Custom category',
                        hintText: 'Example: Milk Tea, Pizza, Silog',
                        prefixIcon: Icon(Icons.create_new_folder_outlined),
                      ),
                    ),
                  ],
                  const SizedBox(height: 16),
                  _EditorSectionTitle(
                    icon: Icons.payments_outlined,
                    title: 'Price & preparation',
                    subtitle: 'Preparation time is shown to customers per dish.',
                  ),
                  const SizedBox(height: 10),
                  LayoutBuilder(
                    builder: (context, constraints) {
                      final narrow = constraints.maxWidth < 520;

                      Widget priceField() => TextField(
                            controller: price,
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                            decoration: const InputDecoration(
                              labelText: 'Price',
                              prefixText: '₱ ',
                              prefixIcon: Icon(Icons.sell_outlined),
                            ),
                          );

                      Widget minField() => TextField(
                            controller: prepMin,
                            keyboardType: TextInputType.number,
                            onChanged: (_) => setLocal(() {}),
                            decoration: const InputDecoration(
                              labelText: 'Prep min',
                              suffixText: 'min',
                              prefixIcon: Icon(Icons.timer_outlined),
                            ),
                          );

                      Widget maxField() => TextField(
                            controller: prepMax,
                            keyboardType: TextInputType.number,
                            onChanged: (_) => setLocal(() {}),
                            decoration: const InputDecoration(
                              labelText: 'Prep max',
                              suffixText: 'min',
                              prefixIcon: Icon(Icons.schedule_rounded),
                            ),
                          );

                      if (narrow) {
                        return Column(
                          children: [
                            priceField(),
                            const SizedBox(height: 10),
                            Row(
                              children: [
                                Expanded(child: minField()),
                                const SizedBox(width: 10),
                                Expanded(child: maxField()),
                              ],
                            ),
                          ],
                        );
                      }

                      return Row(
                        children: [
                          Expanded(child: priceField()),
                          const SizedBox(width: 10),
                          Expanded(child: minField()),
                          const SizedBox(width: 10),
                          Expanded(child: maxField()),
                        ],
                      );
                    },
                  ),
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppTheme.softYellow,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.access_time_filled_rounded, color: AppTheme.deepRed),
                        const SizedBox(width: 9),
                        Expanded(
                          child: Text(
                            'Customer preview: ${prepTimeLabelFromValues(int.tryParse(prepMin.text), int.tryParse(prepMax.text))}',
                            style: const TextStyle(fontWeight: FontWeight.w700, color: AppTheme.deepRed),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  _EditorSectionTitle(
                    icon: Icons.visibility_outlined,
                    title: 'Visibility',
                    subtitle: 'Control whether customers can order or discover this dish.',
                  ),
                  const SizedBox(height: 6),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    value: isAvailable,
                    onChanged: (value) => setLocal(() => isAvailable = value),
                    secondary: Icon(
                      isAvailable ? Icons.check_circle_rounded : Icons.pause_circle_outline_rounded,
                      color: isAvailable ? const Color(0xFF2E9D63) : Colors.orange,
                    ),
                    title: const Text('Available for ordering', style: TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: const Text('Turn this off when the dish is sold out or temporarily unavailable.'),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    value: isFeatured,
                    onChanged: (value) => setLocal(() => isFeatured = value),
                    secondary: const Icon(Icons.local_fire_department_rounded, color: AppTheme.red),
                    title: const Text('Feature this item', style: TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: const Text('Featured items appear prominently on your store and customer home cards.'),
                  ),
                  const SizedBox(height: 12),
                  _EditorSectionTitle(
                    icon: Icons.photo_camera_back_outlined,
                    title: 'Dish photo',
                    subtitle: editing ? 'Keep the current photo or select a replacement.' : 'A clear food photo helps customers choose faster.',
                  ),
                  const SizedBox(height: 10),
                  if (imageBytes != null)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(18),
                      child: Image.memory(imageBytes!, height: 190, fit: BoxFit.cover),
                    )
                  else if (existingImage.isNotEmpty)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(18),
                      child: KNetImage(
                        existingImage,
                        height: 190,
                        fit: BoxFit.cover,
                        errorBuilder: (_, _, _) => const _ImagePlaceholder(),
                      ),
                    )
                  else
                    const _ImagePlaceholder(),
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                    onPressed: () async {
                      final picked = await FilePicker.platform.pickFiles(
                        type: FileType.image,
                        withData: true,
                      );
                      if (picked == null || picked.files.isEmpty) return;
                      final file = picked.files.single;
                      if (file.bytes == null) return;
                      setLocal(() {
                        imageBytes = file.bytes;
                        imageExtension = file.name.contains('.')
                            ? file.name.split('.').last.toLowerCase()
                            : 'jpg';
                      });
                    },
                    icon: const Icon(Icons.add_photo_alternate_outlined),
                    label: Text(
                      imageBytes == null
                          ? (existingImage.isEmpty ? 'Select dish photo' : 'Replace dish photo')
                          : 'Choose another photo',
                    ),
                  ),
                  if (validationMessage != null) ...[
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.red.withValues(alpha: .08),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.error_outline_rounded, color: Colors.redAccent),
                          const SizedBox(width: 8),
                          Expanded(child: Text(validationMessage!, style: const TextStyle(color: Colors.redAccent, fontWeight: FontWeight.w600))),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel'),
            ),
            FilledButton.icon(
              onPressed: validateAndSave,
              icon: Icon(editing ? Icons.save_rounded : Icons.add_rounded),
              label: Text(editing ? 'Save changes' : 'Add to menu'),
            ),
          ],
        );
      },
    ),
  );

  name.dispose();
  description.dispose();
  price.dispose();
  prepMin.dispose();
  prepMax.dispose();
  customCategory.dispose();
  return result;
}

class _EditorSectionTitle extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const _EditorSectionTitle({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) => Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: AppTheme.red.withValues(alpha: .08),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: AppTheme.red, size: 20),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                const SizedBox(height: 2),
                Text(subtitle, style: const TextStyle(color: AppTheme.muted, fontSize: 12, height: 1.3)),
              ],
            ),
          ),
        ],
      );
}

class _ImagePlaceholder extends StatelessWidget {
  const _ImagePlaceholder();

  @override
  Widget build(BuildContext context) => Container(
        height: 150,
        decoration: BoxDecoration(
          color: AppTheme.softYellow,
          borderRadius: BorderRadius.circular(18),
        ),
        child: const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.fastfood_rounded, color: AppTheme.red, size: 42),
              SizedBox(height: 6),
              Text('No dish photo selected', style: TextStyle(fontWeight: FontWeight.w700, color: AppTheme.deepRed)),
            ],
          ),
        ),
      );

}
