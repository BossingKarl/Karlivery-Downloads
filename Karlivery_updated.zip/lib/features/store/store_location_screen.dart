import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import '../../core/camiling_barangays.dart';
import '../../core/modern_ui.dart';
import '../../services/backend.dart';

/// Edits a draft. Nothing is written until the seller explicitly saves.
class StoreLocationScreen extends StatefulWidget {
  final Map<String, dynamic> store;
  const StoreLocationScreen({super.key, required this.store});
  @override
  State<StoreLocationScreen> createState() => _StoreLocationScreenState();
}

class _StoreLocationScreenState extends State<StoreLocationScreen> {
  final _form = GlobalKey<FormState>();
  final _map = MapController();
  late final TextEditingController _address;
  late final TextEditingController _latitude;
  late final TextEditingController _longitude;
  String? _barangay;
  LatLng? _pin;
  bool _saving = false;
  bool _locating = false;
  bool _dirty = false;
  bool _mapReady = false;
  String? _error;
  static const _market = LatLng(15.6861, 120.4123);

  @override
  void initState() {
    super.initState();
    _address = TextEditingController(text: '${widget.store['address_text'] ?? ''}');
    final lat = double.tryParse('${widget.store['latitude']}');
    final lng = double.tryParse('${widget.store['longitude']}');
    if (lat != null && lng != null && lat.isFinite && lng.isFinite &&
        lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
      _pin = LatLng(lat, lng);
    }
    _latitude = TextEditingController(text: _pin?.latitude.toStringAsFixed(6) ?? '');
    _longitude = TextEditingController(text: _pin?.longitude.toStringAsFixed(6) ?? '');
    final saved = '${widget.store['barangay'] ?? ''}';
    _barangay = CamilingBarangays.values.contains(saved) ? saved : null;
  }

  @override
  void dispose() {
    _map.dispose();
    _address.dispose();
    _latitude.dispose();
    _longitude.dispose();
    super.dispose();
  }

  void _setPin(LatLng point, {bool move = false}) {
    setState(() {
      _pin = point;
      _latitude.text = point.latitude.toStringAsFixed(6);
      _longitude.text = point.longitude.toStringAsFixed(6);
      _dirty = true;
      _error = null;
    });
    if (move && _mapReady) _map.move(point, 17);
  }

  bool _applyCoordinates() {
    final lat = double.tryParse(_latitude.text.trim());
    final lng = double.tryParse(_longitude.text.trim());
    if (lat == null || lng == null || !lat.isFinite || !lng.isFinite ||
        lat < -90 || lat > 90 || lng < -180 || lng > 180) {
      setState(() => _error = 'Enter a valid latitude and longitude, or tap the map.');
      return false;
    }
    _setPin(LatLng(lat, lng), move: true);
    return true;
  }

  Future<void> _locate() async {
    setState(() { _locating = true; _error = null; });
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        throw Exception('Turn on device location, or choose the pin on the map.');
      }
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        throw Exception('Location permission is unavailable. You can still select a pin manually.');
      }
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 20)),
      );
      if (!mounted) return;
      _setPin(LatLng(position.latitude, position.longitude), move: true);
    } catch (_) {
      if (mounted) setState(() => _error = 'Could not get your location. Check device permissions or tap the map instead.');
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  Future<void> _leave() async {
    if (_saving) return;
    if (!_dirty) { Navigator.pop(context); return; }
    final discard = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Discard location changes?'),
      content: const Text('Your saved store location has not changed.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Keep editing')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Discard')),
      ],
    ));
    if (discard == true && mounted) Navigator.pop(context);
  }

  Future<void> _save() async {
    if (_saving || _locating || !_form.currentState!.validate()) return;
    if (!_applyCoordinates()) return;
    setState(() { _saving = true; _error = null; });
    try {
      await Backend.updateStoreAddress(
        storeId: widget.store['id'].toString(), address: _address.text.trim(),
        barangay: _barangay!, latitude: _pin!.latitude, longitude: _pin!.longitude,
      );
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      final missing = e.toString().contains('PGRST202');
      setState(() => _error = missing
          ? 'Store location editing is not enabled yet. Ask your administrator to apply update SQL 16, then retry.'
          : 'Your location was not saved. Check your connection and try again.');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: !_dirty && !_saving,
    onPopInvokedWithResult: (didPop, result) { if (!didPop) _leave(); },
    child: Scaffold(
      appBar: AppBar(
        leading: IconButton(tooltip: 'Back', onPressed: _saving ? null : _leave, icon: const Icon(Icons.arrow_back_rounded)),
        title: const Text('Store location'),
      ),
      body: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 900), child: Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.all(20), children: [
          const KPageHeader(eyebrow: 'Your storefront', title: 'Put your store on the map',
            subtitle: 'Help customers find you and riders reach the right pickup point.', icon: Icons.add_location_alt_outlined),
          const SizedBox(height: 20),
          TextFormField(controller: _address, enabled: !_saving, maxLength: 300, maxLines: 2,
            onChanged: (_) => setState(() => _dirty = true),
            decoration: const InputDecoration(labelText: 'Street address / landmark', prefixIcon: Icon(Icons.storefront_outlined)),
            validator: (value) => (value ?? '').trim().length < 5 ? 'Enter your store address (at least 5 characters).' : null),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(initialValue: _barangay, isExpanded: true,
            decoration: const InputDecoration(labelText: 'Barangay • Camiling, Tarlac', prefixIcon: Icon(Icons.location_city_outlined)),
            items: CamilingBarangays.values.map((b) => DropdownMenuItem(value: b, child: Text(b))).toList(),
            onChanged: _saving ? null : (value) => setState(() { _barangay = value; _dirty = true; }),
            validator: (value) => value == null ? 'Select a Camiling barangay.' : null),
          const SizedBox(height: 20),
          const KSectionTitle(title: 'Choose the pickup pin', subtitle: 'Tap the actual storefront on the map. GPS is optional.'),
          const SizedBox(height: 12),
          ClipRRect(borderRadius: BorderRadius.circular(24), child: SizedBox(height: 330, child: FlutterMap(
            mapController: _map,
            options: MapOptions(initialCenter: _pin ?? _market, initialZoom: 15,
              onMapReady: () => _mapReady = true,
              onTap: (_, point) { if (!_saving && !_locating) _setPin(point); }),
            children: [
              TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.karlivery.karl_delivery'),
              MarkerLayer(markers: [if (_pin != null) Marker(point: _pin!, width: 52, height: 52,
                child: Icon(Icons.location_on_rounded, size: 48, color: Theme.of(context).colorScheme.primary))]),
              const RichAttributionWidget(attributions: [TextSourceAttribution('OpenStreetMap contributors')]),
            ],
          ))),
          const SizedBox(height: 12),
          OutlinedButton.icon(onPressed: _saving || _locating ? null : _locate,
            icon: _locating ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.my_location_rounded),
            label: Text(_locating ? 'Finding your location…' : 'Use my current location')),
          const SizedBox(height: 8),
          const Text('Only use device GPS when you are at the store. If the map cannot load, enter coordinates below.'),
          const SizedBox(height: 12),
          Wrap(spacing: 12, runSpacing: 12, children: [
            SizedBox(width: 240, child: TextField(controller: _latitude, enabled: !_saving && !_locating,
              keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
              onChanged: (_) => setState(() => _dirty = true), decoration: const InputDecoration(labelText: 'Latitude'))),
            SizedBox(width: 240, child: TextField(controller: _longitude, enabled: !_saving && !_locating,
              keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
              onChanged: (_) => setState(() => _dirty = true), decoration: const InputDecoration(labelText: 'Longitude'))),
            TextButton(onPressed: _saving || _locating ? null : _applyCoordinates, child: const Text('Preview coordinates')),
          ]),
          const SizedBox(height: 12),
          const Text('Confirm that the address and pin refer to the same store in Camiling. Changes appear after customers and riders refresh their screens.'),
          if (_error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Semantics(liveRegion: true,
            child: Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)))),
          const SizedBox(height: 24),
          FilledButton.icon(onPressed: _saving || _locating ? null : _save,
            icon: _saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.check_rounded),
            label: Text(_saving ? 'Saving location…' : 'Save store location')),
          const SizedBox(height: 24),
        ]),
      ))),
    ),
  );
}
