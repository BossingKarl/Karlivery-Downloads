import 'dart:async';

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'config/app_config.dart';
import 'features/auth/app_router.dart';
import 'core/navigation_loader.dart';
import 'services/location_service.dart';
import 'services/notification_service.dart';
import 'services/theme_controller.dart';
import 'theme/app_theme.dart';
import 'design_system/k_tokens.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Draw a Flutter splash immediately. Slow or failing services can then never
  // leave the user staring at the static HTML loader.
  runApp(const _KarliveryBoot());
}

Future<void>? _supabaseInit;

/// Initializes Supabase once. A retry reuses an in-flight/finished init
/// instead of initializing twice.
Future<void> _initSupabase() {
  return _supabaseInit ??= Supabase.initialize(
    url: AppConfig.supabaseUrl,
    publishableKey: AppConfig.supabasePublishableKey,
  ).then<void>((_) {}).catchError((Object e) {
    _supabaseInit = null;
    throw e;
  });
}

/// Only critical services are awaited. Push/local notification setup happens
/// later, after the first frame.
Future<void> _initCriticalServices() async {
  if (!kIsWeb) {
    try {
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      SystemChrome.setSystemUIOverlayStyle(
        const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          systemNavigationBarColor: Colors.transparent,
          systemNavigationBarDividerColor: Colors.transparent,
        ),
      );
    } catch (e) {
      debugPrint('System UI setup skipped: $e');
    }
  }
  await Future.wait([
    _initSupabase(),
    ThemeController.init(),
  ]).timeout(const Duration(seconds: 12));
}

class _KarliveryBoot extends StatefulWidget {
  const _KarliveryBoot();

  @override
  State<_KarliveryBoot> createState() => _KarliveryBootState();
}

class _KarliveryBootState extends State<_KarliveryBoot> {
  late Future<void> _init = _initCriticalServices();

  void _retry() => setState(() => _init = _initCriticalServices());

  @override
  Widget build(BuildContext context) => FutureBuilder<void>(
        future: _init,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const _KarliveryBootSplash();
          }
          if (snap.hasError) {
            debugPrint('Karlivery startup service error: ${snap.error}');
            return _KarliveryStartupFailure(
              message: '${snap.error}',
              onRetry: _retry,
            );
          }
          return const KarliveryApp();
        },
      );
}

class _KarliveryBootSplash extends StatelessWidget {
  const _KarliveryBootSplash();

  @override
  Widget build(BuildContext context) => const MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          backgroundColor: Color(0xFFFFF9F3),
          body: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Image(
                  image: AssetImage('assets/branding/karlivery_logo.png'),
                  width: 88,
                  height: 88,
                ),
                SizedBox(height: 22),
                SizedBox(
                  width: 26,
                  height: 26,
                  child: CircularProgressIndicator(strokeWidth: 2.6),
                ),
              ],
            ),
          ),
        ),
      );
}

class KarliveryApp extends StatefulWidget {
  const KarliveryApp({super.key});

  @override
  State<KarliveryApp> createState() => _KarliveryAppState();
}

class _KarliveryAppState extends State<KarliveryApp> {
  bool _locationPrompted = false;
  Timer? _locationPromptTimer;
  dynamic _authSub;

  @override
  void initState() {
    super.initState();

    NotificationService.onOpenRoute = (route) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        router.go(route);
      });
    };

    // Initialize notifications only after Flutter has rendered the first frame.
    // This avoids black-screen startup hangs caused by permission/plugin calls
    // before an Android activity is visually ready.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // Give the first route and its Supabase data request priority on mobile.
      // Notifications are important but do not need to compete with startup.
      unawaited(
        Future<void>.delayed(const Duration(milliseconds: 1200)).then(
          (_) => _initializeNotificationsSafely(),
        ),
      );
    });

    try {
      _authSub = Supabase.instance.client.auth.onAuthStateChange.listen((data) {
        if (data.event == AuthChangeEvent.initialSession) return;
        unawaited(NotificationService.startForCurrentUser());
      });
    } catch (e) {
      debugPrint('Auth listener startup error: $e');
    }

    // Location permission is useful only once a customer is browsing/ordering.
    // Never display the permission sheet over login, register, splash or admin
    // authentication screens.
    router.routeInformationProvider.addListener(_handleRouteForLocationPrompt);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _handleRouteForLocationPrompt();
    });
  }

  void _handleRouteForLocationPrompt() {
    if (_locationPrompted || !mounted) return;
    final path = router.routeInformationProvider.value.uri.path;
    if (path != '/browse' && path != '/customer') return;

    _locationPrompted = true;
    _locationPromptTimer?.cancel();
    _locationPromptTimer = Timer(const Duration(milliseconds: 1400), () async {
      if (!mounted) return;
      try {
        await LocationService.showStartupPermissionPrompt(context);
      } catch (e) {
        debugPrint('Location startup prompt error: $e');
      }
    });
  }

  Future<void> _initializeNotificationsSafely() async {
    try {
      await NotificationService.init();
      await NotificationService.startForCurrentUser();
    } catch (e, st) {
      debugPrint('Notification startup error: $e');
      debugPrintStack(stackTrace: st);
    }
  }

  @override
  void dispose() {
    _locationPromptTimer?.cancel();
    router.routeInformationProvider.removeListener(_handleRouteForLocationPrompt);
    _authSub?.cancel();
    unawaited(NotificationService.stop());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: ThemeController.mode,
      builder: (context, mode, _) {
        return MaterialApp.router(
          debugShowCheckedModeBanner: false,
          title: AppConfig.appName,
          theme: AppTheme.light(),
          darkTheme: AppTheme.dark(),
          themeMode: mode,
          routerConfig: router,
          builder: (context, child) => KarliveryNavigationOverlay(
            router: router,
            child: child ?? const SizedBox.shrink(),
          ),
        );
      },
    );
  }
}


/// Rendered only if the critical services could not initialize.
/// Keeps an actionable recovery path instead of silently hanging.
class _KarliveryStartupFailure extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _KarliveryStartupFailure({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Scaffold(
      backgroundColor: const Color(0xFFFFF9F3),
      body: Center(child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 420),
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.wifi_off_rounded, size: 54, color: KPalette.red),
            const SizedBox(height: 16),
            const Text('Karlivery could not start', textAlign: TextAlign.center,
              style: TextStyle(fontSize: 23, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            const Text('Please check your connection and try again. If the problem continues, send the error below to support.',
              textAlign: TextAlign.center),
            const SizedBox(height: 12),
            SelectableText(message, textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 12, color: Colors.black54)),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('Retry startup'),
            ),
          ]),
        ),
      )),
    ),
  );
}
