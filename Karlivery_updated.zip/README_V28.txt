KARLIVERY V28 STUDIO EDITION - Full Flutter source.

Premium visual refresh for customer discovery hero, sign-in and sign-up. Existing authentication logic, Supabase integration, routes and roles retained. Legacy top-level build scripts and docs removed; only current launchers included.

WEB BUILD (Windows): double click BUILD_KARLIVERY_V24_WEB_ONLY.cmd
Or run: flutter pub get; flutter analyze; flutter test; flutter build web --release
Deploy the contents of build/web to Cloudflare Pages, NOT this source ZIP.

Android release requires the ORIGINAL android project identity/signing.

Flutter compilation and browser functionality NOT verified in packaging environment.
