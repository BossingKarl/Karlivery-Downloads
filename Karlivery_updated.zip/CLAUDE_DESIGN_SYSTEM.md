# 🎨 Claude Design System for Karlivery

A sophisticated, minimal design language inspired by Claude's aesthetic. Where elegance, clarity, and thoughtfulness create immediate trust and admiration.

## 🎯 Philosophy

The Claude design system is built on five core principles:

1. **Elegance through simplicity** - Every pixel serves a purpose
2. **Sophisticated restraint** - Less is more, always
3. **Clear hierarchy** - Information architecture is obvious at a glance
4. **Thoughtful spacing** - Generosity with whitespace creates breathing room
5. **Refined typography** - Typography does the heavy lifting

When people see a product designed this way, they immediately notice the **beauty, craftsmanship, and intelligence** behind every detail.

## 🎨 Color Palette

### Primary Palette
- **Primary Teal** `#1E8E89` - Sophisticated, professional, trustworthy
- **Accent Amber** `#D97706` - Warm, inviting, elegant

### Neutral Palette
- **Deep Charcoal** `#0F0F0F` - Main text, not pure black (softer)
- **Professional Gray** `#626262` - Secondary text
- **Light Gray** `#9A9A9A` - Tertiary information
- **Very Light Gray** `#C4C4C4` - Hint text

### Backgrounds
- **Pure White** `#FFFFFF` - Content areas
- **Off-White** `#FAFAFA` - Surface level
- **Subtle Gray** `#F5F5F5` - Slightly darker surface

### Status Colors (Refined)
- **Success Green** `#059669` - Elegant, professional
- **Warning Amber** `#D97706` - Warm alert
- **Error Red** `#DC2626` - Clear but sophisticated
- **Info Blue** `#0284C7` - Professional communication

### Special
- **Rating Gold** `#FCD34D` - Soft, warm gold for stars

## ✨ Typography Scale

The typography is the foundation of elegance:

```
Display XL  36px 600 -0.6 letter-spacing     (Reserved for hero moments)
Display    32px 600 -0.5 letter-spacing     (Page titles)
Heading XL 24px 600                         (Section titles)
Heading L  20px 600                         (Card titles)
Heading M  18px 600                         (Subsections)
Heading S  16px 600                         (Form labels, chips)

Body L     16px 400  1.6 line-height       (Main content)
Body M     15px 400  1.6 line-height       (Card text)
Body S     14px 400  1.5 line-height       (Secondary text)

Label L    13px 600  0.3 letter-spacing    (Buttons, tags)
Label M    12px 600  0.2 letter-spacing    (Form labels)
Label S    11px 500  0.1 letter-spacing    (Small tags)

Caption    12px 400                        (Helper text)
```

### Why This Works
- Generous line height (1.6 for body) creates breathing room
- Consistent letter-spacing adds sophistication
- Font weights are intentional, not random
- Text doesn't feel crowded or cramped

## 📐 Spacing System

```
None   0px
XS     4px      (Tiny gaps)
SM     8px      (Small spacing)
MD    12px      (Comfortable spacing)
LG    16px      (Standard padding/margins)
XL    20px      (Generous spacing)
XXL   24px      (Section separation)
XXXL  32px      (Major sections)
Huge  40px      (Very spacious)
```

Used consistently to create:
- Visual rhythm
- Clear hierarchy
- Breathing room
- Professional proportions

## 🎨 Border Radius

```
XS     4px      (Tiny corners - rare)
SM     8px      (Small corners)
MD    12px      (Standard cards, inputs)
LG    16px      (Large containers)
XL    20px      (Hero sections)
Full  999px     (Pills, circles)
```

Cards and buttons use 12px-16px radius - not too rounded, not sharp.

## 🌟 Shadows - Subtle & Sophisticated

Instead of heavy shadows, Claude uses refined, minimal shadows:

```
None  []
XS    1px blur, 1px offset      (Very subtle)
SM    2px blur, 1px offset      (Slight elevation)
MD    4px blur, 2px offset      (Card depth)
LG    8px blur, 4px offset      (Modal depth)
XL   12px blur, 6px offset      (Maximum elevation)
```

All shadows use very low opacity (6-18% black), creating elegance rather than drama.

## 🧩 Components

### ClaudeRestaurantCard
Elegant restaurant card with:
- Clean borders instead of heavy shadows
- Generous spacing
- Clear typography hierarchy
- Refined status indicators
- Professional star rating

### ClaudeDishCard
Sophisticated product card with:
- Image area (no emoji)
- Price in elegant typography
- Minimal featured badge
- Clean interaction states

### ClaudeSearchBar
Minimal search interface:
- Refined focus state (teal border)
- Subtle placeholder text
- Professional icons
- Filter option

### ClaudeCategoryButton
Elegant category selector:
- Refined borders, not bright colors
- Professional icon + label
- Smooth selected state
- Minimal visual noise

## 📊 Layout Principles

### Hero Section
- Soft teal background with primary color
- Generous padding for breathing room
- Clear, large headline
- Supporting text in slightly lighter teal
- Single, clear CTA button

### Card Grid
- Max 3-4 cards per row on desktop
- 12-16px gaps between cards
- Cards have subtle border and minimal shadow
- Icons are outlined, not filled

### Spacing
- 16px standard padding for most sections
- 24px between major sections
- 32px for top-level separation
- Never cramped, always breathing room

## 🎯 Key Design Differences

| Element | Modern Food Apps | Claude Design |
|---------|-----------------|---------------|
| Colors | Bright red, lime green | Sophisticated teal, warm amber |
| Shadows | Bold, prominent | Subtle, refined |
| Borders | Minimal | Defined, elegant |
| Typography | Bold, attention-grabbing | Refined, clear hierarchy |
| Spacing | Compact, efficient | Generous, breathing room |
| Icons | Emoji or filled | Outlined, professional |
| Overall | "Grab my attention" | "Trust and quality" |

## 🎬 Visual Hierarchy

```
Hero Section (Soft teal background, generous padding)
     ↓
Section Title (24px, bold)
     ↓
Description Text (15px, gray, 1.6 line-height)
     ↓
Content Area (Cards, lists, grids)
     ↓
Supporting Information (12px, light gray)
```

Each level is clearly distinct, creating an elegant flow.

## 💡 Why This Creates Beauty

1. **Restraint** - Not using every color creates sophistication
2. **Proportions** - Generous spacing feels premium
3. **Consistency** - Predictable design feels intentional
4. **Clarity** - Clear hierarchy creates confidence
5. **Detail** - Subtle refinements show craftsmanship
6. **Typography** - Well-chosen typefaces do the work
7. **Whitespace** - Breathing room creates elegance

When people look at a Claude-designed interface, they see:
- ✅ Intelligence (clear thinking behind the design)
- ✅ Quality (attention to detail)
- ✅ Trust (professional, not flashy)
- ✅ Sophistication (refined, minimal)
- ✅ Beauty (elegant proportions, harmony)

## 🚀 Implementation

### Using Claude Colors
```dart
// Instead of bright reds
color: ClaudeColors.primary  // Sophisticated teal
```

### Using Claude Typography
```dart
// Clear hierarchy with refined scale
Text(
  'Discover the finest food',
  style: ClaudeTypography.displayMedium,
)
```

### Using Claude Spacing
```dart
// Generous, breathing room
padding: const EdgeInsets.all(ClaudeSpacing.xxl),
```

### Using Claude Components
```dart
// Elegant cards instead of bright ones
ClaudeRestaurantCard(
  name: 'Restaurant',
  rating: 4.5,
  onTap: () {},
)
```

## 📱 Responsive Design

- **Mobile (<540px)**: 1 column, full padding
- **Tablet (540-1200px)**: 2-3 columns
- **Desktop (>1200px)**: 3-4 columns, max-width container

All layouts maintain the principle of generous spacing and clear hierarchy.

## ✨ The Result

A product that feels:
- **Premium** - Not just functional, but beautiful
- **Trustworthy** - Professional design builds confidence
- **Thoughtful** - Every detail has purpose
- **Elegant** - Sophisticated without being cold
- **Timeless** - Not trendy, but classically beautiful

When users interact with a Claude-designed interface, they pause and think: *"This was made with care and intelligence."*

---

**Remember**: Elegance is not about adding more. It's about removing everything unnecessary, then refining what remains.

- Claude
