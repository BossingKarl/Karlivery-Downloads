# Karlivery Modern UI/UX Redesign

A comprehensive redesign of Karlivery's interface to match modern food delivery apps like **GrabFood**, **Uber Eats**, **DoorDash**, and **ShopeeFood**.

## 🎨 Design System

### Color Palette (Modern)

The new color system is vibrant, appetizing, and professional:

- **Primary Red** (`#E63946`) - Main action color, CTAs, highlights
- **Secondary Green** (`#06A77D`) - Success states, positive feedback
- **Neutral Whites** (`#FFFFFF`, `#FAFAFA`) - Clean backgrounds
- **Text Colors** - Dark (`#1A1A1A`), Medium (`#666666`), Light (`#999999`)
- **Status Colors**:
  - Success: Green (`#06A77D`)
  - Warning: Amber (`#F59E0B`)
  - Error: Red (`#DC2626`)
  - Info: Blue (`#0EA5E9`)

### Typography

Modern sans-serif typography with clear hierarchy:

- **Display Large**: 32px, Bold (700)
- **Display Medium**: 28px, Bold (700)
- **Headline Large**: 24px, Bold (700)
- **Title Large**: 16px, Semi-bold (600)
- **Body Large**: 16px, Regular (400)
- **Label Large**: 12px, Semi-bold (600)

### Spacing & Sizing

- **XS**: 4px
- **SM**: 8px
- **MD**: 12px
- **LG**: 16px (standard padding)
- **XL**: 20px
- **XXL**: 24px
- **Corner Radius**: 8px (small), 12px (medium), 16px (large)

### Shadows

Subtle, modern shadows inspired by Material Design 3:

- **XS**: Light shadow (2px blur)
- **SM**: Subtle shadow (3px blur)
- **MD**: Standard shadow (8px blur)
- **LG**: Prominent shadow (16px blur)

## 🎯 Key Components

### ModernStoreCard
Restaurant/store card featuring:
- Hero image with overlay badges
- Star rating with count
- Delivery time (ETA)
- Free delivery indicator
- Discount badges (top right)
- Promoted/trending badges (top left)
- Closed state overlay

Example uses:
- Browse screen restaurant grid
- Search results
- Category listings

### ModernProductCard
Dish/product card featuring:
- Product image
- Name and description
- Price in peso (₱)
- Rating stars
- Featured badge
- Optimized for horizontal scrolling

Example uses:
- Featured dishes section
- Search results
- Store menu items (future)

### ModernSearchBar
Unified search interface with:
- Rounded search input
- Search icon
- Filter/tune icon for advanced filters
- Location/sorting context

## 📱 Screens Redesigned

### 1. **Modern Browse Screen** (`modern_browse_screen.dart`)

The main discovery interface for customers:

**Features:**
- Hero header with title and subtitle
- Search bar with filter options
- Sort chips (Popular, Fastest, Top Rated)
- Featured dishes horizontal carousel
- Restaurant grid with modern cards
- Pull-to-refresh
- Empty states with helpful icons
- Responsive grid (1-4 columns based on screen width)

**Key Improvements:**
- Faster discovery with featured section
- Clear sort options (not hidden in menu)
- Modern visual hierarchy
- Touch-friendly spacing
- Professional empty states

### 2. **Modern Authentication**

Clean sign-in and sign-up flows:
- Simplified form design
- Clear error messages
- Password strength indicator
- Social login options (future)
- Smooth transitions

### 3. **Modern Store Detail** (coming next)

Enhanced store experience:
- Large hero image with parallax
- Quick info (rating, delivery time, distance)
- Filter and sort products
- Rich product details with images
- Cart drawer that doesn't obstruct navigation

### 4. **Modern Checkout** (coming next)

Streamlined checkout:
- Address selection/input
- Order summary with itemized breakdown
- Promo code input
- Multiple payment methods
- Order confirmation with tracking link

## 🚀 Rollout Plan

### Phase 1: Core Components (Done)
- ✅ Modern palette and tokens
- ✅ Card components (store, product, search)
- ✅ Modern browse screen

### Phase 2: Screens (This release)
- [ ] Modern store detail screen
- [ ] Modern checkout flow
- [ ] Modern order tracking
- [ ] Modern account/profile

### Phase 3: Polish (Next release)
- [ ] Animations and transitions
- [ ] Haptic feedback
- [ ] Accessibility (WCAG AA)
- [ ] Dark mode variants
- [ ] Performance optimization

## 🎬 Visual Examples

### Store Card
```
┌─────────────────────┐
│ [Restaurant Image]  │ ← 180px height, cover photo
│ [Promo Badge] [📍]  │
├─────────────────────┤
│ Restaurant Name     │ ← Bold, truncated to 2 lines
│ ⭐ 4.5 (123) Category│
│ ⏱️ 25 min · 🚚 Free  │
└─────────────────────┘
```

### Product Card (Featured Carousel)
```
┌──────────┐
│ [Image]  │ ← 140px height
│Featured ▼│
├──────────┤
│ Dish Name│
│Price ₱99 │
│ ⭐ 4.8   │
└──────────┘
```

### Browse Screen Layout
```
┌────────────────────────────┐
│ [Logo] [Help] [Cart] [Sign]│
├────────────────────────────┤
│ [🔍 Search] [🎛️ Filter]    │
├────────────────────────────┤
│ Find your next meal        │
│ Browse local restaurants   │
├────────────────────────────┤
│ Popular Fastest Top Rated  │
├────────────────────────────┤
│ Featured Now               │
│ [Card1] [Card2] [Card3]   │
├────────────────────────────┤
│ Restaurants Nearby         │
│ [Card] [Card] [Card]      │
│ [Card] [Card] [Card]      │
│ [Card] [Card] [Card]      │
└────────────────────────────┘
```

## 🔗 File Structure

```
lib/
├── design_system/
│   ├── modern_palette.dart      # Colors, spacing, typography
│   └── modern_cards.dart        # Store, product, search components
├── features/
│   ├── customer/
│   │   └── modern_browse_screen.dart  # New browse UI
│   ├── auth/
│   │   └── modern_auth_screens.dart   # Auth redesign (future)
│   └── ...
└── theme/
    └── modern_theme.dart        # Theme data (future)
```

## 📐 Responsive Behavior

### Mobile (< 540px)
- 1 column restaurant grid
- Full-width cards with 12px padding
- Touch targets: 48px minimum

### Tablet (540-1200px)
- 2-3 column restaurant grid
- Horizontal margins: 16px
- Featured carousel with 4+ visible items

### Desktop (> 1200px)
- 3-4 column restaurant grid
- Max width: 1200px
- Large cards with better proportions

## 🎨 Icon System

Using Material Icons 3 (modern Material Design icons):

- **Search**: `search_rounded`
- **Filter**: `tune_rounded`
- **Location**: `location_on_rounded`
- **Delivery**: `local_shipping_outlined`
- **Rating**: `star_rounded`
- **Time**: `access_time_rounded`
- **Cart**: `shopping_bag_outlined`
- **Menu**: `menu_rounded`
- **Close**: `close_rounded`

All icons are 24px (buttons), 16px (inline), 36px (large indicators).

## 🔄 Migration Guide

### For Existing Screens
Replace old cards with `ModernStoreCard`:

```dart
// Old
KarliveryStoreCard(store: store)

// New
ModernStoreCard(
  id: store['id'],
  name: store['name'],
  imageUrl: store['cover_photo_url'],
  rating: store['rating_avg'],
  eta: store['eta_min_minutes'],
  onTap: () => context.push('/store/${store['id']}'),
)
```

### Color Migration
Replace old `AppTheme` colors with modern palette:

```dart
// Old
color: AppTheme.red

// New
color: ModernPalette.primary
```

## 📊 Performance Notes

- Card images are lazy-loaded with error handling
- Featured carousel uses `ListView` (efficient horizontal scrolling)
- Grid uses `SliverGrid` (optimal memory usage with sliver layout)
- Minimal shadows (xs/sm for performance)

## ✨ Next Steps

1. Implement store detail screen with modern design
2. Add animations and transitions
3. Create modern checkout flow
4. Test on real devices (iOS/Android)
5. Gather user feedback and iterate

---

**Design Lead**: Modern Food Delivery Apps (GrabFood, Uber Eats, DoorDash, ShopeeFood)
**Last Updated**: 2024-10-23
