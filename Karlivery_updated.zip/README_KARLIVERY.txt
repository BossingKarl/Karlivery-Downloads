Karlivery — Mobile-first authentication update

CHANGED:
- lib/features/auth/auth_studio.dart: redesigned portrait-first layout with branded food photo story, safe area, responsive form, keyboard-aware scrolling, desktop secondary layout.
- lib/features/auth/login_screen.dart: simplified native-feeling login heading; all original Backend.login, verification, password recovery, and navigation logic preserved.
- karlivery-preview.html: interactive phone-sized preview of the revised auth concept.

NOT CHANGED: customer, seller, rider, admin interfaces, business logic, Android/iOS identifiers.
VALIDATION: ZIP CRC integrity verified; Flutter analyze/build/tests NOT executed in this environment. HTML preview is illustrative and not Supabase-connected.

For Flutter: flutter pub get && flutter analyze && flutter test && flutter build web --release
For Android/iOS: use original platform folders and signing setup; never replace production app IDs.
