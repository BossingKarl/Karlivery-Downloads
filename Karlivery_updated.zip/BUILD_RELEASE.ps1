param(
  [ValidateSet('all','web','apk')][string]$Target = 'all',
  [string]$OriginalAndroidProject = '',
  [switch]$SkipTests,
  [switch]$NoOpen
)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$root = (Get-Location).Path

function Run([string[]]$ArgsList) {
  Write-Host ("flutter " + ($ArgsList -join ' ')) -ForegroundColor Cyan
  & flutter @ArgsList
  if ($LASTEXITCODE -ne 0) { throw "Flutter command failed: $($ArgsList -join ' ')" }
}
function Size-MB($p) { '{0:N1} MB' -f ((Get-Item $p).Length / 1MB) }

if (!(Get-Command flutter -ErrorAction SilentlyContinue)) { throw 'Flutter SDK not found. Install Flutter and add flutter\bin to PATH.' }
if (!(Test-Path 'pubspec.yaml')) { throw 'pubspec.yaml missing. Run this from the project folder.' }

$results = @()

# ---------- Android platform folder (APK only) ----------
function Patch-Android {
  Write-Host 'Configuring Android (permissions, desugaring, deep link)...' -ForegroundColor Yellow
  $manifest = 'android/app/src/main/AndroidManifest.xml'
  if (Test-Path $manifest) {
    $m = Get-Content $manifest -Raw
    foreach ($p in 'android.permission.INTERNET','android.permission.ACCESS_FINE_LOCATION','android.permission.ACCESS_COARSE_LOCATION','android.permission.POST_NOTIFICATIONS','android.permission.VIBRATE','android.permission.RECEIVE_BOOT_COMPLETED') {
      if ($m -notmatch [regex]::Escape($p)) {
        $m = ([regex]'(<manifest[^>]*>)').Replace($m, ('$1' + "`n    <uses-permission android:name=`"$p`"/>"), 1)
      }
    }
    if ($m -notmatch 'login-callback') {
      $intent = "    <intent-filter>`n                <action android:name=`"android.intent.action.VIEW`"/>`n                <category android:name=`"android.intent.category.DEFAULT`"/>`n                <category android:name=`"android.intent.category.BROWSABLE`"/>`n                <data android:scheme=`"com.karlivery`" android:host=`"login-callback`"/>`n            </intent-filter>`n        </activity>"
      $m = ([regex]'</activity>').Replace($m, $intent, 1)
    }
    $m = $m -replace 'android:label="[^"]*"', 'android:label="Karlivery"'
    Set-Content $manifest $m -Encoding UTF8
  }
  $kts = 'android/app/build.gradle.kts'
  $groovy = 'android/app/build.gradle'
  if (Test-Path $kts) {
    $g = Get-Content $kts -Raw
    if ($g -notmatch 'isCoreLibraryDesugaringEnabled') {
      $g = $g -replace 'compileOptions\s*\{', "compileOptions {`n        isCoreLibraryDesugaringEnabled = true"
      $g += "`ndependencies {`n    coreLibraryDesugaring(`"com.android.tools:desugar_jdk_libs:2.1.4`")`n}`n"
      Set-Content $kts $g -Encoding UTF8
    }
  } elseif (Test-Path $groovy) {
    $g = Get-Content $groovy -Raw
    if ($g -notmatch 'coreLibraryDesugaringEnabled') {
      $g = $g -replace 'compileOptions\s*\{', "compileOptions {`n        coreLibraryDesugaringEnabled true"
      $g += "`ndependencies {`n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'`n}`n"
      Set-Content $groovy $g -Encoding UTF8
    }
  }
}

$generatedAndroid = $false
if ($Target -ne 'web' -and !(Test-Path 'android/app')) {
  if ($OriginalAndroidProject) {
    $android = Join-Path $OriginalAndroidProject 'android'
    if (!(Test-Path (Join-Path $android 'app'))) { throw "Original Android platform not found at: $android" }
    Copy-Item $android (Join-Path $root 'android') -Recurse -Force
    Write-Host 'Using the Android folder from your original project (keeps app ID + signing).' -ForegroundColor Green
  } else {
    Write-Host 'No android folder and no original project given: generating a NEW Android project.' -ForegroundColor Yellow
    Write-Host 'This APK is fine for testing, but it is NOT update-compatible with an already-published Karlivery app.' -ForegroundColor Yellow
    Run @('create','--platforms=android','--org','com.karlivery','--project-name','karl_delivery','.')
    Patch-Android
    $generatedAndroid = $true
  }
}

Run @('pub','get')
Run @('analyze','--no-fatal-infos')
if (!$SkipTests) { Run @('test') }

# ---------- WEB ----------
if ($Target -ne 'apk') {
  $help = (& flutter build web -h 2>&1 | Out-String)
  $webArgs = @('build','web','--release')
  if ($help -match 'pwa-strategy')      { $webArgs += '--pwa-strategy=none' }       # no stale service-worker caches
  if ($help -match 'web-resources-cdn') { $webArgs += '--no-web-resources-cdn' }    # bundle CanvasKit; no gstatic dependency
  Run $webArgs
  if (!(Test-Path 'build/web/index.html')) { throw 'Web build index.html missing.' }

  # Zip with forward-slash paths (Compress-Archive in Windows PowerShell 5.1 writes backslashes,
  # which breaks Cloudflare Pages).
  $dest = Join-Path $root 'build/Karlivery_Cloudflare_Pages.zip'
  if (Test-Path $dest) { Remove-Item $dest -Force }
  Add-Type -AssemblyName System.IO.Compression
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $srcFull = (Resolve-Path 'build/web').Path
  $zip = [System.IO.Compression.ZipFile]::Open($dest, 'Create')
  try {
    Get-ChildItem $srcFull -Recurse -File | ForEach-Object {
      $rel = $_.FullName.Substring($srcFull.Length).TrimStart('\','/') -replace '\\','/'
      [void][System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $_.FullName, $rel, [System.IO.Compression.CompressionLevel]::Optimal)
    }
  } finally { $zip.Dispose() }
  $results += "WEB folder (upload the CONTENTS of this folder to Cloudflare Pages):`r`n   $srcFull"
  $results += "WEB zip    (alternative for Cloudflare direct upload):`r`n   $dest   [$(Size-MB $dest)]"
}

# ---------- APK ----------
if ($Target -ne 'web') {
  Run @('build','apk','--release','--target-platform','android-arm64')
  $built = 'build/app/outputs/flutter-apk/app-release.apk'
  if (!(Test-Path $built)) { throw 'APK artifact missing.' }
  $apk = Join-Path $root 'build/Karlivery-release.apk'
  Copy-Item $built $apk -Force
  $results += "APK        (copy this to your phone and install):`r`n   $apk   [$(Size-MB $apk)]"
  if ($generatedAndroid) { $results += 'NOTE: APK built from a newly generated Android project (app ID com.karlivery.karl_delivery), debug-signed. For Play Store or updating an existing install, use BUILD_APK.cmd with your ORIGINAL project path.' }
}

# ---------- Summary ----------
$line = ('=' * 78)
$report = @($line, ' BUILD COMPLETE - YOUR FILES ARE HERE', $line) + $results + @($line)
$report | ForEach-Object { Write-Host $_ -ForegroundColor Green }
$report | Set-Content (Join-Path $root 'BUILD_OUTPUT_PATHS.txt') -Encoding UTF8
Write-Host "Paths also saved to: $(Join-Path $root 'BUILD_OUTPUT_PATHS.txt')" -ForegroundColor Green
if (!$NoOpen) { try { Start-Process explorer.exe (Join-Path $root 'build') } catch {} }
Write-Host 'Validate login, sign-up, checkout, notifications and delivery flows on real devices before publishing.' -ForegroundColor Yellow
