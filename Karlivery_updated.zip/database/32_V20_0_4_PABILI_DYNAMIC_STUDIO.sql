-- Karlivery V20.0.4 — Pabili with Karlivery, admin-controlled galleries.
-- Non-destructive, idempotent. Existing orders/images remain untouched.
BEGIN;

ALTER TABLE public.pasabuy_shops
  ADD COLUMN IF NOT EXISTS show_bundled_gallery boolean NOT NULL DEFAULT true;

GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT SELECT ON public.pasabuy_shops TO anon, authenticated;
GRANT INSERT, UPDATE ON public.pasabuy_shops TO authenticated;
ALTER TABLE public.pasabuy_shops ENABLE ROW LEVEL SECURITY;

-- Only admin accounts may create/edit/hide stores. Public SELECT still
-- respects the existing "is_active = true" read policy.
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname='public' AND tablename='pasabuy_shops'
      AND policyname='pasabuy admin manage shops'
  ) THEN
    CREATE POLICY "pasabuy admin manage shops"
    ON public.pasabuy_shops FOR ALL TO authenticated
    USING (public.current_user_role() = 'admin')
    WITH CHECK (public.current_user_role() = 'admin');
  END IF;
END $$;

INSERT INTO storage.buckets (id, name, public)
VALUES ('pasabuy-gallery', 'pasabuy-gallery', true)
ON CONFLICT (id) DO UPDATE SET public = true;

-- Uploads use unique paths under auth.uid()/shop-id/file.jpg.
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname='storage' AND tablename='objects'
      AND policyname='karlivery pabili admin upload'
  ) THEN
    CREATE POLICY "karlivery pabili admin upload"
    ON storage.objects FOR INSERT TO authenticated
    WITH CHECK (
      bucket_id = 'pasabuy-gallery'
      AND public.current_user_role() = 'admin'
      AND (storage.foldername(name))[1] = auth.uid()::text
    );
  END IF;
END $$;
COMMIT;
NOTIFY pgrst, 'reload schema';

-- Sanity check (read-only)
SELECT id, name, is_active, show_bundled_gallery,
       jsonb_array_length(coalesce(menu_image_urls, '[]'::jsonb)) AS remote_gallery_count
FROM public.pasabuy_shops ORDER BY sort_order, name;
