-- =========================================================
-- KARLIVERY V12.1 HOTFIX — ADMIN PROFILE BOOTSTRAP
-- Run this in Supabase SQL Editor once, then deploy the admin-users function.
-- Replace YOUR_ADMIN_EMAIL_HERE with the email address you use to sign in as admin.
-- =========================================================

-- 1) Backfill profiles for any existing auth users that were created
--    before the profile trigger was installed or fixed.
insert into public.profiles (
  id,
  email,
  full_name,
  phone,
  role,
  status
)
select
  u.id,
  u.email,
  coalesce(u.raw_user_meta_data->>'full_name',''),
  coalesce(u.raw_user_meta_data->>'phone',''),
  case
    when lower(coalesce(u.raw_user_meta_data->>'role','')) in ('customer','store_owner','rider','admin')
      then lower(u.raw_user_meta_data->>'role')::public.user_role
    else 'customer'::public.user_role
  end,
  case
    when lower(coalesce(u.raw_user_meta_data->>'status','')) in ('active','suspended','rejected','pending')
      then lower(u.raw_user_meta_data->>'status')::public.user_status
    else 'active'::public.user_status
  end
from auth.users u
left join public.profiles p on p.id = u.id
where p.id is null;

-- 2) Promote your chosen admin sign-in account.
update public.profiles
set role = 'admin'::public.user_role,
    status = 'active'::public.user_status,
    updated_at = now()
where lower(email) = lower('YOUR_ADMIN_EMAIL_HERE');

-- 3) Also stamp the auth metadata so the edge function can rebuild
--    the profile automatically in the future if needed.
update auth.users
set raw_user_meta_data = coalesce(raw_user_meta_data, '{}'::jsonb)
  || jsonb_build_object('role','admin','status','active')
where lower(email) = lower('YOUR_ADMIN_EMAIL_HERE');
