-- =========================================================
-- KARLIVERY V9 — SECURE ACCOUNTS / STORE BRANDING / REPORTS
-- Run AFTER database/06_SMART_DELIVERY_GCASH_MEDIA_ADDONS.sql
-- =========================================================

create extension if not exists pgcrypto;

-- =========================================================
-- 1) PUBLIC SIGN-UP IS CUSTOMER ONLY
-- =========================================================
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  insert into public.profiles(
    id,email,full_name,phone,role,status
  )
  values(
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name',''),
    coalesce(new.raw_user_meta_data->>'phone',''),
    'customer'::public.user_role,
    'active'::public.user_status
  )
  on conflict(id) do update set
    email=excluded.email,
    full_name=excluded.full_name,
    phone=excluded.phone,
    -- role/status intentionally remain unchanged on existing profiles.
    updated_at=now();

  return new;
end;
$$;

-- Customers can no longer directly update role/status.
drop policy if exists "profiles_update" on public.profiles;
drop policy if exists "profiles_update_admin" on public.profiles;

create policy "profiles_update_admin"
on public.profiles
for update
to authenticated
using(public.current_user_role()='admin')
with check(public.current_user_role()='admin');

drop function if exists public.update_my_profile(text,text);
create or replace function public.update_my_profile(
  p_full_name text,
  p_phone text
)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  update public.profiles
  set full_name=trim(coalesce(p_full_name,'')),
      phone=trim(coalesce(p_phone,'')),
      updated_at=now()
  where id=auth.uid();
end;
$$;

grant execute on function public.update_my_profile(text,text) to authenticated;


drop function if exists public.set_my_rider_online(boolean);
create or replace function public.set_my_rider_online(
  p_online boolean
)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  if public.current_user_role() <> 'rider' then
    raise exception 'Rider account required';
  end if;

  update public.profiles
  set is_online=coalesce(p_online,false),
      updated_at=now()
  where id=auth.uid();
end;
$$;

grant execute on function public.set_my_rider_online(boolean) to authenticated;

-- =========================================================
-- 2) HARD ACCOUNT DELETE WITHOUT DESTROYING ORDER HISTORY
--    Historical orders remain but deleted users are unlinked.
-- =========================================================

-- stores.owner_id -> nullable, SET NULL
alter table public.stores alter column owner_id drop not null;
alter table public.stores drop constraint if exists stores_owner_id_fkey;
alter table public.stores
  add constraint stores_owner_id_fkey
  foreign key(owner_id) references public.profiles(id) on delete set null;

-- orders.customer_id -> nullable, SET NULL
alter table public.orders alter column customer_id drop not null;
alter table public.orders drop constraint if exists orders_customer_id_fkey;
alter table public.orders
  add constraint orders_customer_id_fkey
  foreign key(customer_id) references public.profiles(id) on delete set null;

-- saved delivery address can be removed while textual delivery_address stays in history
alter table public.orders drop constraint if exists orders_address_id_fkey;
alter table public.orders
  add constraint orders_address_id_fkey
  foreign key(address_id) references public.addresses(id) on delete set null;

-- rider_id -> SET NULL
alter table public.orders drop constraint if exists orders_rider_id_fkey;
alter table public.orders
  add constraint orders_rider_id_fkey
  foreign key(rider_id) references public.profiles(id) on delete set null;

-- payment verifier -> SET NULL
alter table public.orders drop constraint if exists orders_payment_verified_by_fkey;
alter table public.orders
  add constraint orders_payment_verified_by_fkey
  foreign key(payment_verified_by) references public.profiles(id) on delete set null;

-- order event actor -> SET NULL
alter table public.order_events drop constraint if exists order_events_actor_id_fkey;
alter table public.order_events
  add constraint order_events_actor_id_fkey
  foreign key(actor_id) references public.profiles(id) on delete set null;

-- menu items can be deleted while order_items keep their snapshotted product_name/price
alter table public.order_items drop constraint if exists order_items_product_id_fkey;
alter table public.order_items
  add constraint order_items_product_id_fkey
  foreign key(product_id) references public.products(id) on delete set null;

-- chat sender -> keep history, anonymize deleted sender
alter table public.chat_messages alter column sender_id drop not null;
alter table public.chat_messages drop constraint if exists chat_messages_sender_id_fkey;
alter table public.chat_messages
  add constraint chat_messages_sender_id_fkey
  foreign key(sender_id) references public.profiles(id) on delete set null;

-- =========================================================
-- 3) FEATURED MENU ITEMS
-- =========================================================
alter table public.products
  add column if not exists is_featured boolean not null default false;

create index if not exists idx_products_store_featured
  on public.products(store_id,is_featured,is_available);

drop function if exists public.seller_set_product_featured(uuid,boolean);
create or replace function public.seller_set_product_featured(
  p_product_id uuid,
  p_featured boolean
)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if not exists(
    select 1
    from public.products p
    join public.stores s on s.id=p.store_id
    where p.id=p_product_id
      and (s.owner_id=auth.uid() or public.current_user_role()='admin')
  ) then
    raise exception 'Product not found or access denied';
  end if;

  update public.products
  set is_featured=coalesce(p_featured,false),
      updated_at=now()
  where id=p_product_id;
end;
$$;

grant execute on function public.seller_set_product_featured(uuid,boolean)
to authenticated;

-- =========================================================
-- 4) STORE LOGO STORAGE
-- =========================================================
insert into storage.buckets(id,name,public)
values ('store-logos','store-logos',true)
on conflict(id) do update set public=true;

drop policy if exists "seller_store_logo_select" on storage.objects;
drop policy if exists "seller_store_logo_insert" on storage.objects;
drop policy if exists "seller_store_logo_update" on storage.objects;
drop policy if exists "seller_store_logo_delete" on storage.objects;

create policy "seller_store_logo_select"
on storage.objects for select to authenticated
using(
  bucket_id='store-logos'
  and (storage.foldername(name))[1]=(select auth.uid())::text
);

create policy "seller_store_logo_insert"
on storage.objects for insert to authenticated
with check(
  bucket_id='store-logos'
  and (storage.foldername(name))[1]=(select auth.uid())::text
);

create policy "seller_store_logo_update"
on storage.objects for update to authenticated
using(
  bucket_id='store-logos'
  and (storage.foldername(name))[1]=(select auth.uid())::text
)
with check(
  bucket_id='store-logos'
  and (storage.foldername(name))[1]=(select auth.uid())::text
);

create policy "seller_store_logo_delete"
on storage.objects for delete to authenticated
using(
  bucket_id='store-logos'
  and (storage.foldername(name))[1]=(select auth.uid())::text
);

drop function if exists public.seller_save_store_logo(uuid,text);
create or replace function public.seller_save_store_logo(
  p_store_id uuid,
  p_logo_url text
)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if not exists(
    select 1 from public.stores
    where id=p_store_id
      and (owner_id=auth.uid() or public.current_user_role()='admin')
  ) then
    raise exception 'Store not found or access denied';
  end if;

  update public.stores
  set logo_url=nullif(trim(coalesce(p_logo_url,'')),''),
      updated_at=now()
  where id=p_store_id;
end;
$$;

grant execute on function public.seller_save_store_logo(uuid,text)
to authenticated;

-- =========================================================
-- 5) GCASH QR RLS FIX
--    Covers existing V8 installs and allows replace/upsert.
-- =========================================================
insert into storage.buckets(id,name,public)
values ('store-gcash-qr','store-gcash-qr',true)
on conflict(id) do update set public=true;

drop policy if exists "seller_select_qr" on storage.objects;
drop policy if exists "seller_upload_qr" on storage.objects;
drop policy if exists "seller_update_qr" on storage.objects;
drop policy if exists "seller_delete_qr" on storage.objects;

create policy "seller_select_qr"
on storage.objects for select to authenticated
using(
  bucket_id='store-gcash-qr'
  and (storage.foldername(name))[1]=(select auth.uid())::text
);

create policy "seller_upload_qr"
on storage.objects for insert to authenticated
with check(
  bucket_id='store-gcash-qr'
  and (storage.foldername(name))[1]=(select auth.uid())::text
);

create policy "seller_update_qr"
on storage.objects for update to authenticated
using(
  bucket_id='store-gcash-qr'
  and (storage.foldername(name))[1]=(select auth.uid())::text
)
with check(
  bucket_id='store-gcash-qr'
  and (storage.foldername(name))[1]=(select auth.uid())::text
);

create policy "seller_delete_qr"
on storage.objects for delete to authenticated
using(
  bucket_id='store-gcash-qr'
  and (storage.foldername(name))[1]=(select auth.uid())::text
);

-- =========================================================
-- 6) ADMIN/SELLER READ SUPPORT
-- =========================================================
grant usage on schema public to authenticated;
grant select,insert,update,delete on all tables in schema public to authenticated;
grant usage,select on all sequences in schema public to authenticated;
grant execute on all functions in schema public to authenticated;

select 'Karlivery V9 secure commerce upgrade ready' as result;
