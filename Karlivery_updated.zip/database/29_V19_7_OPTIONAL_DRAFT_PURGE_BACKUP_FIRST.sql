-- OPTIONAL SPACE CLEANUP: DO NOT RUN before taking a full Supabase backup.
-- In normal operation, DO NOT run this. Photo-mode app does not read legacy draft items.
-- Preview eligible rows FIRST using database/28_V19_7_LEGACY_CLEANUP_REVIEW_ONLY.sql.
-- Deletes only UNPUBLISHED legacy item drafts with no order-item references.
-- Never drops shops, categories, historical orders, attachments, or payment evidence.
BEGIN;
DO $$
DECLARE
  do_cleanup boolean := false;  -- Explicitly change to TRUE only after backup + review.
  deleted_count integer;
BEGIN
  IF NOT do_cleanup THEN
    RAISE NOTICE 'SAFE DEFAULT: nothing deleted. Change do_cleanup to true AFTER backup.';
    RETURN;
  END IF;

  DELETE FROM public.pasabuy_items i
  WHERE i.is_published = false
    AND NOT EXISTS (
      SELECT 1 FROM public.pasabuy_order_items oi
      WHERE oi.item_id = i.id
    );
  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RAISE NOTICE 'Deleted % unreferenced unpublished legacy draft items', deleted_count;
END $$;
COMMIT;
