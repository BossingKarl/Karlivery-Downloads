-- =========================================================
-- KARLIVERY V17 — NOTIFICATION REALTIME RELIABILITY
-- Run ONCE after database/08_ENGAGEMENT_RATINGS_NOTIFICATIONS_CHAT.sql
--
-- Purpose:
--   Ensure newly inserted notifications (including admin announcements)
--   appear immediately in open Karlivery sessions through Supabase Realtime.
-- =========================================================

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime'
      AND schemaname = 'public'
      AND tablename = 'notifications'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
  END IF;
END
$$;

-- Helpful index for notification inbox streams / unread badges.
CREATE INDEX IF NOT EXISTS idx_notifications_user_created_v17
  ON public.notifications(user_id, created_at DESC);

-- Existing RLS remains authoritative: users can only read their own rows.
GRANT SELECT ON public.notifications TO authenticated;
