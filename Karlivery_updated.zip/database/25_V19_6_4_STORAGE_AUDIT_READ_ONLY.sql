-- KARLIVERY V19.6.4 -- READ-ONLY DIAGNOSTICS ONLY.
-- This does not delete records or alter storage. Run with SQL Editor to inspect first.
select table_schema, table_name, pg_size_pretty(pg_total_relation_size(format('%I.%I', table_schema, table_name))) as total_size
from information_schema.tables
where table_schema='public' and table_type='BASE TABLE'
order by pg_total_relation_size(format('%I.%I', table_schema, table_name)) desc;

-- Review ONLY: orphaned Pasabuy image URLs, media uploads, and draft items should be reviewed
-- against existing orders and storage policies before any deletion.
select id, name, menu_image_urls, logo_url, cover_image_url
from public.pasabuy_shops
order by name;

-- No DELETE, TRUNCATE, DROP, or automatic Storage cleanup is included intentionally.
