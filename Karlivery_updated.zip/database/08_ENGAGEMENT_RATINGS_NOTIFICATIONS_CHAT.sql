-- =========================================================
-- KARLIVERY V11.3 — RATINGS / NOTIFICATION INBOX / CHAT CONTEXT
-- Run ONCE after 07_SECURE_ACCOUNTS_STORE_BRANDING_REPORTS.sql
-- =========================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------
-- 1) Notification inbox upgrades
-- ---------------------------------------------------------
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  order_id uuid references public.orders(id) on delete cascade,
  title text not null,
  message text not null,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.notifications
  add column if not exists order_id uuid,
  add column if not exists is_read boolean not null default false,
  add column if not exists read_at timestamptz,
  add column if not exists kind text not null default 'general',
  add column if not exists data jsonb not null default '{}'::jsonb;

-- Older databases may already have notifications without the order FK.
do $$
begin
  if not exists (
    select 1 from pg_constraint c
    where c.conrelid='public.notifications'::regclass
      and c.contype='f'
      and c.conname='notifications_order_id_fkey'
  ) then
    alter table public.notifications
      add constraint notifications_order_id_fkey
      foreign key(order_id) references public.orders(id) on delete cascade;
  end if;
end $$;

-- Login / announcement notifications do not belong to an order.
do $$
begin
  if exists (
    select 1
    from information_schema.columns
    where table_schema='public'
      and table_name='notifications'
      and column_name='order_id'
  ) then
    execute 'alter table public.notifications alter column order_id drop not null';
  end if;
end $$;

create index if not exists idx_notifications_user_created
  on public.notifications(user_id,created_at desc);

create index if not exists idx_notifications_user_unread
  on public.notifications(user_id,is_read,created_at desc);

alter table public.notifications enable row level security;

drop policy if exists "v113_notifications_select_own" on public.notifications;
create policy "v113_notifications_select_own"
on public.notifications for select
to authenticated
using(user_id=auth.uid());

drop function if exists public.mark_notification_read(uuid);
create or replace function public.mark_notification_read(p_notification_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  update public.notifications
  set is_read=true,
      read_at=coalesce(read_at,now())
  where id=p_notification_id
    and user_id=auth.uid();
end;
$$;

grant execute on function public.mark_notification_read(uuid) to authenticated;

drop function if exists public.mark_all_notifications_read();
create or replace function public.mark_all_notifications_read()
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  update public.notifications
  set is_read=true,
      read_at=coalesce(read_at,now())
  where user_id=auth.uid()
    and coalesce(is_read,false)=false;
end;
$$;

grant execute on function public.mark_all_notifications_read() to authenticated;

drop function if exists public.create_login_notification(text);
create or replace function public.create_login_notification(p_role text)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_role text := lower(trim(coalesce(p_role,'customer')));
  v_label text;
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  v_label := case v_role
    when 'store_owner' then 'Seller'
    when 'rider' then 'Rider'
    when 'admin' then 'Administrator'
    else 'Customer'
  end;

  insert into public.notifications(
    user_id,title,message,kind,data,is_read
  )
  values(
    auth.uid(),
    'Welcome to Karlivery',
    'Signed in successfully as ' || v_label || '.',
    'login',
    jsonb_build_object('role',v_role),
    false
  );
end;
$$;

grant execute on function public.create_login_notification(text) to authenticated;

-- ---------------------------------------------------------
-- 2) Restaurant + rider ratings
-- ---------------------------------------------------------
create table if not exists public.order_ratings (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references public.orders(id) on delete cascade,
  customer_id uuid references public.profiles(id) on delete set null,
  store_id uuid not null references public.stores(id) on delete cascade,
  rider_id uuid references public.profiles(id) on delete set null,
  store_rating integer not null check(store_rating between 1 and 5),
  rider_rating integer check(rider_rating between 1 and 5),
  comment text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_order_ratings_store
  on public.order_ratings(store_id,store_rating);

create index if not exists idx_order_ratings_rider
  on public.order_ratings(rider_id,rider_rating)
  where rider_id is not null;

alter table public.order_ratings enable row level security;

drop policy if exists "v113_ratings_customer_own" on public.order_ratings;
create policy "v113_ratings_customer_own"
on public.order_ratings for select
to authenticated
using(customer_id=auth.uid());

drop policy if exists "v113_ratings_store_owner" on public.order_ratings;
create policy "v113_ratings_store_owner"
on public.order_ratings for select
to authenticated
using(
  exists(
    select 1 from public.stores s
    where s.id=store_id and s.owner_id=auth.uid()
  )
);

drop policy if exists "v113_ratings_rider_own" on public.order_ratings;
create policy "v113_ratings_rider_own"
on public.order_ratings for select
to authenticated
using(rider_id=auth.uid());

drop policy if exists "v113_ratings_admin" on public.order_ratings;
create policy "v113_ratings_admin"
on public.order_ratings for select
to authenticated
using(public.current_user_role()='admin');

drop function if exists public.submit_order_rating(uuid,integer,integer,text);
create or replace function public.submit_order_rating(
  p_order_id uuid,
  p_store_rating integer,
  p_rider_rating integer default null,
  p_comment text default ''
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.orders%rowtype;
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  if p_store_rating not between 1 and 5 then
    raise exception 'Restaurant rating must be between 1 and 5';
  end if;

  if p_rider_rating is not null and p_rider_rating not between 1 and 5 then
    raise exception 'Rider rating must be between 1 and 5';
  end if;

  select * into v_order
  from public.orders
  where id=p_order_id
    and customer_id=auth.uid();

  if not found then
    raise exception 'Order not found';
  end if;

  if v_order.status::text not in ('delivered','completed') then
    raise exception 'Order must be delivered before rating';
  end if;

  insert into public.order_ratings(
    order_id,
    customer_id,
    store_id,
    rider_id,
    store_rating,
    rider_rating,
    comment
  )
  values(
    v_order.id,
    auth.uid(),
    v_order.store_id,
    v_order.rider_id,
    p_store_rating,
    case when v_order.rider_id is null then null else p_rider_rating end,
    left(trim(coalesce(p_comment,'')),1000)
  )
  on conflict(order_id) do update set
    store_rating=excluded.store_rating,
    rider_rating=excluded.rider_rating,
    comment=excluded.comment,
    updated_at=now();
end;
$$;

grant execute on function public.submit_order_rating(uuid,integer,integer,text)
to authenticated;

drop function if exists public.get_my_order_rating(uuid);
create or replace function public.get_my_order_rating(p_order_id uuid)
returns table(
  order_id uuid,
  store_rating integer,
  rider_rating integer,
  comment text,
  updated_at timestamptz
)
language sql
security definer
set search_path=public
as $$
  select
    r.order_id,
    r.store_rating,
    r.rider_rating,
    r.comment,
    r.updated_at
  from public.order_ratings r
  where r.order_id=p_order_id
    and r.customer_id=auth.uid()
  limit 1;
$$;

grant execute on function public.get_my_order_rating(uuid) to authenticated;

drop function if exists public.get_store_rating_stats();
create or replace function public.get_store_rating_stats()
returns table(
  store_id uuid,
  rating_avg numeric,
  rating_count bigint
)
language sql
security definer
set search_path=public
as $$
  select
    r.store_id,
    round(avg(r.store_rating)::numeric,2) as rating_avg,
    count(*)::bigint as rating_count
  from public.order_ratings r
  group by r.store_id;
$$;

grant execute on function public.get_store_rating_stats() to authenticated;

drop function if exists public.get_rider_rating_stats(uuid);
create or replace function public.get_rider_rating_stats(p_rider_id uuid default null)
returns table(
  rider_id uuid,
  rating_avg numeric,
  rating_count bigint
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_rider uuid := coalesce(p_rider_id,auth.uid());
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  return query
  select
    r.rider_id,
    round(avg(r.rider_rating)::numeric,2) as rating_avg,
    count(r.rider_rating)::bigint as rating_count
  from public.order_ratings r
  where r.rider_id=v_rider
    and r.rider_rating is not null
  group by r.rider_id;
end;
$$;

grant execute on function public.get_rider_rating_stats(uuid) to authenticated;

-- ---------------------------------------------------------
-- 3) Secure chat/order context:
--    rider/customer name + order items + latest chat preview.
-- ---------------------------------------------------------
drop function if exists public.get_order_chat_context(uuid);
create or replace function public.get_order_chat_context(p_order_id uuid)
returns table(
  order_id uuid,
  order_no text,
  status text,
  store_name text,
  customer_name text,
  rider_name text,
  rider_id uuid,
  item_summary text,
  last_message text,
  last_message_at timestamptz
)
language sql
security definer
set search_path=public
as $$
  select
    o.id,
    o.order_no::text,
    o.status::text,
    coalesce(s.name,'Store')::text,
    coalesce(c.full_name,'Customer')::text,
    coalesce(r.full_name,'Assigned rider')::text,
    o.rider_id,
    coalesce(
      (
        select string_agg(
          oi.quantity::text || '× ' || oi.product_name,
          ', '
          order by oi.product_name
        )
        from public.order_items oi
        where oi.order_id=o.id
      ),
      'Order items'
    )::text,
    coalesce(
      (
        select cm.message
        from public.chat_messages cm
        where cm.order_id=o.id
        order by cm.created_at desc
        limit 1
      ),
      'No messages yet'
    )::text,
    (
      select cm.created_at
      from public.chat_messages cm
      where cm.order_id=o.id
      order by cm.created_at desc
      limit 1
    )
  from public.orders o
  join public.stores s on s.id=o.store_id
  left join public.profiles c on c.id=o.customer_id
  left join public.profiles r on r.id=o.rider_id
  where o.id=p_order_id
    and (
      o.customer_id=auth.uid()
      or o.rider_id=auth.uid()
      or s.owner_id=auth.uid()
      or public.current_user_role()='admin'
    )
  limit 1;
$$;

grant execute on function public.get_order_chat_context(uuid) to authenticated;

-- Grants required by V11.3.
grant usage on schema public to authenticated;
grant select on public.order_ratings to authenticated;
grant select on public.notifications to authenticated;
