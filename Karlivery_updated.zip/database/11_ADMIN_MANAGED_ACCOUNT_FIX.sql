-- =========================================================
-- KARLIVERY V12.2.1 — MANAGED ACCOUNT CREATION FIX
-- Run ONCE after SQL 10, then redeploy admin-users.
-- Corrected PL/pgSQL CASE syntax from V12.2.
-- This avoids direct enum/profile upserts from the Edge Function
-- and provides a service-role-only profile sync helper.
-- =========================================================

create or replace function public.karlivery_service_upsert_profile(
  p_user_id uuid,
  p_email text,
  p_full_name text,
  p_phone text,
  p_role text,
  p_status text default 'active'
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_role public.user_role;
  v_status public.user_status;
begin
  if p_user_id is null then
    raise exception 'p_user_id is required';
  end if;

  case lower(trim(coalesce(p_role, 'customer')))
    when 'customer' then
      v_role := 'customer'::public.user_role;
    when 'store_owner' then
      v_role := 'store_owner'::public.user_role;
    when 'rider' then
      v_role := 'rider'::public.user_role;
    when 'admin' then
      v_role := 'admin'::public.user_role;
    else
      raise exception 'Invalid role: %', p_role;
  end case;

  case lower(trim(coalesce(p_status, 'active')))
    when 'active' then
      v_status := 'active'::public.user_status;
    when 'pending' then
      v_status := 'pending'::public.user_status;
    when 'rejected' then
      v_status := 'rejected'::public.user_status;
    when 'suspended' then
      v_status := 'suspended'::public.user_status;
    else
      raise exception 'Invalid status: %', p_status;
  end case;

  insert into public.profiles(
    id,
    email,
    full_name,
    phone,
    role,
    status,
    updated_at
  )
  values(
    p_user_id,
    lower(trim(coalesce(p_email, ''))),
    trim(coalesce(p_full_name, '')),
    trim(coalesce(p_phone, '')),
    v_role,
    v_status,
    now()
  )
  on conflict(id) do update set
    email = excluded.email,
    full_name = excluded.full_name,
    phone = excluded.phone,
    role = excluded.role,
    status = excluded.status,
    updated_at = now();
end;
$$;

revoke all on function public.karlivery_service_upsert_profile(
  uuid,text,text,text,text,text
) from public, anon, authenticated;

grant execute on function public.karlivery_service_upsert_profile(
  uuid,text,text,text,text,text
) to service_role;

-- Helpful check: your signed-in admin must exist in profiles.
-- This query does NOT change anything; it simply shows admins.
select id, email, role, status
from public.profiles
where role = 'admin'::public.user_role;
