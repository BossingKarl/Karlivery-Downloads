-- Karlivery V19.5 Pasabuy Photo Mode
-- Adds optional shop-level gallery fields and upserts the curated branches used by the new photo-menu flow.

alter table if exists public.pasabuy_shops
  add column if not exists cover_image_url text,
  add column if not exists menu_image_urls jsonb not null default '[]'::jsonb;

insert into public.pasabuy_shops (
  id, name, brand, description, location_label, is_active, sort_order
) values
  ('pasabuy-jollibee-camiling', 'Jollibee Camiling', 'jollibee', 'Chickenjoy, burgers, spaghetti, desserts and breakfast — now shown through Karlivery photo menus.', 'Wishing Well Plaza Bldg., Quezon Avenue cor. Zamora St, Camiling, Tarlac', true, 1),
  ('pasabuy-chowking-camiling', 'Chowking Camiling', 'chowking', 'Photo-menu ordering for Chao Fan, Lauriat, dimsum, noodles and halo-halo.', 'Quezon Avenue cor. Romulo Hwy, Camiling, Tarlac', true, 2),
  ('pasabuy-mcdonalds-mangatarem', 'McDonald''s Mangatarem', 'mcdonalds', 'Browse the menu boards, type your exact order, then Karlivery forwards it to the rider.', 'Zamora St, Mangatarem, Pangasinan', true, 3),
  ('pasabuy-kfc-mangatarem', 'KFC Mangatarem', 'kfc', 'Buckets, meals, burgers, desserts and add-ons shown using photo menu browsing.', 'Romulo Hwy, Barangay Poblacion, Mangatarem, Pangasinan', true, 4),
  ('pasabuy-mang-inasal-mangatarem', 'Mang Inasal Mangatarem', 'mang_inasal', 'Ihaw-Sarap favorites, chicken inasal, BBQ, palabok and halo-halo through photo menus.', 'Mangatarem, Pangasinan', true, 5),
  ('pasabuy-andoks-camiling', 'Andok''s Camiling', 'andoks', 'Litson manok, dokito, liempo, barbecue and other favorites via photo-menu ordering.', 'Camiling, Tarlac', true, 6),
  ('pasabuy-delishcheese-camiling', 'DelishCheese Dough Camiling', 'delishcheese', 'Pizza choices and prices shown in a Karlivery-friendly photo menu view.', 'Arellano St, Camiling, Tarlac', true, 7),
  ('pasabuy-other-store', 'Other / Custom Store', 'custom', 'Type the store name, location and full order if the branch is not yet listed.', 'Store location supplied by customer', true, 99)
on conflict (id) do update set
  name = excluded.name,
  brand = excluded.brand,
  description = excluded.description,
  location_label = excluded.location_label,
  is_active = excluded.is_active,
  sort_order = excluded.sort_order;
