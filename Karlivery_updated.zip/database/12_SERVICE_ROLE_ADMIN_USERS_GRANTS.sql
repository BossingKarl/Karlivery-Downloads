-- =========================================================
-- KARLIVERY V12.2.2 — ADMIN-USERS SERVICE ROLE GRANTS
-- Run ONCE after SQL 11.
-- Fixes: permission denied for table profiles (SQLSTATE 42501)
-- =========================================================

-- The admin-users Edge Function uses the Supabase service_role key.
-- RLS bypass alone does not replace normal PostgreSQL table privileges,
-- so grant only the relations/actions this function actually needs.

grant usage on schema public to service_role;

-- Caller/admin verification + managed account lookup.
grant select on table public.profiles to service_role;

-- Active-order safety checks before hard delete.
grant select on table public.orders to service_role;

-- Seller ownership / active-order checks; seller unlink on hard delete.
grant select, update on table public.stores to service_role;

-- Managed profile writes are performed through this SECURITY DEFINER helper.
grant execute on function public.karlivery_service_upsert_profile(
  uuid, text, text, text, text, text
) to service_role;

-- Verification: all rows below should show true after this script succeeds.
select
  has_schema_privilege('service_role', 'public', 'USAGE') as schema_usage,
  has_table_privilege('service_role', 'public.profiles', 'SELECT') as profiles_select,
  has_table_privilege('service_role', 'public.orders', 'SELECT') as orders_select,
  has_table_privilege('service_role', 'public.stores', 'SELECT') as stores_select,
  has_table_privilege('service_role', 'public.stores', 'UPDATE') as stores_update,
  has_function_privilege(
    'service_role',
    'public.karlivery_service_upsert_profile(uuid,text,text,text,text,text)',
    'EXECUTE'
  ) as profile_rpc_execute;
