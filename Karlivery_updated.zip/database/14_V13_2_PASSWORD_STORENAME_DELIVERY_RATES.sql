-- ============================================================
-- KARLIVERY V13.2 — ALL-USER PASSWORD / STORE NAME / FLEXIBLE DELIVERY RATES
-- Run ONCE after SQL 13.
-- ============================================================

-- ------------------------------------------------------------
-- 1) GLOBAL DELIVERY RATE SETTINGS
-- ------------------------------------------------------------
create table if not exists public.delivery_rate_settings (
  id smallint primary key default 1 check (id = 1),
  poblacion_flat_fee numeric(10,2) not null default 50,
  outside_base_fee numeric(10,2) not null default 50,
  per_started_km_fee numeric(10,2) not null default 10,
  updated_at timestamptz not null default now(),
  updated_by uuid references public.profiles(id) on delete set null,
  constraint delivery_rate_poblacion_nonnegative check (poblacion_flat_fee >= 0),
  constraint delivery_rate_outside_base_nonnegative check (outside_base_fee >= 0),
  constraint delivery_rate_per_km_nonnegative check (per_started_km_fee >= 0)
);

insert into public.delivery_rate_settings(
  id,poblacion_flat_fee,outside_base_fee,per_started_km_fee
)
values (1,50,50,10)
on conflict (id) do nothing;

alter table public.delivery_rate_settings enable row level security;

drop policy if exists "delivery_rates_public_read" on public.delivery_rate_settings;
create policy "delivery_rates_public_read"
on public.delivery_rate_settings
for select
to anon, authenticated
using (true);

-- Public/authenticated read helper used by Admin UI and fee previews.
drop function if exists public.karlivery_delivery_rates();
create or replace function public.karlivery_delivery_rates()
returns jsonb
language sql
security definer
set search_path=public
as $$
  select jsonb_build_object(
    'poblacion_flat_fee', poblacion_flat_fee,
    'outside_base_fee', outside_base_fee,
    'per_started_km_fee', per_started_km_fee,
    'updated_at', updated_at
  )
  from public.delivery_rate_settings
  where id=1;
$$;

grant execute on function public.karlivery_delivery_rates() to anon, authenticated;

-- Admin-only update RPC.
drop function if exists public.admin_save_delivery_rates(numeric,numeric,numeric);
create or replace function public.admin_save_delivery_rates(
  p_poblacion_flat_fee numeric,
  p_outside_base_fee numeric,
  p_per_started_km_fee numeric
)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  if public.current_user_role() <> 'admin' then
    raise exception 'Admin access required';
  end if;

  if coalesce(p_poblacion_flat_fee,-1) < 0
     or coalesce(p_outside_base_fee,-1) < 0
     or coalesce(p_per_started_km_fee,-1) < 0 then
    raise exception 'Delivery rates must be zero or greater';
  end if;

  insert into public.delivery_rate_settings(
    id,poblacion_flat_fee,outside_base_fee,per_started_km_fee,updated_at,updated_by
  )
  values(
    1,
    round(p_poblacion_flat_fee,2),
    round(p_outside_base_fee,2),
    round(p_per_started_km_fee,2),
    now(),
    auth.uid()
  )
  on conflict(id) do update set
    poblacion_flat_fee=excluded.poblacion_flat_fee,
    outside_base_fee=excluded.outside_base_fee,
    per_started_km_fee=excluded.per_started_km_fee,
    updated_at=excluded.updated_at,
    updated_by=excluded.updated_by;
end;
$$;

grant execute on function public.admin_save_delivery_rates(numeric,numeric,numeric)
to authenticated;

-- ------------------------------------------------------------
-- 2) SELLER CAN CHANGE STORE NAME
-- ------------------------------------------------------------
drop function if exists public.seller_update_store_name(uuid,text);
create or replace function public.seller_update_store_name(
  p_store_id uuid,
  p_name text
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_name text := trim(coalesce(p_name,''));
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  if char_length(v_name) < 2 then
    raise exception 'Store name must be at least 2 characters';
  end if;

  if char_length(v_name) > 80 then
    raise exception 'Store name must be 80 characters or less';
  end if;

  if not exists(
    select 1
    from public.stores s
    where s.id=p_store_id
      and (s.owner_id=auth.uid() or public.current_user_role()='admin')
  ) then
    raise exception 'Store not found or access denied';
  end if;

  update public.stores
  set name=v_name,
      updated_at=now()
  where id=p_store_id;
end;
$$;

grant execute on function public.seller_update_store_name(uuid,text)
to authenticated;

-- ------------------------------------------------------------
-- 3) CENTRAL DELIVERY FEE CALCULATION
--    Poblacion: flat fee
--    Outside Poblacion: base + fee per STARTED km
-- ------------------------------------------------------------
drop function if exists public.get_delivery_fee(uuid,uuid);
create or replace function public.get_delivery_fee(
  p_store_id uuid,
  p_address_id uuid
)
returns numeric
language plpgsql
security definer
set search_path=public
as $$
declare
  v_store_lat double precision;
  v_store_lng double precision;
  v_address_lat double precision;
  v_address_lng double precision;
  v_barangay text;
  v_distance_km double precision;
  v_poblacion_fee numeric := 50;
  v_base_fee numeric := 50;
  v_per_km numeric := 10;
begin
  select
    r.poblacion_flat_fee,
    r.outside_base_fee,
    r.per_started_km_fee
  into v_poblacion_fee,v_base_fee,v_per_km
  from public.delivery_rate_settings r
  where r.id=1;

  v_poblacion_fee := coalesce(v_poblacion_fee,50);
  v_base_fee := coalesce(v_base_fee,50);
  v_per_km := coalesce(v_per_km,10);

  select s.latitude,s.longitude
  into v_store_lat,v_store_lng
  from public.stores s
  where s.id=p_store_id;

  select a.latitude,a.longitude,a.barangay
  into v_address_lat,v_address_lng,v_barangay
  from public.addresses a
  where a.id=p_address_id
    and (auth.uid() is null or a.user_id=auth.uid());

  if v_barangay is null then
    raise exception 'Delivery address not found';
  end if;

  if lower(v_barangay) like '%poblacion%' then
    return round(v_poblacion_fee,2);
  end if;

  -- If a GPS coordinate is missing, fall back to the configured outside base fee.
  if v_store_lat is null or v_store_lng is null
     or v_address_lat is null or v_address_lng is null then
    return round(v_base_fee,2);
  end if;

  v_distance_km := 6371 * 2 * asin(sqrt(
    power(sin(radians(v_address_lat-v_store_lat)/2),2)
    + cos(radians(v_store_lat))*cos(radians(v_address_lat))
    * power(sin(radians(v_address_lng-v_store_lng)/2),2)
  ));

  return round(
    v_base_fee + (v_per_km * ceil(greatest(v_distance_km,0))::numeric),
    2
  );
end;
$$;

grant execute on function public.get_delivery_fee(uuid,uuid) to authenticated;

-- ------------------------------------------------------------
-- 4) HOME FEED PREVIEW USES THE SAME ADMIN-CONTROLLED RATES
-- ------------------------------------------------------------
drop function if exists public.karlivery_home_feed(uuid);
create or replace function public.karlivery_home_feed(p_address_id uuid default null)
returns setof jsonb
language sql
security definer
set search_path=public
as $$
with selected_address as (
  select a.id,a.barangay,a.latitude,a.longitude
  from public.addresses a
  where a.id=p_address_id and auth.uid() is not null and a.user_id=auth.uid()
  limit 1
), rates as (
  select
    coalesce(r.poblacion_flat_fee,50)::numeric poblacion_flat_fee,
    coalesce(r.outside_base_fee,50)::numeric outside_base_fee,
    coalesce(r.per_started_km_fee,10)::numeric per_started_km_fee
  from public.delivery_rate_settings r
  where r.id=1
), rating_stats as (
  select r.store_id, round(avg(r.store_rating)::numeric,2) rating_avg, count(*)::bigint rating_count
  from public.order_ratings r group by r.store_id
), popularity as (
  select o.store_id,
    count(*) filter (where o.status::text in ('delivered','completed'))::bigint completed_orders
  from public.orders o group by o.store_id
)
select to_jsonb(s) || jsonb_build_object(
  'rating_avg',rs.rating_avg,
  'rating_count',coalesce(rs.rating_count,0),
  'completed_orders',coalesce(pop.completed_orders,0),
  'distance_km', case
    when a.latitude is null or a.longitude is null or s.latitude is null or s.longitude is null then null
    else round((6371*2*asin(sqrt(
      power(sin(radians(a.latitude-s.latitude)/2),2)+
      cos(radians(s.latitude))*cos(radians(a.latitude))*
      power(sin(radians(a.longitude-s.longitude)/2),2)
    )))::numeric,2) end,
  'delivery_fee_preview', case
    when a.id is null then null
    when lower(coalesce(a.barangay,'')) like '%poblacion%' then rates.poblacion_flat_fee
    when a.latitude is null or a.longitude is null or s.latitude is null or s.longitude is null then rates.outside_base_fee
    else round((rates.outside_base_fee + rates.per_started_km_fee*(ceil(6371*2*asin(sqrt(
      power(sin(radians(a.latitude-s.latitude)/2),2)+
      cos(radians(s.latitude))*cos(radians(a.latitude))*
      power(sin(radians(a.longitude-s.longitude)/2),2)
    )))::numeric))::numeric,2) end,
  'eta_min_minutes', case
    when a.latitude is null or a.longitude is null or s.latitude is null or s.longitude is null then s.prep_min_minutes
    else s.prep_min_minutes + greatest(5,ceil((6371*2*asin(sqrt(
      power(sin(radians(a.latitude-s.latitude)/2),2)+
      cos(radians(s.latitude))*cos(radians(a.latitude))*
      power(sin(radians(a.longitude-s.longitude)/2),2)
    )))/22*60)::integer) end,
  'eta_max_minutes', case
    when a.latitude is null or a.longitude is null or s.latitude is null or s.longitude is null then s.prep_max_minutes
    else s.prep_max_minutes + greatest(8,ceil((6371*2*asin(sqrt(
      power(sin(radians(a.latitude-s.latitude)/2),2)+
      cos(radians(s.latitude))*cos(radians(a.latitude))*
      power(sin(radians(a.longitude-s.longitude)/2),2)
    )))/18*60)::integer) end
)
from public.stores s
left join selected_address a on true
cross join rates
left join rating_stats rs on rs.store_id=s.id
left join popularity pop on pop.store_id=s.id
where coalesce(s.is_approved,false)=true
order by s.is_open desc,coalesce(pop.completed_orders,0) desc,coalesce(rs.rating_avg,0) desc,s.name;
$$;

grant execute on function public.karlivery_home_feed(uuid) to anon,authenticated;

-- ------------------------------------------------------------
-- 5) SANITY CHECK
-- ------------------------------------------------------------
select * from public.delivery_rate_settings where id=1;
