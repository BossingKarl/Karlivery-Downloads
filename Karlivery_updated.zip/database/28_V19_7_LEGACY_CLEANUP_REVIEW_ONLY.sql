-- KARLIVERY V19.7 -- READ-ONLY REVIEW, NOTHING IS DELETED.
-- Take a Supabase backup BEFORE considering any storage or row deletion.
-- Legacy item tables may contain historical customer orders, OCR drafts, FKs, and payment evidence.
SELECT 'pasabuy_shops' AS entity, COUNT(*) AS records FROM public.pasabuy_shops
UNION ALL SELECT 'pasabuy_items', COUNT(*) FROM public.pasabuy_items
UNION ALL SELECT 'pasabuy_categories', COUNT(*) FROM public.pasabuy_categories
UNION ALL SELECT 'pasabuy_item_addons', COUNT(*) FROM public.pasabuy_item_addons
UNION ALL SELECT 'pasabuy_menu_images', COUNT(*) FROM public.pasabuy_menu_images
UNION ALL SELECT 'pasabuy_orders', COUNT(*) FROM public.pasabuy_orders
UNION ALL SELECT 'pasabuy_order_items', COUNT(*) FROM public.pasabuy_order_items
UNION ALL SELECT 'pasabuy_messages', COUNT(*) FROM public.pasabuy_messages;

SELECT id, name, is_active, coordinate_source, menu_image_urls, cover_image_url, logo_url
FROM public.pasabuy_shops ORDER BY name;

-- Find currently UNUSED draft items. These are CANDIDATES ONLY, not safe to delete yet.
SELECT i.id, i.shop_id, i.name, i.is_published
FROM public.pasabuy_items i
WHERE i.is_published = false
AND NOT EXISTS (SELECT 1 FROM public.pasabuy_order_items oi WHERE oi.item_id = i.id)
ORDER BY i.shop_id, i.name LIMIT 500;

-- Review storage consumption by bucket. Stored objects may be referenced by existing orders.
SELECT bucket_id, COUNT(*) AS object_count,
  pg_size_pretty(COALESCE(SUM((metadata->>'size')::bigint),0)) AS estimated_size
FROM storage.objects
WHERE bucket_id LIKE 'pasabuy%' OR bucket_id LIKE '%gcash%'
GROUP BY bucket_id ORDER BY estimated_size DESC;

-- NO DROP / TRUNCATE / DELETE; the app no longer exposes a menu item editor,
-- but dropping legacy tables would break old migrations and historical flows.
