-- Read-only. Does not alter database records.
-- menu_image_urls in Supabase overrides bundled Flutter photos.
select id, name, brand, menu_image_urls, cover_image_url
from public.pasabuy_shops
order by sort_order nulls last, name;
