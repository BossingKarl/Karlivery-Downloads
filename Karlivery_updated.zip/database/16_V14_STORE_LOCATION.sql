-- Karlivery V14: editable store address and pickup pin.
-- Apply after SQL 15 in the Supabase project used by the app.
-- Additive migration. Does not reset rates, orders, users or approvals.
begin;
create or replace function public.seller_update_store_address(
  p_store_id uuid,
  p_address_text text,
  p_barangay text,
  p_latitude double precision,
  p_longitude double precision
) returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null then
    raise exception 'Authentication required' using errcode = '42501';
  end if;
  if not exists (select 1 from public.stores where id = p_store_id and owner_id = auth.uid()) then
    raise exception 'Store not found or not owned by you' using errcode = '42501';
  end if;
  if p_address_text is null or char_length(trim(p_address_text)) < 5
     or char_length(trim(p_address_text)) > 300 then
    raise exception 'Store address must contain 5 to 300 characters';
  end if;
  if p_barangay is null or not (trim(p_barangay) = any (array['Anoling 1st', 'Anoling 2nd', 'Anoling 3rd', 'Bacabac', 'Bacsay', 'Bancay 1st', 'San Isidro', 'Bilad', 'Birbira', 'Bobon Caarosipan', 'Bobon 1st', 'Bobon 2nd', 'Cabanabaan', 'Cacamilingan Norte', 'Cacamilingan Sur', 'Caniag', 'Carael', 'Cayaoan', 'Cayasan', 'Florida', 'Lasong', 'Libueg', 'Malacampa', 'Manaquem', 'Manupeg', 'Marawi', 'Matubog', 'Nagrambacan', 'Nagserialan', 'Palimbo Proper', 'Palimbo Caarosipan', 'Pao 1st', 'Pao 2nd', 'Pao 3rd', 'Papaac', 'Pindangan 1st', 'Pindangan 2nd', 'Poblacion A', 'Poblacion B', 'Poblacion C', 'Poblacion D', 'Poblacion E', 'Poblacion F', 'Poblacion G', 'Poblacion H', 'Poblacion I', 'Poblacion J', 'Sta. Maria', 'Sawat', 'Sinilian 1st', 'Sinilian 2nd', 'Sinilian 3rd', 'Sinilian Cacalibosoan', 'Sinulatan 1st', 'Sinulatan 2nd', 'Surgui 1st', 'Surgui 2nd', 'Surgui 3rd', 'Tambugan', 'Telbang', 'Tuec']::text[])) then
    raise exception 'Select a supported Camiling barangay';
  end if;
  -- NOT BETWEEN rejects NaN and infinities as well as out-of-range values.
  if p_latitude is null or p_longitude is null
     or not (p_latitude between -90 and 90)
     or not (p_longitude between -180 and 180) then
    raise exception 'Valid latitude and longitude are required';
  end if;
  update public.stores
  set address_text = trim(p_address_text), barangay = trim(p_barangay),
      latitude = p_latitude, longitude = p_longitude
  where id = p_store_id and owner_id = auth.uid();
  if not found then
    raise exception 'Store ownership changed; refresh and try again' using errcode = '42501';
  end if;
end;
$$;
revoke all on function public.seller_update_store_address(uuid,text,text,double precision,double precision) from public, anon;
grant execute on function public.seller_update_store_address(uuid,text,text,double precision,double precision) to authenticated;
notify pgrst, 'reload schema';
commit;
