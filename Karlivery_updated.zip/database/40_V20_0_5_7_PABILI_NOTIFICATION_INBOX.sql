-- Karlivery V20.0.5.7: Pabili participant-only inbox notifications.
-- BACK UP the database before running. No deletions or financial changes.
-- Run AFTER migration 36, 37 and the existing Pabili core/notifications tables.
-- The existing rider_claim / rider_set_status / GCash RPCs already insert inbox
-- notifications. These two triggers ONLY cover new orders and Pabili chat.
-- The push-notify Edge Function sends OS/OneSignal push separately.
BEGIN;

-- Protect against duplicate user-triggered OneSignal pushes. Only the trusted
-- service role (Edge Function) may claim these events. No order data is stored.
CREATE TABLE IF NOT EXISTS public.pabili_push_event_claims (
  event_key text PRIMARY KEY,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.pabili_push_event_claims ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.pabili_push_event_claims FROM anon, authenticated;
GRANT SELECT, INSERT, DELETE ON public.pabili_push_event_claims TO service_role;

CREATE OR REPLACE FUNCTION public.karlivery_pabili_new_order_inbox_v507()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $fn$
BEGIN
  IF NEW.customer_id IS NOT NULL THEN
    INSERT INTO public.notifications
      (user_id, order_id, title, message, kind, data, is_read)
    VALUES (
      NEW.customer_id, NULL, 'Pabili request received',
      'Your Pabili request was submitted. We are looking for an available rider.',
      'pasabuy',
      pg_catalog.jsonb_build_object('screen', 'pabili_order',
        'order_type','pabili','pasabuy_order_id', NEW.id,'event','pabili_created'),
      false
    );
  END IF;

  -- Only active/online riders are notified about AVAILABLE Pabili requests.
  -- Exclude the requester; never leak a customer address, phone, or payment info.
  IF NEW.status = 'Waiting for Rider' AND NEW.rider_id IS NULL THEN
    INSERT INTO public.notifications
      (user_id, order_id, title, message, kind, data, is_read)
    SELECT p.id, NULL, 'New Pabili request',
      'A Pabili request is available. Open Deliveries to check and accept it.',
      'pasabuy',
      pg_catalog.jsonb_build_object('screen','pabili_order',
        'order_type','pabili','pasabuy_order_id',NEW.id,'event','pabili_created'),
      false
    FROM public.profiles AS p
    WHERE p.role = 'rider' AND p.status = 'active' AND p.is_online = true
      AND p.id IS DISTINCT FROM NEW.customer_id;
  END IF;
  RETURN NEW;
END;
$fn$;

DROP TRIGGER IF EXISTS karlivery_pabili_new_order_inbox_v507 ON public.pasabuy_orders;
CREATE TRIGGER karlivery_pabili_new_order_inbox_v507
AFTER INSERT ON public.pasabuy_orders
FOR EACH ROW EXECUTE FUNCTION public.karlivery_pabili_new_order_inbox_v507();

CREATE OR REPLACE FUNCTION public.karlivery_pabili_chat_inbox_v507()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $fn$
DECLARE
  v_customer uuid;
  v_rider uuid;
  v_recipient uuid;
BEGIN
  SELECT customer_id, rider_id INTO v_customer, v_rider
  FROM public.pasabuy_orders WHERE id = NEW.order_id;
  IF NOT FOUND OR v_rider IS NULL THEN
    RETURN NEW;
  END IF;
  IF NEW.sender_id = v_customer THEN
    v_recipient := v_rider;
  ELSIF NEW.sender_id = v_rider THEN
    v_recipient := v_customer;
  ELSE
    RETURN NEW;
  END IF;
  IF v_recipient IS NOT NULL AND v_recipient IS DISTINCT FROM NEW.sender_id THEN
    INSERT INTO public.notifications
      (user_id, order_id, title, message, kind, data, is_read)
    VALUES (
      v_recipient, NULL, 'New Pabili chat message',
      LEFT(NEW.message, 140), 'pasabuy_chat',
      pg_catalog.jsonb_build_object('screen','pabili_chat',
        'order_type','pabili','pasabuy_order_id',NEW.order_id,
        'message_id',NEW.id,'event','pabili_chat'),
      false
    );
  END IF;
  RETURN NEW;
END;
$fn$;

DROP TRIGGER IF EXISTS karlivery_pabili_chat_inbox_v507 ON public.pasabuy_messages;
CREATE TRIGGER karlivery_pabili_chat_inbox_v507
AFTER INSERT ON public.pasabuy_messages
FOR EACH ROW EXECUTE FUNCTION public.karlivery_pabili_chat_inbox_v507();

-- The user's existing notifications RLS continues to authorize SELECT access.
-- Neither trigger grants cross-user access to orders or chat.
COMMIT;

-- READ-ONLY verification after the migration:
-- SELECT tgname, tgrelid::regclass FROM pg_trigger
-- WHERE tgname IN ('karlivery_pabili_new_order_inbox_v507',
--   'karlivery_pabili_chat_inbox_v507') AND NOT tgisinternal;
