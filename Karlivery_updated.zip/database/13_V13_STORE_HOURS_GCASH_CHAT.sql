-- ============================================================
-- KARLIVERY V13 — STORE HOURS / GCASH TWO-SIDED CONFIRMATION / ORDER CHAT
-- Run ONCE after the existing Karlivery migrations.
-- ============================================================

-- ------------------------------------------------------------
-- 1) STORE OPENING HOURS
-- ------------------------------------------------------------
alter table public.stores
  add column if not exists schedule_enabled boolean not null default false,
  add column if not exists opening_time time without time zone not null default '08:00',
  add column if not exists closing_time time without time zone not null default '20:00',
  add column if not exists opening_days smallint[] not null default array[1,2,3,4,5,6,7]::smallint[];

do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'stores_opening_days_valid'
  ) then
    alter table public.stores
      add constraint stores_opening_days_valid
      check (
        cardinality(opening_days) between 1 and 7
        and opening_days <@ array[1,2,3,4,5,6,7]::smallint[]
      );
  end if;
end $$;

drop function if exists public.seller_save_opening_hours(uuid,boolean,time,time,smallint[]);
create or replace function public.seller_save_opening_hours(
  p_store_id uuid,
  p_enabled boolean,
  p_opening_time time without time zone,
  p_closing_time time without time zone,
  p_days smallint[]
)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  if not exists (
    select 1 from public.stores s
    where s.id = p_store_id
      and (s.owner_id = auth.uid() or public.current_user_role() = 'admin')
  ) then
    raise exception 'Store not found or access denied';
  end if;

  if p_days is null
     or cardinality(p_days) < 1
     or not (p_days <@ array[1,2,3,4,5,6,7]::smallint[]) then
    raise exception 'Choose at least one valid opening day';
  end if;

  update public.stores
  set schedule_enabled = coalesce(p_enabled,false),
      opening_time = coalesce(p_opening_time,'08:00'::time),
      closing_time = coalesce(p_closing_time,'20:00'::time),
      opening_days = p_days,
      -- Enabling automatic hours also arms the store for orders. The seller can
      -- still use the normal Open Store switch as a temporary emergency close.
      is_open = case when coalesce(p_enabled,false) then true else is_open end,
      updated_at = now()
  where id = p_store_id;
end;
$$;

grant execute on function public.seller_save_opening_hours(
  uuid,boolean,time without time zone,time without time zone,smallint[]
) to authenticated;

-- ------------------------------------------------------------
-- 2) GCASH TWO-SIDED CONFIRMATION
-- Customer confirms "I sent it" after uploading proof.
-- Seller confirms "Payment received" before the order proceeds.
-- Existing payment status / proof workflow remains authoritative.
-- ------------------------------------------------------------
alter table public.orders
  add column if not exists customer_gcash_sent_at timestamptz,
  add column if not exists seller_gcash_received_at timestamptz,
  add column if not exists gcash_rejected_at timestamptz,
  add column if not exists gcash_rejection_reason text;

drop function if exists public.customer_confirm_gcash_sent(uuid);
create or replace function public.customer_confirm_gcash_sent(p_order_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  if not exists (
    select 1 from public.orders o
    where o.id = p_order_id
      and o.customer_id = auth.uid()
      and lower(o.payment_method::text) = 'gcash'
      and nullif(trim(coalesce(o.payment_reference_no,'')),'') is not null
      and nullif(trim(coalesce(o.payment_proof_path,'')),'') is not null
  ) then
    raise exception 'GCash order not found or access denied';
  end if;

  update public.orders
  set customer_gcash_sent_at = coalesce(customer_gcash_sent_at, now()),
      gcash_rejected_at = null,
      gcash_rejection_reason = null,
      updated_at = now()
  where id = p_order_id;
end;
$$;

grant execute on function public.customer_confirm_gcash_sent(uuid) to authenticated;

drop function if exists public.seller_confirm_gcash_received(uuid);
create or replace function public.seller_confirm_gcash_received(p_order_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  if not exists (
    select 1
    from public.orders o
    join public.stores s on s.id = o.store_id
    where o.id = p_order_id
      and lower(o.payment_method::text) = 'gcash'
      and o.customer_gcash_sent_at is not null
      and nullif(trim(coalesce(o.payment_reference_no,'')),'') is not null
      and nullif(trim(coalesce(o.payment_proof_path,'')),'') is not null
      and (s.owner_id = auth.uid() or public.current_user_role() = 'admin')
  ) then
    raise exception 'GCash order not found or access denied';
  end if;

  perform public.seller_verify_payment(p_order_id, true);

  update public.orders
  set seller_gcash_received_at = now(),
      gcash_rejected_at = null,
      gcash_rejection_reason = null,
      updated_at = now()
  where id = p_order_id;
end;
$$;

grant execute on function public.seller_confirm_gcash_received(uuid) to authenticated;

drop function if exists public.seller_reject_gcash_payment(uuid,text);
create or replace function public.seller_reject_gcash_payment(
  p_order_id uuid,
  p_reason text default 'Please check the payment reference or proof and try again.'
)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  if not exists (
    select 1
    from public.orders o
    join public.stores s on s.id = o.store_id
    where o.id = p_order_id
      and lower(o.payment_method::text) = 'gcash'
      and o.customer_gcash_sent_at is not null
      and nullif(trim(coalesce(o.payment_reference_no,'')),'') is not null
      and nullif(trim(coalesce(o.payment_proof_path,'')),'') is not null
      and (s.owner_id = auth.uid() or public.current_user_role() = 'admin')
  ) then
    raise exception 'GCash order not found or access denied';
  end if;

  perform public.seller_verify_payment(p_order_id, false);

  update public.orders
  set customer_gcash_sent_at = null,
      seller_gcash_received_at = null,
      gcash_rejected_at = now(),
      gcash_rejection_reason = nullif(trim(coalesce(p_reason,'')),''),
      updated_at = now()
  where id = p_order_id;
end;
$$;

grant execute on function public.seller_reject_gcash_payment(uuid,text) to authenticated;

-- ------------------------------------------------------------
-- 3) ORDER CHAT FOR CUSTOMER + SELLER + RIDER
-- Chat becomes a shared order conversation so GCash/payment questions
-- can be resolved before a rider is assigned.
-- ------------------------------------------------------------
alter table public.chat_messages enable row level security;

drop policy if exists "v13_order_participants_read_chat" on public.chat_messages;
create policy "v13_order_participants_read_chat"
on public.chat_messages
for select
to authenticated
using (
  exists (
    select 1
    from public.orders o
    join public.stores s on s.id = o.store_id
    where o.id = chat_messages.order_id
      and (
        o.customer_id = auth.uid()
        or o.rider_id = auth.uid()
        or s.owner_id = auth.uid()
        or public.current_user_role() = 'admin'
      )
  )
);

drop policy if exists "v13_order_participants_send_chat" on public.chat_messages;
create policy "v13_order_participants_send_chat"
on public.chat_messages
for insert
to authenticated
with check (
  sender_id = auth.uid()
  and exists (
    select 1
    from public.orders o
    join public.stores s on s.id = o.store_id
    where o.id = chat_messages.order_id
      and (
        o.customer_id = auth.uid()
        or o.rider_id = auth.uid()
        or s.owner_id = auth.uid()
        or public.current_user_role() = 'admin'
      )
  )
);

-- Richer chat context: includes seller identity for the shared order chat.
drop function if exists public.get_order_chat_context(uuid);
create or replace function public.get_order_chat_context(p_order_id uuid)
returns table(
  order_id uuid,
  order_no text,
  status text,
  store_name text,
  customer_name text,
  rider_name text,
  rider_id uuid,
  seller_name text,
  seller_id uuid,
  item_summary text,
  last_message text,
  last_message_at timestamptz
)
language sql
security definer
set search_path=public
as $$
  select
    o.id,
    o.order_no::text,
    o.status::text,
    coalesce(s.name,'Store')::text,
    coalesce(c.full_name,'Customer')::text,
    coalesce(r.full_name,'Assigned rider')::text,
    o.rider_id,
    coalesce(owner_profile.full_name, s.name, 'Seller')::text,
    s.owner_id,
    coalesce(
      (
        select string_agg(
          oi.quantity::text || '× ' || oi.product_name,
          ', '
          order by oi.product_name
        )
        from public.order_items oi
        where oi.order_id=o.id
      ),
      'Order items'
    )::text,
    coalesce(
      (
        select cm.message
        from public.chat_messages cm
        where cm.order_id=o.id
        order by cm.created_at desc
        limit 1
      ),
      'No messages yet'
    )::text,
    (
      select cm.created_at
      from public.chat_messages cm
      where cm.order_id=o.id
      order by cm.created_at desc
      limit 1
    )
  from public.orders o
  join public.stores s on s.id=o.store_id
  left join public.profiles c on c.id=o.customer_id
  left join public.profiles r on r.id=o.rider_id
  left join public.profiles owner_profile on owner_profile.id=s.owner_id
  where o.id=p_order_id
    and (
      o.customer_id=auth.uid()
      or o.rider_id=auth.uid()
      or s.owner_id=auth.uid()
      or public.current_user_role()='admin'
    )
  limit 1;
$$;

grant execute on function public.get_order_chat_context(uuid) to authenticated;
