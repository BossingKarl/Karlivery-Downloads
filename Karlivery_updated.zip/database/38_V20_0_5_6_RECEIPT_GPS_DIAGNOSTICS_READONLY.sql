-- V20.0.5.6 READ-ONLY diagnostics. Does NOT grant permissions or send mail.
-- Run after backing up and applying verified earlier migrations 33, 36, 37.
-- You should not share row-level customer email/coordinates in screenshots.

SELECT to_regclass('public.order_receipt_email_deliveries') AS email_delivery_ledger,
       to_regclass('public.pasabuy_rider_locations') AS pabili_gps_table,
       to_regclass('public.pasabuy_order_items') AS pabili_receipt_items,
       to_regclass('public.order_items') AS local_store_receipt_items;

SELECT table_name, grantee, privilege_type
FROM information_schema.role_table_grants
WHERE table_schema='public'
  AND table_name IN ('pasabuy_rider_locations','pasabuy_order_items','order_items')
  AND grantee='authenticated'
ORDER BY table_name, privilege_type;

SELECT tablename, policyname, cmd, roles
FROM pg_policies
WHERE schemaname='public'
  AND tablename IN ('pasabuy_rider_locations','pasabuy_order_items','order_items')
ORDER BY tablename, policyname;

-- Look up delivery status using the secure Dashboard Table Editor instead
-- of exposing real order IDs or customer emails in support logs.
-- Edge Function: order-status-email logs + Resend delivery logs must be checked.
