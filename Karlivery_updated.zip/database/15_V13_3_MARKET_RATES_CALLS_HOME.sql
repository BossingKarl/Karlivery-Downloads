-- ============================================================
-- KARLIVERY V13.3 — MARKET-BASED DELIVERY / CHAT CALLS / HOME UX
-- Run ONCE after SQL 14.
-- ============================================================

-- ------------------------------------------------------------
-- 1) MARKET-BASED DELIVERY SETTINGS
--    Default rule requested for Camiling:
--      • Base point: Camiling Public Market
--      • First 3 km: PHP 50
--      • Every started +2 km after 3 km: +PHP 15
-- ------------------------------------------------------------
alter table public.delivery_rate_settings
  add column if not exists base_location_name text not null default 'Camiling Public Market',
  add column if not exists base_latitude double precision not null default 15.6861,
  add column if not exists base_longitude double precision not null default 120.4123,
  add column if not exists base_fee numeric(10,2) not null default 50,
  add column if not exists included_radius_km numeric(10,2) not null default 3,
  add column if not exists step_distance_km numeric(10,2) not null default 2,
  add column if not exists step_fee numeric(10,2) not null default 15;

-- Preserve the requested defaults while retaining the older columns for backwards compatibility.
update public.delivery_rate_settings
set
  base_location_name = coalesce(nullif(trim(base_location_name),''), 'Camiling Public Market'),
  base_latitude = coalesce(base_latitude, 15.6861),
  base_longitude = coalesce(base_longitude, 120.4123),
  base_fee = coalesce(base_fee, 50),
  included_radius_km = coalesce(included_radius_km, 3),
  step_distance_km = coalesce(step_distance_km, 2),
  step_fee = coalesce(step_fee, 15)
where id=1;

-- Read helper used by Admin settings and customer fee explanations.
drop function if exists public.karlivery_delivery_rates();
create or replace function public.karlivery_delivery_rates()
returns jsonb
language sql
security definer
set search_path=public
as $$
  select jsonb_build_object(
    'base_location_name', base_location_name,
    'base_latitude', base_latitude,
    'base_longitude', base_longitude,
    'base_fee', base_fee,
    'included_radius_km', included_radius_km,
    'step_distance_km', step_distance_km,
    'step_fee', step_fee,
    -- Legacy aliases kept so an older client does not immediately break.
    'poblacion_flat_fee', base_fee,
    'outside_base_fee', base_fee,
    'per_started_km_fee', step_fee,
    'updated_at', updated_at
  )
  from public.delivery_rate_settings
  where id=1;
$$;

grant execute on function public.karlivery_delivery_rates() to anon, authenticated;

-- New V13.3 admin-only rate update RPC.
drop function if exists public.admin_save_market_delivery_rates(numeric,numeric,numeric,numeric);
create or replace function public.admin_save_market_delivery_rates(
  p_base_fee numeric,
  p_included_radius_km numeric,
  p_step_distance_km numeric,
  p_step_fee numeric
)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  if public.current_user_role() <> 'admin' then
    raise exception 'Admin access required';
  end if;

  if coalesce(p_base_fee,-1) < 0
     or coalesce(p_included_radius_km,0) <= 0
     or coalesce(p_step_distance_km,0) <= 0
     or coalesce(p_step_fee,-1) < 0 then
    raise exception 'Enter valid delivery rate values';
  end if;

  update public.delivery_rate_settings
  set
    base_fee = round(p_base_fee,2),
    included_radius_km = round(p_included_radius_km,2),
    step_distance_km = round(p_step_distance_km,2),
    step_fee = round(p_step_fee,2),
    -- Keep legacy values synchronized for old clients.
    poblacion_flat_fee = round(p_base_fee,2),
    outside_base_fee = round(p_base_fee,2),
    per_started_km_fee = round(p_step_fee,2),
    updated_at = now(),
    updated_by = auth.uid()
  where id=1;
end;
$$;

grant execute on function public.admin_save_market_delivery_rates(numeric,numeric,numeric,numeric)
to authenticated;

-- Optional admin helper if the operational base point needs to be refined later.
drop function if exists public.admin_save_delivery_base_point(text,double precision,double precision);
create or replace function public.admin_save_delivery_base_point(
  p_name text,
  p_latitude double precision,
  p_longitude double precision
)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if auth.uid() is null or public.current_user_role() <> 'admin' then
    raise exception 'Admin access required';
  end if;

  if p_latitude is null or p_latitude < -90 or p_latitude > 90
     or p_longitude is null or p_longitude < -180 or p_longitude > 180 then
    raise exception 'Invalid base coordinates';
  end if;

  update public.delivery_rate_settings
  set
    base_location_name = coalesce(nullif(trim(p_name),''), 'Camiling Public Market'),
    base_latitude = p_latitude,
    base_longitude = p_longitude,
    updated_at = now(),
    updated_by = auth.uid()
  where id=1;
end;
$$;

grant execute on function public.admin_save_delivery_base_point(text,double precision,double precision)
to authenticated;

-- ------------------------------------------------------------
-- 2) AUTHORITATIVE DELIVERY FEE
--    Fee is based on customer pin distance from the configured market base,
--    not seller-to-customer distance.
-- ------------------------------------------------------------
drop function if exists public.get_delivery_fee(uuid,uuid);
create or replace function public.get_delivery_fee(
  p_store_id uuid,
  p_address_id uuid
)
returns numeric
language plpgsql
security definer
set search_path=public
as $$
declare
  v_address_lat double precision;
  v_address_lng double precision;
  v_base_lat double precision := 15.6861;
  v_base_lng double precision := 120.4123;
  v_base_fee numeric := 50;
  v_included numeric := 3;
  v_step_km numeric := 2;
  v_step_fee numeric := 15;
  v_distance_km numeric;
  v_extra_steps numeric;
begin
  -- Keep the store parameter for API compatibility and ensure the store exists.
  if not exists(select 1 from public.stores s where s.id=p_store_id) then
    raise exception 'Store not found';
  end if;

  select
    r.base_latitude,
    r.base_longitude,
    r.base_fee,
    r.included_radius_km,
    r.step_distance_km,
    r.step_fee
  into
    v_base_lat,
    v_base_lng,
    v_base_fee,
    v_included,
    v_step_km,
    v_step_fee
  from public.delivery_rate_settings r
  where r.id=1;

  v_base_lat := coalesce(v_base_lat,15.6861);
  v_base_lng := coalesce(v_base_lng,120.4123);
  v_base_fee := coalesce(v_base_fee,50);
  v_included := greatest(coalesce(v_included,3),0.1);
  v_step_km := greatest(coalesce(v_step_km,2),0.1);
  v_step_fee := coalesce(v_step_fee,15);

  select a.latitude,a.longitude
  into v_address_lat,v_address_lng
  from public.addresses a
  where a.id=p_address_id
    and (
      a.user_id=auth.uid()
      or public.current_user_role()='admin'
    );

  if not found then
    raise exception 'Delivery address not found';
  end if;

  -- Older saved addresses without a GPS pin fall back to the base fee.
  if v_address_lat is null or v_address_lng is null then
    return round(v_base_fee,2);
  end if;

  v_distance_km := (
    6371 * 2 * asin(sqrt(
      power(sin(radians(v_address_lat-v_base_lat)/2),2)
      + cos(radians(v_base_lat))*cos(radians(v_address_lat))
      * power(sin(radians(v_address_lng-v_base_lng)/2),2)
    ))
  )::numeric;

  if v_distance_km <= v_included then
    return round(v_base_fee,2);
  end if;

  v_extra_steps := ceil((v_distance_km-v_included)/v_step_km);
  return round(v_base_fee + (v_extra_steps*v_step_fee),2);
end;
$$;

grant execute on function public.get_delivery_fee(uuid,uuid) to authenticated;

-- ------------------------------------------------------------
-- 3) HOME FEED
--    Store distance remains seller->customer for useful browsing,
--    while delivery fee follows the Camiling Market base rule.
-- ------------------------------------------------------------
drop function if exists public.karlivery_home_feed(uuid);
create or replace function public.karlivery_home_feed(p_address_id uuid default null)
returns setof jsonb
language sql
security definer
set search_path=public
as $$
with selected_address as (
  select a.id,a.barangay,a.latitude,a.longitude
  from public.addresses a
  where a.id=p_address_id
    and auth.uid() is not null
    and a.user_id=auth.uid()
  limit 1
), rates as (
  select
    coalesce(r.base_location_name,'Camiling Public Market')::text base_location_name,
    coalesce(r.base_latitude,15.6861)::double precision base_latitude,
    coalesce(r.base_longitude,120.4123)::double precision base_longitude,
    coalesce(r.base_fee,50)::numeric base_fee,
    greatest(coalesce(r.included_radius_km,3),0.1)::numeric included_radius_km,
    greatest(coalesce(r.step_distance_km,2),0.1)::numeric step_distance_km,
    coalesce(r.step_fee,15)::numeric step_fee
  from public.delivery_rate_settings r
  where r.id=1
), rating_stats as (
  select r.store_id, round(avg(r.store_rating)::numeric,2) rating_avg, count(*)::bigint rating_count
  from public.order_ratings r group by r.store_id
), popularity as (
  select o.store_id,
    count(*) filter (where o.status::text in ('delivered','completed'))::bigint completed_orders
  from public.orders o group by o.store_id
), distance_calc as (
  select
    s.*,
    a.id selected_address_id,
    a.latitude address_latitude,
    a.longitude address_longitude,
    case
      when a.latitude is null or a.longitude is null or s.latitude is null or s.longitude is null then null
      else 6371*2*asin(sqrt(
        power(sin(radians(a.latitude-s.latitude)/2),2)+
        cos(radians(s.latitude))*cos(radians(a.latitude))*
        power(sin(radians(a.longitude-s.longitude)/2),2)
      ))
    end store_distance_km,
    case
      when a.latitude is null or a.longitude is null then null
      else 6371*2*asin(sqrt(
        power(sin(radians(a.latitude-rates.base_latitude)/2),2)+
        cos(radians(rates.base_latitude))*cos(radians(a.latitude))*
        power(sin(radians(a.longitude-rates.base_longitude)/2),2)
      ))
    end market_distance_km,
    rates.base_location_name,
    rates.base_fee,
    rates.included_radius_km,
    rates.step_distance_km,
    rates.step_fee
  from public.stores s
  left join selected_address a on true
  cross join rates
)
select to_jsonb(s) || jsonb_build_object(
  'rating_avg',rs.rating_avg,
  'rating_count',coalesce(rs.rating_count,0),
  'completed_orders',coalesce(pop.completed_orders,0),
  'distance_km', case when s.store_distance_km is null then null else round(s.store_distance_km::numeric,2) end,
  'delivery_distance_km', case when s.market_distance_km is null then null else round(s.market_distance_km::numeric,2) end,
  'delivery_base_name',s.base_location_name,
  'delivery_fee_preview', case
    when s.selected_address_id is null then null
    when s.market_distance_km is null then s.base_fee
    when s.market_distance_km <= s.included_radius_km then s.base_fee
    else round(
      s.base_fee + ceil((s.market_distance_km::numeric-s.included_radius_km)/s.step_distance_km)*s.step_fee,
      2
    ) end,
  'eta_min_minutes', case
    when s.store_distance_km is null then s.prep_min_minutes
    else s.prep_min_minutes + greatest(5,ceil(s.store_distance_km/22*60)::integer) end,
  'eta_max_minutes', case
    when s.store_distance_km is null then s.prep_max_minutes
    else s.prep_max_minutes + greatest(8,ceil(s.store_distance_km/18*60)::integer) end
)
from distance_calc s
left join rating_stats rs on rs.store_id=s.id
left join popularity pop on pop.store_id=s.id
where coalesce(s.is_approved,false)=true
order by s.is_open desc,coalesce(pop.completed_orders,0) desc,coalesce(rs.rating_avg,0) desc,s.name;
$$;

grant execute on function public.karlivery_home_feed(uuid) to anon,authenticated;

-- ------------------------------------------------------------
-- 4) ORDER CHAT CALL DIRECTORY
--    Phone numbers are returned only to authenticated users who are already
--    authorized to participate in/view that order chat.
-- ------------------------------------------------------------
drop function if exists public.get_order_chat_context(uuid);
create or replace function public.get_order_chat_context(p_order_id uuid)
returns table(
  order_id uuid,
  order_no text,
  status text,
  store_name text,
  customer_name text,
  customer_id uuid,
  customer_phone text,
  rider_name text,
  rider_id uuid,
  rider_phone text,
  seller_name text,
  seller_id uuid,
  seller_phone text,
  item_summary text,
  last_message text,
  last_message_at timestamptz
)
language sql
security definer
set search_path=public
as $$
  select
    o.id,
    o.order_no::text,
    o.status::text,
    coalesce(s.name,'Store')::text,
    coalesce(c.full_name,'Customer')::text,
    o.customer_id,
    coalesce(c.phone,'')::text,
    coalesce(r.full_name,'Assigned rider')::text,
    o.rider_id,
    coalesce(r.phone,'')::text,
    coalesce(owner_profile.full_name, s.name, 'Seller')::text,
    s.owner_id,
    coalesce(nullif(owner_profile.phone,''),nullif(s.phone,''),'')::text,
    coalesce(
      (
        select string_agg(
          oi.quantity::text || '× ' || oi.product_name,
          ', '
          order by oi.product_name
        )
        from public.order_items oi
        where oi.order_id=o.id
      ),
      'Order items'
    )::text,
    coalesce(
      (
        select cm.message
        from public.chat_messages cm
        where cm.order_id=o.id
        order by cm.created_at desc
        limit 1
      ),
      'No messages yet'
    )::text,
    (
      select cm.created_at
      from public.chat_messages cm
      where cm.order_id=o.id
      order by cm.created_at desc
      limit 1
    )
  from public.orders o
  join public.stores s on s.id=o.store_id
  left join public.profiles c on c.id=o.customer_id
  left join public.profiles r on r.id=o.rider_id
  left join public.profiles owner_profile on owner_profile.id=s.owner_id
  where o.id=p_order_id
    and (
      o.customer_id=auth.uid()
      or o.rider_id=auth.uid()
      or s.owner_id=auth.uid()
      or public.current_user_role()='admin'
    )
  limit 1;
$$;

grant execute on function public.get_order_chat_context(uuid) to authenticated;

-- ------------------------------------------------------------
-- 5) SANITY CHECK
-- ------------------------------------------------------------
select
  base_location_name,
  base_latitude,
  base_longitude,
  base_fee,
  included_radius_km,
  step_distance_km,
  step_fee
from public.delivery_rate_settings
where id=1;
