-- KARLIVERY V19.7 - apply once AFTER database/24_V19_5_PASABUY_PHOTO_MODE.sql
-- Safe/idempotent: DOES NOT DROP any table, images, orders, items, or historical records.
-- IMPORTANT: Apply to a backed-up database; exact pickup pins need admin confirmation.
BEGIN;

-- Self-healing prerequisite: the V19.3 coordinate-column migration may have been skipped.
-- No existing store rows are overwritten or removed.
ALTER TABLE public.pasabuy_shops
  ADD COLUMN IF NOT EXISTS latitude double precision,
  ADD COLUMN IF NOT EXISTS longitude double precision;

ALTER TABLE public.pasabuy_shops
  ADD COLUMN IF NOT EXISTS coordinate_source text NOT NULL DEFAULT 'unverified';
ALTER TABLE public.pasabuy_orders ALTER COLUMN handling_fee SET DEFAULT 20;

-- No queue/preparation ETA in Pasabuy, for new or existing shops.
UPDATE public.pasabuy_shops SET estimated_buying_time = NULL
WHERE estimated_buying_time IS NOT NULL;

-- Preserve both historical and new IDs. Old Mangatarem row is hidden, never deleted.
UPDATE public.pasabuy_shops
SET is_active = false, estimated_buying_time = NULL
WHERE id = 'pasabuy-mang-inasal-mangatarem';

INSERT INTO public.pasabuy_shops (id, name, brand, description, location_label, is_active, sort_order, coordinate_source)
VALUES ('pasabuy-mang-inasal-sta-ignacia', 'Mang Inasal Sta. Ignacia', 'mang_inasal',
        'Chicken Inasal, Pork BBQ, Halo-Halo and family meals. Type your order for the rider.',
        'Sta. Ignacia, Tarlac', true, 5, 'unverified')
ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  location_label = EXCLUDED.location_label,
  is_active = true,
  estimated_buying_time = NULL,
  sort_order = EXCLUDED.sort_order;

-- Display only the municipality in the customer UI; the database has a pickup pin.
-- Map positions below are MUNICIPAL/TOWN CENTER APPROXIMATIONS, NOT exact branches.
-- Exact pickup entrance coordinates must be checked by an admin and marked confirmed.
UPDATE public.pasabuy_shops SET latitude = 15.6865, longitude = 120.4147,
    coordinate_source = 'town_center_estimate'
WHERE id IN ('pasabuy-jollibee-camiling','pasabuy-chowking-camiling',
             'pasabuy-andoks-camiling','pasabuy-delishcheese-camiling')
  AND (latitude IS NULL OR longitude IS NULL);

UPDATE public.pasabuy_shops SET latitude = 15.7885, longitude = 120.2939,
    coordinate_source = 'town_center_estimate'
WHERE id IN ('pasabuy-mcdonalds-mangatarem','pasabuy-kfc-mangatarem')
  AND (latitude IS NULL OR longitude IS NULL);

UPDATE public.pasabuy_shops SET latitude = 15.6162, longitude = 120.4359,
    coordinate_source = 'town_center_estimate'
WHERE id = 'pasabuy-mang-inasal-sta-ignacia'
  AND (latitude IS NULL OR longitude IS NULL);

-- Historical coordinates without verification remain unverified.
UPDATE public.pasabuy_shops SET coordinate_source = 'unverified'
WHERE id = 'pasabuy-other-store' AND coordinate_source <> 'admin_confirmed';

-- Store photo uploads, public READ; WRITE restricted to actual admin and own uid folder.
INSERT INTO storage.buckets (id, name, public)
VALUES ('pasabuy-gallery', 'pasabuy-gallery', true)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "karlivery_pasabuys_gallery_admin_insert" ON storage.objects;
CREATE POLICY "karlivery_pasabuys_gallery_admin_insert" ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (
    bucket_id = 'pasabuy-gallery'
    AND public.current_user_role() = 'admin'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );
DROP POLICY IF EXISTS "karlivery_pasabuys_gallery_admin_update" ON storage.objects;
CREATE POLICY "karlivery_pasabuys_gallery_admin_update" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'pasabuy-gallery' AND public.current_user_role() = 'admin'
         AND (storage.foldername(name))[1] = auth.uid()::text)
  WITH CHECK (bucket_id = 'pasabuy-gallery' AND public.current_user_role() = 'admin'
              AND (storage.foldername(name))[1] = auth.uid()::text);

-- Recalculate distance/charges on SERVER; client quote is display only.
-- Straight-line (Haversine) municipal/reference distance, not road route.
CREATE OR REPLACE FUNCTION public.pasabuy_validate_and_quote_v19_7()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  s record;
  a record;
  x double precision;
  km double precision;
BEGIN
  SELECT latitude, longitude, coordinate_source INTO s
  FROM public.pasabuy_shops WHERE id = NEW.shop_id AND is_active = true;
  IF NOT FOUND OR s.latitude IS NULL OR s.longitude IS NULL
     OR s.coordinate_source IS DISTINCT FROM 'admin_confirmed' THEN
    RAISE EXCEPTION 'Pasabuy pickup GPS must be confirmed by admin before checkout';
  END IF;

  SELECT latitude, longitude, user_id INTO a FROM public.addresses WHERE id = NEW.address_id;
  IF NOT FOUND OR a.latitude IS NULL OR a.longitude IS NULL THEN
    RAISE EXCEPTION 'Please choose a delivery address with an accurate map pin';
  END IF;
  IF a.user_id IS DISTINCT FROM NEW.customer_id THEN
    RAISE EXCEPTION 'Delivery address does not belong to this customer';
  END IF;

  IF s.latitude NOT BETWEEN -90 AND 90 OR a.latitude NOT BETWEEN -90 AND 90
     OR s.longitude NOT BETWEEN -180 AND 180 OR a.longitude NOT BETWEEN -180 AND 180 THEN
    RAISE EXCEPTION 'Coordinates outside valid GPS range';
  END IF;
  x := POWER(SIN(RADIANS(a.latitude - s.latitude) / 2), 2)
      + COS(RADIANS(s.latitude)) * COS(RADIANS(a.latitude))
      * POWER(SIN(RADIANS(a.longitude - s.longitude) / 2), 2);
  km := 6371.0 * 2 * ASIN(SQRT(GREATEST(0.0, LEAST(1.0, x))));

  NEW.handling_fee := 20;
  NEW.delivery_fee := CASE WHEN km <= 3 THEN 50
                        ELSE 50 + CEIL((km - 3) / 2.0) * 15 END;
  NEW.total_amount := NEW.subtotal + NEW.handling_fee + NEW.delivery_fee;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS pasabuy_quote_new_order_v19_7 ON public.pasabuy_orders;
CREATE TRIGGER pasabuy_quote_new_order_v19_7
  BEFORE INSERT ON public.pasabuy_orders
  FOR EACH ROW EXECUTE FUNCTION public.pasabuy_validate_and_quote_v19_7();

COMMIT;

-- Review before launch:
SELECT id, name, location_label, latitude, longitude, coordinate_source, is_active
FROM public.pasabuy_shops ORDER BY sort_order, name;
-- Look for town_center_estimate/unverified: set actual pin and mark admin_confirmed in Pasabuy Studio.
