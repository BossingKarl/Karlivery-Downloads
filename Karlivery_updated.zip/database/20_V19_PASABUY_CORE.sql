-- Karlivery V19 Pasabuy core schema
-- Run this after the previous Karlivery SQL files.

create table if not exists public.pasabuy_shops (
  id text primary key,
  name text not null,
  brand text,
  description text,
  location_label text,
  logo_url text,
  source text,
  estimated_buying_time text,
  is_active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.pasabuy_categories (
  id text primary key,
  shop_id text not null references public.pasabuy_shops(id) on delete cascade,
  name text not null,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  unique (shop_id, name)
);

create table if not exists public.pasabuy_items (
  id text primary key,
  shop_id text not null references public.pasabuy_shops(id) on delete cascade,
  category_id text references public.pasabuy_categories(id) on delete set null,
  name text not null,
  price numeric(10,2),
  image_url text,
  source_type text default 'manual',
  source_image_url text,
  is_published boolean not null default false,
  is_available boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.pasabuy_item_addons (
  id text primary key,
  item_id text not null references public.pasabuy_items(id) on delete cascade,
  name text not null,
  price numeric(10,2) not null default 0,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.pasabuy_menu_images (
  id text primary key,
  shop_id text not null references public.pasabuy_shops(id) on delete cascade,
  image_url text,
  source_label text,
  upload_notes text,
  imported_json jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.pasabuy_orders (
  id text primary key default ('PB-' || replace(gen_random_uuid()::text, '-', '')),
  customer_id uuid,
  shop_id text not null references public.pasabuy_shops(id),
  address_id uuid,
  rider_id uuid,
  payment_method text not null default 'COD',
  payment_status text not null default 'unpaid',
  status text not null default 'Waiting for Rider',
  custom_request text,
  notes text,
  subtotal numeric(10,2) not null default 0,
  handling_fee numeric(10,2) not null default 10,
  delivery_fee numeric(10,2) not null default 50,
  total_amount numeric(10,2) not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.pasabuy_order_items (
  id text primary key default ('PBI-' || replace(gen_random_uuid()::text, '-', '')),
  order_id text not null references public.pasabuy_orders(id) on delete cascade,
  item_id text,
  item_name text not null,
  item_price numeric(10,2) not null default 0,
  quantity integer not null default 1,
  note text,
  created_at timestamptz not null default now()
);

create table if not exists public.pasabuy_order_item_addons (
  id text primary key default ('PBIA-' || replace(gen_random_uuid()::text, '-', '')),
  order_item_id text not null references public.pasabuy_order_items(id) on delete cascade,
  addon_name text not null,
  addon_price numeric(10,2) not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.pasabuy_messages (
  id text primary key default ('PBM-' || replace(gen_random_uuid()::text, '-', '')),
  order_id text not null references public.pasabuy_orders(id) on delete cascade,
  sender_id uuid,
  sender_role text,
  message text not null,
  created_at timestamptz not null default now()
);

create index if not exists idx_pasabuy_items_shop on public.pasabuy_items(shop_id);
create index if not exists idx_pasabuy_orders_customer on public.pasabuy_orders(customer_id);
create index if not exists idx_pasabuy_orders_status on public.pasabuy_orders(status);
create index if not exists idx_pasabuy_messages_order on public.pasabuy_messages(order_id, created_at);

alter table public.pasabuy_shops enable row level security;
alter table public.pasabuy_categories enable row level security;
alter table public.pasabuy_items enable row level security;
alter table public.pasabuy_item_addons enable row level security;
alter table public.pasabuy_menu_images enable row level security;
alter table public.pasabuy_orders enable row level security;
alter table public.pasabuy_order_items enable row level security;
alter table public.pasabuy_order_item_addons enable row level security;
alter table public.pasabuy_messages enable row level security;

-- Simplified policies. Adjust later if your project already has a role-aware policy framework.
do $$ begin
  create policy "pasabuy shops public read" on public.pasabuy_shops for select using (is_active = true);
exception when duplicate_object then null; end $$;

do $$ begin
  create policy "pasabuy categories public read" on public.pasabuy_categories for select using (true);
exception when duplicate_object then null; end $$;

do $$ begin
  create policy "pasabuy items public read" on public.pasabuy_items for select using (is_published = true and is_available = true);
exception when duplicate_object then null; end $$;

do $$ begin
  create policy "pasabuy addons public read" on public.pasabuy_item_addons for select using (true);
exception when duplicate_object then null; end $$;

do $$ begin
  create policy "pasabuy orders own read" on public.pasabuy_orders for select using (auth.uid() = customer_id);
exception when duplicate_object then null; end $$;

do $$ begin
  create policy "pasabuy orders own write" on public.pasabuy_orders for insert with check (auth.uid() = customer_id);
exception when duplicate_object then null; end $$;

do $$ begin
  create policy "pasabuy order items own write" on public.pasabuy_order_items for insert with check (true);
exception when duplicate_object then null; end $$;

do $$ begin
  create policy "pasabuy order item addons own write" on public.pasabuy_order_item_addons for insert with check (true);
exception when duplicate_object then null; end $$;

do $$ begin
  create policy "pasabuy messages read" on public.pasabuy_messages for select using (true);
exception when duplicate_object then null; end $$;

do $$ begin
  create policy "pasabuy messages write" on public.pasabuy_messages for insert with check (true);
exception when duplicate_object then null; end $$;

-- Admin/service role should still be used for full management.
