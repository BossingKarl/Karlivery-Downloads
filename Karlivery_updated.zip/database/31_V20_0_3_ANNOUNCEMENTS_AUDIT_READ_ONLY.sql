-- Karlivery V20.0.3: READ ONLY. Review actual audience delivery from the past 7 days.
-- Role filtering uses the existing public.profiles table. No DB migration needed.
SELECT
  n.title,
  n.created_at::date AS sent_date,
  n.data->'target_roles' AS selected_roles_v20_0_3,
  n.data->>'target_role' AS legacy_role_v20_0_2,
  p.role AS recipient_role,
  COUNT(*) AS inbox_rows
FROM public.notifications n
JOIN public.profiles p ON p.id = n.user_id
WHERE n.kind = 'announcement'
  AND n.created_at >= now() - interval '7 days'
GROUP BY n.title, n.created_at::date, n.data->'target_roles',
         n.data->>'target_role', p.role
ORDER BY sent_date DESC, n.title, p.role;

-- After V20.0.3, this MUST return zero rows for correctly targeted sends.
-- If it returns rows, do not broadcast again until the issue is investigated.
SELECT
  n.id, n.created_at, n.title, p.role AS actual_role,
  n.data->'target_roles' AS announced_roles
FROM public.notifications n
JOIN public.profiles p ON p.id = n.user_id
WHERE n.kind = 'announcement'
  AND n.data ? 'target_roles'
  AND jsonb_typeof(n.data->'target_roles') = 'array'
  AND NOT (n.data->'target_roles' ? p.role)
ORDER BY n.created_at DESC
LIMIT 100;
