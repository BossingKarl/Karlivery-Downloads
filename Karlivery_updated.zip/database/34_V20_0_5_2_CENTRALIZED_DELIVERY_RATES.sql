-- KARLIVERY V20.0.5.2 - Centralized store/Pabili GPS delivery pricing.
-- Prerequisite: migrations 15, 27 and 33 already applied, tables populated.
-- REVIEW and BACK UP database BEFORE running. Only NEW order inserts affected.
-- Does not recalculate older order amounts, rider settlements or emails.
-- GPS distance is haversine (straight-line), NOT driving kilometers.
BEGIN;

-- Safe prerequisite recovery for sites where migration 33 failed or was
-- only partially applied. Do not populate or recalculate historical orders.
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_distance_km numeric(10,2);
ALTER TABLE public.pasabuy_orders ADD COLUMN IF NOT EXISTS delivery_distance_km numeric(10,2);
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_rate_snapshot jsonb;
ALTER TABLE public.pasabuy_orders ADD COLUMN IF NOT EXISTS delivery_rate_snapshot jsonb;

-- Exactly one authoritative fee rule, read from settings id=1.
CREATE OR REPLACE FUNCTION public.karlivery_delivery_rate_card(p_distance_km numeric)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE
  r record;
  v_steps numeric;
BEGIN
  IF p_distance_km IS NULL OR p_distance_km < 0 OR p_distance_km > 40050 THEN
    RAISE EXCEPTION 'Invalid GPS distance';
  END IF;
  SELECT base_fee, included_radius_km, step_distance_km, step_fee
    INTO r FROM public.delivery_rate_settings WHERE id = 1;
  IF NOT FOUND OR r.base_fee IS NULL OR r.included_radius_km IS NULL OR
     r.step_distance_km IS NULL OR r.step_fee IS NULL OR
     r.base_fee < 0 OR r.included_radius_km <= 0 OR
     r.step_distance_km <= 0 OR r.step_fee < 0 THEN
    RAISE EXCEPTION 'Admin delivery rates are unavailable or invalid';
  END IF;
  v_steps := ceil(greatest(0, (p_distance_km - r.included_radius_km) / r.step_distance_km));
  RETURN jsonb_build_object(
    'method', 'gps_straight_line',
    'delivery_distance_km', round(p_distance_km, 2),
    'base_fee', r.base_fee,
    'included_radius_km', r.included_radius_km,
    'step_distance_km', r.step_distance_km,
    'step_fee', r.step_fee,
    'extra_steps', v_steps,
    'delivery_fee', round(r.base_fee + v_steps * r.step_fee, 2)
  );
END;
$$;
REVOKE ALL ON FUNCTION public.karlivery_delivery_rate_card(numeric) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.karlivery_delivery_rate_card(numeric) TO authenticated;

CREATE OR REPLACE FUNCTION public.karlivery_delivery_fee_for_km(p_distance_km numeric)
RETURNS numeric LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT (public.karlivery_delivery_rate_card(p_distance_km)->>'delivery_fee')::numeric;
$$;
REVOKE ALL ON FUNCTION public.karlivery_delivery_fee_for_km(numeric) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.karlivery_delivery_fee_for_km(numeric) TO authenticated;

-- Authenticated customer-only Pabili quote from CONFIRMED pickup pin to owned GPS address.
CREATE OR REPLACE FUNCTION public.karlivery_pabili_delivery_quote(p_shop_id text, p_address_id uuid)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE
  s record;
  a record;
  v_part double precision;
  v_km numeric;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Sign in to quote delivery'; END IF;
  SELECT latitude, longitude, coordinate_source, is_active
    INTO s FROM public.pasabuy_shops WHERE id = p_shop_id;
  IF NOT FOUND OR NOT coalesce(s.is_active, false) OR
     s.coordinate_source IS DISTINCT FROM 'admin_confirmed' OR
     s.latitude IS NULL OR s.longitude IS NULL THEN
    RAISE EXCEPTION 'Admin-confirmed Pabili pickup pin required';
  END IF;
  SELECT latitude, longitude INTO a FROM public.addresses
    WHERE id = p_address_id AND user_id = auth.uid();
  IF NOT FOUND OR a.latitude IS NULL OR a.longitude IS NULL THEN
    RAISE EXCEPTION 'Your delivery address needs a GPS pin';
  END IF;
  IF s.latitude NOT BETWEEN -90 AND 90 OR a.latitude NOT BETWEEN -90 AND 90 OR
     s.longitude NOT BETWEEN -180 AND 180 OR a.longitude NOT BETWEEN -180 AND 180 THEN
    RAISE EXCEPTION 'Invalid GPS coordinates';
  END IF;
  v_part := power(sin(radians(a.latitude - s.latitude) / 2), 2)
    + cos(radians(s.latitude)) * cos(radians(a.latitude))
    * power(sin(radians(a.longitude - s.longitude) / 2), 2);
  v_km := (6371.0 * 2 * asin(sqrt(greatest(0.0, least(1.0, v_part)))))::numeric;
  RETURN public.karlivery_delivery_rate_card(v_km);
END;
$$;
REVOKE ALL ON FUNCTION public.karlivery_pabili_delivery_quote(text,uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.karlivery_pabili_delivery_quote(text,uuid) TO authenticated;

-- Regular store quote uses same rate card; preserve strict owned-address checks.
CREATE OR REPLACE FUNCTION public.get_delivery_fee(p_store_id uuid, p_address_id uuid)
RETURNS numeric LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE
  s record;
  a record;
  v_part double precision;
  v_km numeric;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Sign in to quote delivery'; END IF;
  SELECT latitude, longitude INTO s FROM public.stores
    WHERE id = p_store_id AND is_approved = true;
  IF NOT FOUND OR s.latitude IS NULL OR s.longitude IS NULL THEN
    RAISE EXCEPTION 'Store pickup GPS must be set before delivery pricing';
  END IF;
  SELECT latitude, longitude INTO a FROM public.addresses
    WHERE id = p_address_id AND (user_id = auth.uid() OR public.current_user_role() = 'admin');
  IF NOT FOUND OR a.latitude IS NULL OR a.longitude IS NULL THEN
    RAISE EXCEPTION 'Select a delivery address with a GPS map pin';
  END IF;
  IF s.latitude NOT BETWEEN -90 AND 90 OR a.latitude NOT BETWEEN -90 AND 90 OR
     s.longitude NOT BETWEEN -180 AND 180 OR a.longitude NOT BETWEEN -180 AND 180 THEN
    RAISE EXCEPTION 'Invalid GPS coordinates';
  END IF;
  v_part := power(sin(radians(a.latitude - s.latitude) / 2), 2)
    + cos(radians(s.latitude)) * cos(radians(a.latitude))
    * power(sin(radians(a.longitude - s.longitude) / 2), 2);
  v_km := (6371.0 * 2 * asin(sqrt(greatest(0.0, least(1.0, v_part)))))::numeric;
  RETURN public.karlivery_delivery_fee_for_km(v_km);
END;
$$;
GRANT EXECUTE ON FUNCTION public.get_delivery_fee(uuid,uuid) TO authenticated;

-- Pabili INSERT: authoritative recomputation, price mismatch blocks a stale checkout.
CREATE OR REPLACE FUNCTION public.pasabuy_validate_and_quote_v19_7()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  s record;
  a record;
  v_part double precision;
  v_km numeric;
  v_rate jsonb;
  v_fee numeric;
BEGIN
  SELECT latitude, longitude, coordinate_source, is_active INTO s
  FROM public.pasabuy_shops WHERE id = NEW.shop_id;
  IF NOT FOUND OR NOT coalesce(s.is_active, false) OR
     s.coordinate_source IS DISTINCT FROM 'admin_confirmed' OR
     s.latitude IS NULL OR s.longitude IS NULL THEN
    RAISE EXCEPTION 'Pabili pickup GPS must be confirmed by admin before checkout';
  END IF;
  SELECT latitude, longitude, user_id INTO a FROM public.addresses WHERE id = NEW.address_id;
  IF NOT FOUND OR a.latitude IS NULL OR a.longitude IS NULL OR
     a.user_id IS DISTINCT FROM NEW.customer_id OR NEW.customer_id IS DISTINCT FROM auth.uid() THEN
    RAISE EXCEPTION 'Delivery address must belong to the signed-in customer and have a GPS pin';
  END IF;
  IF s.latitude NOT BETWEEN -90 AND 90 OR a.latitude NOT BETWEEN -90 AND 90 OR
     s.longitude NOT BETWEEN -180 AND 180 OR a.longitude NOT BETWEEN -180 AND 180 THEN
    RAISE EXCEPTION 'Invalid GPS coordinates';
  END IF;
  v_part := power(sin(radians(a.latitude - s.latitude) / 2), 2)
    + cos(radians(s.latitude)) * cos(radians(a.latitude))
    * power(sin(radians(a.longitude - s.longitude) / 2), 2);
  v_km := (6371.0 * 2 * asin(sqrt(greatest(0.0, least(1.0, v_part)))))::numeric;
  v_rate := public.karlivery_delivery_rate_card(v_km);
  v_fee := (v_rate->>'delivery_fee')::numeric;
  IF NEW.delivery_fee IS NOT NULL AND abs(NEW.delivery_fee - v_fee) > 0.01 THEN
    RAISE EXCEPTION 'Delivery rate changed; refresh your quote before submitting';
  END IF;
  NEW.delivery_distance_km := round(v_km, 2);
  NEW.delivery_rate_snapshot := v_rate;
  NEW.handling_fee := 20;
  NEW.delivery_fee := v_fee;
  NEW.total_amount := NEW.subtotal + NEW.handling_fee + NEW.delivery_fee;
  RETURN NEW;
END;
$$;
-- Existing pasabuy_quote_new_order_v19_7 BEFORE INSERT trigger remains attached.

-- Regular order INSERT: snapshot the fee rule, WITHOUT rewriting the amount from
-- existing place_order_v8 RPC. This avoids silently altering live transactions.
CREATE OR REPLACE FUNCTION public.karlivery_snapshot_order_distance()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  s record;
  a record;
  v_part double precision;
  v_km numeric;
BEGIN
  IF NEW.fulfillment IS DISTINCT FROM 'delivery' OR NEW.address_id IS NULL THEN
    NEW.delivery_distance_km := NULL;
    NEW.delivery_rate_snapshot := NULL;
    RETURN NEW;
  END IF;
  SELECT latitude, longitude INTO s FROM public.stores WHERE id = NEW.store_id;
  SELECT latitude, longitude INTO a FROM public.addresses WHERE id = NEW.address_id;
  IF s.latitude IS NULL OR s.longitude IS NULL OR a.latitude IS NULL OR a.longitude IS NULL THEN
    NEW.delivery_distance_km := NULL;
    NEW.delivery_rate_snapshot := NULL;
    RETURN NEW;
  END IF;
  IF s.latitude NOT BETWEEN -90 AND 90 OR a.latitude NOT BETWEEN -90 AND 90 OR
     s.longitude NOT BETWEEN -180 AND 180 OR a.longitude NOT BETWEEN -180 AND 180 THEN
    NEW.delivery_distance_km := NULL;
    NEW.delivery_rate_snapshot := NULL;
    RETURN NEW;
  END IF;
  v_part := power(sin(radians(a.latitude - s.latitude) / 2), 2)
    + cos(radians(s.latitude)) * cos(radians(a.latitude))
    * power(sin(radians(a.longitude - s.longitude) / 2), 2);
  v_km := (6371.0 * 2 * asin(sqrt(greatest(0.0, least(1.0, v_part)))))::numeric;
  NEW.delivery_distance_km := round(v_km,2);
  NEW.delivery_rate_snapshot := public.karlivery_delivery_rate_card(v_km);
  RETURN NEW;
END;
$$;
-- Existing karlivery_order_distance_snapshot BEFORE INSERT trigger remains attached.

-- Customer home store cards: same pickup -> customer fee as checkout.
CREATE OR REPLACE FUNCTION public.karlivery_home_feed(p_address_id uuid DEFAULT NULL)
RETURNS SETOF jsonb LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
WITH selected_address AS (
  SELECT a.id, a.latitude, a.longitude FROM public.addresses a
  WHERE a.id = p_address_id AND a.user_id = auth.uid() AND auth.uid() IS NOT NULL
  LIMIT 1
), rating_stats AS (
  SELECT r.store_id, round(avg(r.store_rating)::numeric, 2) rating_avg,
    count(*)::bigint rating_count FROM public.order_ratings r GROUP BY r.store_id
), popularity AS (
  SELECT o.store_id,
    count(*) FILTER (WHERE o.status::text IN ('delivered','completed'))::bigint completed_orders
  FROM public.orders o GROUP BY o.store_id
), distance_calc AS (
  SELECT s.*, a.id selected_address_id,
    CASE
      WHEN a.latitude IS NULL OR a.longitude IS NULL OR
           s.latitude IS NULL OR s.longitude IS NULL OR
           a.latitude NOT BETWEEN -90 AND 90 OR s.latitude NOT BETWEEN -90 AND 90 OR
           a.longitude NOT BETWEEN -180 AND 180 OR s.longitude NOT BETWEEN -180 AND 180 THEN NULL
      ELSE 6371.0 * 2 * asin(sqrt(greatest(0.0, least(1.0,
        power(sin(radians(a.latitude - s.latitude) / 2), 2) +
        cos(radians(s.latitude)) * cos(radians(a.latitude)) *
        power(sin(radians(a.longitude - s.longitude) / 2), 2)
      ))))
    END store_distance_km
  FROM public.stores s LEFT JOIN selected_address a ON true
)
SELECT to_jsonb(s) || jsonb_build_object(
  'rating_avg', rs.rating_avg,
  'rating_count', coalesce(rs.rating_count, 0),
  'completed_orders', coalesce(pop.completed_orders, 0),
  'distance_km', round(s.store_distance_km::numeric, 2),
  'delivery_distance_km', round(s.store_distance_km::numeric, 2),
  'delivery_base_name', 'Store pickup location',
  'delivery_fee_preview', CASE WHEN s.selected_address_id IS NULL OR s.store_distance_km IS NULL
    THEN NULL ELSE public.karlivery_delivery_fee_for_km(s.store_distance_km::numeric) END,
  'eta_min_minutes', CASE WHEN s.store_distance_km IS NULL THEN s.prep_min_minutes
    ELSE s.prep_min_minutes + greatest(5, ceil(s.store_distance_km / 22 * 60)::integer) END,
  'eta_max_minutes', CASE WHEN s.store_distance_km IS NULL THEN s.prep_max_minutes
    ELSE s.prep_max_minutes + greatest(8, ceil(s.store_distance_km / 18 * 60)::integer) END
)
FROM distance_calc s
LEFT JOIN rating_stats rs ON rs.store_id = s.id
LEFT JOIN popularity pop ON pop.store_id = s.id
WHERE coalesce(s.is_approved, false) = true
ORDER BY s.is_open DESC, coalesce(pop.completed_orders,0) DESC,
         coalesce(rs.rating_avg,0) DESC, s.name;
$$;
GRANT EXECUTE ON FUNCTION public.karlivery_home_feed(uuid) TO anon, authenticated;

COMMIT;
NOTIFY pgrst, 'reload schema';

-- VERIFICATION (read-only): check the currently saved admin settings:
SELECT base_fee, included_radius_km, step_distance_km, step_fee
FROM public.delivery_rate_settings WHERE id = 1;
-- Sample boundary checks using CURRENT settings; expected 50/50/65/80 when
-- admin values are base=50, radius=3, step=1, fee=15:
SELECT km, public.karlivery_delivery_fee_for_km(km) AS fee
FROM (VALUES (0.0::numeric),(3.0),(3.01),(4.2)) AS test(km);
-- Audit only: NEW regular order records where old server RPC price differs.
-- REVIEW differences: do NOT overwrite existing charges, settlement or email.
SELECT id, delivery_fee, delivery_rate_snapshot->>'delivery_fee' AS computed_fee,
       delivery_distance_km, created_at
FROM public.orders
WHERE delivery_rate_snapshot IS NOT NULL
  AND abs(delivery_fee - (delivery_rate_snapshot->>'delivery_fee')::numeric) > 0.01
ORDER BY created_at DESC LIMIT 20;
