-- ============================================================
-- KARLIVERY V15 — ADVANCED MENU + DISH PREPARATION TIME
-- Apply after SQL 16.
-- Additive migration: does not reset users, orders, stores or rates.
-- ============================================================

begin;

-- ------------------------------------------------------------
-- 1) PER-DISH PREPARATION TIME
-- ------------------------------------------------------------
alter table public.products
  add column if not exists prep_time_min integer not null default 10,
  add column if not exists prep_time_max integer not null default 20;

update public.products
set prep_time_min = greatest(coalesce(prep_time_min, 10), 1),
    prep_time_max = greatest(coalesce(prep_time_max, 20), greatest(coalesce(prep_time_min, 10), 1));

alter table public.products drop constraint if exists products_prep_time_min_check;
alter table public.products
  add constraint products_prep_time_min_check
  check (prep_time_min between 1 and 240);

alter table public.products drop constraint if exists products_prep_time_max_check;
alter table public.products
  add constraint products_prep_time_max_check
  check (prep_time_max between 1 and 360 and prep_time_max >= prep_time_min);

-- ------------------------------------------------------------
-- 2) SELLER UPDATE MENU ITEM
--    A null p_image_url means keep the existing image.
-- ------------------------------------------------------------
drop function if exists public.seller_update_product(
  uuid,text,text,text,numeric,text,boolean,boolean,integer,integer
);
create or replace function public.seller_update_product(
  p_product_id uuid,
  p_name text,
  p_description text,
  p_category text,
  p_price numeric,
  p_image_url text,
  p_is_featured boolean,
  p_is_available boolean,
  p_prep_time_min integer,
  p_prep_time_max integer
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null then
    raise exception 'Authentication required' using errcode = '42501';
  end if;

  if not exists (
    select 1
    from public.products p
    join public.stores s on s.id = p.store_id
    where p.id = p_product_id
      and (s.owner_id = auth.uid() or public.current_user_role() = 'admin')
  ) then
    raise exception 'Product not found or access denied' using errcode = '42501';
  end if;

  if p_name is null or char_length(trim(p_name)) < 2 or char_length(trim(p_name)) > 80 then
    raise exception 'Dish name must contain 2 to 80 characters';
  end if;

  if p_description is not null and char_length(trim(p_description)) > 280 then
    raise exception 'Description is too long';
  end if;

  if p_category is null or char_length(trim(p_category)) < 2 or char_length(trim(p_category)) > 60 then
    raise exception 'Select a valid category';
  end if;

  if p_price is null or p_price <= 0 or p_price > 100000 then
    raise exception 'Enter a valid product price';
  end if;

  if p_prep_time_min is null or p_prep_time_max is null
     or p_prep_time_min < 1 or p_prep_time_min > 240
     or p_prep_time_max < 1 or p_prep_time_max > 360
     or p_prep_time_max < p_prep_time_min then
    raise exception 'Enter a valid preparation time range';
  end if;

  update public.products
  set name = trim(p_name),
      description = trim(coalesce(p_description, '')),
      category = trim(p_category),
      price = round(p_price, 2),
      image_url = case
        when p_image_url is null or trim(p_image_url) = '' then image_url
        else trim(p_image_url)
      end,
      is_featured = coalesce(p_is_featured, false),
      is_available = coalesce(p_is_available, true),
      prep_time_min = p_prep_time_min,
      prep_time_max = p_prep_time_max,
      updated_at = now()
  where id = p_product_id;
end;
$$;

revoke all on function public.seller_update_product(
  uuid,text,text,text,numeric,text,boolean,boolean,integer,integer
) from public, anon;
grant execute on function public.seller_update_product(
  uuid,text,text,text,numeric,text,boolean,boolean,integer,integer
) to authenticated;

-- ------------------------------------------------------------
-- 3) QUICK AVAILABLE / SOLD-OUT ACTION
-- ------------------------------------------------------------
drop function if exists public.seller_set_product_available(uuid,boolean);
create or replace function public.seller_set_product_available(
  p_product_id uuid,
  p_is_available boolean
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null then
    raise exception 'Authentication required' using errcode = '42501';
  end if;

  if not exists (
    select 1
    from public.products p
    join public.stores s on s.id = p.store_id
    where p.id = p_product_id
      and (s.owner_id = auth.uid() or public.current_user_role() = 'admin')
  ) then
    raise exception 'Product not found or access denied' using errcode = '42501';
  end if;

  update public.products
  set is_available = coalesce(p_is_available, true),
      updated_at = now()
  where id = p_product_id;
end;
$$;

revoke all on function public.seller_set_product_available(uuid,boolean) from public, anon;
grant execute on function public.seller_set_product_available(uuid,boolean) to authenticated;

notify pgrst, 'reload schema';
commit;
