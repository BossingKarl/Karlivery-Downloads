-- KARLIVERY V20.0.5.2 HOTFIX 35
-- Fix missing distance columns after migration 34 verification error (42703).
-- Non-destructive: no order amounts, historical distances, or rate settings updated.
-- Do NOT rerun the entire migration 33 after 34: it contains older Pabili fee logic.

BEGIN;

-- Required by V20.0.5 receipts and V20.0.5.2 rate snapshots.
ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS delivery_distance_km numeric(10,2);
ALTER TABLE public.pasabuy_orders
  ADD COLUMN IF NOT EXISTS delivery_distance_km numeric(10,2);
ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS delivery_rate_snapshot jsonb;
ALTER TABLE public.pasabuy_orders
  ADD COLUMN IF NOT EXISTS delivery_rate_snapshot jsonb;

-- Migration 33 also introduced an email-send audit table. Create it if missing.
CREATE TABLE IF NOT EXISTS public.order_receipt_email_deliveries (
  order_type text NOT NULL CHECK (order_type IN ('regular','pabili')),
  order_id text NOT NULL,
  customer_id uuid NOT NULL,
  status text NOT NULL DEFAULT 'sending' CHECK (status IN ('sending','sent')),
  created_at timestamptz NOT NULL DEFAULT now(),
  sent_at timestamptz,
  PRIMARY KEY (order_type, order_id)
);
ALTER TABLE public.order_receipt_email_deliveries ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.order_receipt_email_deliveries FROM anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE
  ON TABLE public.order_receipt_email_deliveries TO service_role;

-- Migration 34 replaces the trigger function but assumes migration 33
-- already attached it. Attach ONLY if function exists and trigger is missing.
DO $fix$
BEGIN
  IF to_regprocedure('public.karlivery_snapshot_order_distance()') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_trigger
       WHERE tgrelid = 'public.orders'::regclass
         AND tgname = 'karlivery_order_distance_snapshot'
         AND NOT tgisinternal
     ) THEN
    CREATE TRIGGER karlivery_order_distance_snapshot
      BEFORE INSERT ON public.orders
      FOR EACH ROW EXECUTE FUNCTION public.karlivery_snapshot_order_distance();
  END IF;
END;
$fix$;

COMMIT;
NOTIFY pgrst, 'reload schema';

-- Verify four expected columns (four rows should appear):
SELECT table_name, column_name, data_type
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name IN ('orders', 'pasabuy_orders')
  AND column_name IN ('delivery_distance_km', 'delivery_rate_snapshot')
ORDER BY table_name, column_name;

-- Verify rate-function installation and that the order trigger is attached:
SELECT
  to_regprocedure('public.karlivery_delivery_rate_card(numeric)') IS NOT NULL
    AS central_rate_function_installed,
  to_regprocedure('public.karlivery_pabili_delivery_quote(text,uuid)') IS NOT NULL
    AS pabili_quote_function_installed,
  EXISTS (
    SELECT 1 FROM pg_trigger
    WHERE tgrelid = 'public.orders'::regclass
      AND tgname = 'karlivery_order_distance_snapshot'
      AND NOT tgisinternal
  ) AS regular_order_snapshot_trigger_attached;

-- Safe fee check using saved admin settings, ONLY if migration 34 exists:
-- SELECT km, public.karlivery_delivery_fee_for_km(km) AS delivery_fee
-- FROM (VALUES (3.0::numeric), (3.01::numeric), (4.2::numeric)) AS t(km);
