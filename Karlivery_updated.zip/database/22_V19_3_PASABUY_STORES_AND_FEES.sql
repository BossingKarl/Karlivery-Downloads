-- Apply after 20_V19_PASABUY_CORE.sql and 21_V19_PASABUY_SEED.sql.
-- Exact GPS must be populated by the admin. Missing positions show only a provisional fee.
ALTER TABLE public.pasabuy_shops ADD COLUMN IF NOT EXISTS latitude double precision;
ALTER TABLE public.pasabuy_shops ADD COLUMN IF NOT EXISTS longitude double precision;
INSERT INTO public.pasabuy_shops (id, name, brand, description, location_label, source, estimated_buying_time, sort_order)
VALUES
('pasabuy-kfc-mangatarem', 'KFC Mangatarem', 'kfc', 'Chicken meals, buckets, burgers and desserts.', 'Romulo Highway, Barangay Poblacion, Mangatarem, Pangasinan', 'KFC official menu 2026', '20–35 min', 6),
('pasabuy-other-store', 'Other / Custom Store', 'custom', 'Customer specifies the store and shopping request.', 'Location supplied by customer', 'Customer request', 'To be confirmed', 99)
ON CONFLICT (id) DO UPDATE SET name=EXCLUDED.name, description=EXCLUDED.description, location_label=EXCLUDED.location_label;
INSERT INTO public.pasabuy_categories (id, shop_id, name, sort_order)
VALUES ('cat-kfc-2026', 'pasabuy-kfc-mangatarem', 'KFC official menu examples', 1),
       ('cat-jb-mix', 'pasabuy-jollibee-camiling', 'Mix & Match', 8)
ON CONFLICT (id) DO NOTHING;
INSERT INTO public.pasabuy_items (id, shop_id, category_id, name, price, is_published, is_available, sort_order)
VALUES
('kfc-1','pasabuy-kfc-mangatarem','cat-kfc-2026','6-PC Bucket Combo',780,false,true,1),
('kfc-2','pasabuy-kfc-mangatarem','cat-kfc-2026','8-PC Bucket Combo',1010,false,true,2),
('kfc-3','pasabuy-kfc-mangatarem','cat-kfc-2026','Original Recipe Double Down Ala Carte',295,false,true,3),
('kfc-4','pasabuy-kfc-mangatarem','cat-kfc-2026','Zinger Double Down Ala Carte',295,false,true,4),
('kfc-5','pasabuy-kfc-mangatarem','cat-kfc-2026','Original Recipe Double Down Combo',370,false,true,5),
('kfc-6','pasabuy-kfc-mangatarem','cat-kfc-2026','Double Down Fully Loaded Box',450,false,true,6),
('jb-mm1','pasabuy-jollibee-camiling','cat-jb-mix','Mix & Match ₱85',85,false,true,1),
('jb-mm2','pasabuy-jollibee-camiling','cat-jb-mix','Mix & Match ₱95',95,false,true,2)
ON CONFLICT (id) DO UPDATE SET name=EXCLUDED.name, price=EXCLUDED.price, category_id=EXCLUDED.category_id;
-- KFC menu items remain DRAFT until branch prices checked in Admin Studio.
-- Mix & Match remains DRAFT until the applicable promo and options are confirmed.
-- For non-fallback DB records update GPS through Supabase SQL Editor after verifying on map:
-- UPDATE public.pasabuy_shops SET latitude = <verified_lat>, longitude = <verified_lng> WHERE id = 'pasabuy-kfc-mangatarem';
