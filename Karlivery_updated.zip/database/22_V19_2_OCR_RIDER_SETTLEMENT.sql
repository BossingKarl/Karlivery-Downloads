-- KARLIVERY V19.2 — PASABUY OCR/RIDER FLOW + GCASH DELIVERY-FEE SETTLEMENT
-- Run AFTER 20_V19_PASABUY_CORE.sql and 21_V19_PASABUY_SEED.sql.

create extension if not exists pgcrypto;

-- ------------------------------------------------------------------
-- 1) Make admin-generated Pasabuy rows easy to insert dynamically.
-- ------------------------------------------------------------------
alter table public.pasabuy_categories
  alter column id set default ('PBC-' || replace(gen_random_uuid()::text, '-', ''));
alter table public.pasabuy_items
  alter column id set default ('PBI-' || replace(gen_random_uuid()::text, '-', ''));
alter table public.pasabuy_item_addons
  alter column id set default ('PBA-' || replace(gen_random_uuid()::text, '-', ''));
alter table public.pasabuy_menu_images
  alter column id set default ('PBIMG-' || replace(gen_random_uuid()::text, '-', ''));

-- Admin CRUD policies for Pasabuy Studio.
do $$ begin
  create policy "pasabuy admin manage shops" on public.pasabuy_shops
  for all to authenticated using (public.current_user_role()='admin')
  with check (public.current_user_role()='admin');
exception when duplicate_object then null; end $$;

do $$ begin
  create policy "pasabuy admin manage categories" on public.pasabuy_categories
  for all to authenticated using (public.current_user_role()='admin')
  with check (public.current_user_role()='admin');
exception when duplicate_object then null; end $$;

do $$ begin
  create policy "pasabuy admin manage items" on public.pasabuy_items
  for all to authenticated using (public.current_user_role()='admin')
  with check (public.current_user_role()='admin');
exception when duplicate_object then null; end $$;

do $$ begin
  create policy "pasabuy admin manage addons" on public.pasabuy_item_addons
  for all to authenticated using (public.current_user_role()='admin')
  with check (public.current_user_role()='admin');
exception when duplicate_object then null; end $$;

do $$ begin
  create policy "pasabuy admin manage menu images" on public.pasabuy_menu_images
  for all to authenticated using (public.current_user_role()='admin')
  with check (public.current_user_role()='admin');
exception when duplicate_object then null; end $$;

-- ------------------------------------------------------------------
-- 2) Rider GCash identity for Pasabuy payments.
-- ------------------------------------------------------------------
alter table public.profiles
  add column if not exists rider_gcash_number text,
  add column if not exists rider_gcash_qr_url text;

insert into storage.buckets(id,name,public)
values ('rider-gcash-qr','rider-gcash-qr',true)
on conflict(id) do update set public=true;

-- Authenticated riders can manage only their own folder.
drop policy if exists "rider_gcash_qr_read" on storage.objects;
create policy "rider_gcash_qr_read" on storage.objects
for select to authenticated
using (bucket_id='rider-gcash-qr');

drop policy if exists "rider_gcash_qr_insert" on storage.objects;
create policy "rider_gcash_qr_insert" on storage.objects
for insert to authenticated
with check (
  bucket_id='rider-gcash-qr'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "rider_gcash_qr_update" on storage.objects;
create policy "rider_gcash_qr_update" on storage.objects
for update to authenticated
using (
  bucket_id='rider-gcash-qr'
  and (storage.foldername(name))[1] = auth.uid()::text
)
with check (
  bucket_id='rider-gcash-qr'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "rider_gcash_qr_delete" on storage.objects;
create policy "rider_gcash_qr_delete" on storage.objects
for delete to authenticated
using (
  bucket_id='rider-gcash-qr'
  and (storage.foldername(name))[1] = auth.uid()::text
);

create or replace function public.rider_save_pasabuy_gcash(
  p_number text,
  p_qr_url text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if auth.uid() is null or public.current_user_role() <> 'rider' then
    raise exception 'Rider account required';
  end if;

  update public.profiles
  set rider_gcash_number = nullif(trim(coalesce(p_number,'')),''),
      rider_gcash_qr_url = case
        when nullif(trim(coalesce(p_qr_url,'')),'') is null then rider_gcash_qr_url
        else trim(p_qr_url)
      end,
      updated_at = now()
  where id = auth.uid();
end;
$$;
grant execute on function public.rider_save_pasabuy_gcash(text,text) to authenticated;

-- ------------------------------------------------------------------
-- 3) Pasabuy order state / rider payment confirmation.
-- ------------------------------------------------------------------
alter table public.pasabuy_orders
  add column if not exists custom_request_amount numeric(10,2) not null default 0,
  add column if not exists gcash_reference_no text,
  add column if not exists gcash_proof_path text,
  add column if not exists customer_gcash_sent_at timestamptz,
  add column if not exists rider_gcash_received_at timestamptz,
  add column if not exists rider_accepted_at timestamptz,
  add column if not exists delivered_at timestamptz;

-- Add proper history links if the original V19 tables were created without FKs.
do $$ begin
  if not exists (select 1 from pg_constraint where conname='pasabuy_orders_customer_id_fkey') then
    alter table public.pasabuy_orders
      add constraint pasabuy_orders_customer_id_fkey
      foreign key(customer_id) references public.profiles(id) on delete set null;
  end if;
end $$;

do $$ begin
  if not exists (select 1 from pg_constraint where conname='pasabuy_orders_rider_id_fkey') then
    alter table public.pasabuy_orders
      add constraint pasabuy_orders_rider_id_fkey
      foreign key(rider_id) references public.profiles(id) on delete set null;
  end if;
end $$;

do $$ begin
  if not exists (select 1 from pg_constraint where conname='pasabuy_orders_address_id_fkey') then
    alter table public.pasabuy_orders
      add constraint pasabuy_orders_address_id_fkey
      foreign key(address_id) references public.addresses(id) on delete set null;
  end if;
end $$;

create table if not exists public.pasabuy_rider_locations (
  order_id text primary key references public.pasabuy_orders(id) on delete cascade,
  rider_id uuid references public.profiles(id) on delete set null,
  latitude double precision not null,
  longitude double precision not null,
  heading double precision,
  speed double precision,
  updated_at timestamptz not null default now()
);
alter table public.pasabuy_rider_locations enable row level security;

insert into storage.buckets(id,name,public)
values ('pasabuy-payment-proofs','pasabuy-payment-proofs',false)
on conflict(id) do update set public=false;

-- Refresh RLS to support customer, rider, and admin Pasabuy workflows.
drop policy if exists "pasabuy orders own read" on public.pasabuy_orders;
drop policy if exists "pasabuy orders own write" on public.pasabuy_orders;
drop policy if exists "pasabuy orders participants read" on public.pasabuy_orders;
create policy "pasabuy orders participants read" on public.pasabuy_orders
for select to authenticated
using (
  customer_id = auth.uid()
  or rider_id = auth.uid()
  or (rider_id is null and status='Waiting for Rider' and public.current_user_role()='rider')
  or public.current_user_role()='admin'
);
drop policy if exists "pasabuy customer creates order" on public.pasabuy_orders;
create policy "pasabuy customer creates order" on public.pasabuy_orders
for insert to authenticated
with check (customer_id=auth.uid() and public.current_user_role()='customer');

-- Rider/customer can see order items only when they are participants.
drop policy if exists "pasabuy order items own write" on public.pasabuy_order_items;
drop policy if exists "pasabuy order items participant read" on public.pasabuy_order_items;
create policy "pasabuy order items participant read" on public.pasabuy_order_items
for select to authenticated
using (
  exists (
    select 1 from public.pasabuy_orders o
    where o.id=order_id
      and (o.customer_id=auth.uid() or o.rider_id=auth.uid() or public.current_user_role()='admin')
  )
);
drop policy if exists "pasabuy order items customer insert" on public.pasabuy_order_items;
create policy "pasabuy order items customer insert" on public.pasabuy_order_items
for insert to authenticated
with check (
  exists (
    select 1 from public.pasabuy_orders o
    where o.id=order_id and o.customer_id=auth.uid()
  )
);

drop policy if exists "pasabuy order item addons own write" on public.pasabuy_order_item_addons;
drop policy if exists "pasabuy order addon participant read" on public.pasabuy_order_item_addons;
create policy "pasabuy order addon participant read" on public.pasabuy_order_item_addons
for select to authenticated
using (
  exists (
    select 1
    from public.pasabuy_order_items oi
    join public.pasabuy_orders o on o.id=oi.order_id
    where oi.id=order_item_id
      and (o.customer_id=auth.uid() or o.rider_id=auth.uid() or public.current_user_role()='admin')
  )
);
drop policy if exists "pasabuy order addon customer insert" on public.pasabuy_order_item_addons;
create policy "pasabuy order addon customer insert" on public.pasabuy_order_item_addons
for insert to authenticated
with check (
  exists (
    select 1
    from public.pasabuy_order_items oi
    join public.pasabuy_orders o on o.id=oi.order_id
    where oi.id=order_item_id and o.customer_id=auth.uid()
  )
);

-- Pasabuy messages.
drop policy if exists "pasabuy messages read" on public.pasabuy_messages;
drop policy if exists "pasabuy messages write" on public.pasabuy_messages;
drop policy if exists "pasabuy messages participants read" on public.pasabuy_messages;
create policy "pasabuy messages participants read" on public.pasabuy_messages
for select to authenticated
using (
  exists (
    select 1 from public.pasabuy_orders o
    where o.id=order_id
      and (o.customer_id=auth.uid() or o.rider_id=auth.uid() or public.current_user_role()='admin')
  )
);
drop policy if exists "pasabuy messages participants write" on public.pasabuy_messages;
create policy "pasabuy messages participants write" on public.pasabuy_messages
for insert to authenticated
with check (
  sender_id=auth.uid()
  and exists (
    select 1 from public.pasabuy_orders o
    where o.id=order_id
      and (o.customer_id=auth.uid() or o.rider_id=auth.uid() or public.current_user_role()='admin')
  )
);

drop policy if exists "pasabuy tracking participants read" on public.pasabuy_rider_locations;
create policy "pasabuy tracking participants read" on public.pasabuy_rider_locations
for select to authenticated
using (
  exists (
    select 1 from public.pasabuy_orders o
    where o.id=order_id
      and (o.customer_id=auth.uid() or o.rider_id=auth.uid() or public.current_user_role()='admin')
  )
);
drop policy if exists "pasabuy rider tracking write" on public.pasabuy_rider_locations;
create policy "pasabuy rider tracking write" on public.pasabuy_rider_locations
for all to authenticated
using (rider_id=auth.uid())
with check (rider_id=auth.uid());

-- Payment proof storage. Customer writes own order folder; assigned rider/admin can read through signed URL/service APIs.
drop policy if exists "pasabuy proof customer insert" on storage.objects;
create policy "pasabuy proof customer insert" on storage.objects
for insert to authenticated
with check (
  bucket_id='pasabuy-payment-proofs'
  and (storage.foldername(name))[1] = auth.uid()::text
);
drop policy if exists "pasabuy proof customer update" on storage.objects;
create policy "pasabuy proof customer update" on storage.objects
for update to authenticated
using (
  bucket_id='pasabuy-payment-proofs'
  and (storage.foldername(name))[1] = auth.uid()::text
)
with check (
  bucket_id='pasabuy-payment-proofs'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "pasabuy proof participant read" on storage.objects;
create policy "pasabuy proof participant read" on storage.objects
for select to authenticated
using (
  bucket_id='pasabuy-payment-proofs'
  and (
    (storage.foldername(name))[1] = auth.uid()::text
    or exists (
      select 1 from public.pasabuy_orders o
      where o.id=(storage.foldername(name))[2]
        and (o.rider_id=auth.uid() or public.current_user_role()='admin')
    )
  )
);

-- Secure participant detail used by customer/rider Pasabuy screens.
create or replace function public.get_pasabuy_order_detail(p_order_id text)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  result jsonb;
begin
  if auth.uid() is null then raise exception 'Not authenticated'; end if;

  select to_jsonb(o)
    || jsonb_build_object(
      'pasabuy_shops', jsonb_build_object(
        'name', s.name,
        'location_label', s.location_label,
        'logo_url', s.logo_url
      ),
      'profiles', case when r.id is null then null else jsonb_build_object(
        'id', r.id,
        'full_name', r.full_name,
        'phone', r.phone,
        'rider_gcash_number', r.rider_gcash_number,
        'rider_gcash_qr_url', r.rider_gcash_qr_url
      ) end
    )
  into result
  from public.pasabuy_orders o
  join public.pasabuy_shops s on s.id=o.shop_id
  left join public.profiles r on r.id=o.rider_id
  where o.id=p_order_id
    and (
      o.customer_id=auth.uid()
      or o.rider_id=auth.uid()
      or public.current_user_role()='admin'
    );

  if result is null then raise exception 'Pasabuy order not found or access denied'; end if;
  return result;
end;
$$;
grant execute on function public.get_pasabuy_order_detail(text) to authenticated;

-- First-to-accept rider claim.
create or replace function public.rider_claim_pasabuy_order(p_order_id text)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_customer uuid;
  v_rider_name text;
begin
  if auth.uid() is null or public.current_user_role()<>'rider' then
    raise exception 'Rider account required';
  end if;

  if not exists(select 1 from public.profiles where id=auth.uid() and is_online=true and status='active') then
    raise exception 'Go online before accepting Pasabuy orders';
  end if;

  if exists(select 1 from public.pasabuy_orders where id=p_order_id and payment_method='rider_gcash')
     and not exists(select 1 from public.profiles where id=auth.uid() and nullif(trim(coalesce(rider_gcash_number,'')),'') is not null) then
    raise exception 'Add your rider GCash number first before accepting this GCash Pasabuy order';
  end if;

  update public.pasabuy_orders
  set rider_id=auth.uid(),
      status='Rider Accepted',
      rider_accepted_at=now(),
      updated_at=now()
  where id=p_order_id
    and rider_id is null
    and status='Waiting for Rider'
  returning customer_id into v_customer;

  if not found then
    raise exception 'This Pasabuy order was already accepted by another rider';
  end if;

  select coalesce(full_name,'Your rider') into v_rider_name from public.profiles where id=auth.uid();

  if v_customer is not null then
    insert into public.notifications(user_id,order_id,title,message,kind,data,is_read)
    values (
      v_customer,null,
      'Karlivery Pasabuy rider found',
      v_rider_name || ' accepted your Pasabuy request. You can now chat and track the rider.',
      'pasabuy',
      jsonb_build_object('pasabuy_order_id',p_order_id,'event','rider_accepted'),false
    );
  end if;
end;
$$;
grant execute on function public.rider_claim_pasabuy_order(text) to authenticated;

create or replace function public.rider_set_pasabuy_status(p_order_id text,p_status text)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_customer uuid;
  v_status text := trim(coalesce(p_status,''));
begin
  if auth.uid() is null or public.current_user_role()<>'rider' then
    raise exception 'Rider account required';
  end if;

  if v_status not in ('Rider Accepted','Buying in Progress','Purchased','On the Way','Delivered') then
    raise exception 'Invalid Pasabuy status';
  end if;

  update public.pasabuy_orders
  set status=v_status,
      delivered_at=case when v_status='Delivered' then now() else delivered_at end,
      updated_at=now()
  where id=p_order_id and rider_id=auth.uid()
  returning customer_id into v_customer;

  if not found then raise exception 'Pasabuy order not found or access denied'; end if;

  if v_customer is not null then
    insert into public.notifications(user_id,order_id,title,message,kind,data,is_read)
    values (
      v_customer,null,
      'Pasabuy update: ' || v_status,
      case v_status
        when 'Buying in Progress' then 'Your rider is now buying your requested items.'
        when 'Purchased' then 'Your requested items have been purchased.'
        when 'On the Way' then 'Your Karlivery rider is heading to you.'
        when 'Delivered' then 'Your Pasabuy order was marked delivered.'
        else 'Your Pasabuy order was updated.'
      end,
      'pasabuy',jsonb_build_object('pasabuy_order_id',p_order_id,'event','status'),false
    );
  end if;
end;
$$;
grant execute on function public.rider_set_pasabuy_status(text,text) to authenticated;

create or replace function public.customer_confirm_pasabuy_gcash_sent(
  p_order_id text,
  p_reference text,
  p_proof_path text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_rider uuid;
begin
  update public.pasabuy_orders
  set gcash_reference_no=nullif(trim(coalesce(p_reference,'')),''),
      gcash_proof_path=nullif(trim(coalesce(p_proof_path,'')),''),
      customer_gcash_sent_at=now(),
      payment_status='customer_sent',
      updated_at=now()
  where id=p_order_id
    and customer_id=auth.uid()
    and payment_method='rider_gcash'
    and rider_id is not null
  returning rider_id into v_rider;

  if not found then raise exception 'GCash Pasabuy order not found or rider not yet assigned'; end if;

  insert into public.notifications(user_id,order_id,title,message,kind,data,is_read)
  values (
    v_rider,null,'Pasabuy GCash sent',
    'Customer marked the Pasabuy payment as sent. Verify the reference/proof before confirming.',
    'pasabuy',jsonb_build_object('pasabuy_order_id',p_order_id,'event','gcash_sent'),false
  );
end;
$$;
grant execute on function public.customer_confirm_pasabuy_gcash_sent(text,text,text) to authenticated;

create or replace function public.rider_confirm_pasabuy_gcash_received(p_order_id text)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_customer uuid;
begin
  update public.pasabuy_orders
  set rider_gcash_received_at=now(),
      payment_status='paid',
      updated_at=now()
  where id=p_order_id
    and rider_id=auth.uid()
    and payment_method='rider_gcash'
    and customer_gcash_sent_at is not null
  returning customer_id into v_customer;

  if not found then raise exception 'Payment cannot be confirmed yet'; end if;

  if v_customer is not null then
    insert into public.notifications(user_id,order_id,title,message,kind,data,is_read)
    values (
      v_customer,null,'Pasabuy GCash confirmed',
      'Your rider confirmed receiving the GCash payment.',
      'pasabuy',jsonb_build_object('pasabuy_order_id',p_order_id,'event','gcash_received'),false
    );
  end if;
end;
$$;
grant execute on function public.rider_confirm_pasabuy_gcash_received(text) to authenticated;

-- ------------------------------------------------------------------
-- 4) Regular-store GCash: delivery fee belongs to the assigned rider.
--    Two-sided settlement trail: seller SENT -> rider RECEIVED.
-- ------------------------------------------------------------------
alter table public.orders
  add column if not exists delivery_fee numeric(10,2) not null default 0,
  add column if not exists rider_fee_settlement_status text not null default 'not_applicable',
  add column if not exists rider_fee_sent_at timestamptz,
  add column if not exists rider_fee_received_at timestamptz,
  add column if not exists rider_fee_reference text;

create or replace function public.ensure_delivery_fee_settlement(p_order_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_owner uuid;
  v_rider uuid;
  v_fee numeric;
  v_payment text;
  v_fulfillment text;
begin
  if auth.uid() is null then raise exception 'Not authenticated'; end if;
  if not exists (
    select 1 from public.orders ox
    join public.stores sx on sx.id=ox.store_id
    where ox.id=p_order_id
      and (sx.owner_id=auth.uid() or ox.rider_id=auth.uid() or public.current_user_role()='admin')
  ) then
    raise exception 'Order access denied';
  end if;

  select s.owner_id,o.rider_id,coalesce(o.delivery_fee,0),lower(o.payment_method::text),lower(o.fulfillment::text)
  into v_owner,v_rider,v_fee,v_payment,v_fulfillment
  from public.orders o
  join public.stores s on s.id=o.store_id
  where o.id=p_order_id;

  if v_payment <> 'gcash' or v_fulfillment <> 'delivery' or v_fee <= 0 then
    update public.orders set rider_fee_settlement_status='not_applicable' where id=p_order_id;
    return;
  end if;

  update public.orders
  set rider_fee_settlement_status = case
        when rider_fee_received_at is not null then 'received'
        when rider_fee_sent_at is not null then 'sent'
        else 'due'
      end,
      updated_at=now()
  where id=p_order_id;

  if v_owner is not null and not exists (
    select 1 from public.notifications n
    where n.user_id=v_owner
      and n.order_id=p_order_id
      and n.kind='rider_fee'
      and coalesce(n.data->>'event','')='rider_fee_due'
      and n.is_read=false
  ) then
    insert into public.notifications(user_id,order_id,title,message,kind,data,is_read)
    values (
      v_owner,p_order_id,
      'Rider delivery fee must be settled',
      'This GCash delivery includes a rider delivery fee of ₱' || trim(to_char(v_fee,'FM999999990.00')) || '. Keep this amount for the assigned rider and mark it sent once transferred.',
      'rider_fee',
      jsonb_build_object('event','rider_fee_due','amount',v_fee,'rider_id',v_rider),false
    );
  end if;
end;
$$;
grant execute on function public.ensure_delivery_fee_settlement(uuid) to authenticated;

create or replace function public.trg_refresh_rider_fee_settlement()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  if lower(coalesce(new.payment_method::text,''))='gcash'
     and lower(coalesce(new.fulfillment::text,''))='delivery' then
    perform public.ensure_delivery_fee_settlement(new.id);
  end if;
  return new;
end;
$$;

drop trigger if exists trg_orders_refresh_rider_fee_settlement on public.orders;
create trigger trg_orders_refresh_rider_fee_settlement
after update of rider_id, seller_gcash_received_at on public.orders
for each row execute function public.trg_refresh_rider_fee_settlement();

create or replace function public.seller_mark_rider_fee_sent(p_order_id uuid,p_reference text default null)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_rider uuid;
  v_fee numeric;
begin
  update public.orders o
  set rider_fee_settlement_status='sent',
      rider_fee_sent_at=now(),
      rider_fee_reference=nullif(trim(coalesce(p_reference,'')),''),
      updated_at=now()
  from public.stores s
  where o.id=p_order_id
    and s.id=o.store_id
    and (s.owner_id=auth.uid() or public.current_user_role()='admin')
    and lower(o.payment_method::text)='gcash'
    and lower(o.fulfillment::text)='delivery'
    and o.rider_id is not null
  returning o.rider_id,coalesce(o.delivery_fee,0) into v_rider,v_fee;

  if not found then raise exception 'Assign a rider before marking the delivery fee sent'; end if;

  insert into public.notifications(user_id,order_id,title,message,kind,data,is_read)
  values (
    v_rider,p_order_id,'Seller sent your delivery fee',
    'The store marked your ₱' || trim(to_char(v_fee,'FM999999990.00')) || ' delivery fee as sent. Confirm it only after you actually receive it.',
    'rider_fee',jsonb_build_object('event','rider_fee_sent','amount',v_fee),false
  );
end;
$$;
grant execute on function public.seller_mark_rider_fee_sent(uuid,text) to authenticated;

create or replace function public.rider_confirm_rider_fee_received(p_order_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_owner uuid;
  v_fee numeric;
begin
  update public.orders o
  set rider_fee_settlement_status='received',
      rider_fee_received_at=now(),
      updated_at=now()
  where o.id=p_order_id
    and o.rider_id=auth.uid()
    and o.rider_fee_sent_at is not null
  returning coalesce(o.delivery_fee,0),(select owner_id from public.stores where id=o.store_id)
  into v_fee,v_owner;

  if not found then raise exception 'The seller has not marked this delivery fee as sent'; end if;

  if v_owner is not null then
    insert into public.notifications(user_id,order_id,title,message,kind,data,is_read)
    values (
      v_owner,p_order_id,'Rider confirmed delivery fee',
      'The rider confirmed receiving the ₱' || trim(to_char(v_fee,'FM999999990.00')) || ' delivery fee.',
      'rider_fee',jsonb_build_object('event','rider_fee_received','amount',v_fee),false
    );
  end if;
end;
$$;
grant execute on function public.rider_confirm_rider_fee_received(uuid) to authenticated;


-- Realtime for customer/rider Pasabuy status, chat, and location.
do $$ begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname='supabase_realtime' and schemaname='public' and tablename='pasabuy_orders'
  ) then alter publication supabase_realtime add table public.pasabuy_orders; end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname='supabase_realtime' and schemaname='public' and tablename='pasabuy_messages'
  ) then alter publication supabase_realtime add table public.pasabuy_messages; end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname='supabase_realtime' and schemaname='public' and tablename='pasabuy_rider_locations'
  ) then alter publication supabase_realtime add table public.pasabuy_rider_locations; end if;
end $$;

-- Keep PostgREST schema cache fresh.
notify pgrst, 'reload schema';
