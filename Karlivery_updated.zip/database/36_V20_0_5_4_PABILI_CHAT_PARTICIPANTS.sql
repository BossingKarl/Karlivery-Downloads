-- Karlivery V20.0.5.4: Pabili customer <-> assigned rider chat
-- Review and back up the Supabase project before running in SQL Editor.
-- Does NOT delete orders, messages, or change delivery prices.
-- Intended for Supabase PostgreSQL after Pabili base migrations (20/22).

BEGIN;

-- The app uses the signed-in user's JWT, not the service_role key.
-- Table permissions are necessary even when RLS policies already exist.
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT SELECT ON public.pasabuy_orders TO authenticated;
GRANT SELECT ON public.pasabuy_shops TO authenticated;
GRANT SELECT, INSERT ON public.pasabuy_messages TO authenticated;

-- No anonymous access to private rider/customer conversations.
REVOKE ALL ON TABLE public.pasabuy_messages FROM anon;
REVOKE ALL ON TABLE public.pasabuy_messages FROM PUBLIC;
REVOKE UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER
  ON TABLE public.pasabuy_messages FROM authenticated;

ALTER TABLE public.pasabuy_messages ENABLE ROW LEVEL SECURITY;

-- Older V19 installations may still have permissive public policies.
DROP POLICY IF EXISTS "pasabuy messages read" ON public.pasabuy_messages;
DROP POLICY IF EXISTS "pasabuy messages write" ON public.pasabuy_messages;
DROP POLICY IF EXISTS "pasabuy messages participants read" ON public.pasabuy_messages;
DROP POLICY IF EXISTS "pasabuy messages participants write" ON public.pasabuy_messages;
DROP POLICY IF EXISTS "v20_0_5_4_pabili_chat_read" ON public.pasabuy_messages;
DROP POLICY IF EXISTS "v20_0_5_4_pabili_chat_send" ON public.pasabuy_messages;

-- Customers and the CURRENTLY assigned rider may view these messages.
-- Orders must already be visible to the participant through their own RLS.
CREATE POLICY "v20_0_5_4_pabili_chat_read"
ON public.pasabuy_messages FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.pasabuy_orders o
    WHERE o.id = pasabuy_messages.order_id
      AND o.rider_id IS NOT NULL
      AND (o.customer_id = (SELECT auth.uid())
           OR o.rider_id = (SELECT auth.uid()))
  )
);

-- Never allow user-supplied sender_id/role to impersonate another participant.
CREATE POLICY "v20_0_5_4_pabili_chat_send"
ON public.pasabuy_messages FOR INSERT TO authenticated
WITH CHECK (
  sender_id = (SELECT auth.uid())
  AND length(btrim(message)) BETWEEN 1 AND 2000
  AND EXISTS (
    SELECT 1 FROM public.pasabuy_orders o
    WHERE o.id = pasabuy_messages.order_id
      AND o.rider_id IS NOT NULL
      AND (
        (o.customer_id = (SELECT auth.uid()) AND sender_role = 'customer')
        OR (o.rider_id = (SELECT auth.uid()) AND sender_role = 'rider')
      )
  )
);

-- A participant's status may update while they are viewing the conversation.
-- Supabase streams need pasabuy_messages in the Realtime publication.
DO $realtime$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime')
     AND NOT EXISTS (
       SELECT 1 FROM pg_publication_tables
       WHERE pubname = 'supabase_realtime'
         AND schemaname = 'public'
         AND tablename = 'pasabuy_messages'
     ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.pasabuy_messages;
  END IF;
END
$realtime$;

NOTIFY pgrst, 'reload schema';
COMMIT;

-- Diagnostic checks: does not expose user messages or change data.
SELECT grantee, privilege_type
FROM information_schema.role_table_grants
WHERE table_schema = 'public'
  AND table_name = 'pasabuy_messages'
  AND grantee IN ('authenticated','anon')
ORDER BY grantee, privilege_type;

SELECT policyname, cmd, roles
FROM pg_policies
WHERE schemaname = 'public' AND tablename = 'pasabuy_messages'
ORDER BY policyname;

SELECT schemaname, tablename
FROM pg_publication_tables
WHERE pubname = 'supabase_realtime'
  AND schemaname = 'public'
  AND tablename = 'pasabuy_messages';
