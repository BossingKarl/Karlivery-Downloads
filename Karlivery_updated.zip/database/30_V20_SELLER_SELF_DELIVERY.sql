-- KARLIVERY V20 | seller-operated delivery (regular stores, NOT Pasabuy)
-- Safe / rerunnable migration, no data deletion. Run after previous V19 migrations.
-- Historical orders stay with Karlivery riders unless explicitly created after enabling self delivery.
BEGIN;

ALTER TABLE public.stores
  ADD COLUMN IF NOT EXISTS delivery_provider text NOT NULL DEFAULT 'karlivery';
ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS delivery_provider text NOT NULL DEFAULT 'karlivery';

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'karlivery_stores_delivery_provider_check') THEN
    ALTER TABLE public.stores ADD CONSTRAINT karlivery_stores_delivery_provider_check
      CHECK (delivery_provider IN ('karlivery', 'seller'));
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'karlivery_orders_delivery_provider_check') THEN
    ALTER TABLE public.orders ADD CONSTRAINT karlivery_orders_delivery_provider_check
      CHECK (delivery_provider IN ('karlivery', 'seller'));
  END IF;
END $$;

CREATE OR REPLACE FUNCTION public.seller_set_delivery_provider(p_store_id uuid, p_provider text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Login required'; END IF;
  IF p_provider NOT IN ('karlivery', 'seller') OR p_provider IS NULL THEN
    RAISE EXCEPTION 'Choose Karlivery or own rider';
  END IF;
  UPDATE public.stores SET delivery_provider=p_provider
    WHERE id=p_store_id AND owner_id=auth.uid();
  IF NOT FOUND THEN RAISE EXCEPTION 'Only the store owner may change this preference'; END IF;
END; $$;
REVOKE ALL ON FUNCTION public.seller_set_delivery_provider(uuid,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.seller_set_delivery_provider(uuid,text) TO authenticated;

-- Checkout displays the same delivery provider the server will snapshot.
CREATE OR REPLACE FUNCTION public.get_store_delivery_provider(p_store_id uuid)
RETURNS text LANGUAGE sql SECURITY DEFINER SET search_path=public AS $$
  SELECT COALESCE(s.delivery_provider,'karlivery') FROM public.stores s WHERE s.id=p_store_id;
$$;
REVOKE ALL ON FUNCTION public.get_store_delivery_provider(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_store_delivery_provider(uuid) TO authenticated;

-- The provider is snapshotted at creation so changes do not affect already placed orders.
-- Self-delivery orders never enter the Karlivery-rider pool / rider assignment.
CREATE OR REPLACE FUNCTION public.karlivery_v20_order_delivery_guard()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE v_provider text;
BEGIN
  IF TG_OP = 'INSERT' THEN
    SELECT delivery_provider INTO v_provider FROM public.stores WHERE id=NEW.store_id;
    NEW.delivery_provider := CASE WHEN lower(coalesce(NEW.fulfillment::text,''))='delivery'
      THEN coalesce(v_provider,'karlivery') ELSE 'karlivery' END;
  ELSE
    NEW.delivery_provider := OLD.delivery_provider;
  END IF;
  IF NEW.delivery_provider='seller' AND NEW.rider_id IS NOT NULL THEN
    RAISE EXCEPTION 'This order uses the restaurant own rider, not a Karlivery rider';
  END IF;
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS trg_karlivery_v20_order_delivery_guard ON public.orders;
CREATE TRIGGER trg_karlivery_v20_order_delivery_guard
  BEFORE INSERT OR UPDATE ON public.orders FOR EACH ROW
  EXECUTE FUNCTION public.karlivery_v20_order_delivery_guard();

-- Only store owner is authorized to advance the own-rider steps.
CREATE OR REPLACE FUNCTION public.seller_self_delivery_status(p_order_id uuid, p_new_status text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE v_old_status text;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Login required'; END IF;
  SELECT o.status::text INTO v_old_status
  FROM public.orders o JOIN public.stores s ON s.id=o.store_id
  WHERE o.id=p_order_id AND s.owner_id=auth.uid()
    AND o.delivery_provider='seller' AND lower(o.fulfillment::text)='delivery'
  FOR UPDATE OF o;
  IF NOT FOUND THEN RAISE EXCEPTION 'Own-rider order not found or access denied'; END IF;
  IF NOT ((v_old_status='ready' AND p_new_status='delivering') OR
          (v_old_status='delivering' AND p_new_status='delivered')) THEN
    RAISE EXCEPTION 'Invalid own-rider order transition: % -> %', v_old_status,p_new_status;
  END IF;
  -- Dynamic, quoted literal allows either a text or enum order-status column.
  EXECUTE format('UPDATE public.orders SET status=%L, updated_at=now() WHERE id=%L',
    p_new_status, p_order_id);
END; $$;
REVOKE ALL ON FUNCTION public.seller_self_delivery_status(uuid,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.seller_self_delivery_status(uuid,text) TO authenticated;

-- For a seller's own rider, there is no Karlivery-rider settlement to mark sent.
-- Keep existing settlement logic for Karlivery-assigned riders unchanged.
CREATE OR REPLACE FUNCTION public.ensure_delivery_fee_settlement(p_order_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE
  v_owner uuid; v_rider uuid; v_fee numeric;
  v_payment text; v_fulfillment text; v_provider text;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF NOT EXISTS (
    SELECT 1 FROM public.orders ox JOIN public.stores sx ON sx.id=ox.store_id
    WHERE ox.id=p_order_id AND
      (sx.owner_id=auth.uid() OR ox.rider_id=auth.uid() OR public.current_user_role()='admin')
  ) THEN RAISE EXCEPTION 'Order access denied'; END IF;
  SELECT s.owner_id,o.rider_id,coalesce(o.delivery_fee,0),
         lower(o.payment_method::text),lower(o.fulfillment::text),o.delivery_provider
    INTO v_owner,v_rider,v_fee,v_payment,v_fulfillment,v_provider
    FROM public.orders o JOIN public.stores s ON s.id=o.store_id
    WHERE o.id=p_order_id;
  IF v_provider='seller' OR v_payment<>'gcash' OR v_fulfillment<>'delivery' OR v_fee<=0 THEN
    UPDATE public.orders SET rider_fee_settlement_status='not_applicable' WHERE id=p_order_id;
    RETURN;
  END IF;
  UPDATE public.orders
    SET rider_fee_settlement_status=CASE
      WHEN rider_fee_received_at IS NOT NULL THEN 'received'
      WHEN rider_fee_sent_at IS NOT NULL THEN 'sent'
      ELSE 'due' END, updated_at=now()
    WHERE id=p_order_id;
  IF v_owner IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM public.notifications n WHERE n.user_id=v_owner
      AND n.order_id=p_order_id AND n.kind='rider_fee'
      AND coalesce(n.data->>'event','')='rider_fee_due' AND n.is_read=false
  ) THEN
    INSERT INTO public.notifications(user_id,order_id,title,message,kind,data,is_read)
    VALUES (v_owner,p_order_id,'Rider delivery fee must be settled',
      'This GCash delivery includes a Karlivery rider fee of PHP ' || trim(to_char(v_fee,'FM999999990.00')) ||
      '. Transfer it to your assigned rider and mark sent only after paying.',
      'rider_fee',jsonb_build_object('event','rider_fee_due','amount',v_fee,'rider_id',v_rider),false);
  END IF;
END; $$;
GRANT EXECUTE ON FUNCTION public.ensure_delivery_fee_settlement(uuid) TO authenticated;

-- Keep existing paid orders and old settlement records. No update of historical delivery_provider.
CREATE INDEX IF NOT EXISTS idx_karlivery_orders_delivery_provider
  ON public.orders(delivery_provider,status);
COMMIT;

-- Optional read-only post-migration checks:
-- SELECT name,delivery_provider FROM public.stores ORDER BY name;
-- SELECT delivery_provider,count(*) FROM public.orders GROUP BY delivery_provider;
