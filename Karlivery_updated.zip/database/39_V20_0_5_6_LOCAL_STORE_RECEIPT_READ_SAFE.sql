-- Optional permission repair for local-store itemized receipt (review before run).
-- This does NOT modify existing orders, fees, receipts or broad roles.
-- Run only if local-store receipt returns PostgREST 42501 for public.order_items.
-- Customer, assigned rider and store owner remain scoped by the order.
BEGIN;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT SELECT ON TABLE public.order_items TO authenticated;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
DO $policy$
BEGIN
  CREATE POLICY "v20_0_5_6_local_receipt_items_read"
  ON public.order_items FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.orders o
      WHERE o.id = order_items.order_id
        AND (
          o.customer_id = (SELECT auth.uid())
          OR o.rider_id = (SELECT auth.uid())
          OR EXISTS (
            SELECT 1 FROM public.stores s
            WHERE s.id = o.store_id AND s.owner_id = (SELECT auth.uid())
          )
        )
    )
  );
EXCEPTION WHEN duplicate_object THEN NULL;
END;
$policy$;
COMMIT;
-- Verify a customer can read *only their own* order items with a test account.
