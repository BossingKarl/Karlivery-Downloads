-- KARLIVERY V20.0.5: completion receipts, store-to-customer GPS distance.
-- Run AFTER V20 / Pabili migrations 30-32. Back up the project database first.
-- Non-destructive: does not rewrite existing orders or delete customer data.
-- NOTE: changes the delivery fee basis for FUTURE regular-store orders
-- from Camiling Market -> address to STORE -> address.
BEGIN;

ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS delivery_distance_km numeric(10,2);
ALTER TABLE public.pasabuy_orders
  ADD COLUMN IF NOT EXISTS delivery_distance_km numeric(10,2);

CREATE TABLE IF NOT EXISTS public.order_receipt_email_deliveries (
  order_type text NOT NULL CHECK (order_type IN ('regular','pabili')),
  order_id text NOT NULL,
  customer_id uuid NOT NULL,
  status text NOT NULL DEFAULT 'sending' CHECK (status IN ('sending','sent')),
  created_at timestamptz NOT NULL DEFAULT now(),
  sent_at timestamptz,
  PRIMARY KEY (order_type, order_id)
);
ALTER TABLE public.order_receipt_email_deliveries ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.order_receipt_email_deliveries FROM anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.order_receipt_email_deliveries TO service_role;

-- Store-origin pricing uses the existing admin-editable rate settings.
-- Only the authenticated address owner (or admin) can request a quote.
CREATE OR REPLACE FUNCTION public.get_delivery_fee(p_store_id uuid, p_address_id uuid)
RETURNS numeric
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_lat1 double precision;
  v_lon1 double precision;
  v_lat2 double precision;
  v_lon2 double precision;
  v_distance numeric;
  v_base numeric := 50;
  v_included numeric := 3;
  v_step numeric := 2;
  v_increment numeric := 15;
  v_part double precision;
BEGIN
  SELECT latitude, longitude INTO v_lat1, v_lon1
  FROM public.stores WHERE id = p_store_id AND is_approved = true;
  IF NOT FOUND OR v_lat1 IS NULL OR v_lon1 IS NULL THEN
    RAISE EXCEPTION 'Store pickup GPS must be set before delivery pricing';
  END IF;
  SELECT latitude, longitude INTO v_lat2, v_lon2
  FROM public.addresses
  WHERE id = p_address_id
    AND (user_id = auth.uid() OR public.current_user_role() = 'admin');
  IF NOT FOUND OR v_lat2 IS NULL OR v_lon2 IS NULL THEN
    RAISE EXCEPTION 'Select your delivery address with a GPS map pin';
  END IF;
  IF v_lat1 NOT BETWEEN -90 AND 90 OR v_lat2 NOT BETWEEN -90 AND 90 OR
     v_lon1 NOT BETWEEN -180 AND 180 OR v_lon2 NOT BETWEEN -180 AND 180 THEN
    RAISE EXCEPTION 'Store or customer coordinates are outside valid GPS range';
  END IF;
  SELECT base_fee, included_radius_km, step_distance_km, step_fee
    INTO v_base, v_included, v_step, v_increment
  FROM public.delivery_rate_settings WHERE id = 1;
  v_base := coalesce(v_base, 50);
  v_included := greatest(coalesce(v_included, 3), 0.1);
  v_step := greatest(coalesce(v_step, 2), 0.1);
  v_increment := coalesce(v_increment, 15);
  v_part := power(sin(radians(v_lat2 - v_lat1) / 2), 2)
    + cos(radians(v_lat1)) * cos(radians(v_lat2))
    * power(sin(radians(v_lon2 - v_lon1) / 2), 2);
  v_distance := (6371 * 2 * asin(sqrt(greatest(0.0, least(1.0, v_part)))))::numeric;
  RETURN round(v_base + greatest(0, ceil((v_distance - v_included) / v_step)) * v_increment, 2);
END;
$$;
GRANT EXECUTE ON FUNCTION public.get_delivery_fee(uuid, uuid) TO authenticated;

-- Snapshot original pickup/delivery distance for regular orders on insertion.
-- Fee is calculated by the authoritative place_order RPC; snapshot will never
-- silently overwrite the charged fee or amend existing order records.
CREATE OR REPLACE FUNCTION public.karlivery_snapshot_order_distance()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_lat1 double precision;
  v_lon1 double precision;
  v_lat2 double precision;
  v_lon2 double precision;
  v_part double precision;
BEGIN
  IF NEW.fulfillment IS DISTINCT FROM 'delivery' OR NEW.address_id IS NULL THEN
    NEW.delivery_distance_km := NULL;
    RETURN NEW;
  END IF;
  SELECT latitude, longitude INTO v_lat1, v_lon1 FROM public.stores WHERE id = NEW.store_id;
  SELECT latitude, longitude INTO v_lat2, v_lon2 FROM public.addresses WHERE id = NEW.address_id;
  IF v_lat1 IS NULL OR v_lon1 IS NULL OR v_lat2 IS NULL OR v_lon2 IS NULL THEN
    NEW.delivery_distance_km := NULL;
    RETURN NEW;
  END IF;
  v_part := power(sin(radians(v_lat2 - v_lat1) / 2), 2)
    + cos(radians(v_lat1)) * cos(radians(v_lat2))
    * power(sin(radians(v_lon2 - v_lon1) / 2), 2);
  NEW.delivery_distance_km := round((6371 * 2 * asin(sqrt(greatest(0.0, least(1.0, v_part)))))::numeric, 2);
  RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS karlivery_order_distance_snapshot ON public.orders;
CREATE TRIGGER karlivery_order_distance_snapshot
BEFORE INSERT ON public.orders
FOR EACH ROW EXECUTE FUNCTION public.karlivery_snapshot_order_distance();

-- Preserve the existing server-side Pabili fee validation and include the
-- calculated kilometer snapshot in every NEW Pabili order.
CREATE OR REPLACE FUNCTION public.pasabuy_validate_and_quote_v19_7()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  s record;
  a record;
  x double precision;
  km double precision;
BEGIN
  SELECT latitude, longitude, coordinate_source INTO s
  FROM public.pasabuy_shops WHERE id = NEW.shop_id AND is_active = true;
  IF NOT FOUND OR s.latitude IS NULL OR s.longitude IS NULL OR
     s.coordinate_source IS DISTINCT FROM 'admin_confirmed' THEN
    RAISE EXCEPTION 'Pabili pickup GPS must be confirmed by admin before checkout';
  END IF;
  SELECT latitude, longitude, user_id INTO a FROM public.addresses WHERE id = NEW.address_id;
  IF NOT FOUND OR a.latitude IS NULL OR a.longitude IS NULL THEN
    RAISE EXCEPTION 'Choose a delivery address with a GPS map pin';
  END IF;
  IF a.user_id IS DISTINCT FROM NEW.customer_id THEN
    RAISE EXCEPTION 'Delivery address does not belong to customer';
  END IF;
  IF s.latitude NOT BETWEEN -90 AND 90 OR a.latitude NOT BETWEEN -90 AND 90 OR
     s.longitude NOT BETWEEN -180 AND 180 OR a.longitude NOT BETWEEN -180 AND 180 THEN
    RAISE EXCEPTION 'Invalid GPS coordinates';
  END IF;
  x := power(sin(radians(a.latitude - s.latitude) / 2), 2)
     + cos(radians(s.latitude)) * cos(radians(a.latitude))
     * power(sin(radians(a.longitude - s.longitude) / 2), 2);
  km := 6371 * 2 * asin(sqrt(greatest(0.0, least(1.0, x))));
  NEW.delivery_distance_km := round(km::numeric, 2);
  NEW.handling_fee := 20;
  NEW.delivery_fee := CASE WHEN km <= 3 THEN 50
                      ELSE 50 + ceil((km - 3) / 2.0) * 15 END;
  NEW.total_amount := NEW.subtotal + NEW.handling_fee + NEW.delivery_fee;
  RETURN NEW;
END;
$$;

-- The existing pasabuy_quote_new_order_v19_7 trigger continues using this
-- replaced function. Order history is deliberately not recalculated.
COMMIT;
NOTIFY pgrst, 'reload schema';

-- Read-only review of newly snapshotted data:
SELECT 'regular' AS order_type, count(*) FILTER (WHERE delivery_distance_km IS NOT NULL) AS with_distance
FROM public.orders
UNION ALL
SELECT 'pabili', count(*) FILTER (WHERE delivery_distance_km IS NOT NULL)
FROM public.pasabuy_orders;
