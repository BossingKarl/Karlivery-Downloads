-- ============================================================
-- KARLIVERY V11.6 — HOME FEED / GUEST BROWSE / REVIEWS / REORDER
-- Run ONCE after SQL 08.
-- ============================================================

alter table public.stores
  add column if not exists prep_min_minutes integer not null default 15,
  add column if not exists prep_max_minutes integer not null default 30;

do $$
begin
  if not exists (select 1 from pg_constraint where conname='stores_prep_min_minutes_check') then
    alter table public.stores add constraint stores_prep_min_minutes_check
      check (prep_min_minutes between 5 and 180);
  end if;
  if not exists (select 1 from pg_constraint where conname='stores_prep_max_minutes_check') then
    alter table public.stores add constraint stores_prep_max_minutes_check
      check (prep_max_minutes between 5 and 240 and prep_max_minutes >= prep_min_minutes);
  end if;
end $$;

-- One optimized request for approved restaurants + real popularity/rating data.
drop function if exists public.karlivery_home_feed(uuid);
create or replace function public.karlivery_home_feed(p_address_id uuid default null)
returns setof jsonb
language sql
security definer
set search_path=public
as $$
with selected_address as (
  select a.id,a.barangay,a.latitude,a.longitude
  from public.addresses a
  where a.id=p_address_id and auth.uid() is not null and a.user_id=auth.uid()
  limit 1
), rating_stats as (
  select r.store_id, round(avg(r.store_rating)::numeric,2) rating_avg, count(*)::bigint rating_count
  from public.order_ratings r group by r.store_id
), popularity as (
  select o.store_id,
    count(*) filter (where o.status::text in ('delivered','completed'))::bigint completed_orders
  from public.orders o group by o.store_id
)
select to_jsonb(s) || jsonb_build_object(
  'rating_avg',rs.rating_avg,
  'rating_count',coalesce(rs.rating_count,0),
  'completed_orders',coalesce(pop.completed_orders,0),
  'distance_km', case
    when a.latitude is null or a.longitude is null or s.latitude is null or s.longitude is null then null
    else round((6371*2*asin(sqrt(
      power(sin(radians(a.latitude-s.latitude)/2),2)+
      cos(radians(s.latitude))*cos(radians(a.latitude))*
      power(sin(radians(a.longitude-s.longitude)/2),2)
    )))::numeric,2) end,
  'delivery_fee_preview', case
    when a.id is null then null
    when lower(coalesce(a.barangay,'')) like '%poblacion%' then 50
    when a.latitude is null or a.longitude is null or s.latitude is null or s.longitude is null then null
    else (50 + 10*ceil(6371*2*asin(sqrt(
      power(sin(radians(a.latitude-s.latitude)/2),2)+
      cos(radians(s.latitude))*cos(radians(a.latitude))*
      power(sin(radians(a.longitude-s.longitude)/2),2)
    ))))::numeric end,
  'eta_min_minutes', case
    when a.latitude is null or a.longitude is null or s.latitude is null or s.longitude is null then s.prep_min_minutes
    else s.prep_min_minutes + greatest(5,ceil((6371*2*asin(sqrt(
      power(sin(radians(a.latitude-s.latitude)/2),2)+
      cos(radians(s.latitude))*cos(radians(a.latitude))*
      power(sin(radians(a.longitude-s.longitude)/2),2)
    )))/22*60)::integer) end,
  'eta_max_minutes', case
    when a.latitude is null or a.longitude is null or s.latitude is null or s.longitude is null then s.prep_max_minutes
    else s.prep_max_minutes + greatest(8,ceil((6371*2*asin(sqrt(
      power(sin(radians(a.latitude-s.latitude)/2),2)+
      cos(radians(s.latitude))*cos(radians(a.latitude))*
      power(sin(radians(a.longitude-s.longitude)/2),2)
    )))/18*60)::integer) end
)
from public.stores s
left join selected_address a on true
left join rating_stats rs on rs.store_id=s.id
left join popularity pop on pop.store_id=s.id
where coalesce(s.is_approved,false)=true
order by s.is_open desc,coalesce(pop.completed_orders,0) desc,coalesce(rs.rating_avg,0) desc,s.name;
$$;
grant execute on function public.karlivery_home_feed(uuid) to anon,authenticated;

-- One request for featured food instead of one request per restaurant.
drop function if exists public.karlivery_featured_products(integer);
create or replace function public.karlivery_featured_products(p_limit integer default 16)
returns setof jsonb
language sql
security definer
set search_path=public
as $$
select to_jsonb(p) || jsonb_build_object(
  '_store_id',s.id,'_store_name',s.name,'_store_logo',s.logo_url,
  '_store_open',s.is_open,'_store_rating_avg',rs.rating_avg,
  '_store_rating_count',coalesce(rs.rating_count,0)
)
from public.products p
join public.stores s on s.id=p.store_id
left join lateral (
  select round(avg(r.store_rating)::numeric,2) rating_avg,count(*)::bigint rating_count
  from public.order_ratings r where r.store_id=s.id
) rs on true
where coalesce(s.is_approved,false)=true and coalesce(p.is_available,true)=true
order by p.is_featured desc,s.is_open desc,coalesce(rs.rating_avg,0) desc,p.name
limit greatest(1,least(coalesce(p_limit,16),50));
$$;
grant execute on function public.karlivery_featured_products(integer) to anon,authenticated;

-- Guest-safe approved restaurant/catalog RPCs.
drop function if exists public.karlivery_public_store(uuid);
create or replace function public.karlivery_public_store(p_store_id uuid)
returns setof jsonb language sql security definer set search_path=public as $$
select to_jsonb(s) || jsonb_build_object(
  'rating_avg',rs.rating_avg,'rating_count',coalesce(rs.rating_count,0),
  'completed_orders',coalesce(pop.completed_orders,0)
)
from public.stores s
left join lateral (
  select round(avg(r.store_rating)::numeric,2) rating_avg,count(*)::bigint rating_count
  from public.order_ratings r where r.store_id=s.id
) rs on true
left join lateral (
  select count(*) filter (where o.status::text in ('delivered','completed'))::bigint completed_orders
  from public.orders o where o.store_id=s.id
) pop on true
where s.id=p_store_id and coalesce(s.is_approved,false)=true limit 1;
$$;
grant execute on function public.karlivery_public_store(uuid) to anon,authenticated;

drop function if exists public.karlivery_public_products(uuid);
create or replace function public.karlivery_public_products(p_store_id uuid)
returns setof jsonb language sql security definer set search_path=public as $$
select to_jsonb(p) || jsonb_build_object(
  'product_addons',coalesce((
    select jsonb_agg(to_jsonb(pa) order by pa.name)
    from public.product_addons pa
    where pa.product_id=p.id and coalesce(pa.is_available,true)=true
  ),'[]'::jsonb)
)
from public.products p
join public.stores s on s.id=p.store_id
where p.store_id=p_store_id and coalesce(s.is_approved,false)=true
order by p.is_featured desc,coalesce(p.is_available,true) desc,p.category,p.name;
$$;
grant execute on function public.karlivery_public_products(uuid) to anon,authenticated;

drop function if exists public.karlivery_public_gallery(uuid);
create or replace function public.karlivery_public_gallery(p_store_id uuid)
returns setof jsonb language sql security definer set search_path=public as $$
select to_jsonb(g)
from public.store_gallery g join public.stores s on s.id=g.store_id
where g.store_id=p_store_id and coalesce(s.is_approved,false)=true
order by g.sort_order,g.created_at;
$$;
grant execute on function public.karlivery_public_gallery(uuid) to anon,authenticated;

-- Verified-order restaurant reviews.
drop function if exists public.karlivery_store_reviews(uuid,integer);
create or replace function public.karlivery_store_reviews(p_store_id uuid,p_limit integer default 60)
returns table(rating integer,rider_rating integer,comment text,customer_name text,created_at timestamptz)
language sql security definer set search_path=public as $$
select r.store_rating,r.rider_rating,r.comment,
  case when coalesce(trim(p.full_name),'')='' then 'Karlivery customer'
       else split_part(trim(p.full_name),' ',1) end,
  r.created_at
from public.order_ratings r
left join public.profiles p on p.id=r.customer_id
where r.store_id=p_store_id
order by r.created_at desc
limit greatest(1,least(coalesce(p_limit,60),100));
$$;
grant execute on function public.karlivery_store_reviews(uuid,integer) to anon,authenticated;

-- Reorder only currently available products. Add-ons are intentionally reselected.
drop function if exists public.karlivery_reorder_payload(uuid);
create or replace function public.karlivery_reorder_payload(p_order_id uuid)
returns jsonb language sql security definer set search_path=public as $$
select jsonb_build_object(
  'store_id',o.store_id,'store_name',s.name,
  'original_item_count',(select coalesce(sum(oi.quantity),0) from public.order_items oi where oi.order_id=o.id),
  'available_item_count',(select coalesce(sum(oi.quantity),0) from public.order_items oi join public.products p on p.id=oi.product_id and p.store_id=o.store_id and coalesce(p.is_available,true)=true where oi.order_id=o.id),
  'items',coalesce((
    select jsonb_agg(jsonb_build_object(
      'product',to_jsonb(p) || jsonb_build_object('product_addons',coalesce((
        select jsonb_agg(to_jsonb(pa) order by pa.name) from public.product_addons pa
        where pa.product_id=p.id and coalesce(pa.is_available,true)=true
      ),'[]'::jsonb)),
      'quantity',oi.quantity
    ) order by oi.product_name)
    from public.order_items oi
    join public.products p on p.id=oi.product_id and p.store_id=o.store_id and coalesce(p.is_available,true)=true
    where oi.order_id=o.id
  ),'[]'::jsonb)
)
from public.orders o join public.stores s on s.id=o.store_id
where o.id=p_order_id and o.customer_id=auth.uid() and o.status::text in ('delivered','completed')
limit 1;
$$;
grant execute on function public.karlivery_reorder_payload(uuid) to authenticated;
