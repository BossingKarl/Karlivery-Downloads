-- Karlivery: approved-store menu search for customer & guest web/mobile feeds.
-- Optional: deploy once using Supabase SQL Editor before enabling full menu search.
-- Read-only, bounded, with no private profiles, orders, or payment information.
create or replace function public.karlivery_search_menu(
  p_query text,
  p_limit integer default 40
)
returns setof jsonb
language sql stable security definer set search_path = ''
as $$
  select to_jsonb(p) || jsonb_build_object(
    '_store_id', s.id,
    '_store_name', s.name,
    '_store_logo', s.logo_url,
    '_store_open', s.is_open
  )
  from public.products p
  join public.stores s on s.id = p.store_id
  where coalesce(s.is_approved, false) = true
    and coalesce(p.is_available, true) = true
    and length(btrim(coalesce(p_query, ''))) >= 2
    and (
      coalesce(p.name, '') ilike '%' || btrim(p_query) || '%'
      or coalesce(p.description, '') ilike '%' || btrim(p_query) || '%'
      or coalesce(p.category, '') ilike '%' || btrim(p_query) || '%'
    )
  order by s.is_open desc, p.is_featured desc, p.name
  limit greatest(1, least(coalesce(p_limit, 40), 60));
$$;
revoke all on function public.karlivery_search_menu(text, integer) from public;
grant execute on function public.karlivery_search_menu(text, integer) to anon, authenticated;
