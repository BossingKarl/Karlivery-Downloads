-- KARLIVERY V20.0.5.5 -- Pabili receipt reads and privacy-scoped rider GPS.
-- Back up Supabase before applying; execute only once after Pabili core tables (20, 22).
-- No table deletion, order deletion, historical price updates, or public GPS access.

BEGIN;

GRANT USAGE ON SCHEMA public TO authenticated;
GRANT SELECT ON public.pasabuy_orders TO authenticated;

-- The receipt SELECTs order rows and nested addons. RLS is still enforced.
GRANT SELECT ON public.pasabuy_order_items TO authenticated;
GRANT SELECT ON public.pasabuy_order_item_addons TO authenticated;
ALTER TABLE public.pasabuy_order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pasabuy_order_item_addons ENABLE ROW LEVEL SECURITY;

-- Explicit participant policies repair installations where migration 22 was
-- only partly executed. Policies are additive with existing restrictive ones.
DROP POLICY IF EXISTS "v20_0_5_5_pabili_receipt_items_read" ON public.pasabuy_order_items;
CREATE POLICY "v20_0_5_5_pabili_receipt_items_read"
ON public.pasabuy_order_items FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.pasabuy_orders o
    WHERE o.id = pasabuy_order_items.order_id
      AND (o.customer_id = (SELECT auth.uid())
           OR o.rider_id = (SELECT auth.uid())
           OR public.current_user_role() = 'admin')
  )
);

DROP POLICY IF EXISTS "v20_0_5_5_pabili_receipt_addons_read" ON public.pasabuy_order_item_addons;
CREATE POLICY "v20_0_5_5_pabili_receipt_addons_read"
ON public.pasabuy_order_item_addons FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.pasabuy_order_items oi
    JOIN public.pasabuy_orders o ON o.id = oi.order_id
    WHERE oi.id = pasabuy_order_item_addons.order_item_id
      AND (o.customer_id = (SELECT auth.uid())
           OR o.rider_id = (SELECT auth.uid())
           OR public.current_user_role() = 'admin')
  )
);

-- Pabili location is private. Only the assigned rider can publish it;
-- only the order participants/admin may view the latest saved point.
GRANT SELECT, INSERT, UPDATE ON public.pasabuy_rider_locations TO authenticated;
REVOKE ALL ON public.pasabuy_rider_locations FROM anon;
ALTER TABLE public.pasabuy_rider_locations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "pasabuy tracking participants read" ON public.pasabuy_rider_locations;
DROP POLICY IF EXISTS "pasabuy rider tracking write" ON public.pasabuy_rider_locations;
DROP POLICY IF EXISTS "v20_0_5_5_pabili_gps_read" ON public.pasabuy_rider_locations;
DROP POLICY IF EXISTS "v20_0_5_5_pabili_gps_insert" ON public.pasabuy_rider_locations;
DROP POLICY IF EXISTS "v20_0_5_5_pabili_gps_update" ON public.pasabuy_rider_locations;

CREATE POLICY "v20_0_5_5_pabili_gps_read"
ON public.pasabuy_rider_locations FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.pasabuy_orders o
    WHERE o.id = pasabuy_rider_locations.order_id
      AND (o.customer_id = (SELECT auth.uid())
           OR o.rider_id = (SELECT auth.uid())
           OR public.current_user_role() = 'admin')
  )
);

CREATE POLICY "v20_0_5_5_pabili_gps_insert"
ON public.pasabuy_rider_locations FOR INSERT TO authenticated
WITH CHECK (
  rider_id = (SELECT auth.uid())
  AND EXISTS (
    SELECT 1 FROM public.pasabuy_orders o
    WHERE o.id = pasabuy_rider_locations.order_id
      AND o.rider_id = (SELECT auth.uid())
      AND o.status NOT IN ('Delivered', 'Cancelled', 'Canceled')
  )
);

CREATE POLICY "v20_0_5_5_pabili_gps_update"
ON public.pasabuy_rider_locations FOR UPDATE TO authenticated
USING (
  rider_id = (SELECT auth.uid())
  AND EXISTS (
    SELECT 1 FROM public.pasabuy_orders o
    WHERE o.id = pasabuy_rider_locations.order_id
      AND o.rider_id = (SELECT auth.uid())
      AND o.status NOT IN ('Delivered', 'Cancelled', 'Canceled')
  )
)
WITH CHECK (
  rider_id = (SELECT auth.uid())
  AND EXISTS (
    SELECT 1 FROM public.pasabuy_orders o
    WHERE o.id = pasabuy_rider_locations.order_id
      AND o.rider_id = (SELECT auth.uid())
      AND o.status NOT IN ('Delivered', 'Cancelled', 'Canceled')
  )
);

-- An assigned rider needs destination coordinates, but should not need broad
-- SELECT access to all customer addresses. Authorize this single order only.
CREATE OR REPLACE FUNCTION public.karlivery_pabili_tracking_destination(p_order_id text)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = ''
AS $function$
DECLARE
  v_customer uuid;
  v_rider uuid;
  v_address uuid;
  v_lat double precision;
  v_lng double precision;
  v_line text;
  v_barangay text;
  v_city text;
  v_user uuid;
BEGIN
  v_user := auth.uid();
  IF v_user IS NULL THEN
    RAISE EXCEPTION 'Please sign in to see Pabili navigation' USING ERRCODE = '42501';
  END IF;
  SELECT o.customer_id, o.rider_id, o.address_id
    INTO v_customer, v_rider, v_address
  FROM public.pasabuy_orders o WHERE o.id = p_order_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Pabili order not available' USING ERRCODE = '42501';
  END IF;
  IF v_user IS DISTINCT FROM v_customer
     AND v_user IS DISTINCT FROM v_rider
     AND public.current_user_role() IS DISTINCT FROM 'admin' THEN
    RAISE EXCEPTION 'Only order participants may access this delivery pin'
      USING ERRCODE = '42501';
  END IF;
  SELECT a.latitude, a.longitude, a.address_line, a.barangay, a.city
    INTO v_lat, v_lng, v_line, v_barangay, v_city
  FROM public.addresses a WHERE a.id = v_address;
  IF NOT FOUND OR v_lat IS NULL OR v_lng IS NULL OR
     v_lat NOT BETWEEN -90 AND 90 OR v_lng NOT BETWEEN -180 AND 180 THEN
    RAISE EXCEPTION 'Delivery address GPS pin is missing or invalid';
  END IF;
  RETURN jsonb_build_object(
    'latitude', v_lat,
    'longitude', v_lng,
    'address_label', concat_ws(', ', nullif(btrim(v_line), ''),
                               nullif(btrim(v_barangay), ''), nullif(btrim(v_city), ''))
  );
END;
$function$;

REVOKE ALL ON FUNCTION public.karlivery_pabili_tracking_destination(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.karlivery_pabili_tracking_destination(text) TO authenticated;

-- Supabase .stream() requires tables to be in the publication for updates.
DO $realtime$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime')
     AND NOT EXISTS (
       SELECT 1 FROM pg_publication_tables
       WHERE pubname = 'supabase_realtime'
         AND schemaname = 'public'
         AND tablename = 'pasabuy_rider_locations'
     ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.pasabuy_rider_locations;
  END IF;
END
$realtime$;

NOTIFY pgrst, 'reload schema';
COMMIT;

-- Read-only diagnostics: verify privileges, policies and Realtime publication.
SELECT table_name, grantee, privilege_type
FROM information_schema.role_table_grants
WHERE table_schema = 'public'
  AND table_name IN ('pasabuy_order_items','pasabuy_order_item_addons','pasabuy_rider_locations')
  AND grantee IN ('authenticated','anon')
ORDER BY table_name, grantee, privilege_type;

SELECT tablename, policyname, cmd, roles
FROM pg_policies
WHERE schemaname = 'public'
  AND tablename IN ('pasabuy_order_items','pasabuy_order_item_addons','pasabuy_rider_locations')
ORDER BY tablename, policyname;

SELECT schemaname, tablename FROM pg_publication_tables
WHERE pubname = 'supabase_realtime' AND schemaname = 'public'
  AND tablename = 'pasabuy_rider_locations';
