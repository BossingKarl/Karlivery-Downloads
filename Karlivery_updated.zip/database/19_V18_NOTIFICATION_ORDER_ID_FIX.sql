-- =========================================================
-- KARLIVERY V18.0.1 — NOTIFICATION ORDER_ID SCHEMA FIX
-- Run ONCE after database/18_V17_NOTIFICATION_REALTIME.sql
--
-- Fixes older Karlivery databases where public.notifications already
-- existed before migration 08, so CREATE TABLE IF NOT EXISTS did not
-- add order_id. V17/V18 push-notify persists order/chat notifications
-- with this column and announcements use NULL.
-- =========================================================

BEGIN;

ALTER TABLE public.notifications
  ADD COLUMN IF NOT EXISTS order_id uuid;

-- Announcements and login notices are not tied to an order.
ALTER TABLE public.notifications
  ALTER COLUMN order_id DROP NOT NULL;

-- Add the FK only when it is not already present.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint c
    WHERE c.conrelid = 'public.notifications'::regclass
      AND c.contype = 'f'
      AND c.conname = 'notifications_order_id_fkey'
  ) THEN
    ALTER TABLE public.notifications
      ADD CONSTRAINT notifications_order_id_fkey
      FOREIGN KEY (order_id)
      REFERENCES public.orders(id)
      ON DELETE CASCADE;
  END IF;
END
$$;

CREATE INDEX IF NOT EXISTS idx_notifications_order_id
  ON public.notifications(order_id)
  WHERE order_id IS NOT NULL;

-- Ask PostgREST to immediately refresh its schema cache.
NOTIFY pgrst, 'reload schema';

COMMIT;
