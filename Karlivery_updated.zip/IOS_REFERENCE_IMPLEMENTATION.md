# Karlivery — iOS-inspired implementation checkpoint

Based on the provided 10-screen visual reference. This package preserves existing Supabase-backed Flutter workflows and changes the shared Customer Home hero, Customer navigation, search hierarchy, and Android route transitions.

## Implemented in source
- Photo-first Customer Home promotional hero, with network image from existing featured products and a neutral fallback. No fabricated discounts or stores.
- Compact iOS-like customer tab bar, with original five working destinations and basket badge.
- Delivery-address hierarchy and search copy.
- Cupertino-style page transitions on Android and iOS.

## Reference screens mapped to existing Flutter source
- Customer Home: `lib/features/customer/customer_shell.dart`
- Restaurant Menu: `lib/features/customer/store_screen.dart`
- Item Details: `lib/features/customer/product_detail_sheet.dart`
- Cart & Checkout: `lib/features/customer/cart_screen.dart`, `checkout_flow.dart`
- Order Tracking: `lib/features/customer/order_detail_screen.dart`, `lib/features/shared/tracking_screen.dart`
- Seller Dashboard: `lib/features/store/store_dashboard.dart`
- Rider App: `lib/features/rider/rider_dashboard.dart`
- Admin Dashboard: `lib/features/admin/admin_dashboard.dart`
- Pasabuy: `lib/features/pasabuy/pasabuy_home_screen.dart`
- Profile: `lib/features/customer/customer_shell.dart`

## Validation
Source edits and ZIP integrity can be verified here. Flutter SDK is not installed in this environment; `flutter analyze`, tests, Android compilation, and web compilation have NOT been run. The screenshot is a visual target, not a representation of current implemented screens.

## Build
Use `flutter pub get`, `flutter analyze`, `flutter test`, `flutter build web --release`, and `flutter build apk --release` from the source root. Review Supabase configuration and original Android signing before release.
