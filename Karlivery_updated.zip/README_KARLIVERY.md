# Karlivery

## This delivery
- Rebuilt the **actual Flutter customer discovery hero** (`lib/core/customer_discovery_hero.dart`) with a photography-first editorial layout, improved contrast, responsive text sizing, and accessible action.
- Preserved live featured-product image URL, store counts, and scroll-to-stores callback. No fabricated discounts or ETAs.
- Included `karlivery-preview.html` with the real Karlivery logo embedded. Store cards in the preview are illustrative, not live Supabase data.
- Kept existing customer, seller, rider, admin and backend files intact.

## Validation
- ZIP integrity checked. No Flutter SDK in this execution environment, so analyzer/tests/Android/iOS compilation are **not verified**.
- No changes to Supabase database, Edge Functions or GitHub production branches.

## Important
The connected GitHub repository `Karlivery-Camiling-Android` is an Android WebView wrapper (package `com.karlivery.camiling`), not the full Flutter source. Do not replace its signing identity or application ID.

## Test locally
Run `flutter pub get`, `flutter analyze`, `flutter test`, and `flutter build web --release`. Android and iOS require appropriate platform projects and signing configuration.

## Basket usability update (October 23)
- Added per-line Remove action, explicit basket-clear confirmation, and visible item count.
- Shows both per-unit price and line subtotal, including selected add-ons.
- Clarifies that delivery charges are finalized in checkout; no fake delivery quote.
- Existing CartService and checkout order flow are unchanged.
- Static code inspection only; Flutter SDK is not installed here, so compilation must be verified locally.
