import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:karl_delivery/core/modern_ui.dart';
import 'package:karl_delivery/features/rider/hydration_card.dart';
import 'package:karl_delivery/theme/app_theme.dart';

void main() {
  testWidgets('Dashboard cards fit a small phone at large text scale', (tester) async {
    tester.view.physicalSize = const Size(320, 800);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(MaterialApp(theme: AppTheme.light(), home: MediaQuery(
      data: const MediaQueryData(size: Size(320, 800), textScaler: TextScaler.linear(2)),
      child: Scaffold(body: ListView(padding: const EdgeInsets.all(18), children: const [
        KPageHeader(eyebrow: 'Rider workspace', title: 'Ready for deliveries',
          subtitle: 'Manage your deliveries.', icon: Icons.delivery_dining_outlined),
        SizedBox(height: 12),
        RiderHydrationCard(),
        SizedBox(height: 12),
        KMetricGrid(children: [
          KMetricCard(label: 'Active deliveries', value: '12', icon: Icons.route_outlined),
          KMetricCard(label: 'Ready to claim', value: '8', icon: Icons.inventory_2_outlined),
        ]),
      ])),
    )));
    expect(tester.takeException(), isNull);
    expect(find.text('Stay hydrated, ka-rider!'), findsOneWidget);
    await tester.drag(find.byType(ListView), const Offset(0, -400));
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
  });

  testWidgets('Wide dashboard rail switches pages', (tester) async {
    tester.view.physicalSize = const Size(1200, 800);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    int page = 0;
    await tester.pumpWidget(MaterialApp(theme: AppTheme.dark(), home: StatefulBuilder(
      builder: (context, setState) => KDashboardScaffold(
        body: Center(child: Text('Page $page')),
        bottomNavigationBar: NavigationBar(selectedIndex: page,
          onDestinationSelected: (value) => setState(() => page = value),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'Orders'),
          ]),
      ),
    )));
    expect(find.byType(NavigationRail), findsOneWidget);
    await tester.tap(find.descendant(
      of: find.byType(NavigationRail),
      matching: find.text('Orders'),
    ));
    // The dashboard may contain repeating decorative animations, so waiting
    // for every scheduled frame to settle would never finish. Pump long
    // enough for the NavigationRail selection animation, then check the page.
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 500));
    expect(find.text('Page 1'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
