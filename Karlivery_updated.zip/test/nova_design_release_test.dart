import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:karl_delivery/theme/app_theme.dart';
import 'package:karl_delivery/core/nova_headline.dart';

void main() {
  test('Karlivery warm design system palette', () {
    expect(AppTheme.red, const Color(0xFFE51E32));
    expect(AppTheme.yellow, const Color(0xFFFFCC35));
    expect(AppTheme.ink, const Color(0xFF1C1C1E));
    expect(AppTheme.light().useMaterial3, isTrue);
  });

  testWidgets('Shared warm hero adapts on small screen', (tester) async {
    tester.view.physicalSize = const Size(320, 680);
    tester.view.devicePixelRatio = 1;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    await tester.pumpWidget(MaterialApp(
      theme: AppTheme.light(),
      home: const Scaffold(body: SingleChildScrollView(child: NovaHeadline(
        eyebrow: 'KARLIVERY / RIDER',
        title: 'Let’s make moves.',
        subtitle: 'Your route and requests in one place.',
        icon: Icons.delivery_dining_rounded,
      ))),
    ));
    expect(find.text('Let’s make moves.'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
