import 'package:flutter_test/flutter_test.dart';
import 'package:karl_delivery/services/pasabuy_service.dart';

void main() {
  test('Pabili keeps its handling charge separate from delivery rates', () {
    expect(PasabuyService.handlingFee, 20);
  });

  test('Quote fee is read from server (not a fixed 2 km step formula)', () {
    // These are examples of server responses after different admin settings.
    expect(PasabuyService.quoteDeliveryFee({'delivery_fee': 50}), 50);
    expect(PasabuyService.quoteDeliveryFee({'delivery_fee': '80.00'}), 80);
    expect(PasabuyService.quoteDeliveryFee({'delivery_fee': 125.5}), 125.5);
  });

  test('Missing, invalid or unsafe server quotes are rejected', () {
    for (final invalid in [null, '', -1, 'NaN', 'Infinity', 'invalid']) {
      expect(
        () => PasabuyService.quoteDeliveryFee({'delivery_fee': invalid}),
        throwsStateError,
      );
    }
  });

  test('Unconfirmed pickup pins cannot accept Pabili orders', () {
    expect(PasabuyService.hasConfirmedPickup(null), isFalse);
    expect(PasabuyService.hasConfirmedPickup({}), isFalse);
    expect(PasabuyService.hasConfirmedPickup({'coordinate_source': 'town_center_estimate'}), isFalse);
    expect(PasabuyService.hasConfirmedPickup({'coordinate_source': 'admin_confirmed'}), isTrue);
  });
}
