import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:karl_delivery/core/karlivery_2026.dart';
import 'package:karl_delivery/theme/app_theme.dart';

void main() {
  testWidgets('Customer quick actions keep accessible tap targets', (tester) async {
    var navigated = false;
    await tester.pumpWidget(MaterialApp(
      theme: AppTheme.light(),
      home: Scaffold(
        body: Center(
          child: SizedBox(
            width: 340,
            child: K26ActionGrid(actions: [
              K26Action(
                icon: Icons.shopping_basket_rounded,
                title: 'Pabili',
                subtitle: 'Request from nearby stores',
                onTap: () => navigated = true,
              ),
              K26Action(
                icon: Icons.receipt_long_rounded,
                title: 'Receipts',
                subtitle: 'Completed orders',
                onTap: () {},
              ),
            ]),
          ),
        ),
      ),
    ));
    expect(find.text('Pabili'), findsOneWidget);
    expect(find.text('Receipts'), findsOneWidget);
    await tester.tap(find.text('Pabili'));
    await tester.pump();
    expect(navigated, isTrue);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Workspace banner renders on compact phones', (tester) async {
    await tester.pumpWidget(MaterialApp(
      theme: AppTheme.light(),
      home: Scaffold(body: SizedBox(
        width: 320,
        child: const K26Headline(
          eyebrow: 'Rider workspace',
          title: 'Ready when you are.',
          subtitle: 'Everything for your next delivery, all in one place.',
          icon: Icons.delivery_dining_rounded,
        ),
      )),
    ));
    expect(find.text('Ready when you are.'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
