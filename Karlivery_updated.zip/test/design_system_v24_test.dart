import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:karl_delivery/design_system/k_tokens.dart';
import 'package:karl_delivery/design_system/k_components.dart';
import 'package:karl_delivery/core/future_food_ui.dart';
import 'package:karl_delivery/core/nova_headline.dart';
import 'package:karl_delivery/theme/app_theme.dart';

void main() {
  test('V24 retains Karlivery brand colors and shared responsive rules', () {
    expect(AppTheme.red, const Color(0xFFE51E32));
    expect(AppTheme.yellow, const Color(0xFFFFCC35));
    expect(AppTheme.ink, const Color(0xFF1C1C1E));
    expect(KBreakpoints.storeColumns(320), 1);
    expect(KBreakpoints.storeColumns(356), 2);
    expect(KBreakpoints.storeColumns(390), 2);
    expect(KBreakpoints.storeColumns(760), 3);
    expect(KBreakpoints.storeColumns(1100), 4);
    expect(KBreakpoints.storeColumns(390, textScale: 1.7), 1);
  });

  testWidgets('All role hero variants remain renderable on a phone', (tester) async {
    tester.view.physicalSize = const Size(390, 844);
    tester.view.devicePixelRatio = 1;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    await tester.pumpWidget(MaterialApp(
      theme: AppTheme.light(),
      home: const Scaffold(body: SingleChildScrollView(child: Column(
        children: [
          NovaHeadline(eyebrow: 'KARLIVERY / CUSTOMER', title: 'Good food, brighter days',
            subtitle: 'Discover neighborhood favorites', icon: Icons.restaurant),
          SizedBox(height: 12),
          NovaHeadline(eyebrow: 'KARLIVERY / RIDER', title: 'Your shift, your pace',
            subtitle: 'Your deliveries', icon: Icons.delivery_dining),
          SizedBox(height: 12),
          NovaHeadline(eyebrow: 'YOUR STORE DASHBOARD', title: 'Seller HQ',
            subtitle: 'Manage menu and orders', icon: Icons.storefront),
          SizedBox(height: 12),
          NovaHeadline(eyebrow: 'KARLIVERY / ADMIN', title: 'Command center',
            subtitle: 'Approvals and orders', icon: Icons.admin_panel_settings),
        ],
      ))),
    ));
    expect(find.text('Good food, brighter days'), findsOneWidget);
    expect(find.text('Your shift, your pace'), findsOneWidget);
    expect(find.text('Seller HQ'), findsOneWidget);
    expect(find.text('Command center'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Shared action component keeps a real callback', (tester) async {
    var selected = false;
    await tester.pumpWidget(MaterialApp(
      theme: AppTheme.light(),
      home: Scaffold(body: KDSActionTile(
        icon: Icons.receipt_long, title: 'View orders',
        subtitle: 'Manage current requests', onTap: () => selected = true,
      )),
    ));
    await tester.tap(find.text('View orders'));
    expect(selected, isTrue);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Shop cards keep their original Supabase-backed navigation callback', (tester) async {
    String? opened;
    await tester.pumpWidget(MaterialApp(
      theme: AppTheme.light(),
      home: Scaffold(body: Center(child: SizedBox(width: 174,
        child: FutureFoodStoreCard(
          store: const {'id': 'real-id-from-backend', 'name': 'Local Kitchen',
            'is_open': true, 'barangay': 'Camiling', 'logo_url': '', 'rating_count': 0},
          dishes: const [], onTap: () => opened = 'real-id-from-backend',
        ),
      ))),
    ));
    await tester.tap(find.text('Local Kitchen'));
    expect(opened, 'real-id-from-backend');
    expect(tester.takeException(), isNull);
  });
}
