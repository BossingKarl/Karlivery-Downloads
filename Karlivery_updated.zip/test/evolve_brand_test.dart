import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:karl_delivery/theme/app_theme.dart';

void main() {
  test('Karlivery warm brand palette stays consistent', () {
    expect(AppTheme.red, const Color(0xFFE51E32));
    expect(AppTheme.yellow, const Color(0xFFFFCC35));
    expect(AppTheme.ink, const Color(0xFF1C1C1E));
  });

  test('Shared theme extensions exist for both light and dark', () {
    expect(AppTheme.light().extension<KarliveryVisualTokens>(), isNotNull);
    expect(AppTheme.dark().extension<KarliveryVisualTokens>(), isNotNull);
  });
}
