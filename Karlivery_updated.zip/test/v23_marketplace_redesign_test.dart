import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:karl_delivery/core/future_food_ui.dart';
import 'package:karl_delivery/core/customer_discovery_hero.dart';
import 'package:karl_delivery/core/nova_headline.dart';
import 'package:karl_delivery/theme/app_theme.dart';

void main() {
  testWidgets('V23 two local shop cards render and keep their original taps', (tester) async {
    tester.view.physicalSize = const Size(390, 844);
    tester.view.devicePixelRatio = 1;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    String? selected;
    Widget shop(String id, String name) => FutureFoodStoreCard(
      store: {'id': id, 'name': name, 'is_open': true,
        'barangay': 'Camiling', 'logo_url': '', 'rating_count': 0},
      dishes: const [],
      onTap: () => selected = id,
    );
    await tester.pumpWidget(MaterialApp(theme: AppTheme.light(), home: Scaffold(
      body: SingleChildScrollView(child: Padding(
        padding: const EdgeInsets.all(17),
        child: Row(children: [
          Expanded(child: shop('shop-one', 'First Local Kitchen')),
          const SizedBox(width: 10),
          Expanded(child: shop('shop-two', 'Second Local Kitchen')),
        ]),
      )),
    )));
    expect(find.text('First Local Kitchen'), findsOneWidget);
    expect(find.text('Second Local Kitchen'), findsOneWidget);
    await tester.tap(find.text('Second Local Kitchen'));
    expect(selected, 'shop-two');
    expect(tester.takeException(), isNull);
  });

  testWidgets('V23 hero maintains original explore callback without live data', (tester) async {
    var called = 0;
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: Center(child:
      SizedBox(width: 370, child: KarliveryDiscoveryHero(
        storeCount: 0, onExplore: () => called++))))));
    await tester.tap(find.text('Order now'));
    await tester.pump();
    expect(called, 1);
    expect(tester.takeException(), isNull);
  });

  testWidgets('V23 seller and rider use distinct themed headers', (tester) async {
    await tester.pumpWidget(MaterialApp(theme: AppTheme.light(), home: Scaffold(
      body: SingleChildScrollView(child: Column(children: const [
        NovaHeadline(eyebrow: 'KARLIVERY / RIDER', title: 'Online rider',
          subtitle: 'Orders and earnings', icon: Icons.delivery_dining_rounded),
        NovaHeadline(eyebrow: 'YOUR STORE DASHBOARD', title: 'Seller HQ',
          subtitle: 'Manage your store', icon: Icons.storefront_rounded),
      ])),
    )));
    expect(find.text('Online rider'), findsOneWidget);
    expect(find.text('Seller HQ'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
