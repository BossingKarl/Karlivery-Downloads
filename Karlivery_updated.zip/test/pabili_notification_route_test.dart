import 'package:flutter_test/flutter_test.dart';
import 'package:karl_delivery/services/notification_service.dart';

void main() {
  test('Pabili push notifications route to Pabili screens, never regular orders', () {
    expect(NotificationService.routeForNotificationData({
      'screen': 'pabili_order',
      'pasabuy_order_id': 'PB-TEST',
      'order_type': 'pabili',
    }), '/pasabuy/order/PB-TEST');
    expect(NotificationService.routeForNotificationData({
      'screen': 'pabili_chat',
      'pasabuy_order_id': 'PB-TEST',
    }), '/pasabuy/chat/PB-TEST');
    expect(NotificationService.routeForNotificationData({
      'screen': 'pabili_tracking',
      'pasabuy_order_id': 'PB-TEST',
    }), '/pasabuy/track/PB-TEST');
  });

  test('Regular order deep links are unchanged', () {
    expect(NotificationService.routeForNotificationData({
      'screen': 'order', 'order_id': 'regular-1',
    }), '/order/regular-1');
  });
}
