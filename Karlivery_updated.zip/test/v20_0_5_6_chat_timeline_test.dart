import 'package:flutter_test/flutter_test.dart';
import 'package:karl_delivery/core/chat_timeline.dart';

void main() {
  test('Newest message is at index zero for bottom-anchored reverse chat', () {
    final rows = [
      {'id': 'old', 'created_at': '2026-10-11T01:00:00Z'},
      {'id': 'new', 'created_at': '2026-10-11T01:02:00Z'},
      {'id': 'mid', 'created_at': '2026-10-11T01:01:00Z'},
    ];
    expect(newestFirstChatMessages(rows).map((e) => e['id']),
        orderedEquals(['new', 'mid', 'old']));
  });

  test('Equal timestamps preserve most recently arrived message at bottom', () {
    final rows = [
      {'id': 'a', 'created_at': '2026-10-11T01:00:00Z'},
      {'id': 'b', 'created_at': '2026-10-11T01:00:00Z'},
    ];
    expect(newestFirstChatMessages(rows).first['id'], 'b');
  });
}
