import 'package:flutter_test/flutter_test.dart';
import 'package:karl_delivery/services/cart.dart';
import 'package:karl_delivery/services/pasabuy_cart.dart';

void main() {
  final cart = CartService.instance;
  final pabili = PasabuyCartService.instance;

  setUp(() {
    cart.clear();
    pabili.clear();
  });
  tearDown(() {
    cart.clear();
    pabili.clear();
  });

  test('Adding from another restaurant never silently deletes basket', () {
    final chicken = <String, dynamic>{'id': 'meal-1', 'name': 'Chicken meal', 'price': 135};
    final burger = <String, dynamic>{'id': 'meal-2', 'name': 'Burger', 'price': 115};

    cart.add(chicken, 'store-1', 'First Kitchen', quantity: 2);
    expect(cart.count, 2);
    expect(cart.subtotal, 270);

    expect(
      () => cart.add(burger, 'store-2', 'Second Kitchen'),
      throwsStateError,
    );
    expect(cart.storeId, 'store-1');
    expect(cart.count, 2);
    expect(cart.lines.single.product['id'], 'meal-1');
  });

  test('Confirmed reset allows a different restaurant basket', () {
    cart.add({'id': '1', 'price': 25}, 's1', 'A');
    cart.clear();
    cart.add({'id': '2', 'price': 40}, 's2', 'B');
    expect(cart.storeId, 's2');
    expect(cart.subtotal, 40);
  });

  test('Switching Pabili shop requires explicit basket reset', () {
    final a = <String, dynamic>{'id': 'shop-1', 'name': 'First shop'};
    final b = <String, dynamic>{'id': 'shop-2', 'name': 'Second shop'};
    pabili.setShop(a);
    pabili.setCustomRequest('2 rice meals');
    pabili.setCustomRequestAmount(250);
    expect(() => pabili.setShop(b), throwsStateError);
    expect(pabili.shopId, 'shop-1');
    expect(pabili.customRequest, '2 rice meals');
    expect(pabili.customRequestAmount, 250);
    pabili.clear();
    pabili.setShop(b);
    expect(pabili.shopId, 'shop-2');
  });
}
