import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:karl_delivery/core/future_food_ui.dart';

void main() {
  testWidgets('The new Food Edit opens the actual store ID', (tester) async {
    String? opened;
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: FutureFoodSpotlight(
      dishes: const [
        {'name': 'Sample dish', '_store_id': 'genuine-store-id', 'price': 88},
      ],
      onOpenStore: (id) => opened = id,
    ))));
    expect(find.text('What sounds delicious?'), findsOneWidget);
    await tester.tap(find.text('Sample dish'));
    expect(opened, 'genuine-store-id');
  });

  testWidgets('No featured data means no invented dishes', (tester) async {
    await tester.pumpWidget(MaterialApp(home: Scaffold(body:
      FutureFoodSpotlight(dishes: const [], onOpenStore: _noOp))));
    expect(find.text('What sounds delicious?'), findsNothing);
  });

  testWidgets('Future category choice has real callback', (tester) async {
    String? selected;
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: FutureFoodCategories(
      query: '', onSelect: (term) => selected = term))));
    await tester.tap(find.text('Burgers'));
    expect(selected, 'burger');
  });

  testWidgets('Future bottom nav preserves all five app tabs', (tester) async {
    int? tab;
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: const SizedBox(),
      bottomNavigationBar: FutureBottomBar(selected: 0,
        onTap: (value) => tab = value))));
    await tester.tap(find.text('Orders'));
    expect(tab, 1);
    expect(find.text('Home'), findsOneWidget);
    expect(find.text('Chats'), findsOneWidget);
  });
}

void _noOp(String id) {}
