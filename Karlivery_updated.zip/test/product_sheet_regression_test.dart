import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:karl_delivery/features/customer/product_detail_sheet.dart';
import 'package:karl_delivery/services/cart.dart';

void main() {
  setUp(CartService.instance.clear);
  tearDown(CartService.instance.clear);

  testWidgets('Product sheet keeps action available when browsing add-ons', (tester) async {
    final product = <String, dynamic>{
      'id': 'food-1',
      'name': 'Rice meal',
      'price': 120,
      'product_addons': [
        for (var i = 0; i < 18; i++)
          {'id': 'addon-$i', 'name': 'Extra $i', 'price': 10, 'is_available': true},
      ],
    };
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: Builder(builder: (context) => FilledButton(
          onPressed: () => showKarliveryProductSheet(
            context,
            product: product,
            storeId: 'store-1',
            storeName: 'Restaurant',
            storeOpen: true,
          ),
          child: const Text('Open meal'),
        )),
      ),
    ));
    await tester.tap(find.text('Open meal'));
    await tester.pumpAndSettle();
    expect(find.textContaining('Add 1 to basket'), findsOneWidget);
    await tester.drag(find.byType(SingleChildScrollView).last, const Offset(0, -550));
    await tester.pumpAndSettle();
    expect(find.textContaining('Add 1 to basket'), findsOneWidget);
  });

  testWidgets('Cross-store basket change can be cancelled', (tester) async {
    final cart = CartService.instance;
    cart.add({'id': 'a', 'name': 'Original', 'price': 50}, 'store-a', 'Original shop');
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: Builder(
      builder: (context) => FilledButton(
        onPressed: () => showKarliveryProductSheet(
          context,
          product: {'id': 'b', 'name': 'Other dish', 'price': 90},
          storeId: 'store-b',
          storeName: 'New shop',
          storeOpen: true,
        ),
        child: const Text('Add food'),
      ),
    ))));
    await tester.tap(find.text('Add food'));
    await tester.pumpAndSettle();
    await tester.tap(find.textContaining('Add 1 to basket'));
    await tester.pumpAndSettle();
    expect(find.text('Start a new restaurant basket?'), findsOneWidget);
    await tester.tap(find.text('Keep current basket'));
    await tester.pumpAndSettle();
    expect(cart.storeId, 'store-a');
    expect(cart.lines.single.product['id'], 'a');
  });
}
