import 'package:flutter_test/flutter_test.dart';
import 'package:karl_delivery/services/pasabuy_service.dart';

void main() {
  test('GPS quote distance is a saved server value, not locally invented', () {
    expect(PasabuyService.quoteDistanceKm({'delivery_distance_km': 0}), 0);
    expect(PasabuyService.quoteDistanceKm({'delivery_distance_km': '4.23'}), 4.23);
    expect(PasabuyService.quoteDistanceKm({'delivery_distance_km': 12.5}), 12.5);
  });

  test('Missing or invalid straight-line distance stays unavailable', () {
    for (final invalid in [null, '', 'invalid', -1, 'NaN', 'Infinity']) {
      expect(PasabuyService.quoteDistanceKm({'delivery_distance_km': invalid}), isNull);
    }
    expect(PasabuyService.quoteDistanceKm({}), isNull);
  });

  test('Admin-selected server fee is never recalculated from guessed kilometers', () {
    // The same kilometers may have different fees when the admin updates rates.
    final oldQuote = {'delivery_fee': 65, 'delivery_distance_km': 4.2};
    final newQuote = {'delivery_fee': 80, 'delivery_distance_km': 4.2};
    expect(PasabuyService.quoteDistanceKm(oldQuote), PasabuyService.quoteDistanceKm(newQuote));
    expect(PasabuyService.quoteDeliveryFee(oldQuote), 65);
    expect(PasabuyService.quoteDeliveryFee(newQuote), 80);
  });
}
