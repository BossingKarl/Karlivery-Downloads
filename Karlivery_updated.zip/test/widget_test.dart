import 'package:flutter_test/flutter_test.dart';
import 'package:karl_delivery/main.dart';

void main() {
  test('KarliveryApp is available as the application entry widget', () {
    const app = KarliveryApp();
    expect(app, isA<KarliveryApp>());
  });
}
