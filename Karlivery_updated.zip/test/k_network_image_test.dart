import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:karl_delivery/design_system/k_network_image.dart';

void main() {
  testWidgets('skeleton and shimmer render without layout errors', (tester) async {
    await tester.pumpWidget(const MaterialApp(
      home: Scaffold(
        body: Padding(
          padding: EdgeInsets.all(16),
          child: SizedBox(width: 180, child: KStoreCardSkeleton()),
        ),
      ),
    ));
    await tester.pump(const Duration(milliseconds: 400));
    expect(find.byType(KShimmer), findsWidgets);
    expect(tester.takeException(), isNull);
  });
}
