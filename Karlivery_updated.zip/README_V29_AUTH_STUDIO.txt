KARLIVERY V29 AUTH STUDIO — ACTUAL FLUTTER REDESIGN

Modified actual runtime widgets:
lib/features/auth/auth_studio.dart (new responsive editorial shell, form card, fields, buttons)
lib/features/auth/login_screen.dart (new shell and card; backend login untouched)
lib/features/auth/register_screen.dart (new shell and card; backend register/validation untouched)

Preserved Supabase auth, role routing, verification, password reset, browse, help, and notification calls.

BUILD: run BUILD_KARLIVERY_V24_WEB_ONLY.cmd in extracted folder. Upload only the generated build/Karlivery-V24-Cloudflare-Web.zip to Cloudflare Pages.

IMPORTANT: Flutter SDK unavailable in packaging environment; run flutter analyze, flutter test, flutter build web --release on your PC. ZIP integrity verified, NOT a claim of compilation success.
